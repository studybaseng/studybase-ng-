// StudyBase NG - Clean Version
// All practice questions = FREE
// Payment only for Live Classes

let currentUser = null;
let currentProfile = null;
let currentSubjectId = null;
let currentSubjectName = '';
let currentQuestions = [];
let currentIndex = 0;
let selectedOption = null;
let score = 0;
let mode = 'practice';
let timerInterval = null;
let timeLeft = 0;
let allQuestionsForSubject = [];

// ========== AUTH ==========
async function checkAuth() {
  let tries = 0;
  while (!window.supabaseClient && tries < 40) {
    await new Promise(r => setTimeout(r, 100));
    tries++;
  }
  if (!window.supabaseClient) {
    showScreen('auth-screen');
    return;
  }

  const { data: { session } } = await window.supabaseClient.auth.getSession();
  if (session) {
    currentUser = session.user;
    await loadProfile();
    showMainApp();
  } else {
    showScreen('auth-screen');
    document.getElementById('bottom-nav')?.classList.add('hidden');
  }
}

async function loadProfile() {
  const { data } = await window.supabaseClient
    .from('profiles')
    .select('*')
    .eq('id', currentUser.id)
    .single();

  if (data) {
    currentProfile = data;
  } else {
    const name = localStorage.getItem('pending_name') || '';
    const phone = localStorage.getItem('pending_phone') || '';
    const role = localStorage.getItem('pending_role') || 'student';

    await window.supabaseClient.from('profiles').insert({
      id: currentUser.id,
      full_name: name,
      email: currentUser.email,
      phone: phone,
      role: role
    });

    localStorage.removeItem('pending_name');
    localStorage.removeItem('pending_phone');
    localStorage.removeItem('pending_role');

    const { data: newP } = await window.supabaseClient
      .from('profiles')
      .select('*')
      .eq('id', currentUser.id)
      .single();
    currentProfile = newP;
  }
}

function showLogin() {
  document.getElementById('signup-card').classList.add('hidden');
  document.getElementById('login-card').classList.remove('hidden');
}

function showSignup() {
  document.getElementById('login-card').classList.add('hidden');
  document.getElementById('signup-card').classList.remove('hidden');
}

async function handleSignup() {
  const name = document.getElementById('signup-name').value.trim();
  const email = document.getElementById('signup-email').value.trim();
  const phone = document.getElementById('signup-phone').value.trim();
  const password = document.getElementById('signup-password').value;
  const role = document.querySelector('input[name="role"]:checked')?.value || 'student';

  if (!name || !email || !password) {
    alert('Please fill Name, Email and Password');
    return;
  }
  if (password.length < 6) {
    alert('Password must be at least 6 characters');
    return;
  }

  localStorage.setItem('pending_name', name);
  localStorage.setItem('pending_phone', phone);
  localStorage.setItem('pending_role', role);

  // Sign up
  const { data, error } = await window.supabaseClient.auth.signUp({ email, password });
  if (error) {
    alert('Error: ' + error.message);
    return;
  }

  // Immediately try to log in so user does not have to login again
  const { data: loginData, error: loginError } = await window.supabaseClient.auth.signInWithPassword({
    email: email,
    password: password
  });

  if (loginError) {
    alert('Account created successfully!\n\nPlease login with the same email and password.');
    showLogin();
    document.getElementById('login-email').value = email;
    return;
  }

  // Success - user is logged in
  currentUser = loginData.user;
  await loadProfile();
  alert('Account created and you are now logged in!');
  showMainApp();
}

async function handleLogin() {
  const email = document.getElementById('login-email').value.trim();
  const password = document.getElementById('login-password').value;

  if (!email || !password) {
    alert('Enter email and password');
    return;
  }

  const { data, error } = await window.supabaseClient.auth.signInWithPassword({ email, password });
  if (error) {
    let msg = error.message;
    if (msg.toLowerCase().includes('invalid') || msg.toLowerCase().includes('credentials')) {
      msg = 'Incorrect email or password.\n\nPlease check carefully and try again.\nMake sure there is no extra space.';
    }
    alert('Login failed: ' + msg);
    return;
  }

  currentUser = data.user;
  await loadProfile();
  showMainApp();
}

async function handleForgotPassword() {
  const email = document.getElementById('login-email').value.trim();
  if (!email) {
    alert('Please enter your email address first');
    return;
  }
  const { error } = await window.supabaseClient.auth.resetPasswordForEmail(email, {
    redirectTo: window.location.origin
  });
  if (error) {
    alert('Error: ' + error.message);
  } else {
    alert('Password reset link has been sent to your email.\n\nPlease check your inbox (and spam folder).');
  }
}

function showMainApp() {
  document.getElementById('bottom-nav')?.classList.remove('hidden');
  const name = currentProfile?.full_name || currentUser?.email || 'Student';
  document.getElementById('welcome-user').textContent = `Hi, ${name} 👋`;
  showScreen('home-screen');
  buildCBTLists();
  setTimeout(checkForSavedQuiz, 400);
}

// ========== NAVIGATION ==========
function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  const el = document.getElementById(id);
  if (el) el.classList.add('active');

  const navs = document.querySelectorAll('.nav-item');
  navs.forEach(n => n.classList.remove('active'));
  if (id === 'home-screen') navs[0]?.classList.add('active');
  if (id === 'cbt-screen') navs[1]?.classList.add('active');
  if (id === 'progress-screen') { navs[2]?.classList.add('active'); loadProgress(); }
  if (id === 'classes-screen') { navs[3]?.classList.add('active'); loadMyClasses(); }
}

function showPremium() {
  showScreen('premium-screen');
}

// ========== SUBJECTS (ALL FREE) ==========
function showSubjects(type) {
  const title = type === 'jamb' ? 'JAMB Subjects' : '100 Level Courses';
  const subjects = type === 'jamb' ? jambSubjects : level100Courses;

  document.getElementById('subjects-title').textContent = title;
  const list = document.getElementById('subjects-list');
  list.innerHTML = '';

  subjects.forEach(sub => {
    const count = (sampleQuestions[sub.id] || []).length;
    const btn = document.createElement('button');
    btn.className = 'subject-card';
    btn.innerHTML = `
      <span class="emoji">${sub.icon}</span>
      <div style="flex:1">
        <strong>${sub.name}</strong>
        <small style="display:block;color:#64748B;font-size:12px;margin-top:2px">${count} questions (Free)</small>
      </div>
      <span class="arrow">›</span>
    `;
    btn.onclick = () => askQuestionCount(sub.id, sub.name, 'practice');
    list.appendChild(btn);
  });
  showScreen('subjects-screen');
}

function askQuestionCount(subjectId, subjectName, quizMode) {
  allQuestionsForSubject = sampleQuestions[subjectId] || [];
  if (allQuestionsForSubject.length === 0) {
    alert('No questions available for this subject yet.');
    return;
  }

  const max = allQuestionsForSubject.length;
  const choices = [10, 20, 30, 50].filter(n => n <= max);
  if (max > 50 && !choices.includes(max)) choices.push(max);

  let msg = `How many questions for ${subjectName}?\n\nAvailable: ${max} (All Free)\n\n`;
  choices.forEach((n, i) => msg += `${i + 1}. ${n} questions\n`);
  msg += `\nEnter a number:`;

  const answer = prompt(msg);
  if (!answer) return;

  let num = parseInt(answer);
  if (num >= 1 && num <= choices.length) num = choices[num - 1];
  if (isNaN(num) || num < 1) {
    alert('Invalid number');
    return;
  }
  num = Math.min(num, max);
  startQuiz(subjectId, subjectName, quizMode, num);
}

function buildCBTLists() {
  const jambList = document.getElementById('cbt-jamb-list');
  const levelList = document.getElementById('cbt-100l-list');
  if (!jambList || !levelList) return;

  jambList.innerHTML = '';
  levelList.innerHTML = '';

  jambSubjects.forEach(sub => {
    const count = (sampleQuestions[sub.id] || []).length;
    const btn = document.createElement('button');
    btn.className = 'subject-card';
    btn.innerHTML = `
      <span class="emoji">${sub.icon}</span>
      <div style="flex:1">
        <strong>${sub.name}</strong>
        <small style="display:block;color:#64748B;font-size:12px">${count} questions</small>
      </div>
      <span class="arrow" style="color:#3B82F6">Start ›</span>
    `;
    btn.onclick = () => askQuestionCount(sub.id, sub.name, 'cbt');
    jambList.appendChild(btn);
  });

  level100Courses.forEach(sub => {
    const count = (sampleQuestions[sub.id] || []).length;
    const btn = document.createElement('button');
    btn.className = 'subject-card';
    btn.innerHTML = `
      <span class="emoji">${sub.icon}</span>
      <div style="flex:1">
        <strong>${sub.name}</strong>
        <small style="display:block;color:#64748B;font-size:12px">${count} questions</small>
      </div>
      <span class="arrow" style="color:#3B82F6">Start ›</span>
    `;
    btn.onclick = () => askQuestionCount(sub.id, sub.name, 'cbt');
    levelList.appendChild(btn);
  });
}

// ========== QUIZ ==========
function startQuiz(subjectId, subjectName, quizMode, numQuestions) {
  currentSubjectId = subjectId;
  currentSubjectName = subjectName;
  const shuffled = [...allQuestionsForSubject].sort(() => Math.random() - 0.5);
  currentQuestions = shuffled.slice(0, numQuestions);
  currentIndex = 0;
  selectedOption = null;
  score = 0;
  mode = quizMode;

  if (mode === 'cbt') {
    timeLeft = currentQuestions.length * 45;
    startTimer();
    document.getElementById('quiz-timer').classList.remove('hidden');
  } else {
    document.getElementById('quiz-timer').classList.add('hidden');
    clearInterval(timerInterval);
  }

  showScreen('quiz-screen');
  renderQuestion();
}

function renderQuestion() {
  const q = currentQuestions[currentIndex];
  document.getElementById('quiz-subject').textContent = currentSubjectName;
  document.getElementById('quiz-question').textContent = q.question;
  document.getElementById('quiz-progress').textContent = `Question ${currentIndex + 1} of ${currentQuestions.length}`;
  document.getElementById('progress-fill').style.width = `${((currentIndex + 1) / currentQuestions.length) * 100}%`;

  const container = document.getElementById('options-container');
  container.innerHTML = '';
  document.getElementById('explanation-box').classList.add('hidden');
  document.getElementById('quiz-footer').classList.add('hidden');
  selectedOption = null;

  q.options.forEach((opt, i) => {
    const div = document.createElement('div');
    div.className = 'option';
    div.innerHTML = `<div class="letter">${String.fromCharCode(65 + i)}</div><span>${opt}</span>`;
    div.onclick = () => selectOption(i);
    container.appendChild(div);
  });
}

function selectOption(index) {
  if (selectedOption !== null) return;
  selectedOption = index;
  const q = currentQuestions[currentIndex];
  const options = document.querySelectorAll('.option');

  options.forEach((opt, i) => {
    if (i === q.correct) opt.classList.add('correct');
    else if (i === index) opt.classList.add('wrong');
  });

  const box = document.getElementById('explanation-box');
  box.classList.remove('hidden');
  box.innerHTML = `
    <strong>${index === q.correct ? '✅ Correct!' : '❌ Wrong'}</strong>
    <p style="margin-top:6px;font-size:13px;line-height:1.4">${q.explanation || ''}</p>
  `;

  if (index === q.correct) score++;
  document.getElementById('quiz-footer').classList.remove('hidden');
  document.getElementById('next-btn').textContent =
    currentIndex + 1 === currentQuestions.length ? 'Finish' : 'Next Question';
  saveQuizState();
}

function nextQuestion() {
  if (currentIndex + 1 < currentQuestions.length) {
    currentIndex++;
    selectedOption = null;
    saveQuizState();
    renderQuestion();
  } else {
    finishQuiz();
  }
}

function finishQuiz() {
  clearInterval(timerInterval);
  clearQuizState();
  document.getElementById('final-score').textContent = `${score} / ${currentQuestions.length}`;
  const percent = Math.round((score / currentQuestions.length) * 100);
  document.getElementById('final-percent').textContent = percent + '%';
  document.getElementById('result-subject').textContent = currentSubjectName;
  saveProgress(currentSubjectName, percent);
  showScreen('result-screen');
}

function restartQuiz() {
  askQuestionCount(currentSubjectId, currentSubjectName, mode);
}

function exitQuiz() {
  if (confirm('Exit this quiz?\n\nYou can continue later if you leave by mistake.')) {
    clearInterval(timerInterval);
    // Keep the saved state so they can resume
    showScreen('home-screen');
  }
}

function startTimer() {
  clearInterval(timerInterval);
  updateTimerDisplay();
  timerInterval = setInterval(() => {
    timeLeft--;
    updateTimerDisplay();
    if (timeLeft <= 0) {
      clearInterval(timerInterval);
      finishQuiz();
    }
  }, 1000);
}

function updateTimerDisplay() {
  const m = Math.floor(timeLeft / 60);
  const s = timeLeft % 60;
  const el = document.getElementById('quiz-timer');
  el.textContent = `⏱ ${m}:${s < 10 ? '0' : ''}${s}`;
  el.classList.toggle('danger', timeLeft < 30);
}

// ========== PROGRESS ==========
function saveProgress(subject, percent) {
  let data = JSON.parse(localStorage.getItem('studybase_progress') || '{}');
  if (!data[subject]) data[subject] = { attempts: 0, total: 0 };
  data[subject].attempts += 1;
  data[subject].total += percent;
  localStorage.setItem('studybase_progress', JSON.stringify(data));
}

function loadProgress() {
  const data = JSON.parse(localStorage.getItem('studybase_progress') || '{}');
  const list = document.getElementById('progress-list');
  list.innerHTML = '';

  let totalAttempts = 0, totalScore = 0, count = 0;
  const subjects = Object.keys(data);

  if (subjects.length === 0) {
    list.innerHTML = '<p style="color:#64748B;text-align:center;padding:20px">No quizzes taken yet. Start practicing!</p>';
    document.getElementById('total-quizzes').textContent = '0';
    document.getElementById('avg-score').textContent = '0%';
    return;
  }

  subjects.forEach(sub => {
    const avg = Math.round(data[sub].total / data[sub].attempts);
    totalAttempts += data[sub].attempts;
    totalScore += avg;
    count++;
    const div = document.createElement('div');
    div.className = 'progress-item';
    div.innerHTML = `
      <div class="info">
        <strong>${sub}</strong>
        <small>${data[sub].attempts} quiz${data[sub].attempts > 1 ? 'zes' : ''}</small>
      </div>
      <div class="score-circle">${avg}%</div>
    `;
    list.appendChild(div);
  });

  document.getElementById('total-quizzes').textContent = totalAttempts;
  document.getElementById('avg-score').textContent = Math.round(totalScore / count) + '%';
}

// ========== CLASSES (PAID) ==========
async function loadMyClasses() {
  const container = document.getElementById('my-classes');
  if (!container) return;
  container.innerHTML = '<p style="color:#64748B;text-align:center">Loading...</p>';

  try {
    const { data: teacherClasses } = await window.supabaseClient
      .from('classes')
      .select('id, name, subject')
      .eq('teacher_id', currentUser.id);

    const { data: memberRows } = await window.supabaseClient
      .from('class_members')
      .select('class_id, classes(id, name, subject)')
      .eq('student_id', currentUser.id);

    let html = '';

    if (teacherClasses && teacherClasses.length > 0) {
      html += '<p style="font-weight:600;margin-bottom:8px">My Classes (Teacher)</p>';
      for (const cls of teacherClasses) {
        const today = new Date().toISOString().split('T')[0];
        const { data: codes } = await window.supabaseClient
          .from('class_codes')
          .select('code')
          .eq('class_id', cls.id)
          .eq('valid_date', today)
          .limit(1);

        const codeText = codes && codes.length ? codes[0].code : 'No code yet';
        html += `
          <div class="class-card" style="margin-bottom:10px">
            <strong>${cls.name}</strong>
            <small style="display:block;margin-top:4px">Today's Code: <b style="color:#1E40AF;font-size:16px">${codeText}</b></small>
            <button onclick="generateTodayCode('${cls.id}')" style="margin-top:8px;padding:8px 12px;background:#1E40AF;color:white;border:none;border-radius:8px;font-size:13px">
              Generate / Refresh Code
            </button>
          </div>`;
      }
    }

    if (memberRows && memberRows.length > 0) {
      html += '<p style="font-weight:600;margin:16px 0 8px">Joined Classes</p>';
      memberRows.forEach(row => {
        if (row.classes) {
          html += `<div class="class-card"><strong>${row.classes.name}</strong>
            <small style="display:block;margin-top:2px">${row.classes.subject || ''}</small></div>`;
        }
      });
    }

    if (!html) {
      html = '<p style="color:#64748B;text-align:center;padding:16px">No classes yet.<br>Teachers create classes. Students join with a code.</p>';
    }
    container.innerHTML = html;
  } catch (e) {
    console.error(e);
    container.innerHTML = '<p style="color:#ef4444;text-align:center">Error loading classes</p>';
  }
}

async function createClass() {
  if (!currentProfile) {
    alert('Please login first');
    return;
  }
  if (currentProfile.role !== 'teacher' || !currentProfile.is_premium) {
    alert('Only premium teachers can create classes.\nPlease subscribe as a Teacher (₦15,000).');
    showPremium();
    return;
  }

  const name = prompt('Enter Class Name (e.g. JAMB Science 2026):');
  if (!name || !name.trim()) return;
  const subject = prompt('Enter Subject (optional):') || '';

  try {
    const { data, error } = await window.supabaseClient
      .from('classes')
      .insert({ teacher_id: currentUser.id, name: name.trim(), subject: subject.trim() })
      .select()
      .single();

    if (error) {
      alert('Error: ' + error.message);
      return;
    }
    await generateTodayCode(data.id);
    alert('Class created successfully!');
    loadMyClasses();
  } catch (e) {
    alert('Error creating class');
  }
}

async function generateTodayCode(classId) {
  const today = new Date().toISOString().split('T')[0];
  const code = 'SB' + Math.random().toString(36).substring(2, 8).toUpperCase();

  try {
    await window.supabaseClient.from('class_codes').delete().eq('class_id', classId).eq('valid_date', today);
    const { error } = await window.supabaseClient.from('class_codes').insert({
      class_id: classId, code, valid_date: today
    });
    if (error) {
      alert('Error generating code: ' + error.message);
      return;
    }
    alert("Today's code is: " + code + "\n\nShare it with your students. It expires tomorrow.");
    loadMyClasses();
  } catch (e) {
    alert('Error generating code');
  }
}

async function joinClass() {
  const code = document.getElementById('invite-code').value.trim().toUpperCase();
  if (!code) {
    alert('Please enter an invite code');
    return;
  }

  if (!currentProfile || !currentProfile.is_premium) {
    alert('Only premium students can join classes.\nPlease subscribe first (₦3,500).');
    showPremium();
    return;
  }

  try {
    const today = new Date().toISOString().split('T')[0];
    const { data: codeRows } = await window.supabaseClient
      .from('class_codes')
      .select('class_id')
      .eq('code', code)
      .eq('valid_date', today)
      .limit(1);

    if (!codeRows || codeRows.length === 0) {
      alert('Invalid or expired code. Codes are valid only for today.');
      return;
    }

    const classId = codeRows[0].class_id;
    const { count } = await window.supabaseClient
      .from('class_members')
      .select('*', { count: 'exact', head: true })
      .eq('class_id', classId);

    if (count >= 20) {
      alert('This class is full (maximum 20 students).');
      return;
    }

    const { error } = await window.supabaseClient
      .from('class_members')
      .insert({ class_id: classId, student_id: currentUser.id });

    if (error) {
      if (error.code === '23505') alert('You have already joined this class.');
      else alert('Error: ' + error.message);
      return;
    }

    alert('Successfully joined the class!');
    document.getElementById('invite-code').value = '';
    loadMyClasses();
  } catch (e) {
    alert('Error joining class');
  }
}

// ========== PAYSTACK ==========
function startPayment(plan) {
  if (!currentUser) {
    alert('Please login first');
    return;
  }

  const amount = plan === 'teacher' ? 1500000 : 350000; // kobo
  const handler = PaystackPop.setup({
    key: 'pk_live_49822843a0842f4555b089e4045fadd9b0de8291',
    email: currentUser.email,
    amount: amount,
    currency: 'NGN',
    ref: 'SB_' + plan + '_' + Date.now(),
    metadata: { user_id: currentUser.id, plan: plan },
    callback: function(response) {
      alert('Payment successful! Reference: ' + response.reference);
      activatePremium(plan, response.reference);
    },
    onClose: function() {
      alert('Payment window closed.');
    }
  });
  handler.openIframe();
}

async function activatePremium(plan, reference) {
  try {
    const until = new Date();
    until.setMonth(until.getMonth() + 1);

    await window.supabaseClient
      .from('profiles')
      .update({
        is_premium: true,
        premium_until: until.toISOString(),
        role: plan === 'teacher' ? 'teacher' : 'student'
      })
      .eq('id', currentUser.id);

    await window.supabaseClient.from('payments').insert({
      user_id: currentUser.id,
      amount: plan === 'teacher' ? 15000 : 3500,
      currency: 'NGN',
      paystack_reference: reference,
      status: 'success',
      plan: plan === 'teacher' ? 'teacher_monthly' : 'student_monthly'
    });

    alert('🎉 Premium activated! You now have access to Live Classes for 1 month.');
    await loadProfile();
    showScreen('home-screen');
  } catch (e) {
    alert('Payment received but activation failed. Contact support with reference: ' + reference);
  }
}


// ========== QUIZ RESUME ==========
function saveQuizState() {
  if (!currentQuestions || currentQuestions.length === 0) return;
  const state = {
    subjectId: currentSubjectId,
    subjectName: currentSubjectName,
    questions: currentQuestions,
    index: currentIndex,
    score: score,
    mode: mode,
    timeLeft: timeLeft,
    selectedOption: selectedOption
  };
  localStorage.setItem('studybase_quiz_state', JSON.stringify(state));
}

function clearQuizState() {
  localStorage.removeItem('studybase_quiz_state');
}

function hasSavedQuiz() {
  return !!localStorage.getItem('studybase_quiz_state');
}

function resumeQuiz() {
  const raw = localStorage.getItem('studybase_quiz_state');
  if (!raw) return false;

  try {
    const state = JSON.parse(raw);
    currentSubjectId = state.subjectId;
    currentSubjectName = state.subjectName;
    currentQuestions = state.questions;
    currentIndex = state.index;
    score = state.score;
    mode = state.mode;
    timeLeft = state.timeLeft || 0;
    selectedOption = null; // reset selection so they can re-answer current question if needed

    if (mode === 'cbt' && timeLeft > 0) {
      startTimer();
      document.getElementById('quiz-timer').classList.remove('hidden');
    } else {
      document.getElementById('quiz-timer').classList.add('hidden');
      clearInterval(timerInterval);
    }

    showScreen('quiz-screen');
    renderQuestion();
    return true;
  } catch (e) {
    clearQuizState();
    return false;
  }
}

function checkForSavedQuiz() {
  if (hasSavedQuiz()) {
    const resume = confirm('You have an unfinished quiz.\n\nDo you want to continue from where you stopped?');
    if (resume) {
      resumeQuiz();
    } else {
      clearQuizState();
    }
  }
}


// ========== INIT ==========
document.addEventListener('DOMContentLoaded', () => {
  checkAuth();
});
