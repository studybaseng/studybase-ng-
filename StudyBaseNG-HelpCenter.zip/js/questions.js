// StudyBase NG - Complete Question Bank
// All questions are FREE. Only live classes require payment.

const allSubjects = [
  {
    "id": "mth",
    "name": "Mathematics",
    "icon": "\ud83d\udd22",
    "field": "science",
    "count": 200
  },
  {
    "id": "phy",
    "name": "Physics",
    "icon": "\u269b\ufe0f",
    "field": "science",
    "count": 200
  },
  {
    "id": "chm",
    "name": "Chemistry",
    "icon": "\ud83e\uddea",
    "field": "science",
    "count": 200
  },
  {
    "id": "bio",
    "name": "Biology",
    "icon": "\ud83e\uddec",
    "field": "science",
    "count": 200
  },
  {
    "id": "agr",
    "name": "Agricultural Science",
    "icon": "\ud83c\udf3e",
    "field": "science",
    "count": 200
  },
  {
    "id": "geo",
    "name": "Geography",
    "icon": "\ud83c\udf0d",
    "field": "science",
    "count": 200
  },
  {
    "id": "eng",
    "name": "Use of English",
    "icon": "\ud83d\udcd8",
    "field": "all",
    "count": 200
  },
  {
    "id": "eco",
    "name": "Economics",
    "icon": "\ud83d\udcc8",
    "field": "commercial",
    "count": 201
  },
  {
    "id": "com",
    "name": "Commerce",
    "icon": "\ud83d\uded2",
    "field": "commercial",
    "count": 196
  },
  {
    "id": "acc",
    "name": "Accounting",
    "icon": "\ud83d\udcd2",
    "field": "commercial",
    "count": 201
  },
  {
    "id": "gov",
    "name": "Government",
    "icon": "\ud83c\udfdb\ufe0f",
    "field": "commercial",
    "count": 207
  },
  {
    "id": "lit",
    "name": "Literature in English",
    "icon": "\ud83d\udcd6",
    "field": "arts",
    "count": 200
  },
  {
    "id": "crs",
    "name": "Christian Religious Studies",
    "icon": "\u271d\ufe0f",
    "field": "arts",
    "count": 200
  },
  {
    "id": "irs",
    "name": "Islamic Religious Studies",
    "icon": "\u262a\ufe0f",
    "field": "arts",
    "count": 200
  },
  {
    "id": "his",
    "name": "History",
    "icon": "\ud83d\udcdc",
    "field": "arts",
    "count": 200
  }
];

const sampleQuestions = {
  "mth": [
    {
      "question": "Simplify: 2x + 5x - 3x",
      "options": [
        "3x",
        "5x",
        "10x",
        "4x"
      ],
      "correct": 3,
      "explanation": "2x + 5x - 3x = (2+5-3)x = 4x"
    },
    {
      "question": "What is 15% of 240?",
      "options": [
        "48",
        "30",
        "36",
        "24"
      ],
      "correct": 2,
      "explanation": "15% of 240 = 0.15 × 240 = 36"
    },
    {
      "question": "Solve for x: 3x - 7 = 14",
      "options": [
        "7",
        "3",
        "5",
        "9"
      ],
      "correct": 0,
      "explanation": "3x = 21 → x = 7"
    },
    {
      "question": "The LCM of 12 and 18 is?",
      "options": [
        "6",
        "72",
        "54",
        "36"
      ],
      "correct": 3,
      "explanation": "LCM of 12 and 18 is 36"
    },
    {
      "question": "If a = 3 and b = 4, find a² + b²",
      "options": [
        "25",
        "49",
        "7",
        "12"
      ],
      "correct": 0,
      "explanation": "9 + 16 = 25"
    },
    {
      "question": "Convert 0.125 to a fraction",
      "options": [
        "1/5",
        "1/4",
        "1/8",
        "1/6"
      ],
      "correct": 2,
      "explanation": "0.125 = 125/1000 = 1/8"
    },
    {
      "question": "Find the mean of 4, 8, 6, 10, 12",
      "options": [
        "8",
        "9",
        "6",
        "10"
      ],
      "correct": 0,
      "explanation": "(4+8+6+10+12)/5 = 40/5 = 8"
    },
    {
      "question": "Simplify: (2³)²",
      "options": [
        "32",
        "64",
        "8",
        "16"
      ],
      "correct": 1,
      "explanation": "2^6 = 64"
    },
    {
      "question": "What is the square root of 169?",
      "options": [
        "13",
        "14",
        "11",
        "12"
      ],
      "correct": 0,
      "explanation": "13 × 13 = 169"
    },
    {
      "question": "Solve: x/5 = 4",
      "options": [
        "1",
        "15",
        "9",
        "20"
      ],
      "correct": 3,
      "explanation": "x = 4 × 5 = 20"
    },
    {
      "question": "The area of a rectangle with length 8cm and width 5cm is?",
      "options": [
        "26 cm²",
        "40 cm²",
        "13 cm²",
        "35 cm²"
      ],
      "correct": 1,
      "explanation": "Area = l × w = 8 × 5 = 40"
    },
    {
      "question": "If 2x + 3 = 11, then x = ?",
      "options": [
        "4",
        "7",
        "5",
        "3"
      ],
      "correct": 0,
      "explanation": "2x = 8 → x = 4"
    },
    {
      "question": "What is 7²?",
      "options": [
        "56",
        "49",
        "42",
        "14"
      ],
      "correct": 1,
      "explanation": "7 × 7 = 49"
    },
    {
      "question": "Find the mode of 2, 3, 3, 5, 7, 3, 8",
      "options": [
        "5",
        "7",
        "2",
        "3"
      ],
      "correct": 3,
      "explanation": "3 appears most frequently"
    },
    {
      "question": "Simplify: 5/6 + 1/6",
      "options": [
        "5/12",
        "4/6",
        "1",
        "6/6"
      ],
      "correct": 2,
      "explanation": "5/6 + 1/6 = 6/6 = 1"
    },
    {
      "question": "The perimeter of a square of side 9cm is?",
      "options": [
        "18 cm",
        "81 cm",
        "36 cm",
        "27 cm"
      ],
      "correct": 2,
      "explanation": "Perimeter = 4 × side = 36 cm"
    },
    {
      "question": "Solve: 4x = 28",
      "options": [
        "8",
        "6",
        "5",
        "7"
      ],
      "correct": 3,
      "explanation": "x = 28/4 = 7"
    },
    {
      "question": "What is the value of π (approximately)?",
      "options": [
        "2.14",
        "4.13",
        "3.41",
        "3.14"
      ],
      "correct": 3,
      "explanation": "π ≈ 3.1416... commonly taken as 3.14"
    },
    {
      "question": "Factorize: x² - 16",
      "options": [
        "(x-4)²",
        "(x-4)(x+4)",
        "(x-8)(x+2)",
        "(x+4)²"
      ],
      "correct": 1,
      "explanation": "Difference of squares: a² - b² = (a-b)(a+b)"
    },
    {
      "question": "If y = 3x + 2 and x = 4, find y",
      "options": [
        "16",
        "12",
        "10",
        "14"
      ],
      "correct": 3,
      "explanation": "y = 3(4) + 2 = 14"
    },
    {
      "question": "The HCF of 24 and 36 is?",
      "options": [
        "12",
        "8",
        "18",
        "6"
      ],
      "correct": 0,
      "explanation": "Highest common factor of 24 and 36 is 12"
    },
    {
      "question": "Convert 3/4 to percentage",
      "options": [
        "25%",
        "75%",
        "50%",
        "60%"
      ],
      "correct": 1,
      "explanation": "3/4 = 0.75 = 75%"
    },
    {
      "question": "What is 9 × 8?",
      "options": [
        "81",
        "72",
        "70",
        "64"
      ],
      "correct": 1,
      "explanation": "9 × 8 = 72"
    },
    {
      "question": "Solve: 2(x + 3) = 14",
      "options": [
        "3",
        "4",
        "7",
        "5"
      ],
      "correct": 1,
      "explanation": "x + 3 = 7 → x = 4"
    },
    {
      "question": "The volume of a cube of side 3cm is?",
      "options": [
        "18 cm³",
        "9 cm³",
        "27 cm³",
        "12 cm³"
      ],
      "correct": 2,
      "explanation": "Volume = side³ = 27"
    },
    {
      "question": "If 5x = 45, what is the value of x?",
      "options": [
        "10",
        "9",
        "7",
        "8"
      ],
      "correct": 1,
      "explanation": "x = 45 ÷ 5 = 9"
    },
    {
      "question": "What is the next prime number after 7?",
      "options": [
        "11",
        "10",
        "8",
        "9"
      ],
      "correct": 0,
      "explanation": "The next prime after 7 is 11"
    },
    {
      "question": "Simplify: 12 ÷ 3 × 2",
      "options": [
        "8",
        "18",
        "4",
        "2"
      ],
      "correct": 0,
      "explanation": "12 ÷ 3 = 4, then 4 × 2 = 8"
    },
    {
      "question": "The sum of angles in a triangle is?",
      "options": [
        "270°",
        "180°",
        "90°",
        "360°"
      ],
      "correct": 1,
      "explanation": "Sum of angles in any triangle is 180°"
    },
    {
      "question": "What is 20% of 80?",
      "options": [
        "12",
        "20",
        "18",
        "16"
      ],
      "correct": 3,
      "explanation": "0.20 × 80 = 16"
    },
    {
      "question": "Find the median of 3, 7, 9, 5, 11",
      "options": [
        "5",
        "8",
        "7",
        "9"
      ],
      "correct": 2,
      "explanation": "Ordered: 3,5,7,9,11 → median is 7"
    },
    {
      "question": "What is 2⁵?",
      "options": [
        "64",
        "16",
        "32",
        "10"
      ],
      "correct": 2,
      "explanation": "2×2×2×2×2 = 32"
    },
    {
      "question": "Solve: x + 9 = 20",
      "options": [
        "29",
        "11",
        "12",
        "10"
      ],
      "correct": 1,
      "explanation": "x = 20 - 9 = 11"
    },
    {
      "question": "The area of a triangle with base 10cm and height 6cm is?",
      "options": [
        "20 cm²",
        "16 cm²",
        "30 cm²",
        "60 cm²"
      ],
      "correct": 2,
      "explanation": "Area = ½ × base × height = ½ × 10 × 6 = 30"
    },
    {
      "question": "What is the reciprocal of 5?",
      "options": [
        "0",
        "1/5",
        "5",
        "25"
      ],
      "correct": 1,
      "explanation": "Reciprocal of 5 is 1/5"
    },
    {
      "question": "Simplify: 3² + 4²",
      "options": [
        "14",
        "25",
        "49",
        "12"
      ],
      "correct": 1,
      "explanation": "9 + 16 = 25"
    },
    {
      "question": "If a:b = 2:3 and a = 8, find b",
      "options": [
        "10",
        "16",
        "6",
        "12"
      ],
      "correct": 3,
      "explanation": "2/3 = 8/b → b = 12"
    },
    {
      "question": "What is the value of 0 × 15?",
      "options": [
        "15",
        "0",
        "1",
        "30"
      ],
      "correct": 1,
      "explanation": "Any number multiplied by 0 is 0"
    },
    {
      "question": "Find the range of 4, 9, 2, 11, 7",
      "options": [
        "11",
        "9",
        "7",
        "5"
      ],
      "correct": 1,
      "explanation": "Range = highest - lowest = 11 - 2 = 9"
    },
    {
      "question": "Solve: 3x + 2x = 20",
      "options": [
        "3",
        "10",
        "5",
        "4"
      ],
      "correct": 3,
      "explanation": "5x = 20 → x = 4"
    },
    {
      "question": "What is 50% of 90?",
      "options": [
        "50",
        "45",
        "40",
        "55"
      ],
      "correct": 1,
      "explanation": "Half of 90 is 45"
    },
    {
      "question": "The circumference of a circle is given by?",
      "options": [
        "2πr",
        "2πd",
        "πr²",
        "πd²"
      ],
      "correct": 0,
      "explanation": "Circumference = 2πr"
    },
    {
      "question": "What is the square of 12?",
      "options": [
        "24",
        "132",
        "120",
        "144"
      ],
      "correct": 3,
      "explanation": "12 × 12 = 144"
    },
    {
      "question": "Simplify: 8/2 + 3",
      "options": [
        "7",
        "5",
        "4",
        "6"
      ],
      "correct": 0,
      "explanation": "4 + 3 = 7"
    },
    {
      "question": "If the radius of a circle is 7cm, find the diameter",
      "options": [
        "7 cm",
        "14 cm",
        "21 cm",
        "3.5 cm"
      ],
      "correct": 1,
      "explanation": "Diameter = 2 × radius = 14 cm"
    },
    {
      "question": "What is 1000 ÷ 25?",
      "options": [
        "25",
        "40",
        "50",
        "30"
      ],
      "correct": 1,
      "explanation": "1000 ÷ 25 = 40"
    },
    {
      "question": "Solve: 2x - 5 = 9",
      "options": [
        "4",
        "6",
        "8",
        "7"
      ],
      "correct": 3,
      "explanation": "2x = 14 → x = 7"
    },
    {
      "question": "The product of 9 and 6 is?",
      "options": [
        "45",
        "36",
        "54",
        "15"
      ],
      "correct": 2,
      "explanation": "9 × 6 = 54"
    },
    {
      "question": "What is the place value of 7 in 3,745?",
      "options": [
        "Thousands",
        "Tens",
        "Units",
        "Hundreds"
      ],
      "correct": 3,
      "explanation": "7 is in the hundreds place"
    },
    {
      "question": "Simplify: 15 - 3 × 2",
      "options": [
        "24",
        "6",
        "12",
        "9"
      ],
      "correct": 3,
      "explanation": "3 × 2 = 6, then 15 - 6 = 9 (BODMAS)"
    },
    {
      "question": "What is the value of 5! (5 factorial)?",
      "options": [
        "60",
        "120",
        "24",
        "100"
      ],
      "correct": 1,
      "explanation": "5! = 5×4×3×2×1 = 120"
    },
    {
      "question": "Solve: 7x = 0",
      "options": [
        "1",
        "No solution",
        "7",
        "0"
      ],
      "correct": 3,
      "explanation": "Any number times 0 is 0, so x = 0"
    },
    {
      "question": "The simple interest on ₦5000 at 5% per annum for 2 years is?",
      "options": [
        "₦250",
        "₦200",
        "₦500",
        "₦1000"
      ],
      "correct": 2,
      "explanation": "SI = PRT/100 = 5000×5×2/100 = 500"
    },
    {
      "question": "What is the probability of getting a head when a fair coin is tossed?",
      "options": [
        "1/2",
        "0",
        "1",
        "1/4"
      ],
      "correct": 0,
      "explanation": "A fair coin has two outcomes; probability of head is 1/2"
    },
    {
      "question": "Expand: (x + 3)(x + 2)",
      "options": [
        "x² + 5x + 5",
        "x² + 5x + 6",
        "x² + 3x + 2",
        "x² + 6x + 5"
      ],
      "correct": 1,
      "explanation": "x² + 2x + 3x + 6 = x² + 5x + 6"
    },
    {
      "question": "If the average of 5 numbers is 12, their total sum is?",
      "options": [
        "24",
        "60",
        "50",
        "17"
      ],
      "correct": 1,
      "explanation": "Sum = average × number of items = 12 × 5 = 60"
    },
    {
      "question": "What is 3/5 as a decimal?",
      "options": [
        "0.3",
        "0.8",
        "0.6",
        "0.5"
      ],
      "correct": 2,
      "explanation": "3 ÷ 5 = 0.6"
    },
    {
      "question": "The gradient of the line y = 4x - 3 is?",
      "options": [
        "-3",
        "3",
        "1",
        "4"
      ],
      "correct": 3,
      "explanation": "In y = mx + c, m is the gradient"
    },
    {
      "question": "How many degrees are in a right angle?",
      "options": [
        "90°",
        "180°",
        "45°",
        "360°"
      ],
      "correct": 0,
      "explanation": "A right angle is 90°"
    },
    {
      "question": "Solve the inequality: x + 3 > 7",
      "options": [
        "x > 4",
        "x < 10",
        "x < 4",
        "x > 10"
      ],
      "correct": 0,
      "explanation": "x > 7 - 3 → x > 4"
    },
    {
      "question": "What is the cube root of 27?",
      "options": [
        "9",
        "6",
        "3",
        "4"
      ],
      "correct": 2,
      "explanation": "3 × 3 × 3 = 27"
    },
    {
      "question": "If sin θ = 1/2, one possible value of θ is?",
      "options": [
        "60°",
        "30°",
        "45°",
        "90°"
      ],
      "correct": 1,
      "explanation": "sin 30° = 1/2"
    },
    {
      "question": "The number of sides of a hexagon is?",
      "options": [
        "8",
        "7",
        "6",
        "5"
      ],
      "correct": 2,
      "explanation": "A hexagon has 6 sides"
    },
    {
      "question": "What is 2.5 × 4?",
      "options": [
        "10",
        "6.5",
        "12",
        "8"
      ],
      "correct": 0,
      "explanation": "2.5 × 4 = 10"
    },
    {
      "question": "Express 45% as a fraction in its lowest term",
      "options": [
        "9/20",
        "45/100",
        "9/10",
        "5/9"
      ],
      "correct": 0,
      "explanation": "45/100 = 9/20"
    },
    {
      "question": "The distance between two points (0,0) and (3,4) is?",
      "options": [
        "5",
        "12",
        "1",
        "7"
      ],
      "correct": 0,
      "explanation": "√(3² + 4²) = √25 = 5"
    },
    {
      "question": "What is the value of log₁₀ 100?",
      "options": [
        "2",
        "100",
        "10",
        "1"
      ],
      "correct": 0,
      "explanation": "10² = 100, so log₁₀ 100 = 2"
    },
    {
      "question": "If 3 apples cost ₦150, how much do 7 apples cost?",
      "options": [
        "₦250",
        "₦350",
        "₦450",
        "₦300"
      ],
      "correct": 1,
      "explanation": "1 apple = ₦50, 7 apples = ₦350"
    },
    {
      "question": "The sum of the interior angles of a quadrilateral is?",
      "options": [
        "540°",
        "90°",
        "180°",
        "360°"
      ],
      "correct": 3,
      "explanation": "Sum of interior angles of quadrilateral is 360°"
    },
    {
      "question": "What is the least common multiple of 4 and 6?",
      "options": [
        "2",
        "24",
        "12",
        "8"
      ],
      "correct": 2,
      "explanation": "LCM of 4 and 6 is 12"
    },
    {
      "question": "Solve: x² = 81",
      "options": [
        "3",
        "±9",
        "9 only",
        "±81"
      ],
      "correct": 1,
      "explanation": "x = ±√81 = ±9"
    },
    {
      "question": "The ratio of 2 hours to 30 minutes is?",
      "options": [
        "2:30",
        "4:1",
        "2:1",
        "1:15"
      ],
      "correct": 1,
      "explanation": "2 hours = 120 min, 120:30 = 4:1"
    },
    {
      "question": "What is the value of 0.2 × 0.3?",
      "options": [
        "0.6",
        "0.06",
        "0.06",
        "0.5"
      ],
      "correct": 1,
      "explanation": "0.2 × 0.3 = 0.06"
    },
    {
      "question": "If a triangle has angles 40°, 60°, the third angle is?",
      "options": [
        "80°",
        "70°",
        "100°",
        "90°"
      ],
      "correct": 0,
      "explanation": "180° - 40° - 60° = 80°"
    },
    {
      "question": "The standard form of 45000 is?",
      "options": [
        "4.5 × 10⁴",
        "45 × 10³",
        "45 × 10⁴",
        "4.5 × 10³"
      ],
      "correct": 0,
      "explanation": "45000 = 4.5 × 10⁴"
    },
    {
      "question": "What is the value of √64?",
      "options": [
        "6",
        "16",
        "8",
        "4"
      ],
      "correct": 2,
      "explanation": "8 × 8 = 64"
    },
    {
      "question": "Solve: 5x + 3 = 3x + 11",
      "options": [
        "7",
        "4",
        "3",
        "5"
      ],
      "correct": 1,
      "explanation": "5x - 3x = 11 - 3 → 2x = 8 → x = 4"
    },
    {
      "question": "The area of a circle with radius 7cm (π = 22/7) is?",
      "options": [
        "22 cm²",
        "154 cm²",
        "44 cm²",
        "77 cm²"
      ],
      "correct": 1,
      "explanation": "πr² = 22/7 × 49 = 154"
    },
    {
      "question": "What is 12.5% of 80?",
      "options": [
        "15",
        "12",
        "10",
        "8"
      ],
      "correct": 2,
      "explanation": "12.5% of 80 = 0.125 × 80 = 10"
    },
    {
      "question": "If 2x² = 50, then x = ?",
      "options": [
        "±25",
        "10",
        "±5",
        "5 only"
      ],
      "correct": 2,
      "explanation": "x² = 25 → x = ±5"
    },
    {
      "question": "The sum of 2.5 + 3.7 is?",
      "options": [
        "5.2",
        "5.12",
        "6.2",
        "6.12"
      ],
      "correct": 2,
      "explanation": "2.5 + 3.7 = 6.2"
    },
    {
      "question": "How many faces does a cube have?",
      "options": [
        "8",
        "12",
        "4",
        "6"
      ],
      "correct": 3,
      "explanation": "A cube has 6 faces"
    },
    {
      "question": "What is the next number in the sequence 2, 4, 8, 16, ...?",
      "options": [
        "30",
        "20",
        "32",
        "24"
      ],
      "correct": 2,
      "explanation": "Each term is multiplied by 2"
    },
    {
      "question": "Express 0.75 as a percentage",
      "options": [
        "750%",
        "7.5%",
        "0.75%",
        "75%"
      ],
      "correct": 3,
      "explanation": "0.75 × 100 = 75%"
    },
    {
      "question": "The volume of a cuboid 5cm × 3cm × 2cm is?",
      "options": [
        "30 cm³",
        "10 cm³",
        "25 cm³",
        "15 cm³"
      ],
      "correct": 0,
      "explanation": "Volume = l × b × h = 30"
    },
    {
      "question": "If y varies directly as x and y = 10 when x = 2, find y when x = 5",
      "options": [
        "20",
        "15",
        "25",
        "50"
      ],
      "correct": 2,
      "explanation": "y = kx → 10 = 2k → k = 5 → y = 25"
    },
    {
      "question": "What is the complement of 35°?",
      "options": [
        "145°",
        "65°",
        "45°",
        "55°"
      ],
      "correct": 3,
      "explanation": "Complement = 90° - 35° = 55°"
    },
    {
      "question": "Simplify: 2a + 3a - a",
      "options": [
        "3a",
        "6a",
        "4a",
        "5a"
      ],
      "correct": 2,
      "explanation": "2 + 3 - 1 = 4a"
    },
    {
      "question": "The average of 10, 20 and 30 is?",
      "options": [
        "30",
        "15",
        "60",
        "20"
      ],
      "correct": 3,
      "explanation": "(10+20+30)/3 = 20"
    },
    {
      "question": "What is 7% of 200?",
      "options": [
        "20",
        "14",
        "28",
        "7"
      ],
      "correct": 1,
      "explanation": "0.07 × 200 = 14"
    },
    {
      "question": "Solve: x/4 + 2 = 5",
      "options": [
        "10",
        "8",
        "12",
        "3"
      ],
      "correct": 2,
      "explanation": "x/4 = 3 → x = 12"
    },
    {
      "question": "The perimeter of a rectangle 8cm by 5cm is?",
      "options": [
        "13 cm",
        "20 cm",
        "26 cm",
        "40 cm"
      ],
      "correct": 2,
      "explanation": "2(l + b) = 2(13) = 26"
    },
    {
      "question": "What is the value of 3⁰?",
      "options": [
        "0",
        "1",
        "3",
        "Undefined"
      ],
      "correct": 1,
      "explanation": "Any non-zero number to power 0 is 1"
    },
    {
      "question": "If a = 2 and b = 3, find 2a + b",
      "options": [
        "5",
        "6",
        "8",
        "7"
      ],
      "correct": 3,
      "explanation": "2(2) + 3 = 7"
    },
    {
      "question": "The highest common factor of 16 and 24 is?",
      "options": [
        "8",
        "12",
        "2",
        "4"
      ],
      "correct": 0,
      "explanation": "HCF of 16 and 24 is 8"
    },
    {
      "question": "Convert 2 hours 30 minutes to minutes",
      "options": [
        "120",
        "180",
        "150",
        "90"
      ],
      "correct": 2,
      "explanation": "2 × 60 + 30 = 150 minutes"
    },
    {
      "question": "What is the square root of 0.25?",
      "options": [
        "5",
        "0.05",
        "0.025",
        "0.5"
      ],
      "correct": 3,
      "explanation": "0.5 × 0.5 = 0.25"
    },
    {
      "question": "The sum of the first 5 natural numbers is?",
      "options": [
        "20",
        "5",
        "15",
        "10"
      ],
      "correct": 2,
      "explanation": "1+2+3+4+5 = 15"
    },
    {
      "question": "If 40% of a number is 20, the number is?",
      "options": [
        "60",
        "50",
        "80",
        "40"
      ],
      "correct": 1,
      "explanation": "0.4x = 20 → x = 50"
    },
    {
      "question": "What is the value of 2³ × 3?",
      "options": [
        "36",
        "18",
        "12",
        "24"
      ],
      "correct": 3,
      "explanation": "8 × 3 = 24"
    },
    {
      "question": "What is the value of 4³?",
      "options": [
        "16",
        "32",
        "12",
        "64"
      ],
      "correct": 3,
      "explanation": "4 × 4 × 4 = 64"
    },
    {
      "question": "Solve: 2(x - 3) = 10",
      "options": [
        "13",
        "5",
        "8",
        "7"
      ],
      "correct": 2,
      "explanation": "x - 3 = 5 → x = 8"
    },
    {
      "question": "The circumference of a circle with diameter 14cm (π=22/7) is?",
      "options": [
        "88 cm",
        "154 cm",
        "44 cm",
        "22 cm"
      ],
      "correct": 2,
      "explanation": "C = πd = 22/7 × 14 = 44"
    },
    {
      "question": "What is 1/4 of 80?",
      "options": [
        "16",
        "40",
        "10",
        "20"
      ],
      "correct": 3,
      "explanation": "80 ÷ 4 = 20"
    },
    {
      "question": "If 3x - 5 = 10, then x = ?",
      "options": [
        "2",
        "5",
        "15",
        "3"
      ],
      "correct": 1,
      "explanation": "3x = 15 → x = 5"
    },
    {
      "question": "The mode of 5, 7, 5, 9, 5, 8 is?",
      "options": [
        "5",
        "8",
        "9",
        "7"
      ],
      "correct": 0,
      "explanation": "5 appears most often"
    },
    {
      "question": "What is 15²?",
      "options": [
        "225",
        "250",
        "30",
        "200"
      ],
      "correct": 0,
      "explanation": "15 × 15 = 225"
    },
    {
      "question": "Simplify: 9/3 + 4",
      "options": [
        "3",
        "7",
        "13",
        "1"
      ],
      "correct": 1,
      "explanation": "3 + 4 = 7"
    },
    {
      "question": "The area of a square of side 6cm is?",
      "options": [
        "18 cm²",
        "24 cm²",
        "36 cm²",
        "12 cm²"
      ],
      "correct": 2,
      "explanation": "Area = side² = 36"
    },
    {
      "question": "What is the value of 10³?",
      "options": [
        "1000",
        "30",
        "10000",
        "100"
      ],
      "correct": 0,
      "explanation": "10 × 10 × 10 = 1000"
    },
    {
      "question": "If a = 5 and b = 2, find a² - b²",
      "options": [
        "25",
        "21",
        "3",
        "9"
      ],
      "correct": 1,
      "explanation": "25 - 4 = 21"
    },
    {
      "question": "The sum of angles on a straight line is?",
      "options": [
        "360°",
        "90°",
        "180°",
        "270°"
      ],
      "correct": 2,
      "explanation": "Angles on a straight line sum to 180°"
    },
    {
      "question": "What is 30% of 50?",
      "options": [
        "10",
        "15",
        "20",
        "25"
      ],
      "correct": 1,
      "explanation": "0.3 × 50 = 15"
    },
    {
      "question": "Solve: x - 8 = 12",
      "options": [
        "96",
        "-4",
        "4",
        "20"
      ],
      "correct": 3,
      "explanation": "x = 12 + 8 = 20"
    },
    {
      "question": "The LCM of 5 and 10 is?",
      "options": [
        "50",
        "10",
        "15",
        "5"
      ],
      "correct": 1,
      "explanation": "LCM of 5 and 10 is 10"
    },
    {
      "question": "What is √100?",
      "options": [
        "5",
        "20",
        "50",
        "10"
      ],
      "correct": 3,
      "explanation": "10 × 10 = 100"
    },
    {
      "question": "If 4x = 36, x = ?",
      "options": [
        "8",
        "40",
        "32",
        "9"
      ],
      "correct": 3,
      "explanation": "x = 36 ÷ 4 = 9"
    },
    {
      "question": "The perimeter of an equilateral triangle of side 7cm is?",
      "options": [
        "21 cm",
        "14 cm",
        "49 cm",
        "28 cm"
      ],
      "correct": 0,
      "explanation": "3 × 7 = 21 cm"
    },
    {
      "question": "What is 2.5 + 1.75?",
      "options": [
        "3.25",
        "4.25",
        "4.75",
        "3.75"
      ],
      "correct": 1,
      "explanation": "2.5 + 1.75 = 4.25"
    },
    {
      "question": "The number of edges of a cube is?",
      "options": [
        "12",
        "8",
        "10",
        "6"
      ],
      "correct": 0,
      "explanation": "A cube has 12 edges"
    },
    {
      "question": "What is 5 × 0.2?",
      "options": [
        "1",
        "0.1",
        "10",
        "2"
      ],
      "correct": 0,
      "explanation": "5 × 0.2 = 1"
    },
    {
      "question": "Solve: 3x + 6 = 15",
      "options": [
        "9",
        "5",
        "3",
        "7"
      ],
      "correct": 2,
      "explanation": "3x = 9 → x = 3"
    },
    {
      "question": "The average of 6, 8 and 10 is?",
      "options": [
        "6",
        "12",
        "24",
        "8"
      ],
      "correct": 3,
      "explanation": "(6+8+10)/3 = 8"
    },
    {
      "question": "What is 100 ÷ 4?",
      "options": [
        "25",
        "40",
        "20",
        "50"
      ],
      "correct": 0,
      "explanation": "100 ÷ 4 = 25"
    },
    {
      "question": "The square of 0 is?",
      "options": [
        "0",
        "1",
        "10",
        "Undefined"
      ],
      "correct": 0,
      "explanation": "0 × 0 = 0"
    },
    {
      "question": "What is 8 × 7?",
      "options": [
        "56",
        "48",
        "54",
        "64"
      ],
      "correct": 0,
      "explanation": "8 × 7 = 56"
    },
    {
      "question": "Solve: x + 15 = 30",
      "options": [
        "0",
        "15",
        "45",
        "2"
      ],
      "correct": 1,
      "explanation": "x = 30 - 15 = 15"
    },
    {
      "question": "The area of a rectangle 12cm by 4cm is?",
      "options": [
        "32 cm²",
        "48 cm²",
        "40 cm²",
        "16 cm²"
      ],
      "correct": 1,
      "explanation": "12 × 4 = 48"
    },
    {
      "question": "What is 25% of 200?",
      "options": [
        "100",
        "25",
        "75",
        "50"
      ],
      "correct": 3,
      "explanation": "0.25 × 200 = 50"
    },
    {
      "question": "If 6x = 42, x = ?",
      "options": [
        "6",
        "36",
        "7",
        "8"
      ],
      "correct": 2,
      "explanation": "x = 42 ÷ 6 = 7"
    },
    {
      "question": "What is √81?",
      "options": [
        "18",
        "9",
        "7",
        "8"
      ],
      "correct": 1,
      "explanation": "9 × 9 = 81"
    },
    {
      "question": "The sum of 45 and 55 is?",
      "options": [
        "80",
        "100",
        "110",
        "90"
      ],
      "correct": 1,
      "explanation": "45 + 55 = 100"
    },
    {
      "question": "What is 3² + 4² + 5²?",
      "options": [
        "12",
        "25",
        "36",
        "50"
      ],
      "correct": 3,
      "explanation": "9 + 16 + 25 = 50"
    },
    {
      "question": "The perimeter of a square of side 10cm is?",
      "options": [
        "30 cm",
        "40 cm",
        "100 cm",
        "20 cm"
      ],
      "correct": 1,
      "explanation": "4 × 10 = 40"
    },
    {
      "question": "What is 1/2 + 1/4?",
      "options": [
        "1/8",
        "2/6",
        "3/4",
        "1/6"
      ],
      "correct": 2,
      "explanation": "2/4 + 1/4 = 3/4"
    },
    {
      "question": "If y = 5x and x = 3, y = ?",
      "options": [
        "2",
        "8",
        "5",
        "15"
      ],
      "correct": 3,
      "explanation": "y = 5 × 3 = 15"
    },
    {
      "question": "What is 1000 × 0?",
      "options": [
        "1",
        "1000",
        "0",
        "100"
      ],
      "correct": 2,
      "explanation": "Any number × 0 = 0"
    },
    {
      "question": "The HCF of 8 and 12 is?",
      "options": [
        "24",
        "2",
        "8",
        "4"
      ],
      "correct": 3,
      "explanation": "Highest common factor is 4"
    },
    {
      "question": "What is 9 × 9?",
      "options": [
        "90",
        "18",
        "81",
        "72"
      ],
      "correct": 2,
      "explanation": "9 × 9 = 81"
    },
    {
      "question": "Solve: 4x - 8 = 0",
      "options": [
        "0",
        "8",
        "2",
        "4"
      ],
      "correct": 2,
      "explanation": "4x = 8 → x = 2"
    },
    {
      "question": "The volume of a cube of side 4cm is?",
      "options": [
        "16 cm³",
        "64 cm³",
        "12 cm³",
        "32 cm³"
      ],
      "correct": 1,
      "explanation": "4³ = 64"
    },
    {
      "question": "What is 50 ÷ 5?",
      "options": [
        "10",
        "15",
        "5",
        "25"
      ],
      "correct": 0,
      "explanation": "50 ÷ 5 = 10"
    },
    {
      "question": "If 20% of x is 10, x = ?",
      "options": [
        "50",
        "20",
        "30",
        "40"
      ],
      "correct": 0,
      "explanation": "0.2x = 10 → x = 50"
    },
    {
      "question": "What is the next odd number after 17?",
      "options": [
        "18",
        "21",
        "19",
        "15"
      ],
      "correct": 2,
      "explanation": "Odd numbers increase by 2"
    },
    {
      "question": "The average of 2, 4, 6 is?",
      "options": [
        "3",
        "12",
        "4",
        "6"
      ],
      "correct": 2,
      "explanation": "(2+4+6)/3 = 4"
    },
    {
      "question": "What is 2 × 3 × 4?",
      "options": [
        "12",
        "24",
        "20",
        "18"
      ],
      "correct": 1,
      "explanation": "2 × 3 × 4 = 24"
    },
    {
      "question": "Solve: x/3 = 6",
      "options": [
        "18",
        "2",
        "3",
        "9"
      ],
      "correct": 0,
      "explanation": "x = 6 × 3 = 18"
    },
    {
      "question": "The number of vertices of a cube is?",
      "options": [
        "6",
        "4",
        "8",
        "12"
      ],
      "correct": 2,
      "explanation": "A cube has 8 vertices"
    },
    {
      "question": "What is 0.5 × 10?",
      "options": [
        "50",
        "15",
        "0.5",
        "5"
      ],
      "correct": 3,
      "explanation": "0.5 × 10 = 5"
    },
    {
      "question": "If a = 4, find a² + 2a",
      "options": [
        "16",
        "8",
        "20",
        "24"
      ],
      "correct": 3,
      "explanation": "16 + 8 = 24"
    },
    {
      "question": "What is 6 × 8?",
      "options": [
        "48",
        "54",
        "42",
        "36"
      ],
      "correct": 0,
      "explanation": "6 × 8 = 48"
    },
    {
      "question": "Solve: 5x = 35",
      "options": [
        "8",
        "6",
        "30",
        "7"
      ],
      "correct": 3,
      "explanation": "x = 35 ÷ 5 = 7"
    },
    {
      "question": "The area of a triangle with base 8cm and height 5cm is?",
      "options": [
        "25 cm²",
        "40 cm²",
        "13 cm²",
        "20 cm²"
      ],
      "correct": 3,
      "explanation": "½ × 8 × 5 = 20"
    },
    {
      "question": "What is 10% of 250?",
      "options": [
        "10",
        "15",
        "25",
        "50"
      ],
      "correct": 2,
      "explanation": "0.1 × 250 = 25"
    },
    {
      "question": "If x - 4 = 9, x = ?",
      "options": [
        "13",
        "5",
        "36",
        "-5"
      ],
      "correct": 0,
      "explanation": "x = 9 + 4 = 13"
    },
    {
      "question": "What is √36?",
      "options": [
        "9",
        "12",
        "18",
        "6"
      ],
      "correct": 3,
      "explanation": "6 × 6 = 36"
    },
    {
      "question": "The sum of 28 and 17 is?",
      "options": [
        "40",
        "50",
        "35",
        "45"
      ],
      "correct": 3,
      "explanation": "28 + 17 = 45"
    },
    {
      "question": "What is 2⁴?",
      "options": [
        "16",
        "6",
        "32",
        "8"
      ],
      "correct": 0,
      "explanation": "2×2×2×2 = 16"
    },
    {
      "question": "The perimeter of a rectangle 9cm by 3cm is?",
      "options": [
        "24 cm",
        "18 cm",
        "12 cm",
        "27 cm"
      ],
      "correct": 0,
      "explanation": "2(9+3) = 24"
    },
    {
      "question": "What is 3/4 of 40?",
      "options": [
        "10",
        "30",
        "20",
        "35"
      ],
      "correct": 1,
      "explanation": "0.75 × 40 = 30"
    },
    {
      "question": "If 2a = 16, a = ?",
      "options": [
        "18",
        "14",
        "8",
        "4"
      ],
      "correct": 2,
      "explanation": "a = 16 ÷ 2 = 8"
    },
    {
      "question": "What is 7 + 8 × 2?",
      "options": [
        "23",
        "22",
        "30",
        "15"
      ],
      "correct": 0,
      "explanation": "8 × 2 = 16, then 7 + 16 = 23 (BODMAS)"
    },
    {
      "question": "The LCM of 3 and 9 is?",
      "options": [
        "3",
        "27",
        "9",
        "18"
      ],
      "correct": 2,
      "explanation": "LCM of 3 and 9 is 9"
    },
    {
      "question": "What is 11²?",
      "options": [
        "110",
        "22",
        "100",
        "121"
      ],
      "correct": 3,
      "explanation": "11 × 11 = 121"
    },
    {
      "question": "Solve: x + 7 = 20",
      "options": [
        "14",
        "27",
        "6",
        "13"
      ],
      "correct": 3,
      "explanation": "x = 20 - 7 = 13"
    },
    {
      "question": "The volume of a cuboid 6cm × 2cm × 3cm is?",
      "options": [
        "24 cm³",
        "36 cm³",
        "18 cm³",
        "12 cm³"
      ],
      "correct": 1,
      "explanation": "6 × 2 × 3 = 36"
    },
    {
      "question": "What is 80 ÷ 8?",
      "options": [
        "72",
        "8",
        "10",
        "16"
      ],
      "correct": 2,
      "explanation": "80 ÷ 8 = 10"
    },
    {
      "question": "If 5% of a number is 15, the number is?",
      "options": [
        "45",
        "300",
        "75",
        "150"
      ],
      "correct": 1,
      "explanation": "0.05x = 15 → x = 300"
    },
    {
      "question": "What is the next even number after 24?",
      "options": [
        "25",
        "26",
        "28",
        "22"
      ],
      "correct": 1,
      "explanation": "Even numbers increase by 2"
    },
    {
      "question": "The average of 5, 10 and 15 is?",
      "options": [
        "10",
        "15",
        "30",
        "5"
      ],
      "correct": 0,
      "explanation": "(5+10+15)/3 = 10"
    },
    {
      "question": "What is 4 × 5 × 2?",
      "options": [
        "11",
        "20",
        "40",
        "30"
      ],
      "correct": 2,
      "explanation": "4 × 5 × 2 = 40"
    },
    {
      "question": "Solve: x/5 = 3",
      "options": [
        "5",
        "2",
        "8",
        "15"
      ],
      "correct": 3,
      "explanation": "x = 3 × 5 = 15"
    },
    {
      "question": "The number of faces of a cuboid is?",
      "options": [
        "12",
        "4",
        "8",
        "6"
      ],
      "correct": 3,
      "explanation": "A cuboid has 6 faces"
    },
    {
      "question": "What is 0.25 × 8?",
      "options": [
        "1",
        "2",
        "0.2",
        "4"
      ],
      "correct": 1,
      "explanation": "0.25 × 8 = 2"
    },
    {
      "question": "If b = 6, find 3b - 4",
      "options": [
        "18",
        "10",
        "14",
        "22"
      ],
      "correct": 2,
      "explanation": "18 - 4 = 14"
    },
    {
      "question": "What is 9 × 6?",
      "options": [
        "54",
        "36",
        "63",
        "45"
      ],
      "correct": 0,
      "explanation": "9 × 6 = 54"
    },
    {
      "question": "Solve: 3x = 27",
      "options": [
        "24",
        "10",
        "9",
        "8"
      ],
      "correct": 2,
      "explanation": "x = 27 ÷ 3 = 9"
    },
    {
      "question": "The area of a square of side 5cm is?",
      "options": [
        "25 cm²",
        "15 cm²",
        "20 cm²",
        "10 cm²"
      ],
      "correct": 0,
      "explanation": "5 × 5 = 25"
    },
    {
      "question": "What is 40% of 50?",
      "options": [
        "30",
        "40",
        "10",
        "20"
      ],
      "correct": 3,
      "explanation": "0.4 × 50 = 20"
    },
    {
      "question": "If x + 6 = 14, x = ?",
      "options": [
        "8",
        "7",
        "20",
        "9"
      ],
      "correct": 0,
      "explanation": "x = 14 - 6 = 8"
    },
    {
      "question": "What is √49?",
      "options": [
        "6",
        "9",
        "7",
        "14"
      ],
      "correct": 2,
      "explanation": "7 × 7 = 49"
    },
    {
      "question": "The sum of 33 and 27 is?",
      "options": [
        "60",
        "70",
        "55",
        "50"
      ],
      "correct": 0,
      "explanation": "33 + 27 = 60"
    },
    {
      "question": "What is 5³?",
      "options": [
        "125",
        "15",
        "25",
        "100"
      ],
      "correct": 0,
      "explanation": "5 × 5 × 5 = 125"
    },
    {
      "question": "The perimeter of a square of side 8cm is?",
      "options": [
        "32 cm",
        "24 cm",
        "16 cm",
        "64 cm"
      ],
      "correct": 0,
      "explanation": "4 × 8 = 32"
    },
    {
      "question": "What is 2/5 of 50?",
      "options": [
        "20",
        "25",
        "10",
        "15"
      ],
      "correct": 0,
      "explanation": "0.4 × 50 = 20"
    },
    {
      "question": "If 4b = 28, b = ?",
      "options": [
        "6",
        "24",
        "7",
        "8"
      ],
      "correct": 2,
      "explanation": "b = 28 ÷ 4 = 7"
    },
    {
      "question": "What is 12 ÷ 3 + 5?",
      "options": [
        "11",
        "9",
        "7",
        "4"
      ],
      "correct": 1,
      "explanation": "4 + 5 = 9"
    },
    {
      "question": "The HCF of 10 and 15 is?",
      "options": [
        "15",
        "5",
        "1",
        "10"
      ],
      "correct": 1,
      "explanation": "Highest common factor is 5"
    },
    {
      "question": "What is 13²?",
      "options": [
        "130",
        "156",
        "26",
        "169"
      ],
      "correct": 3,
      "explanation": "13 × 13 = 169"
    },
    {
      "question": "Solve: x - 9 = 11",
      "options": [
        "99",
        "2",
        "20",
        "-2"
      ],
      "correct": 2,
      "explanation": "x = 11 + 9 = 20"
    },
    {
      "question": "The volume of a cube of side 5cm is?",
      "options": [
        "125 cm³",
        "15 cm³",
        "25 cm³",
        "100 cm³"
      ],
      "correct": 0,
      "explanation": "5³ = 125"
    },
    {
      "question": "What is 90 ÷ 9?",
      "options": [
        "9",
        "10",
        "19",
        "81"
      ],
      "correct": 1,
      "explanation": "90 ÷ 9 = 10"
    },
    {
      "question": "If 25% of a number is 40, the number is?",
      "options": [
        "80",
        "160",
        "200",
        "100"
      ],
      "correct": 1,
      "explanation": "0.25x = 40 → x = 160"
    },
    {
      "question": "What is the next prime number after 13?",
      "options": [
        "17",
        "19",
        "15",
        "14"
      ],
      "correct": 0,
      "explanation": "Next prime after 13 is 17"
    },
    {
      "question": "The average of 8, 12 and 16 is?",
      "options": [
        "36",
        "16",
        "12",
        "10"
      ],
      "correct": 2,
      "explanation": "(8+12+16)/3 = 12"
    },
    {
      "question": "What is 3 × 7 × 2?",
      "options": [
        "42",
        "35",
        "14",
        "21"
      ],
      "correct": 0,
      "explanation": "3 × 7 × 2 = 42"
    },
    {
      "question": "Solve: x/2 = 9",
      "options": [
        "11",
        "18",
        "4.5",
        "7"
      ],
      "correct": 1,
      "explanation": "x = 9 × 2 = 18"
    },
    {
      "question": "The number of edges of a cuboid is?",
      "options": [
        "12",
        "8",
        "4",
        "6"
      ],
      "correct": 0,
      "explanation": "A cuboid has 12 edges"
    },
    {
      "question": "What is 0.1 × 50?",
      "options": [
        "5",
        "0.5",
        "50",
        "15"
      ],
      "correct": 0,
      "explanation": "0.1 × 50 = 5"
    },
    {
      "question": "If c = 7, find 2c + 3",
      "options": [
        "21",
        "10",
        "17",
        "14"
      ],
      "correct": 2,
      "explanation": "14 + 3 = 17"
    }
  ],
  "phy": [
    {
      "question": "The SI unit of force is?",
      "options": [
        "Newton",
        "Joule",
        "Pascal",
        "Watt"
      ],
      "correct": 0,
      "explanation": "Force is measured in Newtons (N)"
    },
    {
      "question": "Speed is defined as?",
      "options": [
        "Distance / Time",
        "Force × Distance",
        "Mass × Velocity",
        "Time / Distance"
      ],
      "correct": 0,
      "explanation": "Speed = Distance ÷ Time"
    },
    {
      "question": "The instrument used to measure electric current is?",
      "options": [
        "Ammeter",
        "Thermometer",
        "Barometer",
        "Voltmeter"
      ],
      "correct": 0,
      "explanation": "Ammeter measures current"
    },
    {
      "question": "Ohm's law states that V = ?",
      "options": [
        "R/I",
        "IR",
        "I/R",
        "I + R"
      ],
      "correct": 1,
      "explanation": "V = I × R"
    },
    {
      "question": "The acceleration due to gravity is approximately?",
      "options": [
        "20 m/s²",
        "5 m/s²",
        "10 m/s²",
        "1 m/s²"
      ],
      "correct": 2,
      "explanation": "g ≈ 9.8 or 10 m/s²"
    },
    {
      "question": "Light travels fastest in?",
      "options": [
        "Glass",
        "Air",
        "Vacuum",
        "Water"
      ],
      "correct": 2,
      "explanation": "Light is fastest in a vacuum"
    },
    {
      "question": "The unit of frequency is?",
      "options": [
        "Watt",
        "Joule",
        "Newton",
        "Hertz"
      ],
      "correct": 3,
      "explanation": "Frequency is measured in Hertz (Hz)"
    },
    {
      "question": "Sound cannot travel through?",
      "options": [
        "Iron",
        "Water",
        "Air",
        "Vacuum"
      ],
      "correct": 3,
      "explanation": "Sound needs a medium; it cannot travel in vacuum"
    },
    {
      "question": "Kinetic energy is given by?",
      "options": [
        "½mv²",
        "ma",
        "mgh",
        "mv"
      ],
      "correct": 0,
      "explanation": "KE = ½mv²"
    },
    {
      "question": "Potential energy is given by?",
      "options": [
        "mv",
        "Fd",
        "mgh",
        "½mv²"
      ],
      "correct": 2,
      "explanation": "PE = mgh"
    },
    {
      "question": "A device that converts electrical energy to mechanical energy is?",
      "options": [
        "Transformer",
        "Electric motor",
        "Battery",
        "Generator"
      ],
      "correct": 1,
      "explanation": "Motor converts electrical to mechanical energy"
    },
    {
      "question": "A generator converts?",
      "options": [
        "Chemical to electrical",
        "Electrical to mechanical",
        "Heat to light",
        "Mechanical to electrical energy"
      ],
      "correct": 3,
      "explanation": "Generator converts mechanical energy to electrical energy"
    },
    {
      "question": "The SI unit of power is?",
      "options": [
        "Newton",
        "Watt",
        "Joule",
        "Volt"
      ],
      "correct": 1,
      "explanation": "Power is measured in Watts"
    },
    {
      "question": "The boiling point of water is?",
      "options": [
        "212°C",
        "50°C",
        "100°C",
        "0°C"
      ],
      "correct": 2,
      "explanation": "Water boils at 100°C at standard pressure"
    },
    {
      "question": "The freezing point of water is?",
      "options": [
        "100°C",
        "-10°C",
        "32°C",
        "0°C"
      ],
      "correct": 3,
      "explanation": "Water freezes at 0°C"
    },
    {
      "question": "Which mirror is used in car side mirrors?",
      "options": [
        "Plane",
        "None",
        "Concave",
        "Convex"
      ],
      "correct": 3,
      "explanation": "Convex mirrors give a wider field of view"
    },
    {
      "question": "The colour of light with the highest frequency is?",
      "options": [
        "Green",
        "Violet",
        "Red",
        "Yellow"
      ],
      "correct": 1,
      "explanation": "Violet has the highest frequency in the visible spectrum"
    },
    {
      "question": "The unit of electric charge is?",
      "options": [
        "Volt",
        "Coulomb",
        "Ampere",
        "Ohm"
      ],
      "correct": 1,
      "explanation": "Charge is measured in Coulombs"
    },
    {
      "question": "Pressure is defined as?",
      "options": [
        "Force × Area",
        "Mass / Volume",
        "Force / Area",
        "Weight / Time"
      ],
      "correct": 2,
      "explanation": "Pressure = Force ÷ Area"
    },
    {
      "question": "The SI unit of pressure is?",
      "options": [
        "Pascal",
        "Watt",
        "Newton",
        "Joule"
      ],
      "correct": 0,
      "explanation": "Pressure is measured in Pascals (Pa)"
    },
    {
      "question": "Newton's first law is also known as the law of?",
      "options": [
        "Gravity",
        "Acceleration",
        "Action-Reaction",
        "Inertia"
      ],
      "correct": 3,
      "explanation": "First law is the law of inertia"
    },
    {
      "question": "The work done is zero when the force is?",
      "options": [
        "Very large",
        "Parallel to displacement",
        "In the same direction",
        "Perpendicular to displacement"
      ],
      "correct": 3,
      "explanation": "Work = Fd cosθ; when θ=90°, work=0"
    },
    {
      "question": "Which of these is a scalar quantity?",
      "options": [
        "Acceleration",
        "Velocity",
        "Force",
        "Speed"
      ],
      "correct": 3,
      "explanation": "Speed has only magnitude, no direction"
    },
    {
      "question": "The image formed by a plane mirror is?",
      "options": [
        "Real and erect",
        "Real and inverted",
        "Virtual and erect",
        "Virtual and inverted"
      ],
      "correct": 2,
      "explanation": "Plane mirrors form virtual, erect images"
    },
    {
      "question": "The speed of light in vacuum is approximately?",
      "options": [
        "3 × 10⁵ m/s",
        "3 × 10⁶ m/s",
        "3 × 10¹⁰ m/s",
        "3 × 10⁸ m/s"
      ],
      "correct": 3,
      "explanation": "Speed of light c ≈ 3 × 10⁸ m/s"
    },
    {
      "question": "Which of the following is a unit of energy?",
      "options": [
        "Watt",
        "Pascal",
        "Joule",
        "Newton"
      ],
      "correct": 2,
      "explanation": "Energy is measured in Joules"
    },
    {
      "question": "The force that opposes motion between two surfaces is?",
      "options": [
        "Magnetism",
        "Friction",
        "Gravity",
        "Tension"
      ],
      "correct": 1,
      "explanation": "Friction opposes relative motion"
    },
    {
      "question": "A body at rest will remain at rest unless acted upon by?",
      "options": [
        "An external force",
        "Nothing",
        "Gravity only",
        "Friction only"
      ],
      "correct": 0,
      "explanation": "Newton's first law of motion"
    },
    {
      "question": "The unit of electric resistance is?",
      "options": [
        "Ohm",
        "Watt",
        "Ampere",
        "Volt"
      ],
      "correct": 0,
      "explanation": "Resistance is measured in Ohms (Ω)"
    },
    {
      "question": "Which of these is a renewable source of energy?",
      "options": [
        "Coal",
        "Petrol",
        "Diesel",
        "Solar energy"
      ],
      "correct": 3,
      "explanation": "Solar energy is renewable"
    },
    {
      "question": "The bending of light as it passes from one medium to another is called?",
      "options": [
        "Refraction",
        "Reflection",
        "Diffraction",
        "Dispersion"
      ],
      "correct": 0,
      "explanation": "Refraction is the bending of light"
    },
    {
      "question": "The instrument used to measure temperature is?",
      "options": [
        "Thermometer",
        "Hygrometer",
        "Ammeter",
        "Barometer"
      ],
      "correct": 0,
      "explanation": "Thermometer measures temperature"
    },
    {
      "question": "Which colour of light has the longest wavelength?",
      "options": [
        "Green",
        "Blue",
        "Red",
        "Violet"
      ],
      "correct": 2,
      "explanation": "Red has the longest wavelength in the visible spectrum"
    },
    {
      "question": "The rate of change of velocity is called?",
      "options": [
        "Force",
        "Acceleration",
        "Speed",
        "Momentum"
      ],
      "correct": 1,
      "explanation": "Acceleration = change in velocity / time"
    },
    {
      "question": "A transformer works on the principle of?",
      "options": [
        "Mutual induction",
        "Heating effect",
        "Self induction only",
        "Electrolysis"
      ],
      "correct": 0,
      "explanation": "Transformers work by mutual induction"
    },
    {
      "question": "The weight of a body is the force of?",
      "options": [
        "Air on it",
        "Gravity on it",
        "Friction on it",
        "Magnetism on it"
      ],
      "correct": 1,
      "explanation": "Weight = mass × gravity"
    },
    {
      "question": "Which of these is used to measure atmospheric pressure?",
      "options": [
        "Thermometer",
        "Voltmeter",
        "Ammeter",
        "Barometer"
      ],
      "correct": 3,
      "explanation": "Barometer measures atmospheric pressure"
    },
    {
      "question": "The energy possessed by a body due to its position is?",
      "options": [
        "Potential energy",
        "Heat energy",
        "Sound energy",
        "Kinetic energy"
      ],
      "correct": 0,
      "explanation": "Potential energy is due to position"
    },
    {
      "question": "When light is reflected from a surface, the angle of incidence equals?",
      "options": [
        "90 degrees",
        "0 degrees",
        "Angle of refraction",
        "Angle of reflection"
      ],
      "correct": 3,
      "explanation": "Law of reflection: i = r"
    },
    {
      "question": "The unit of capacitance is?",
      "options": [
        "Henry",
        "Farad",
        "Ohm",
        "Tesla"
      ],
      "correct": 1,
      "explanation": "Capacitance is measured in Farads"
    },
    {
      "question": "A person standing in a moving bus falls backward when the bus starts because of?",
      "options": [
        "Gravity",
        "Momentum",
        "Inertia",
        "Friction"
      ],
      "correct": 2,
      "explanation": "Inertia tends to keep the body at rest"
    },
    {
      "question": "The heat required to raise the temperature of 1 kg of a substance by 1°C is?",
      "options": [
        "Latent heat",
        "Specific heat capacity",
        "Heat capacity",
        "Thermal conductivity"
      ],
      "correct": 1,
      "explanation": "This is the definition of specific heat capacity"
    },
    {
      "question": "Which of the following is a good conductor of electricity?",
      "options": [
        "Plastic",
        "Wood",
        "Rubber",
        "Copper"
      ],
      "correct": 3,
      "explanation": "Copper is an excellent conductor"
    },
    {
      "question": "The number of vibrations per second is called?",
      "options": [
        "Amplitude",
        "Wavelength",
        "Period",
        "Frequency"
      ],
      "correct": 3,
      "explanation": "Frequency is the number of vibrations per second"
    },
    {
      "question": "An echo is produced by?",
      "options": [
        "Refraction of sound",
        "Diffraction of sound",
        "Reflection of sound",
        "Absorption of sound"
      ],
      "correct": 2,
      "explanation": "Echo is due to reflection of sound"
    },
    {
      "question": "The SI unit of work is?",
      "options": [
        "Pascal",
        "Joule",
        "Watt",
        "Newton"
      ],
      "correct": 1,
      "explanation": "Work is measured in Joules"
    },
    {
      "question": "A magnetic field is produced by?",
      "options": [
        "Wood",
        "A current-carrying conductor",
        "Plastic",
        "A stationary charge only"
      ],
      "correct": 1,
      "explanation": "Current produces magnetic field"
    },
    {
      "question": "The process by which a liquid changes to gas at the surface is?",
      "options": [
        "Condensation",
        "Sublimation",
        "Evaporation",
        "Boiling"
      ],
      "correct": 2,
      "explanation": "Evaporation occurs at the surface"
    },
    {
      "question": "Which lens is used to correct short-sightedness?",
      "options": [
        "Cylindrical lens",
        "Convex lens",
        "Bifocal only",
        "Concave lens"
      ],
      "correct": 3,
      "explanation": "Myopia is corrected with concave lens"
    },
    {
      "question": "The product of mass and velocity is?",
      "options": [
        "Energy",
        "Momentum",
        "Force",
        "Power"
      ],
      "correct": 1,
      "explanation": "Momentum = mass × velocity"
    },
    {
      "question": "Which of the following is measured in Amperes?",
      "options": [
        "Resistance",
        "Electric current",
        "Voltage",
        "Power"
      ],
      "correct": 1,
      "explanation": "Current is measured in Amperes"
    },
    {
      "question": "The force of gravity on an object is called its?",
      "options": [
        "Density",
        "Mass",
        "Volume",
        "Weight"
      ],
      "correct": 3,
      "explanation": "Weight is the force of gravity on an object"
    },
    {
      "question": "A concave lens always produces?",
      "options": [
        "Real image",
        "Inverted image only",
        "Virtual image",
        "Magnified image only"
      ],
      "correct": 2,
      "explanation": "Concave lenses produce virtual, erect, diminished images"
    },
    {
      "question": "The unit of inductance is?",
      "options": [
        "Farad",
        "Henry",
        "Tesla",
        "Ohm"
      ],
      "correct": 1,
      "explanation": "Inductance is measured in Henrys"
    },
    {
      "question": "Which of these waves can travel through a vacuum?",
      "options": [
        "Seismic waves",
        "Water waves",
        "Sound waves",
        "Light waves"
      ],
      "correct": 3,
      "explanation": "Electromagnetic waves (light) can travel through vacuum"
    },
    {
      "question": "The pressure in a liquid increases with?",
      "options": [
        "Colour of liquid",
        "Depth",
        "Height above surface",
        "Width of container"
      ],
      "correct": 1,
      "explanation": "Pressure increases with depth in a liquid"
    },
    {
      "question": "Newton's third law states that action and reaction are?",
      "options": [
        "Always zero",
        "Equal and opposite",
        "Unequal",
        "Equal and in the same direction"
      ],
      "correct": 1,
      "explanation": "Action and reaction are equal and opposite"
    },
    {
      "question": "The device used to measure potential difference is?",
      "options": [
        "Ammeter",
        "Galvanometer",
        "Voltmeter",
        "Ohmmeter"
      ],
      "correct": 2,
      "explanation": "Voltmeter measures potential difference"
    },
    {
      "question": "Heat transfer by movement of fluids is called?",
      "options": [
        "Evaporation",
        "Radiation",
        "Convection",
        "Conduction"
      ],
      "correct": 2,
      "explanation": "Convection is heat transfer by fluid movement"
    },
    {
      "question": "The focal length of a plane mirror is?",
      "options": [
        "Zero",
        "Negative",
        "Infinity",
        "One"
      ],
      "correct": 2,
      "explanation": "Plane mirrors have infinite focal length"
    },
    {
      "question": "Which particle has a negative charge?",
      "options": [
        "Proton",
        "Electron",
        "Nucleus",
        "Neutron"
      ],
      "correct": 1,
      "explanation": "Electrons are negatively charged"
    },
    {
      "question": "The energy stored in a stretched rubber band is?",
      "options": [
        "Chemical energy",
        "Elastic potential energy",
        "Nuclear energy",
        "Kinetic energy"
      ],
      "correct": 1,
      "explanation": "Stretched rubber has elastic potential energy"
    },
    {
      "question": "A fuse is used in an electric circuit to?",
      "options": [
        "Store charge",
        "Increase current",
        "Prevent excessive current",
        "Decrease voltage"
      ],
      "correct": 2,
      "explanation": "Fuse protects the circuit from high current"
    },
    {
      "question": "The speed of sound is greatest in?",
      "options": [
        "Vacuum",
        "Gases",
        "Liquids",
        "Solids"
      ],
      "correct": 3,
      "explanation": "Sound travels fastest in solids"
    },
    {
      "question": "Which of the following is a vector quantity?",
      "options": [
        "Time",
        "Speed",
        "Mass",
        "Velocity"
      ],
      "correct": 3,
      "explanation": "Velocity has both magnitude and direction"
    },
    {
      "question": "The process of coating a metal with another metal using electricity is?",
      "options": [
        "Electroplating",
        "Soldering",
        "Welding",
        "Galvanizing"
      ],
      "correct": 0,
      "explanation": "Electroplating uses electricity to coat metals"
    },
    {
      "question": "The unit of magnetic flux density is?",
      "options": [
        "Tesla",
        "Henry",
        "Weber",
        "Farad"
      ],
      "correct": 0,
      "explanation": "Magnetic flux density is measured in Tesla"
    },
    {
      "question": "When the temperature of a gas increases at constant pressure, its volume?",
      "options": [
        "Becomes zero",
        "Remains constant",
        "Increases",
        "Decreases"
      ],
      "correct": 2,
      "explanation": "Charles' law: volume increases with temperature"
    },
    {
      "question": "The primary colours of light are?",
      "options": [
        "Red, Yellow, Blue",
        "Cyan, Magenta, Yellow",
        "Red, Green, Yellow",
        "Red, Green, Blue"
      ],
      "correct": 3,
      "explanation": "Primary colours of light are R, G, B"
    },
    {
      "question": "An object is said to be in equilibrium when?",
      "options": [
        "It has large mass",
        "It is moving fast",
        "Net force on it is zero",
        "It is accelerating"
      ],
      "correct": 2,
      "explanation": "Equilibrium means net force (and net torque) is zero"
    },
    {
      "question": "The frequency of mains electricity in Nigeria is?",
      "options": [
        "40 Hz",
        "50 Hz",
        "60 Hz",
        "100 Hz"
      ],
      "correct": 1,
      "explanation": "Nigeria uses 50 Hz mains frequency"
    },
    {
      "question": "Which of these is not an electromagnetic wave?",
      "options": [
        "Radio wave",
        "Sound wave",
        "Light",
        "X-ray"
      ],
      "correct": 1,
      "explanation": "Sound is a mechanical wave, not electromagnetic"
    },
    {
      "question": "The potential energy of a body of mass m at height h is?",
      "options": [
        "½mv²",
        "ma",
        "Fd",
        "mgh"
      ],
      "correct": 3,
      "explanation": "PE = mgh"
    },
    {
      "question": "A body moving with constant speed in a circular path has?",
      "options": [
        "Zero acceleration",
        "Constant velocity",
        "Zero force",
        "Changing velocity"
      ],
      "correct": 3,
      "explanation": "Direction changes, so velocity changes"
    },
    {
      "question": "The instrument used to see distant objects is?",
      "options": [
        "Periscope",
        "Spectroscope",
        "Microscope",
        "Telescope"
      ],
      "correct": 3,
      "explanation": "Telescope is used for distant objects"
    },
    {
      "question": "The rate of doing work is called?",
      "options": [
        "Energy",
        "Force",
        "Power",
        "Momentum"
      ],
      "correct": 2,
      "explanation": "Power is the rate of doing work"
    },
    {
      "question": "Which of the following is a unit of density?",
      "options": [
        "J/s",
        "N/m²",
        "kg/m",
        "kg/m³"
      ],
      "correct": 3,
      "explanation": "Density = mass/volume → kg/m³"
    },
    {
      "question": "A body weighs less in water than in air because of?",
      "options": [
        "Friction",
        "Gravity reduction",
        "Upthrust",
        "Viscosity"
      ],
      "correct": 2,
      "explanation": "Upthrust reduces the apparent weight"
    },
    {
      "question": "The law of reflection states that?",
      "options": [
        "Light bends in water",
        "Light travels in a straight line",
        "Angle of incidence equals angle of reflection",
        "Light can be polarized"
      ],
      "correct": 2,
      "explanation": "i = r is the law of reflection"
    },
    {
      "question": "Which of these is used to measure very high temperatures?",
      "options": [
        "Pyrometer",
        "Barometer",
        "Hygrometer",
        "Thermometer"
      ],
      "correct": 0,
      "explanation": "Pyrometers measure high temperatures"
    },
    {
      "question": "The energy of a photon is given by?",
      "options": [
        "hf",
        "mc²",
        "mgh",
        "½mv²"
      ],
      "correct": 0,
      "explanation": "E = hf (Planck's equation)"
    },
    {
      "question": "A step-up transformer?",
      "options": [
        "Decreases voltage",
        "Increases current only",
        "Has equal turns",
        "Increases voltage"
      ],
      "correct": 3,
      "explanation": "Step-up increases voltage"
    },
    {
      "question": "The force that keeps planets in orbit is?",
      "options": [
        "Nuclear force",
        "Gravitational force",
        "Frictional force",
        "Magnetic force"
      ],
      "correct": 1,
      "explanation": "Gravity keeps planets in orbit"
    },
    {
      "question": "Which of the following is a longitudinal wave?",
      "options": [
        "Light wave",
        "Water wave (surface)",
        "Sound wave",
        "Radio wave"
      ],
      "correct": 2,
      "explanation": "Sound is a longitudinal wave"
    },
    {
      "question": "The boiling point of water decreases as?",
      "options": [
        "Pressure decreases",
        "Mass increases",
        "Pressure increases",
        "Volume increases"
      ],
      "correct": 0,
      "explanation": "Lower pressure → lower boiling point"
    },
    {
      "question": "An object is placed at the focus of a concave mirror. The image is?",
      "options": [
        "At the pole",
        "At infinity",
        "Behind the mirror",
        "At the centre of curvature"
      ],
      "correct": 1,
      "explanation": "Object at F → image at infinity"
    },
    {
      "question": "The unit of electric potential is?",
      "options": [
        "Volt",
        "Watt",
        "Ohm",
        "Ampere"
      ],
      "correct": 0,
      "explanation": "Potential difference is measured in Volts"
    },
    {
      "question": "Which material is used as a moderator in nuclear reactors?",
      "options": [
        "Graphite",
        "Uranium",
        "Lead",
        "Iron"
      ],
      "correct": 0,
      "explanation": "Graphite is commonly used as a moderator"
    },
    {
      "question": "The acceleration of free fall is independent of?",
      "options": [
        "Height",
        "Mass of the object",
        "Velocity",
        "Time"
      ],
      "correct": 1,
      "explanation": "All objects fall with same acceleration (ignoring air resistance)"
    },
    {
      "question": "A ammeter is always connected in?",
      "options": [
        "Series",
        "Parallel",
        "Either way",
        "Diagonal"
      ],
      "correct": 0,
      "explanation": "Ammeter is connected in series"
    },
    {
      "question": "The phenomenon of light bending around obstacles is?",
      "options": [
        "Diffraction",
        "Dispersion",
        "Reflection",
        "Refraction"
      ],
      "correct": 0,
      "explanation": "Diffraction is bending around obstacles"
    },
    {
      "question": "Which of the following has the highest penetrating power?",
      "options": [
        "Protons",
        "Beta particles",
        "Alpha particles",
        "Gamma rays"
      ],
      "correct": 3,
      "explanation": "Gamma rays are most penetrating"
    },
    {
      "question": "The work done by a force of 10N moving an object 5m in its direction is?",
      "options": [
        "0.5 J",
        "2 J",
        "50 J",
        "15 J"
      ],
      "correct": 2,
      "explanation": "Work = force × distance = 50 J"
    },
    {
      "question": "A body of mass 2kg moving at 3m/s has kinetic energy of?",
      "options": [
        "18 J",
        "6 J",
        "9 J",
        "3 J"
      ],
      "correct": 2,
      "explanation": "KE = ½ × 2 × 9 = 9 J"
    },
    {
      "question": "The centre of gravity of a uniform rod is at?",
      "options": [
        "Its midpoint",
        "One end",
        "A quarter length",
        "Outside the rod"
      ],
      "correct": 0,
      "explanation": "For a uniform rod, CG is at the centre"
    },
    {
      "question": "Which of these is a renewable energy source?",
      "options": [
        "Wind energy",
        "Petrol",
        "Coal",
        "Natural gas"
      ],
      "correct": 0,
      "explanation": "Wind is renewable"
    },
    {
      "question": "The resistance of a conductor increases when?",
      "options": [
        "Area increases",
        "Temperature increases",
        "Temperature decreases",
        "Length decreases"
      ],
      "correct": 1,
      "explanation": "Resistance of metals increases with temperature"
    },
    {
      "question": "A real image can be?",
      "options": [
        "Only virtual",
        "Projected on a screen",
        "Always upright",
        "Never magnified"
      ],
      "correct": 1,
      "explanation": "Real images can be caught on a screen"
    },
    {
      "question": "The time taken for one complete oscillation is called?",
      "options": [
        "Amplitude",
        "Frequency",
        "Period",
        "Wavelength"
      ],
      "correct": 2,
      "explanation": "Period is the time for one oscillation"
    },
    {
      "question": "Which of the following is conserved in an inelastic collision?",
      "options": [
        "Momentum",
        "Kinetic energy",
        "Both",
        "Neither"
      ],
      "correct": 0,
      "explanation": "Momentum is conserved; kinetic energy is not"
    },
    {
      "question": "Which of the following is a unit of frequency?",
      "options": [
        "Hertz",
        "Joule",
        "Meter",
        "Second"
      ],
      "correct": 0,
      "explanation": "Frequency is measured in Hertz"
    },
    {
      "question": "The force that attracts objects towards the centre of the earth is?",
      "options": [
        "Friction",
        "Magnetism",
        "Tension",
        "Gravity"
      ],
      "correct": 3,
      "explanation": "Gravity pulls objects towards the earth"
    },
    {
      "question": "A voltmeter is connected in?",
      "options": [
        "Series",
        "Diagonal",
        "Either way",
        "Parallel"
      ],
      "correct": 3,
      "explanation": "Voltmeter is connected in parallel"
    },
    {
      "question": "Which of these is an example of potential energy?",
      "options": [
        "A burning candle",
        "A flowing river",
        "A moving car",
        "A stretched spring"
      ],
      "correct": 3,
      "explanation": "Stretched spring has elastic potential energy"
    },
    {
      "question": "The SI unit of mass is?",
      "options": [
        "Gram",
        "Newton",
        "Pound",
        "Kilogram"
      ],
      "correct": 3,
      "explanation": "SI unit of mass is kilogram"
    },
    {
      "question": "Light travels in a?",
      "options": [
        "Straight line",
        "Zigzag path",
        "Curved path",
        "Circle"
      ],
      "correct": 0,
      "explanation": "Light travels in straight lines in a uniform medium"
    },
    {
      "question": "Which of the following is a non-renewable energy source?",
      "options": [
        "Solar",
        "Wind",
        "Hydro",
        "Coal"
      ],
      "correct": 3,
      "explanation": "Coal is non-renewable"
    },
    {
      "question": "The image formed by a convex mirror is always?",
      "options": [
        "Real and magnified",
        "Real and inverted",
        "Virtual and magnified",
        "Virtual and diminished"
      ],
      "correct": 3,
      "explanation": "Convex mirrors always form virtual, erect, diminished images"
    },
    {
      "question": "Which particle is found in the nucleus of an atom?",
      "options": [
        "Photon",
        "Electron only",
        "Positron",
        "Proton"
      ],
      "correct": 3,
      "explanation": "Protons (and neutrons) are in the nucleus"
    },
    {
      "question": "The rate of change of displacement is?",
      "options": [
        "Speed",
        "Force",
        "Velocity",
        "Acceleration"
      ],
      "correct": 2,
      "explanation": "Velocity is rate of change of displacement"
    },
    {
      "question": "A device that stores electric charge is?",
      "options": [
        "Inductor",
        "Capacitor",
        "Resistor",
        "Transformer"
      ],
      "correct": 1,
      "explanation": "Capacitors store charge"
    },
    {
      "question": "Which of these materials is a poor conductor of heat?",
      "options": [
        "Plastic",
        "Iron",
        "Aluminium",
        "Copper"
      ],
      "correct": 0,
      "explanation": "Plastic is a thermal insulator"
    },
    {
      "question": "The unit of work is the same as the unit of?",
      "options": [
        "Force",
        "Power",
        "Energy",
        "Momentum"
      ],
      "correct": 2,
      "explanation": "Work and energy are both measured in Joules"
    },
    {
      "question": "Sound waves are produced by?",
      "options": [
        "Magnetic fields",
        "Hot objects only",
        "Stationary objects",
        "Vibrating objects"
      ],
      "correct": 3,
      "explanation": "Sound is produced by vibration"
    },
    {
      "question": "Which of the following affects the resistance of a wire?",
      "options": [
        "Shape only",
        "Colour only",
        "Weight only",
        "Length and thickness"
      ],
      "correct": 3,
      "explanation": "Resistance depends on length, area, and material"
    },
    {
      "question": "The process of heat transfer without a medium is?",
      "options": [
        "Convection",
        "Radiation",
        "Evaporation",
        "Conduction"
      ],
      "correct": 1,
      "explanation": "Radiation does not need a medium"
    },
    {
      "question": "A body of mass 5kg has weight approximately?",
      "options": [
        "500 N",
        "0.5 N",
        "50 N",
        "5 N"
      ],
      "correct": 2,
      "explanation": "Weight ≈ mg = 5 × 10 = 50 N"
    },
    {
      "question": "Which of these is used to measure current?",
      "options": [
        "Ammeter",
        "Ohmmeter",
        "Voltmeter",
        "Wattmeter"
      ],
      "correct": 0,
      "explanation": "Ammeter measures current"
    },
    {
      "question": "The refractive index of a medium is the ratio of?",
      "options": [
        "Speed of light in vacuum to speed in medium",
        "Wavelength to frequency",
        "Frequency to wavelength",
        "Speed in medium to speed in vacuum"
      ],
      "correct": 0,
      "explanation": "n = c / v"
    },
    {
      "question": "An example of a lever of the first class is?",
      "options": [
        "Wheelbarrow",
        "See-saw",
        "Fishing rod",
        "Tongs"
      ],
      "correct": 1,
      "explanation": "See-saw has fulcrum in the middle"
    },
    {
      "question": "The frequency of a wave is the reciprocal of its?",
      "options": [
        "Period",
        "Wavelength",
        "Amplitude",
        "Speed"
      ],
      "correct": 0,
      "explanation": "Frequency = 1 / Period"
    },
    {
      "question": "Which of the following is true about magnetic field lines?",
      "options": [
        "They are visible to the eye",
        "They never cross each other",
        "They start from south pole",
        "They always cross"
      ],
      "correct": 1,
      "explanation": "Magnetic field lines never intersect"
    },
    {
      "question": "The energy conversion in a microphone is?",
      "options": [
        "Light to electrical",
        "Heat to sound",
        "Electrical to sound",
        "Sound to electrical"
      ],
      "correct": 3,
      "explanation": "Microphone converts sound energy to electrical energy"
    },
    {
      "question": "A body is said to be in unstable equilibrium when?",
      "options": [
        "CG remains at same height",
        "Its centre of gravity is raised on slight displacement",
        "CG is lowered",
        "It cannot be displaced"
      ],
      "correct": 1,
      "explanation": "Unstable equilibrium: CG rises when displaced"
    },
    {
      "question": "Which of these is measured in Pascals?",
      "options": [
        "Power",
        "Force",
        "Pressure",
        "Energy"
      ],
      "correct": 2,
      "explanation": "Pressure is measured in Pascals"
    },
    {
      "question": "Which of the following is a scalar quantity?",
      "options": [
        "Distance",
        "Velocity",
        "Acceleration",
        "Displacement"
      ],
      "correct": 0,
      "explanation": "Distance has only magnitude"
    },
    {
      "question": "The SI unit of time is?",
      "options": [
        "Minute",
        "Second",
        "Hour",
        "Day"
      ],
      "correct": 1,
      "explanation": "SI unit of time is the second"
    },
    {
      "question": "A body moving with uniform velocity has?",
      "options": [
        "Negative acceleration",
        "Zero acceleration",
        "Constant acceleration",
        "Increasing acceleration"
      ],
      "correct": 1,
      "explanation": "Uniform velocity means zero acceleration"
    },
    {
      "question": "Which of these is used to measure atmospheric humidity?",
      "options": [
        "Thermometer",
        "Manometer",
        "Hygrometer",
        "Barometer"
      ],
      "correct": 2,
      "explanation": "Hygrometer measures humidity"
    },
    {
      "question": "The force between two charges is given by?",
      "options": [
        "Ohm's law",
        "Newton's law of gravity",
        "Faraday's law",
        "Coulomb's law"
      ],
      "correct": 3,
      "explanation": "Coulomb's law describes force between charges"
    },
    {
      "question": "Which colour is at the top of a rainbow?",
      "options": [
        "Red",
        "Blue",
        "Green",
        "Violet"
      ],
      "correct": 0,
      "explanation": "Red is at the top of a rainbow"
    },
    {
      "question": "The energy stored in a battery is?",
      "options": [
        "Kinetic energy",
        "Nuclear energy",
        "Chemical energy",
        "Sound energy"
      ],
      "correct": 2,
      "explanation": "Batteries store chemical energy"
    },
    {
      "question": "A concave mirror can form?",
      "options": [
        "Both real and virtual images",
        "Only virtual images",
        "Only real images",
        "No image"
      ],
      "correct": 0,
      "explanation": "Concave mirrors can form both types of images"
    },
    {
      "question": "The unit of electric power is?",
      "options": [
        "Volt",
        "Watt",
        "Joule",
        "Ampere"
      ],
      "correct": 1,
      "explanation": "Power is measured in Watts"
    },
    {
      "question": "Which of the following is true for a liquid?",
      "options": [
        "It has neither shape nor volume",
        "It has definite shape only",
        "It has definite shape and volume",
        "It has definite volume but no definite shape"
      ],
      "correct": 3,
      "explanation": "Liquids have fixed volume but take the shape of the container"
    },
    {
      "question": "The process of heat transfer in solids is mainly by?",
      "options": [
        "Convection",
        "Radiation",
        "Evaporation",
        "Conduction"
      ],
      "correct": 3,
      "explanation": "Solids transfer heat mainly by conduction"
    },
    {
      "question": "Which of these particles has the least mass?",
      "options": [
        "Proton",
        "Neutron",
        "Electron",
        "Alpha particle"
      ],
      "correct": 2,
      "explanation": "Electron is the lightest"
    },
    {
      "question": "The product of force and time is?",
      "options": [
        "Energy",
        "Impulse",
        "Power",
        "Momentum"
      ],
      "correct": 1,
      "explanation": "Impulse = force × time"
    },
    {
      "question": "A transformer cannot work with?",
      "options": [
        "Alternating current",
        "Low voltage",
        "High voltage",
        "Direct current"
      ],
      "correct": 3,
      "explanation": "Transformers require changing current (AC)"
    },
    {
      "question": "Which of the following is an electromagnetic wave?",
      "options": [
        "X-ray",
        "Sound wave",
        "Water wave",
        "Seismic wave"
      ],
      "correct": 0,
      "explanation": "X-rays are electromagnetic waves"
    },
    {
      "question": "The acceleration due to gravity on the moon is?",
      "options": [
        "More than on earth",
        "Same as on earth",
        "Zero",
        "Less than on earth"
      ],
      "correct": 3,
      "explanation": "Moon's gravity is about 1/6 of earth's"
    },
    {
      "question": "Which instrument is used to measure small thicknesses?",
      "options": [
        "Metre rule",
        "Vernier only",
        "Micrometer screw gauge",
        "Measuring tape"
      ],
      "correct": 2,
      "explanation": "Micrometer is used for small thicknesses"
    },
    {
      "question": "The resistance of an ideal voltmeter is?",
      "options": [
        "Very small",
        "One ohm",
        "Zero",
        "Infinite"
      ],
      "correct": 3,
      "explanation": "Ideal voltmeter has infinite resistance"
    },
    {
      "question": "A body at rest has?",
      "options": [
        "Zero kinetic energy",
        "Infinite energy",
        "Zero potential energy always",
        "Maximum kinetic energy"
      ],
      "correct": 0,
      "explanation": "At rest, velocity is zero so KE is zero"
    },
    {
      "question": "Which of these is a unit of magnetic field strength?",
      "options": [
        "Weber",
        "Tesla",
        "Henry",
        "Farad"
      ],
      "correct": 1,
      "explanation": "Magnetic field strength can be in Tesla"
    },
    {
      "question": "The phenomenon of splitting of white light is?",
      "options": [
        "Refraction",
        "Dispersion",
        "Diffraction",
        "Reflection"
      ],
      "correct": 1,
      "explanation": "Dispersion splits white light into colours"
    },
    {
      "question": "Which of the following is conserved in all collisions?",
      "options": [
        "Temperature",
        "Momentum",
        "Potential energy",
        "Kinetic energy"
      ],
      "correct": 1,
      "explanation": "Momentum is always conserved"
    },
    {
      "question": "The focal length of a convex lens is?",
      "options": [
        "Infinite",
        "Zero",
        "Positive",
        "Negative"
      ],
      "correct": 2,
      "explanation": "By convention, convex lens has positive focal length"
    },
    {
      "question": "Heat capacity is measured in?",
      "options": [
        "W",
        "N",
        "J only",
        "J/K or J/°C"
      ],
      "correct": 3,
      "explanation": "Heat capacity unit is J/K or J/°C"
    },
    {
      "question": "Which of these is an example of periodic motion?",
      "options": [
        "A rocket in space",
        "A car moving with constant speed on a straight road",
        "A free-falling body",
        "Simple pendulum"
      ],
      "correct": 3,
      "explanation": "Pendulum motion is periodic"
    },
    {
      "question": "Which of the following is a unit of power?",
      "options": [
        "Joule",
        "Newton",
        "Pascal",
        "Watt"
      ],
      "correct": 3,
      "explanation": "Power is measured in Watts"
    },
    {
      "question": "The force that opposes the relative motion of two surfaces is?",
      "options": [
        "Tension",
        "Upthrust",
        "Friction",
        "Gravity"
      ],
      "correct": 2,
      "explanation": "Friction opposes relative motion"
    },
    {
      "question": "A body in free fall experiences?",
      "options": [
        "Zero force",
        "Acceleration due to gravity",
        "Upward force only",
        "Constant speed always"
      ],
      "correct": 1,
      "explanation": "Free fall is under gravity"
    },
    {
      "question": "Which of these is used to measure gas pressure?",
      "options": [
        "Hygrometer",
        "Thermometer",
        "Ammeter",
        "Manometer"
      ],
      "correct": 3,
      "explanation": "Manometer measures gas pressure"
    },
    {
      "question": "The unit of electric charge is?",
      "options": [
        "Volt",
        "Ohm",
        "Coulomb",
        "Ampere"
      ],
      "correct": 2,
      "explanation": "Charge is measured in Coulombs"
    },
    {
      "question": "Which of the following is true about light?",
      "options": [
        "It cannot be reflected",
        "It needs air to travel",
        "It is a longitudinal wave",
        "It can travel through vacuum"
      ],
      "correct": 3,
      "explanation": "Light can travel through vacuum"
    },
    {
      "question": "The energy of a moving object is called?",
      "options": [
        "Chemical energy",
        "Potential energy",
        "Nuclear energy",
        "Kinetic energy"
      ],
      "correct": 3,
      "explanation": "Moving objects have kinetic energy"
    },
    {
      "question": "A plane mirror forms an image that is?",
      "options": [
        "Virtual and erect",
        "Real and erect",
        "Virtual and inverted",
        "Real and inverted"
      ],
      "correct": 0,
      "explanation": "Plane mirrors form virtual erect images"
    },
    {
      "question": "Which of these is a good conductor of electricity?",
      "options": [
        "Rubber",
        "Wood",
        "Plastic",
        "Copper"
      ],
      "correct": 3,
      "explanation": "Copper is a good conductor"
    },
    {
      "question": "The pressure exerted by a liquid depends on?",
      "options": [
        "Colour of liquid",
        "Shape of container only",
        "Volume only",
        "Depth and density"
      ],
      "correct": 3,
      "explanation": "Pressure = ρgh"
    },
    {
      "question": "Which of the following is a renewable source of energy?",
      "options": [
        "Natural gas",
        "Solar energy",
        "Petrol",
        "Coal"
      ],
      "correct": 1,
      "explanation": "Solar is renewable"
    },
    {
      "question": "The bending of light at the boundary of two media is?",
      "options": [
        "Reflection",
        "Diffraction",
        "Refraction",
        "Interference"
      ],
      "correct": 2,
      "explanation": "Refraction is bending at a boundary"
    },
    {
      "question": "Newton's second law relates force to?",
      "options": [
        "Mass and velocity",
        "Energy and power",
        "Weight and time",
        "Mass and acceleration"
      ],
      "correct": 3,
      "explanation": "F = ma"
    },
    {
      "question": "Which instrument measures current?",
      "options": [
        "Ohmmeter",
        "Voltmeter",
        "Ammeter",
        "Barometer"
      ],
      "correct": 2,
      "explanation": "Ammeter measures current"
    },
    {
      "question": "The speed of light is maximum in?",
      "options": [
        "Vacuum",
        "Glass",
        "Diamond",
        "Water"
      ],
      "correct": 0,
      "explanation": "Light is fastest in vacuum"
    },
    {
      "question": "A fuse wire is made of material with?",
      "options": [
        "High resistance only",
        "High melting point",
        "Low melting point",
        "Low density"
      ],
      "correct": 2,
      "explanation": "Fuse has low melting point"
    },
    {
      "question": "Which of these is a transverse wave?",
      "options": [
        "Ultrasound in air",
        "Sound wave",
        "Pressure wave in air",
        "Light wave"
      ],
      "correct": 3,
      "explanation": "Light is a transverse wave"
    },
    {
      "question": "The work done is maximum when the force is?",
      "options": [
        "Zero",
        "Perpendicular to displacement",
        "Opposite to displacement",
        "Parallel to displacement"
      ],
      "correct": 3,
      "explanation": "Work is maximum when cosθ = 1"
    },
    {
      "question": "Which of the following has no mass?",
      "options": [
        "Photon",
        "Electron",
        "Proton",
        "Neutron"
      ],
      "correct": 0,
      "explanation": "Photons are massless"
    },
    {
      "question": "The unit of frequency is?",
      "options": [
        "Hertz",
        "Second",
        "Meter",
        "Joule"
      ],
      "correct": 0,
      "explanation": "Frequency is in Hertz"
    },
    {
      "question": "An object weighs more at the poles than at the equator because?",
      "options": [
        "Temperature is lower",
        "Earth is farther at poles",
        "Air is denser at poles",
        "Gravity is stronger at poles"
      ],
      "correct": 3,
      "explanation": "Gravity is slightly stronger at poles"
    },
    {
      "question": "Which of these converts electrical energy to light energy?",
      "options": [
        "Battery",
        "Generator",
        "Electric motor",
        "Electric bulb"
      ],
      "correct": 3,
      "explanation": "Bulb converts electrical energy to light (and heat)"
    },
    {
      "question": "The time rate of change of momentum is equal to?",
      "options": [
        "Force",
        "Power",
        "Energy",
        "Velocity"
      ],
      "correct": 0,
      "explanation": "Force = rate of change of momentum"
    },
    {
      "question": "Which of the following is used in optical fibres?",
      "options": [
        "Total internal reflection",
        "Diffraction",
        "Polarization only",
        "Interference only"
      ],
      "correct": 0,
      "explanation": "Optical fibres use total internal reflection"
    },
    {
      "question": "A body is in equilibrium when the net force is?",
      "options": [
        "Zero",
        "Minimum but not zero",
        "Equal to weight",
        "Maximum"
      ],
      "correct": 0,
      "explanation": "Net force must be zero for equilibrium"
    },
    {
      "question": "Which of the following is a unit of energy?",
      "options": [
        "Pascal",
        "Watt",
        "Newton",
        "Joule"
      ],
      "correct": 3,
      "explanation": "Energy is measured in Joules"
    },
    {
      "question": "The force of attraction between the earth and an object is?",
      "options": [
        "Pressure",
        "Density",
        "Weight",
        "Mass"
      ],
      "correct": 2,
      "explanation": "Weight is the force of gravity"
    },
    {
      "question": "A body moving in a circle at constant speed has?",
      "options": [
        "Zero force",
        "Changing velocity",
        "Constant velocity",
        "Zero acceleration"
      ],
      "correct": 1,
      "explanation": "Direction changes so velocity changes"
    },
    {
      "question": "Which instrument is used to measure temperature?",
      "options": [
        "Hygrometer",
        "Manometer",
        "Barometer",
        "Thermometer"
      ],
      "correct": 3,
      "explanation": "Thermometer measures temperature"
    },
    {
      "question": "The unit of resistance is?",
      "options": [
        "Ampere",
        "Ohm",
        "Volt",
        "Watt"
      ],
      "correct": 1,
      "explanation": "Resistance is measured in Ohms"
    },
    {
      "question": "Which of the following can travel through vacuum?",
      "options": [
        "Water waves",
        "Seismic waves",
        "Light",
        "Sound"
      ],
      "correct": 2,
      "explanation": "Light can travel through vacuum"
    },
    {
      "question": "The energy possessed due to motion is?",
      "options": [
        "Kinetic energy",
        "Nuclear energy",
        "Chemical energy",
        "Potential energy"
      ],
      "correct": 0,
      "explanation": "Kinetic energy is energy of motion"
    },
    {
      "question": "A concave lens produces?",
      "options": [
        "Inverted image only",
        "Magnified image only",
        "Real image only",
        "Virtual image"
      ],
      "correct": 3,
      "explanation": "Concave lenses produce virtual images"
    },
    {
      "question": "Which of these is a poor conductor of electricity?",
      "options": [
        "Aluminium",
        "Copper",
        "Rubber",
        "Silver"
      ],
      "correct": 2,
      "explanation": "Rubber is an insulator"
    },
    {
      "question": "Pressure in a fluid increases with?",
      "options": [
        "Depth",
        "Temperature only",
        "Width",
        "Colour"
      ],
      "correct": 0,
      "explanation": "Pressure increases with depth"
    },
    {
      "question": "Which of the following is non-renewable?",
      "options": [
        "Wind energy",
        "Petroleum",
        "Solar energy",
        "Hydroelectricity"
      ],
      "correct": 1,
      "explanation": "Petroleum is non-renewable"
    },
    {
      "question": "The change in direction of light when it enters a different medium is?",
      "options": [
        "Diffraction",
        "Refraction",
        "Reflection",
        "Dispersion"
      ],
      "correct": 1,
      "explanation": "Refraction is the change in direction"
    },
    {
      "question": "Newton's first law is also called the law of?",
      "options": [
        "Acceleration",
        "Inertia",
        "Gravitation",
        "Action-reaction"
      ],
      "correct": 1,
      "explanation": "First law is law of inertia"
    },
    {
      "question": "Which device measures potential difference?",
      "options": [
        "Voltmeter",
        "Galvanometer",
        "Ammeter",
        "Ohmmeter"
      ],
      "correct": 0,
      "explanation": "Voltmeter measures potential difference"
    },
    {
      "question": "Sound travels fastest in?",
      "options": [
        "Liquids",
        "Vacuum",
        "Gases",
        "Solids"
      ],
      "correct": 3,
      "explanation": "Sound is fastest in solids"
    },
    {
      "question": "A fuse is used to?",
      "options": [
        "Protect the circuit",
        "Reduce voltage permanently",
        "Store energy",
        "Increase current"
      ],
      "correct": 0,
      "explanation": "Fuse protects against excess current"
    },
    {
      "question": "Which of these is a longitudinal wave?",
      "options": [
        "X-ray",
        "Radio wave",
        "Sound",
        "Light"
      ],
      "correct": 2,
      "explanation": "Sound is longitudinal"
    },
    {
      "question": "Work is done when a force causes?",
      "options": [
        "Only colour change",
        "Displacement",
        "No movement",
        "Only temperature change"
      ],
      "correct": 1,
      "explanation": "Work requires displacement in the direction of force"
    },
    {
      "question": "Which particle is positively charged?",
      "options": [
        "Electron",
        "Neutron",
        "Proton",
        "Photon"
      ],
      "correct": 2,
      "explanation": "Protons are positively charged"
    },
    {
      "question": "The unit of frequency is?",
      "options": [
        "Second",
        "Joule",
        "Hertz",
        "Meter"
      ],
      "correct": 2,
      "explanation": "Frequency is measured in Hertz"
    },
    {
      "question": "Objects fall to the earth because of?",
      "options": [
        "Friction",
        "Magnetism",
        "Air pressure only",
        "Gravity"
      ],
      "correct": 3,
      "explanation": "Gravity pulls objects down"
    },
    {
      "question": "Which of these converts electrical energy to mechanical energy?",
      "options": [
        "Generator",
        "Electric motor",
        "Battery",
        "Transformer"
      ],
      "correct": 1,
      "explanation": "Motor converts electrical to mechanical energy"
    },
    {
      "question": "Momentum is the product of mass and?",
      "options": [
        "Time",
        "Force",
        "Velocity",
        "Acceleration"
      ],
      "correct": 2,
      "explanation": "Momentum = mass × velocity"
    },
    {
      "question": "Optical fibres work on the principle of?",
      "options": [
        "Total internal reflection",
        "Polarization",
        "Interference",
        "Diffraction"
      ],
      "correct": 0,
      "explanation": "Total internal reflection is used in optical fibres"
    },
    {
      "question": "A system is in equilibrium when net force is?",
      "options": [
        "Equal to weight",
        "Maximum",
        "Zero",
        "Constant but not zero"
      ],
      "correct": 2,
      "explanation": "Net force is zero in equilibrium"
    }
  ],
  "chm": [
    {
      "question": "The smallest particle of an element is?",
      "options": [
        "Atom",
        "Electron",
        "Ion",
        "Molecule"
      ],
      "correct": 0,
      "explanation": "An atom is the smallest particle of an element"
    },
    {
      "question": "The chemical symbol for Sodium is?",
      "options": [
        "Sd",
        "Na",
        "So",
        "S"
      ],
      "correct": 1,
      "explanation": "Sodium is Na (from Natrium)"
    },
    {
      "question": "The pH of a neutral solution is?",
      "options": [
        "14",
        "1",
        "7",
        "0"
      ],
      "correct": 2,
      "explanation": "Neutral solutions have pH = 7"
    },
    {
      "question": "Acids turn blue litmus paper?",
      "options": [
        "Red",
        "Yellow",
        "Blue",
        "Green"
      ],
      "correct": 0,
      "explanation": "Acids turn blue litmus red"
    },
    {
      "question": "The most abundant gas in the air is?",
      "options": [
        "Nitrogen",
        "Carbon dioxide",
        "Oxygen",
        "Hydrogen"
      ],
      "correct": 0,
      "explanation": "Nitrogen makes up about 78% of air"
    },
    {
      "question": "The chemical formula of water is?",
      "options": [
        "OH",
        "H₂O",
        "H₂O₂",
        "HO₂"
      ],
      "correct": 1,
      "explanation": "Water is H₂O"
    },
    {
      "question": "Which of these is an alkaline earth metal?",
      "options": [
        "Iron",
        "Copper",
        "Calcium",
        "Sodium"
      ],
      "correct": 2,
      "explanation": "Calcium belongs to Group 2 (alkaline earth metals)"
    },
    {
      "question": "The process of solid changing directly to gas is?",
      "options": [
        "Sublimation",
        "Condensation",
        "Evaporation",
        "Melting"
      ],
      "correct": 0,
      "explanation": "Sublimation is solid → gas"
    },
    {
      "question": "Rusting of iron is an example of?",
      "options": [
        "Oxidation",
        "Polymerization",
        "Reduction",
        "Neutralization"
      ],
      "correct": 0,
      "explanation": "Rusting involves oxidation of iron"
    },
    {
      "question": "The gas used in balloons that makes them float is?",
      "options": [
        "Helium",
        "Chlorine",
        "Oxygen",
        "Nitrogen"
      ],
      "correct": 0,
      "explanation": "Helium is less dense than air"
    },
    {
      "question": "The valency of carbon is?",
      "options": [
        "4",
        "2",
        "1",
        "3"
      ],
      "correct": 0,
      "explanation": "Carbon has valency of 4"
    },
    {
      "question": "Which element has the chemical symbol Fe?",
      "options": [
        "Francium",
        "Iron",
        "Fermium",
        "Fluorine"
      ],
      "correct": 1,
      "explanation": "Fe stands for Iron (Ferrum)"
    },
    {
      "question": "A substance that speeds up a chemical reaction is called?",
      "options": [
        "Solvent",
        "Solute",
        "Catalyst",
        "Inhibitor"
      ],
      "correct": 2,
      "explanation": "A catalyst increases reaction rate"
    },
    {
      "question": "The common name for sodium chloride is?",
      "options": [
        "Vinegar",
        "Sugar",
        "Table salt",
        "Baking soda"
      ],
      "correct": 2,
      "explanation": "NaCl is common salt"
    },
    {
      "question": "Which of these is a noble gas?",
      "options": [
        "Oxygen",
        "Chlorine",
        "Neon",
        "Nitrogen"
      ],
      "correct": 2,
      "explanation": "Neon is a noble gas (Group 0)"
    },
    {
      "question": "The process by which plants make food is?",
      "options": [
        "Fermentation",
        "Photosynthesis",
        "Transpiration",
        "Respiration"
      ],
      "correct": 1,
      "explanation": "Photosynthesis produces food in plants"
    },
    {
      "question": "An acid is a substance that produces ______ in water",
      "options": [
        "Salt",
        "Oxygen",
        "OH- ions",
        "H+ ions"
      ],
      "correct": 3,
      "explanation": "Acids produce hydrogen ions (H+)"
    },
    {
      "question": "The chemical formula of carbon dioxide is?",
      "options": [
        "C₂O₂",
        "C₂O",
        "CO₂",
        "CO"
      ],
      "correct": 2,
      "explanation": "Carbon dioxide is CO₂"
    },
    {
      "question": "Which metal is liquid at room temperature?",
      "options": [
        "Iron",
        "Sodium",
        "Mercury",
        "Gold"
      ],
      "correct": 2,
      "explanation": "Mercury is liquid at room temperature"
    },
    {
      "question": "The number of protons in an atom is called?",
      "options": [
        "Mass number",
        "Valency",
        "Atomic number",
        "Isotope"
      ],
      "correct": 2,
      "explanation": "Atomic number = number of protons"
    },
    {
      "question": "Hard water contains salts of?",
      "options": [
        "Potassium only",
        "Iron only",
        "Sodium only",
        "Calcium and Magnesium"
      ],
      "correct": 3,
      "explanation": "Hardness is caused mainly by Ca and Mg salts"
    },
    {
      "question": "The process of removing hardness of water is called?",
      "options": [
        "Filtration",
        "Softening",
        "Chlorination",
        "Distillation"
      ],
      "correct": 1,
      "explanation": "Removing hardness is called softening"
    },
    {
      "question": "Which of these is an example of a compound?",
      "options": [
        "Gold",
        "Iron",
        "Oxygen",
        "Water"
      ],
      "correct": 3,
      "explanation": "Water (H₂O) is a compound"
    },
    {
      "question": "The lightest element is?",
      "options": [
        "Oxygen",
        "Helium",
        "Lithium",
        "Hydrogen"
      ],
      "correct": 3,
      "explanation": "Hydrogen is the lightest element"
    },
    {
      "question": "Bases feel?",
      "options": [
        "Sweet",
        "Slippery",
        "Rough",
        "Sour"
      ],
      "correct": 1,
      "explanation": "Bases feel soapy/slippery to touch"
    },
    {
      "question": "Which of the following is a mixture?",
      "options": [
        "Salt",
        "Sugar",
        "Air",
        "Water"
      ],
      "correct": 2,
      "explanation": "Air is a mixture of gases"
    },
    {
      "question": "The chemical symbol for Potassium is?",
      "options": [
        "Pt",
        "Po",
        "K",
        "P"
      ],
      "correct": 2,
      "explanation": "Potassium is K (from Kalium)"
    },
    {
      "question": "A solution with pH less than 7 is?",
      "options": [
        "Basic",
        "Alkaline",
        "Neutral",
        "Acidic"
      ],
      "correct": 3,
      "explanation": "pH < 7 indicates an acid"
    },
    {
      "question": "Which gas is produced when an acid reacts with a metal?",
      "options": [
        "Carbon dioxide",
        "Nitrogen",
        "Hydrogen",
        "Oxygen"
      ],
      "correct": 2,
      "explanation": "Acid + metal → salt + hydrogen"
    },
    {
      "question": "The process of separating a solid from a liquid by pouring off the liquid is?",
      "options": [
        "Evaporation",
        "Decantation",
        "Distillation",
        "Filtration"
      ],
      "correct": 1,
      "explanation": "Decantation is carefully pouring off the liquid"
    },
    {
      "question": "Which of these is an element?",
      "options": [
        "Oxygen",
        "Air",
        "Salt",
        "Water"
      ],
      "correct": 0,
      "explanation": "Oxygen is an element"
    },
    {
      "question": "The atomic number of carbon is?",
      "options": [
        "6",
        "12",
        "8",
        "14"
      ],
      "correct": 0,
      "explanation": "Carbon has 6 protons"
    },
    {
      "question": "Which of the following is used in the manufacture of ammonia?",
      "options": [
        "Haber process",
        "Contact process",
        "Ostwald process",
        "Solvay process"
      ],
      "correct": 0,
      "explanation": "Haber process is used for ammonia"
    },
    {
      "question": "The change of state from gas to liquid is called?",
      "options": [
        "Condensation",
        "Evaporation",
        "Melting",
        "Sublimation"
      ],
      "correct": 0,
      "explanation": "Gas to liquid is condensation"
    },
    {
      "question": "Which of these is a halogen?",
      "options": [
        "Calcium",
        "Iron",
        "Chlorine",
        "Sodium"
      ],
      "correct": 2,
      "explanation": "Chlorine is in Group 7 (halogens)"
    },
    {
      "question": "The main constituent of natural gas is?",
      "options": [
        "Butane",
        "Propane",
        "Ethane",
        "Methane"
      ],
      "correct": 3,
      "explanation": "Natural gas is mainly methane"
    },
    {
      "question": "An example of a physical change is?",
      "options": [
        "Burning of paper",
        "Melting of ice",
        "Rusting of iron",
        "Cooking of egg"
      ],
      "correct": 1,
      "explanation": "Melting is a physical change"
    },
    {
      "question": "The chemical formula of sulphuric acid is?",
      "options": [
        "HNO₃",
        "HCl",
        "H₂CO₃",
        "H₂SO₄"
      ],
      "correct": 3,
      "explanation": "Sulphuric acid is H₂SO₄"
    },
    {
      "question": "Which metal is extracted from bauxite?",
      "options": [
        "Aluminium",
        "Iron",
        "Copper",
        "Zinc"
      ],
      "correct": 0,
      "explanation": "Bauxite is the ore of aluminium"
    },
    {
      "question": "The process by which green plants remove carbon dioxide from the air is?",
      "options": [
        "Transpiration",
        "Photosynthesis",
        "Combustion",
        "Respiration"
      ],
      "correct": 1,
      "explanation": "Photosynthesis uses CO₂"
    },
    {
      "question": "A substance that can act as both acid and base is called?",
      "options": [
        "Neutral",
        "Indicator",
        "Amphoteric",
        "Catalyst"
      ],
      "correct": 2,
      "explanation": "Amphoteric substances can act as acid or base"
    },
    {
      "question": "Which of the following is a greenhouse gas?",
      "options": [
        "Nitrogen",
        "Hydrogen",
        "Carbon dioxide",
        "Oxygen"
      ],
      "correct": 2,
      "explanation": "CO₂ is a major greenhouse gas"
    },
    {
      "question": "The number of electrons in a neutral atom is equal to?",
      "options": [
        "Mass number",
        "Number of protons",
        "Number of neutrons",
        "Atomic mass"
      ],
      "correct": 1,
      "explanation": "In a neutral atom, electrons = protons"
    },
    {
      "question": "Which method is used to separate petroleum into its components?",
      "options": [
        "Decantation",
        "Fractional distillation",
        "Filtration",
        "Evaporation"
      ],
      "correct": 1,
      "explanation": "Petroleum is separated by fractional distillation"
    },
    {
      "question": "The chemical name for baking soda is?",
      "options": [
        "Sodium chloride",
        "Sodium carbonate",
        "Sodium hydroxide",
        "Sodium hydrogen carbonate"
      ],
      "correct": 3,
      "explanation": "Baking soda is NaHCO₃"
    },
    {
      "question": "Which of these is a property of metals?",
      "options": [
        "They are poor conductors of heat",
        "They are dull",
        "They conduct electricity",
        "They are brittle"
      ],
      "correct": 2,
      "explanation": "Metals are good conductors of electricity"
    },
    {
      "question": "The process of coating iron with zinc to prevent rusting is?",
      "options": [
        "Oiling",
        "Galvanization",
        "Painting",
        "Electroplating with copper"
      ],
      "correct": 1,
      "explanation": "Galvanization is coating with zinc"
    },
    {
      "question": "Which gas turns lime water milky?",
      "options": [
        "Hydrogen",
        "Oxygen",
        "Carbon dioxide",
        "Nitrogen"
      ],
      "correct": 2,
      "explanation": "CO₂ turns lime water milky"
    },
    {
      "question": "The relative atomic mass of oxygen is?",
      "options": [
        "32",
        "16",
        "8",
        "18"
      ],
      "correct": 1,
      "explanation": "Atomic mass of oxygen is 16"
    },
    {
      "question": "An endothermic reaction?",
      "options": [
        "Has no heat change",
        "Produces light only",
        "Absorbs heat",
        "Releases heat"
      ],
      "correct": 2,
      "explanation": "Endothermic reactions absorb heat"
    },
    {
      "question": "The particle that has no charge in an atom is?",
      "options": [
        "Neutron",
        "Proton",
        "Electron",
        "Ion"
      ],
      "correct": 0,
      "explanation": "Neutrons are neutral"
    },
    {
      "question": "Which of the following is a strong acid?",
      "options": [
        "Ethanoic acid",
        "Citric acid",
        "Carbonic acid",
        "Hydrochloric acid"
      ],
      "correct": 3,
      "explanation": "HCl is a strong acid"
    },
    {
      "question": "The process of converting a solid directly to gas is used in?",
      "options": [
        "Purification of iodine",
        "Filtration of sand",
        "Evaporation of salt",
        "Distillation of water"
      ],
      "correct": 0,
      "explanation": "Iodine is purified by sublimation"
    },
    {
      "question": "Which element is used in the manufacture of matches?",
      "options": [
        "Nitrogen",
        "Sulphur",
        "Phosphorus",
        "Carbon"
      ],
      "correct": 2,
      "explanation": "Phosphorus is used in matches"
    },
    {
      "question": "The chemical formula of methane is?",
      "options": [
        "CO₂",
        "C₂H₆",
        "CH₄",
        "C₃H₈"
      ],
      "correct": 2,
      "explanation": "Methane is CH₄"
    },
    {
      "question": "A base that is soluble in water is called?",
      "options": [
        "Acid",
        "Oxide",
        "Alkali",
        "Salt"
      ],
      "correct": 2,
      "explanation": "Soluble bases are called alkalis"
    },
    {
      "question": "Which of the following is an alloy?",
      "options": [
        "Aluminium",
        "Copper",
        "Brass",
        "Iron"
      ],
      "correct": 2,
      "explanation": "Brass is an alloy of copper and zinc"
    },
    {
      "question": "The laboratory preparation of oxygen uses?",
      "options": [
        "Hydrogen peroxide",
        "Calcium carbonate",
        "Sodium chloride",
        "Ammonia"
      ],
      "correct": 0,
      "explanation": "H₂O₂ decomposes to give oxygen"
    },
    {
      "question": "Which gas is responsible for the brown colour of polluted air?",
      "options": [
        "Carbon monoxide",
        "Sulphur dioxide",
        "Nitrogen dioxide",
        "Oxygen"
      ],
      "correct": 2,
      "explanation": "NO₂ is a brown gas"
    },
    {
      "question": "The number of moles in 22g of CO₂ is? (C=12, O=16)",
      "options": [
        "2",
        "0.5",
        "0.25",
        "1"
      ],
      "correct": 1,
      "explanation": "Molar mass of CO₂ = 44g, 22/44 = 0.5 mole"
    },
    {
      "question": "Hardness of water can be removed by?",
      "options": [
        "Adding salt",
        "Adding more calcium",
        "Boiling only (for all types)",
        "Adding washing soda"
      ],
      "correct": 3,
      "explanation": "Washing soda helps remove hardness"
    },
    {
      "question": "Which of these is a property of ionic compounds?",
      "options": [
        "They are gases at room temperature",
        "They are insoluble in water",
        "They have low melting points",
        "They conduct electricity when molten"
      ],
      "correct": 3,
      "explanation": "Ionic compounds conduct when molten or in solution"
    },
    {
      "question": "The catalyst used in the Haber process is?",
      "options": [
        "Nickel",
        "Iron",
        "Vanadium(V) oxide",
        "Platinum"
      ],
      "correct": 1,
      "explanation": "Iron is the catalyst in the Haber process"
    },
    {
      "question": "Which of the following is a chemical change?",
      "options": [
        "Breaking of glass",
        "Melting of wax",
        "Dissolving sugar",
        "Burning of magnesium"
      ],
      "correct": 3,
      "explanation": "Burning produces new substances"
    },
    {
      "question": "The pH of pure water is?",
      "options": [
        "1",
        "14",
        "0",
        "7"
      ],
      "correct": 3,
      "explanation": "Pure water is neutral (pH 7)"
    },
    {
      "question": "Which metal is the best conductor of electricity?",
      "options": [
        "Aluminium",
        "Silver",
        "Gold",
        "Copper"
      ],
      "correct": 1,
      "explanation": "Silver is the best electrical conductor"
    },
    {
      "question": "The process of heating a liquid to its boiling point and cooling the vapour is?",
      "options": [
        "Filtration",
        "Distillation",
        "Chromatography",
        "Sublimation"
      ],
      "correct": 1,
      "explanation": "This describes distillation"
    },
    {
      "question": "An oxidizing agent?",
      "options": [
        "Is always a metal",
        "Produces hydrogen",
        "Accepts electrons",
        "Loses electrons"
      ],
      "correct": 2,
      "explanation": "Oxidizing agents gain electrons"
    },
    {
      "question": "The functional group in alcohols is?",
      "options": [
        "-COOH",
        "-CHO",
        "-NH₂",
        "-OH"
      ],
      "correct": 3,
      "explanation": "Alcohols contain the hydroxyl group -OH"
    },
    {
      "question": "Which of these is used as a drying agent?",
      "options": [
        "Dilute HCl",
        "Concentrated H₂SO₄",
        "Water",
        "Sodium chloride"
      ],
      "correct": 1,
      "explanation": "Conc. H₂SO₄ is a powerful drying agent"
    },
    {
      "question": "The relative molecular mass of water is?",
      "options": [
        "10",
        "16",
        "18",
        "20"
      ],
      "correct": 2,
      "explanation": "H₂O = 2(1) + 16 = 18"
    },
    {
      "question": "Which of the following is an acidic oxide?",
      "options": [
        "CaO",
        "CO₂",
        "MgO",
        "Na₂O"
      ],
      "correct": 1,
      "explanation": "CO₂ is an acidic oxide"
    },
    {
      "question": "Allotropes of carbon include?",
      "options": [
        "Iron and steel",
        "Water and ice",
        "Oxygen and ozone",
        "Diamond and graphite"
      ],
      "correct": 3,
      "explanation": "Diamond and graphite are allotropes of carbon"
    },
    {
      "question": "The gas produced during photosynthesis is?",
      "options": [
        "Nitrogen",
        "Oxygen",
        "Carbon dioxide",
        "Hydrogen"
      ],
      "correct": 1,
      "explanation": "Photosynthesis releases oxygen"
    },
    {
      "question": "A reduction reaction involves?",
      "options": [
        "Gain of oxygen",
        "Gain of electrons",
        "Loss of hydrogen only",
        "Loss of electrons"
      ],
      "correct": 1,
      "explanation": "Reduction is gain of electrons"
    },
    {
      "question": "Which of the following is a noble gas?",
      "options": [
        "Oxygen",
        "Argon",
        "Nitrogen",
        "Chlorine"
      ],
      "correct": 1,
      "explanation": "Argon is a noble gas"
    },
    {
      "question": "The bond formed by sharing of electrons is?",
      "options": [
        "Hydrogen bond",
        "Metallic bond",
        "Covalent bond",
        "Ionic bond"
      ],
      "correct": 2,
      "explanation": "Covalent bonds involve sharing of electrons"
    },
    {
      "question": "Which acid is present in vinegar?",
      "options": [
        "Nitric acid",
        "Hydrochloric acid",
        "Ethanoic acid",
        "Sulphuric acid"
      ],
      "correct": 2,
      "explanation": "Vinegar contains ethanoic (acetic) acid"
    },
    {
      "question": "The process of extracting metals from their ores is?",
      "options": [
        "Electrolysis only",
        "Distillation",
        "Chromatography",
        "Metallurgy"
      ],
      "correct": 3,
      "explanation": "Metallurgy is the science of extracting metals"
    },
    {
      "question": "Which of these is used as an anaesthetic?",
      "options": [
        "Benzene",
        "Ethene",
        "Methane",
        "Chloroform"
      ],
      "correct": 3,
      "explanation": "Chloroform was used as an anaesthetic"
    },
    {
      "question": "The number of neutrons in an atom is equal to?",
      "options": [
        "Number of electrons",
        "Atomic number",
        "Mass number",
        "Mass number - Atomic number"
      ],
      "correct": 3,
      "explanation": "Neutrons = Mass number − Atomic number"
    },
    {
      "question": "Which of the following is a reducing agent?",
      "options": [
        "Carbon monoxide",
        "Nitric acid",
        "Chlorine",
        "Oxygen"
      ],
      "correct": 0,
      "explanation": "CO is a common reducing agent"
    },
    {
      "question": "The smell of garlic is due to compounds containing?",
      "options": [
        "Phosphorus",
        "Chlorine",
        "Nitrogen",
        "Sulphur"
      ],
      "correct": 3,
      "explanation": "Sulphur compounds cause the smell"
    },
    {
      "question": "Which indicator is used in titration of strong acid vs strong base?",
      "options": [
        "Only litmus",
        "No indicator needed",
        "Phenolphthalein or Methyl orange",
        "Only universal indicator"
      ],
      "correct": 2,
      "explanation": "Both phenolphthalein and methyl orange can be used"
    },
    {
      "question": "The chemical formula of quicklime is?",
      "options": [
        "Ca(OH)₂",
        "CaO",
        "CaCl₂",
        "CaCO₃"
      ],
      "correct": 1,
      "explanation": "Quicklime is calcium oxide (CaO)"
    },
    {
      "question": "Which of the following is an example of a polymer?",
      "options": [
        "Ethene",
        "Polythene",
        "Ethanol",
        "Methane"
      ],
      "correct": 1,
      "explanation": "Polythene is a polymer of ethene"
    },
    {
      "question": "The process by which a nucleus splits into lighter nuclei is?",
      "options": [
        "Nuclear fission",
        "Nuclear fusion",
        "Ionization",
        "Radioactivity"
      ],
      "correct": 0,
      "explanation": "Fission is splitting of a heavy nucleus"
    },
    {
      "question": "Which gas is used in the manufacture of soft drinks?",
      "options": [
        "Carbon dioxide",
        "Nitrogen",
        "Hydrogen",
        "Oxygen"
      ],
      "correct": 0,
      "explanation": "CO₂ is used for fizz in soft drinks"
    },
    {
      "question": "The valency of aluminium is?",
      "options": [
        "3",
        "4",
        "1",
        "2"
      ],
      "correct": 0,
      "explanation": "Aluminium has valency 3"
    },
    {
      "question": "Which of these is a property of bases?",
      "options": [
        "They turn red litmus blue",
        "They taste sour",
        "They react with metals to give hydrogen",
        "They turn blue litmus red"
      ],
      "correct": 0,
      "explanation": "Bases turn red litmus blue"
    },
    {
      "question": "The main component of biogas is?",
      "options": [
        "Ethane",
        "Methane",
        "Propane",
        "Butane"
      ],
      "correct": 1,
      "explanation": "Biogas is mainly methane"
    },
    {
      "question": "Which method is suitable for separating dyes in ink?",
      "options": [
        "Filtration",
        "Chromatography",
        "Decantation",
        "Distillation"
      ],
      "correct": 1,
      "explanation": "Chromatography separates dyes"
    },
    {
      "question": "An element with atomic number 17 is?",
      "options": [
        "Fluorine",
        "Chlorine",
        "Argon",
        "Sulphur"
      ],
      "correct": 1,
      "explanation": "Atomic number 17 is chlorine"
    },
    {
      "question": "Which of the following is a greenhouse gas produced by cattle?",
      "options": [
        "Oxygen",
        "Methane",
        "Argon",
        "Nitrogen"
      ],
      "correct": 1,
      "explanation": "Cattle produce methane"
    },
    {
      "question": "The reaction between an acid and a base produces?",
      "options": [
        "Water only",
        "Gas only",
        "Salt and water",
        "Salt only"
      ],
      "correct": 2,
      "explanation": "Neutralization produces salt and water"
    },
    {
      "question": "Which metal is liquid at room temperature?",
      "options": [
        "Potassium",
        "Gallium (borderline)",
        "Mercury",
        "Sodium"
      ],
      "correct": 2,
      "explanation": "Mercury is liquid at room temperature"
    },
    {
      "question": "The process of converting sugar to alcohol is?",
      "options": [
        "Reduction",
        "Oxidation",
        "Neutralization",
        "Fermentation"
      ],
      "correct": 3,
      "explanation": "Fermentation converts sugar to alcohol"
    },
    {
      "question": "Which of these is an example of a homogeneous mixture?",
      "options": [
        "Oil and water",
        "Sugar solution",
        "Sand and water",
        "Smoke"
      ],
      "correct": 1,
      "explanation": "Sugar solution is uniform throughout"
    },
    {
      "question": "The lightest metal is?",
      "options": [
        "Potassium",
        "Sodium",
        "Beryllium",
        "Lithium"
      ],
      "correct": 3,
      "explanation": "Lithium is the lightest metal"
    },
    {
      "question": "Which of the following is used in water treatment to kill germs?",
      "options": [
        "Helium",
        "Nitrogen",
        "Chlorine",
        "Hydrogen"
      ],
      "correct": 2,
      "explanation": "Chlorine is used for disinfection"
    },
    {
      "question": "Which of the following is an alkali metal?",
      "options": [
        "Iron",
        "Sodium",
        "Calcium",
        "Aluminium"
      ],
      "correct": 1,
      "explanation": "Sodium is in Group 1 (alkali metals)"
    },
    {
      "question": "The chemical formula of ammonia is?",
      "options": [
        "N₂H₄",
        "NO₂",
        "NH₃",
        "NH₄"
      ],
      "correct": 2,
      "explanation": "Ammonia is NH₃"
    },
    {
      "question": "Which of these is used as a bleaching agent?",
      "options": [
        "Helium",
        "Nitrogen",
        "Argon",
        "Chlorine"
      ],
      "correct": 3,
      "explanation": "Chlorine is used for bleaching"
    },
    {
      "question": "The process of adding hydrogen to an unsaturated compound is?",
      "options": [
        "Hydration",
        "Hydrolysis",
        "Oxidation",
        "Hydrogenation"
      ],
      "correct": 3,
      "explanation": "Hydrogenation adds hydrogen"
    },
    {
      "question": "Which of the following is a physical property?",
      "options": [
        "Flammability",
        "Ability to rust",
        "Reactivity with acid",
        "Melting point"
      ],
      "correct": 3,
      "explanation": "Melting point is a physical property"
    },
    {
      "question": "The gas given off when sodium reacts with water is?",
      "options": [
        "Oxygen",
        "Chlorine",
        "Hydrogen",
        "Nitrogen"
      ],
      "correct": 2,
      "explanation": "Alkali metals liberate hydrogen from water"
    },
    {
      "question": "Which of these is an example of a covalent compound?",
      "options": [
        "Sodium chloride",
        "Calcium chloride",
        "Magnesium oxide",
        "Water"
      ],
      "correct": 3,
      "explanation": "Water is covalently bonded"
    },
    {
      "question": "The number of periods in the modern periodic table is?",
      "options": [
        "18",
        "8",
        "9",
        "7"
      ],
      "correct": 3,
      "explanation": "There are 7 periods"
    },
    {
      "question": "Which acid is used in car batteries?",
      "options": [
        "Sulphuric acid",
        "Acetic acid",
        "Nitric acid",
        "Hydrochloric acid"
      ],
      "correct": 0,
      "explanation": "Car batteries use sulphuric acid"
    },
    {
      "question": "The process of coating iron with zinc is called?",
      "options": [
        "Tempering",
        "Galvanization",
        "Electroplating",
        "Anodizing"
      ],
      "correct": 1,
      "explanation": "Galvanization is zinc coating"
    },
    {
      "question": "Which of the following is a greenhouse gas?",
      "options": [
        "Oxygen",
        "Nitrogen",
        "Argon",
        "Methane"
      ],
      "correct": 3,
      "explanation": "Methane is a greenhouse gas"
    },
    {
      "question": "The colour of copper(II) sulphate crystals is?",
      "options": [
        "Yellow",
        "Blue",
        "Green",
        "White"
      ],
      "correct": 1,
      "explanation": "Hydrated copper(II) sulphate is blue"
    },
    {
      "question": "Which of these is used to test for the presence of starch?",
      "options": [
        "Iodine solution",
        "Phenolphthalein",
        "Litmus",
        "Methyl orange"
      ],
      "correct": 0,
      "explanation": "Iodine turns blue-black with starch"
    },
    {
      "question": "The relative atomic mass of hydrogen is?",
      "options": [
        "16",
        "12",
        "1",
        "2"
      ],
      "correct": 2,
      "explanation": "Hydrogen has atomic mass 1"
    },
    {
      "question": "Which of the following is an example of a mixture?",
      "options": [
        "Salt",
        "Brass",
        "Sugar",
        "Water"
      ],
      "correct": 1,
      "explanation": "Brass is a mixture (alloy)"
    },
    {
      "question": "The process by which green plants prepare food is?",
      "options": [
        "Digestion",
        "Transpiration",
        "Photosynthesis",
        "Respiration"
      ],
      "correct": 2,
      "explanation": "Photosynthesis is how plants make food"
    },
    {
      "question": "Which metal is extracted using electrolysis of its molten ore?",
      "options": [
        "Zinc",
        "Aluminium",
        "Iron",
        "Copper"
      ],
      "correct": 1,
      "explanation": "Aluminium is extracted by electrolysis"
    },
    {
      "question": "The pH range of acids is?",
      "options": [
        "Above 7",
        "7 only",
        "Exactly 14",
        "0 to less than 7"
      ],
      "correct": 3,
      "explanation": "Acids have pH below 7"
    },
    {
      "question": "Which of these is a property of metals?",
      "options": [
        "Dullness",
        "Malleability",
        "Brittleness",
        "Poor conductivity"
      ],
      "correct": 1,
      "explanation": "Metals are malleable"
    },
    {
      "question": "The chemical used to remove temporary hardness of water by boiling is related to?",
      "options": [
        "Sodium chloride",
        "Calcium hydrogen carbonate",
        "Potassium nitrate",
        "Magnesium sulphate only"
      ],
      "correct": 1,
      "explanation": "Temporary hardness is due to hydrogen carbonates"
    },
    {
      "question": "Which of the following is an organic compound?",
      "options": [
        "Methane",
        "Sodium chloride",
        "Water",
        "Ammonia"
      ],
      "correct": 0,
      "explanation": "Methane is an organic compound"
    },
    {
      "question": "The catalyst used in the contact process is?",
      "options": [
        "Platinum",
        "Iron",
        "Vanadium(V) oxide",
        "Nickel"
      ],
      "correct": 2,
      "explanation": "V₂O₅ is used in the contact process"
    },
    {
      "question": "Which gas is produced when calcium carbonate is heated?",
      "options": [
        "Nitrogen",
        "Hydrogen",
        "Carbon dioxide",
        "Oxygen"
      ],
      "correct": 2,
      "explanation": "CaCO₃ → CaO + CO₂"
    },
    {
      "question": "The smallest unit of a compound is?",
      "options": [
        "Atom",
        "Molecule",
        "Ion",
        "Electron"
      ],
      "correct": 1,
      "explanation": "A molecule is the smallest unit of a compound"
    },
    {
      "question": "Which of the following is a non-metal that conducts electricity?",
      "options": [
        "Graphite",
        "Phosphorus",
        "Sulphur",
        "Iodine"
      ],
      "correct": 0,
      "explanation": "Graphite conducts electricity"
    },
    {
      "question": "Which of the following is a transition metal?",
      "options": [
        "Sodium",
        "Calcium",
        "Aluminium",
        "Iron"
      ],
      "correct": 3,
      "explanation": "Iron is a transition metal"
    },
    {
      "question": "The chemical formula of ethanol is?",
      "options": [
        "CH₃OH",
        "C₂H₆",
        "C₂H₅OH",
        "C₂H₄"
      ],
      "correct": 2,
      "explanation": "Ethanol is C₂H₅OH"
    },
    {
      "question": "Which of these is used in the Solvay process?",
      "options": [
        "Ammonia",
        "Chlorine",
        "Sulphur",
        "Phosphorus"
      ],
      "correct": 0,
      "explanation": "Ammonia is used in the Solvay process"
    },
    {
      "question": "The process of removing dissolved salts from water is?",
      "options": [
        "Desalination",
        "Sedimentation",
        "Chlorination",
        "Filtration"
      ],
      "correct": 0,
      "explanation": "Desalination removes salts"
    },
    {
      "question": "Which of the following is an acidic salt?",
      "options": [
        "NaCl",
        "NaOH",
        "NaHSO₄",
        "Na₂CO₃"
      ],
      "correct": 2,
      "explanation": "NaHSO₄ is an acidic salt"
    },
    {
      "question": "The gas produced during the reaction of zinc with dilute HCl is?",
      "options": [
        "Oxygen",
        "Hydrogen",
        "Chlorine",
        "Nitrogen"
      ],
      "correct": 1,
      "explanation": "Metal + acid → salt + hydrogen"
    },
    {
      "question": "Which of these is a property of covalent compounds?",
      "options": [
        "Are always soluble in water",
        "Conduct electricity when solid",
        "High melting points",
        "Low melting and boiling points"
      ],
      "correct": 3,
      "explanation": "Many covalent compounds have low melting points"
    },
    {
      "question": "The atomic number of oxygen is?",
      "options": [
        "8",
        "6",
        "12",
        "16"
      ],
      "correct": 0,
      "explanation": "Oxygen has 8 protons"
    },
    {
      "question": "Which of the following is used as a refrigerant?",
      "options": [
        "Oxygen",
        "Hydrogen",
        "Nitrogen",
        "Ammonia"
      ],
      "correct": 3,
      "explanation": "Ammonia is used as a refrigerant"
    },
    {
      "question": "The process of converting liquid to solid is?",
      "options": [
        "Condensation",
        "Melting",
        "Boiling",
        "Freezing"
      ],
      "correct": 3,
      "explanation": "Freezing is liquid to solid"
    },
    {
      "question": "Which of these is an example of a double salt?",
      "options": [
        "Copper sulphate",
        "Potash alum",
        "Calcium carbonate",
        "Sodium chloride"
      ],
      "correct": 1,
      "explanation": "Potash alum is a double salt"
    },
    {
      "question": "The catalyst used in the hydrogenation of oils is?",
      "options": [
        "Iron",
        "Nickel",
        "Vanadium",
        "Platinum"
      ],
      "correct": 1,
      "explanation": "Nickel is used in hydrogenation of oils"
    },
    {
      "question": "Which of the following is a basic oxide?",
      "options": [
        "CO₂",
        "Na₂O",
        "SO₂",
        "NO₂"
      ],
      "correct": 1,
      "explanation": "Na₂O is a basic oxide"
    },
    {
      "question": "The number of electrons in a sodium ion (Na⁺) is?",
      "options": [
        "12",
        "9",
        "11",
        "10"
      ],
      "correct": 3,
      "explanation": "Sodium atom has 11 electrons; Na⁺ has 10"
    },
    {
      "question": "Which of these is used to test for carbon dioxide?",
      "options": [
        "Iodine",
        "Phenolphthalein",
        "Lime water",
        "Litmus"
      ],
      "correct": 2,
      "explanation": "Lime water turns milky with CO₂"
    },
    {
      "question": "The process of coating a metal with a thin layer of another metal is?",
      "options": [
        "Anodizing only",
        "Galvanizing only",
        "Electroplating",
        "Tempering"
      ],
      "correct": 2,
      "explanation": "Electroplating coats with another metal"
    },
    {
      "question": "Which of the following is a saturated hydrocarbon?",
      "options": [
        "Ethyne",
        "Benzene",
        "Ethene",
        "Ethane"
      ],
      "correct": 3,
      "explanation": "Ethane is saturated (single bonds only)"
    },
    {
      "question": "The chemical formula of hydrogen peroxide is?",
      "options": [
        "HO",
        "H₂O",
        "H₂O₂",
        "H₂O₃"
      ],
      "correct": 2,
      "explanation": "Hydrogen peroxide is H₂O₂"
    },
    {
      "question": "Which of these elements is a metalloid?",
      "options": [
        "Silicon",
        "Iron",
        "Sulphur",
        "Sodium"
      ],
      "correct": 0,
      "explanation": "Silicon is a metalloid"
    },
    {
      "question": "The process by which a solid changes to liquid is?",
      "options": [
        "Condensation",
        "Freezing",
        "Boiling",
        "Melting"
      ],
      "correct": 3,
      "explanation": "Melting is solid to liquid"
    },
    {
      "question": "Which of the following is used in the manufacture of glass?",
      "options": [
        "Sodium chloride",
        "Silicon dioxide",
        "Iron oxide only",
        "Calcium carbonate only"
      ],
      "correct": 1,
      "explanation": "Sand (SiO₂) is a major component of glass"
    },
    {
      "question": "The ion responsible for acidity is?",
      "options": [
        "Na⁺",
        "H⁺",
        "OH⁻",
        "Cl⁻"
      ],
      "correct": 1,
      "explanation": "H⁺ ions cause acidity"
    },
    {
      "question": "Which of these is a method of preventing rusting?",
      "options": [
        "Painting",
        "Adding salt",
        "Heating strongly",
        "Exposing to air"
      ],
      "correct": 0,
      "explanation": "Painting prevents contact with air and water"
    },
    {
      "question": "The relative molecular mass of CO₂ is? (C=12, O=16)",
      "options": [
        "22",
        "32",
        "28",
        "44"
      ],
      "correct": 3,
      "explanation": "12 + 32 = 44"
    },
    {
      "question": "Which of the following is an example of a redox reaction?",
      "options": [
        "Dissolving sugar",
        "Boiling water",
        "Melting of ice",
        "Rusting of iron"
      ],
      "correct": 3,
      "explanation": "Rusting involves oxidation and reduction"
    },
    {
      "question": "Which of the following is a halogen?",
      "options": [
        "Iron",
        "Sodium",
        "Fluorine",
        "Calcium"
      ],
      "correct": 2,
      "explanation": "Fluorine is a halogen"
    },
    {
      "question": "The chemical formula of sodium hydroxide is?",
      "options": [
        "NaOH",
        "NaCl",
        "Na₂CO₃",
        "NaHCO₃"
      ],
      "correct": 0,
      "explanation": "Sodium hydroxide is NaOH"
    },
    {
      "question": "Which of these is used in the manufacture of ammonia?",
      "options": [
        "Chlorine and sodium",
        "Carbon and oxygen",
        "Nitrogen and hydrogen",
        "Oxygen and hydrogen"
      ],
      "correct": 2,
      "explanation": "Haber process uses N₂ and H₂"
    },
    {
      "question": "The process of separating crude oil into fractions is?",
      "options": [
        "Chromatography",
        "Simple distillation",
        "Fractional distillation",
        "Filtration"
      ],
      "correct": 2,
      "explanation": "Crude oil is separated by fractional distillation"
    },
    {
      "question": "Which of the following is an example of a weak acid?",
      "options": [
        "Nitric acid",
        "Ethanoic acid",
        "Hydrochloric acid",
        "Sulphuric acid"
      ],
      "correct": 1,
      "explanation": "Ethanoic acid is a weak acid"
    },
    {
      "question": "The gas that supports combustion is?",
      "options": [
        "Carbon dioxide",
        "Nitrogen",
        "Oxygen",
        "Hydrogen"
      ],
      "correct": 2,
      "explanation": "Oxygen supports combustion"
    },
    {
      "question": "Which of these is a property of ionic compounds?",
      "options": [
        "Are soft",
        "Do not conduct when molten",
        "High melting points",
        "Low melting points"
      ],
      "correct": 2,
      "explanation": "Ionic compounds have high melting points"
    },
    {
      "question": "The atomic number of nitrogen is?",
      "options": [
        "6",
        "7",
        "14",
        "8"
      ],
      "correct": 1,
      "explanation": "Nitrogen has 7 protons"
    },
    {
      "question": "Which of the following is used as a drying agent for gases?",
      "options": [
        "Water",
        "Dilute hydrochloric acid",
        "Sodium chloride solution",
        "Concentrated sulphuric acid"
      ],
      "correct": 3,
      "explanation": "Conc. H₂SO₄ is a drying agent"
    },
    {
      "question": "The process of converting a gas to liquid is?",
      "options": [
        "Condensation",
        "Evaporation",
        "Melting",
        "Sublimation"
      ],
      "correct": 0,
      "explanation": "Condensation is gas to liquid"
    },
    {
      "question": "Which of these is an alloy of copper and tin?",
      "options": [
        "Solder",
        "Brass",
        "Bronze",
        "Steel"
      ],
      "correct": 2,
      "explanation": "Bronze is copper + tin"
    },
    {
      "question": "The catalyst used in the Haber process is?",
      "options": [
        "Iron",
        "Platinum",
        "Vanadium(V) oxide",
        "Nickel"
      ],
      "correct": 0,
      "explanation": "Iron is the catalyst in Haber process"
    },
    {
      "question": "Which of the following is an acidic oxide?",
      "options": [
        "MgO",
        "CaO",
        "Na₂O",
        "SO₂"
      ],
      "correct": 3,
      "explanation": "SO₂ is an acidic oxide"
    },
    {
      "question": "The number of protons in a carbon atom is?",
      "options": [
        "12",
        "8",
        "6",
        "14"
      ],
      "correct": 2,
      "explanation": "Carbon has atomic number 6"
    },
    {
      "question": "Which of these turns blue litmus red?",
      "options": [
        "Base",
        "Acid",
        "Water",
        "Salt solution (neutral)"
      ],
      "correct": 1,
      "explanation": "Acids turn blue litmus red"
    },
    {
      "question": "The main gas in the atmosphere is?",
      "options": [
        "Argon",
        "Carbon dioxide",
        "Oxygen",
        "Nitrogen"
      ],
      "correct": 3,
      "explanation": "Nitrogen is about 78% of air"
    },
    {
      "question": "Which of the following is a method of purifying water?",
      "options": [
        "Chlorination",
        "Adding salt",
        "Adding sugar",
        "Heating only without filtration"
      ],
      "correct": 0,
      "explanation": "Chlorination kills germs in water"
    },
    {
      "question": "The chemical formula of calcium carbonate is?",
      "options": [
        "Ca(OH)₂",
        "CaCl₂",
        "CaCO₃",
        "CaO"
      ],
      "correct": 2,
      "explanation": "Calcium carbonate is CaCO₃"
    },
    {
      "question": "Which of these is a non-metal?",
      "options": [
        "Copper",
        "Zinc",
        "Iron",
        "Sulphur"
      ],
      "correct": 3,
      "explanation": "Sulphur is a non-metal"
    },
    {
      "question": "The process by which plants lose water vapour is?",
      "options": [
        "Respiration",
        "Transpiration",
        "Photosynthesis",
        "Germination"
      ],
      "correct": 1,
      "explanation": "Transpiration is loss of water vapour"
    },
    {
      "question": "Which of the following is used in baking powder?",
      "options": [
        "Sodium carbonate only",
        "Sodium hydrogen carbonate",
        "Sodium hydroxide",
        "Sodium chloride"
      ],
      "correct": 1,
      "explanation": "Baking powder contains NaHCO₃"
    },
    {
      "question": "The ion that makes a solution alkaline is?",
      "options": [
        "H⁺",
        "OH⁻",
        "Cl⁻",
        "Na⁺"
      ],
      "correct": 1,
      "explanation": "OH⁻ ions make solutions alkaline"
    },
    {
      "question": "Which of these is an example of a chemical change?",
      "options": [
        "Breaking of glass",
        "Burning of paper",
        "Dissolving salt",
        "Melting of ice"
      ],
      "correct": 1,
      "explanation": "Burning produces new substances"
    },
    {
      "question": "The relative atomic mass of carbon is?",
      "options": [
        "6",
        "12",
        "16",
        "14"
      ],
      "correct": 1,
      "explanation": "Carbon has atomic mass 12"
    },
    {
      "question": "Which of the following is used to test for hydrogen gas?",
      "options": [
        "Glowing splint",
        "Litmus paper",
        "Lime water",
        "A lighted splint (pops)"
      ],
      "correct": 3,
      "explanation": "Hydrogen gives a pop sound with a lighted splint"
    },
    {
      "question": "Which of the following is an alkali metal?",
      "options": [
        "Potassium",
        "Iron",
        "Calcium",
        "Aluminium"
      ],
      "correct": 0,
      "explanation": "Potassium is an alkali metal"
    },
    {
      "question": "The chemical formula of water is?",
      "options": [
        "H₂O₂",
        "HO",
        "H₂O",
        "H₂"
      ],
      "correct": 2,
      "explanation": "Water is H₂O"
    },
    {
      "question": "Which gas is used in the Haber process?",
      "options": [
        "Neon",
        "Chlorine",
        "Nitrogen",
        "Argon"
      ],
      "correct": 2,
      "explanation": "Nitrogen is used with hydrogen in Haber process"
    },
    {
      "question": "The separation of petroleum is done by?",
      "options": [
        "Filtration",
        "Decantation",
        "Sublimation",
        "Fractional distillation"
      ],
      "correct": 3,
      "explanation": "Fractional distillation separates petroleum"
    },
    {
      "question": "Which of these is a strong acid?",
      "options": [
        "CH₃COOH",
        "HCl",
        "H₂CO₃",
        "H₂S"
      ],
      "correct": 1,
      "explanation": "HCl is a strong acid"
    },
    {
      "question": "The gas that rekindles a glowing splint is?",
      "options": [
        "Nitrogen",
        "Carbon dioxide",
        "Hydrogen",
        "Oxygen"
      ],
      "correct": 3,
      "explanation": "Oxygen rekindles a glowing splint"
    },
    {
      "question": "Ionic compounds generally have?",
      "options": [
        "Low melting points",
        "No melting point",
        "High melting points",
        "Variable melting points only"
      ],
      "correct": 2,
      "explanation": "Ionic compounds have high melting points"
    },
    {
      "question": "The atomic number of helium is?",
      "options": [
        "4",
        "2",
        "1",
        "3"
      ],
      "correct": 1,
      "explanation": "Helium has 2 protons"
    },
    {
      "question": "Which of these is a drying agent?",
      "options": [
        "NaCl solution",
        "Dilute HCl",
        "Water",
        "Concentrated H₂SO₄"
      ],
      "correct": 3,
      "explanation": "Conc. sulphuric acid is a drying agent"
    },
    {
      "question": "Gas to liquid change is called?",
      "options": [
        "Condensation",
        "Evaporation",
        "Sublimation",
        "Melting"
      ],
      "correct": 0,
      "explanation": "Condensation is gas → liquid"
    },
    {
      "question": "Brass is an alloy of?",
      "options": [
        "Iron and carbon",
        "Copper and tin",
        "Copper and zinc",
        "Lead and tin"
      ],
      "correct": 2,
      "explanation": "Brass is copper + zinc"
    },
    {
      "question": "The catalyst in Haber process is?",
      "options": [
        "Nickel",
        "Platinum",
        "Palladium",
        "Iron"
      ],
      "correct": 3,
      "explanation": "Iron is used as catalyst"
    },
    {
      "question": "Which oxide is acidic?",
      "options": [
        "CO₂",
        "K₂O",
        "Na₂O",
        "CaO"
      ],
      "correct": 0,
      "explanation": "CO₂ is acidic oxide"
    },
    {
      "question": "Carbon has atomic number?",
      "options": [
        "12",
        "14",
        "6",
        "8"
      ],
      "correct": 2,
      "explanation": "Carbon atomic number is 6"
    },
    {
      "question": "Acids turn blue litmus?",
      "options": [
        "Green",
        "Colourless",
        "Red",
        "Blue"
      ],
      "correct": 2,
      "explanation": "Acids turn blue litmus red"
    },
    {
      "question": "The most abundant gas in air is?",
      "options": [
        "Oxygen",
        "Nitrogen",
        "Argon",
        "Carbon dioxide"
      ],
      "correct": 1,
      "explanation": "Nitrogen is about 78%"
    },
    {
      "question": "Chlorine is used in water treatment to?",
      "options": [
        "Add taste",
        "Remove salt",
        "Kill germs",
        "Add colour"
      ],
      "correct": 2,
      "explanation": "Chlorine disinfects water"
    },
    {
      "question": "The formula of calcium carbonate is?",
      "options": [
        "CaCO₃",
        "CaO",
        "Ca(OH)₂",
        "CaCl₂"
      ],
      "correct": 0,
      "explanation": "Calcium carbonate is CaCO₃"
    },
    {
      "question": "Which is a non-metal?",
      "options": [
        "Copper",
        "Iron",
        "Carbon",
        "Zinc"
      ],
      "correct": 2,
      "explanation": "Carbon is a non-metal"
    },
    {
      "question": "Loss of water vapour from plants is?",
      "options": [
        "Transpiration",
        "Respiration",
        "Photosynthesis",
        "Translocation"
      ],
      "correct": 0,
      "explanation": "Transpiration is loss of water vapour"
    },
    {
      "question": "Baking soda is?",
      "options": [
        "NaOH",
        "NaHCO₃",
        "NaCl",
        "Na₂CO₃"
      ],
      "correct": 1,
      "explanation": "Baking soda is sodium hydrogen carbonate"
    },
    {
      "question": "Alkaline solutions contain?",
      "options": [
        "Only Cl⁻",
        "OH⁻ ions",
        "Only Na⁺",
        "H⁺ ions"
      ],
      "correct": 1,
      "explanation": "OH⁻ ions make solutions alkaline"
    },
    {
      "question": "Burning of magnesium is a?",
      "options": [
        "Physical change",
        "Temporary change",
        "Chemical change",
        "Reversible change only"
      ],
      "correct": 2,
      "explanation": "Burning produces new substances"
    },
    {
      "question": "The atomic mass of carbon is approximately?",
      "options": [
        "14",
        "12",
        "6",
        "16"
      ],
      "correct": 1,
      "explanation": "Carbon atomic mass is 12"
    },
    {
      "question": "Hydrogen is tested with a?",
      "options": [
        "Lighted splint",
        "Lime water",
        "Glowing splint",
        "Litmus paper"
      ],
      "correct": 0,
      "explanation": "Hydrogen pops with a lighted splint"
    }
  ],
  "bio": [
    {
      "question": "The basic unit of life is the?",
      "options": [
        "Tissue",
        "Cell",
        "System",
        "Organ"
      ],
      "correct": 1,
      "explanation": "The cell is the basic unit of life"
    },
    {
      "question": "Which of these is a vertebrate?",
      "options": [
        "Earthworm",
        "Snail",
        "Cockroach",
        "Fish"
      ],
      "correct": 3,
      "explanation": "Fish have a backbone"
    },
    {
      "question": "The process by which green plants make food is?",
      "options": [
        "Digestion",
        "Photosynthesis",
        "Respiration",
        "Transpiration"
      ],
      "correct": 1,
      "explanation": "Photosynthesis is how plants make food"
    },
    {
      "question": "Which blood cells fight disease?",
      "options": [
        "Red blood cells",
        "Plasma",
        "White blood cells",
        "Platelets"
      ],
      "correct": 2,
      "explanation": "White blood cells defend against disease"
    },
    {
      "question": "The organ that pumps blood is the?",
      "options": [
        "Kidney",
        "Lungs",
        "Heart",
        "Liver"
      ],
      "correct": 2,
      "explanation": "The heart pumps blood"
    },
    {
      "question": "Which of these is a mammal?",
      "options": [
        "Frog",
        "Crocodile",
        "Shark",
        "Whale"
      ],
      "correct": 3,
      "explanation": "Whales are mammals"
    },
    {
      "question": "The green pigment in plants is?",
      "options": [
        "Haemoglobin",
        "Carotene",
        "Chlorophyll",
        "Melanin"
      ],
      "correct": 2,
      "explanation": "Chlorophyll makes plants green"
    },
    {
      "question": "Which part of the plant absorbs water?",
      "options": [
        "Leaf",
        "Root",
        "Stem only",
        "Flower"
      ],
      "correct": 1,
      "explanation": "Roots absorb water from the soil"
    },
    {
      "question": "The largest organ in the human body is the?",
      "options": [
        "Heart",
        "Liver",
        "Brain",
        "Skin"
      ],
      "correct": 3,
      "explanation": "The skin is the largest organ"
    },
    {
      "question": "Which of these is an insect?",
      "options": [
        "Spider",
        "Scorpion",
        "Butterfly",
        "Centipede"
      ],
      "correct": 2,
      "explanation": "Butterflies are insects (6 legs)"
    },
    {
      "question": "The process of breaking down food is?",
      "options": [
        "Digestion",
        "Circulation",
        "Excretion",
        "Respiration"
      ],
      "correct": 0,
      "explanation": "Digestion breaks down food"
    },
    {
      "question": "Which gas do plants take in during photosynthesis?",
      "options": [
        "Nitrogen",
        "Oxygen",
        "Carbon dioxide",
        "Hydrogen"
      ],
      "correct": 2,
      "explanation": "Plants use CO₂ for photosynthesis"
    },
    {
      "question": "The male reproductive cell is the?",
      "options": [
        "Egg",
        "Sperm",
        "Zygote",
        "Embryo"
      ],
      "correct": 1,
      "explanation": "Sperm is the male gamete"
    },
    {
      "question": "Which of these is a reptile?",
      "options": [
        "Frog",
        "Toad",
        "Salamander",
        "Snake"
      ],
      "correct": 3,
      "explanation": "Snakes are reptiles"
    },
    {
      "question": "The organ of smell is the?",
      "options": [
        "Nose",
        "Eye",
        "Ear",
        "Tongue"
      ],
      "correct": 0,
      "explanation": "The nose is the organ of smell"
    },
    {
      "question": "Which of these is a producer in a food chain?",
      "options": [
        "Lion",
        "Snake",
        "Green plant",
        "Eagle"
      ],
      "correct": 2,
      "explanation": "Green plants produce food"
    },
    {
      "question": "The liquid part of blood is called?",
      "options": [
        "Plasma",
        "Lymph",
        "Haemoglobin",
        "Serum"
      ],
      "correct": 0,
      "explanation": "Plasma is the liquid part of blood"
    },
    {
      "question": "Which of these animals is cold-blooded?",
      "options": [
        "Lizard",
        "Dog",
        "Cow",
        "Cat"
      ],
      "correct": 0,
      "explanation": "Lizards are cold-blooded"
    },
    {
      "question": "The process of removing waste from the body is?",
      "options": [
        "Respiration",
        "Digestion",
        "Excretion",
        "Reproduction"
      ],
      "correct": 2,
      "explanation": "Excretion removes waste"
    },
    {
      "question": "Which part of the flower produces pollen?",
      "options": [
        "Ovary",
        "Anther",
        "Stigma",
        "Style"
      ],
      "correct": 1,
      "explanation": "Anther produces pollen"
    },
    {
      "question": "The bone that protects the brain is the?",
      "options": [
        "Skull",
        "Rib",
        "Pelvis",
        "Spine"
      ],
      "correct": 0,
      "explanation": "The skull protects the brain"
    },
    {
      "question": "Which of these is a parasite?",
      "options": [
        "Goat",
        "Chicken",
        "Fish",
        "Tapeworm"
      ],
      "correct": 3,
      "explanation": "Tapeworm lives in a host"
    },
    {
      "question": "The exchange of gases in humans occurs in the?",
      "options": [
        "Stomach",
        "Lungs",
        "Liver",
        "Heart"
      ],
      "correct": 1,
      "explanation": "Gas exchange occurs in the lungs"
    },
    {
      "question": "Which of these is an amphibian?",
      "options": [
        "Snake",
        "Frog",
        "Crocodile",
        "Lizard"
      ],
      "correct": 1,
      "explanation": "Frogs are amphibians"
    },
    {
      "question": "The substance that carries oxygen in blood is?",
      "options": [
        "Plasma",
        "White cells",
        "Haemoglobin",
        "Platelets"
      ],
      "correct": 2,
      "explanation": "Haemoglobin carries oxygen"
    },
    {
      "question": "Which of these is a function of the roots?",
      "options": [
        "Attracting insects",
        "Production of seeds",
        "Absorption of water",
        "Photosynthesis"
      ],
      "correct": 2,
      "explanation": "Roots absorb water and minerals"
    },
    {
      "question": "The female reproductive cell is the?",
      "options": [
        "Embryo",
        "Zygote",
        "Egg (ovum)",
        "Sperm"
      ],
      "correct": 2,
      "explanation": "The egg is the female gamete"
    },
    {
      "question": "Which of these is a warm-blooded animal?",
      "options": [
        "Bird",
        "Fish",
        "Lizard",
        "Snake"
      ],
      "correct": 0,
      "explanation": "Birds are warm-blooded"
    },
    {
      "question": "The process by which plants lose water is?",
      "options": [
        "Photosynthesis",
        "Transpiration",
        "Germination",
        "Respiration"
      ],
      "correct": 1,
      "explanation": "Transpiration is loss of water from plants"
    },
    {
      "question": "Which organ filters blood in humans?",
      "options": [
        "Heart",
        "Stomach",
        "Lungs",
        "Kidney"
      ],
      "correct": 3,
      "explanation": "Kidneys filter blood"
    },
    {
      "question": "A group of similar cells is called?",
      "options": [
        "System",
        "Organ",
        "Organism",
        "Tissue"
      ],
      "correct": 3,
      "explanation": "Similar cells form a tissue"
    },
    {
      "question": "Which of these is a carnivore?",
      "options": [
        "Goat",
        "Cow",
        "Rabbit",
        "Lion"
      ],
      "correct": 3,
      "explanation": "Lions eat meat"
    },
    {
      "question": "The part of the eye that controls light entry is?",
      "options": [
        "Retina",
        "Iris",
        "Cornea",
        "Lens"
      ],
      "correct": 1,
      "explanation": "The iris controls the amount of light"
    },
    {
      "question": "Which of these is a seed dispersal method?",
      "options": [
        "By wind",
        "By respiration",
        "By photosynthesis",
        "By digestion"
      ],
      "correct": 0,
      "explanation": "Wind is a common dispersal agent"
    },
    {
      "question": "The backbone is also known as the?",
      "options": [
        "Rib cage",
        "Vertebral column",
        "Pelvis",
        "Skull"
      ],
      "correct": 1,
      "explanation": "The backbone is the vertebral column"
    },
    {
      "question": "Which of these is an invertebrate?",
      "options": [
        "Fish",
        "Earthworm",
        "Bird",
        "Lizard"
      ],
      "correct": 1,
      "explanation": "Earthworms have no backbone"
    },
    {
      "question": "The process of producing offspring is?",
      "options": [
        "Digestion",
        "Reproduction",
        "Excretion",
        "Respiration"
      ],
      "correct": 1,
      "explanation": "Reproduction produces offspring"
    },
    {
      "question": "Which blood cells carry oxygen?",
      "options": [
        "Red blood cells",
        "Plasma cells",
        "Platelets",
        "White blood cells"
      ],
      "correct": 0,
      "explanation": "Red blood cells carry oxygen"
    },
    {
      "question": "The stomata are found mainly on the?",
      "options": [
        "Roots",
        "Fruits",
        "Flowers",
        "Leaves"
      ],
      "correct": 3,
      "explanation": "Stomata are mostly on leaves"
    },
    {
      "question": "Which of these is a herbivore?",
      "options": [
        "Cow",
        "Snake",
        "Eagle",
        "Lion"
      ],
      "correct": 0,
      "explanation": "Cows eat plants"
    },
    {
      "question": "The organ of hearing is the?",
      "options": [
        "Tongue",
        "Eye",
        "Nose",
        "Ear"
      ],
      "correct": 3,
      "explanation": "The ear is for hearing"
    },
    {
      "question": "Which of these is a function of the skeleton?",
      "options": [
        "Production of hormones only",
        "Support and protection",
        "Digestion of food",
        "Transport of oxygen"
      ],
      "correct": 1,
      "explanation": "Skeleton supports and protects the body"
    },
    {
      "question": "A place where an organism lives is its?",
      "options": [
        "Niche",
        "Population",
        "Habitat",
        "Community"
      ],
      "correct": 2,
      "explanation": "Habitat is the living place"
    },
    {
      "question": "Which of these is a flowering plant?",
      "options": [
        "Algae",
        "Mango",
        "Fern",
        "Moss"
      ],
      "correct": 1,
      "explanation": "Mango is a flowering plant"
    },
    {
      "question": "The joining of sperm and egg is called?",
      "options": [
        "Pollination",
        "Fertilization",
        "Ovulation",
        "Germination"
      ],
      "correct": 1,
      "explanation": "Fertilization is the fusion of gametes"
    },
    {
      "question": "Which of these helps in clotting of blood?",
      "options": [
        "Red blood cells",
        "Platelets",
        "White blood cells",
        "Plasma only"
      ],
      "correct": 1,
      "explanation": "Platelets help in clotting"
    },
    {
      "question": "The largest part of the brain is the?",
      "options": [
        "Medulla",
        "Cerebrum",
        "Cerebellum",
        "Spinal cord"
      ],
      "correct": 1,
      "explanation": "Cerebrum is the largest part"
    },
    {
      "question": "Which of these is a decomposer?",
      "options": [
        "Fungi",
        "Eagle",
        "Goat",
        "Lion"
      ],
      "correct": 0,
      "explanation": "Fungi break down dead matter"
    },
    {
      "question": "The movement of food through the gullet is by?",
      "options": [
        "Osmosis",
        "Diffusion",
        "Active transport only",
        "Peristalsis"
      ],
      "correct": 3,
      "explanation": "Peristalsis moves food along the gut"
    },
    {
      "question": "Which of these is a characteristic of living things?",
      "options": [
        "Melting",
        "Evaporation",
        "Rusting",
        "Respiration"
      ],
      "correct": 3,
      "explanation": "Respiration is a life process"
    },
    {
      "question": "Which of these is a function of the leaves?",
      "options": [
        "Anchorage",
        "Photosynthesis",
        "Absorption of water",
        "Production of pollen only"
      ],
      "correct": 1,
      "explanation": "Leaves carry out photosynthesis"
    },
    {
      "question": "The smallest bone in the human body is in the?",
      "options": [
        "Ear",
        "Nose",
        "Hand",
        "Foot"
      ],
      "correct": 0,
      "explanation": "The stapes in the ear is the smallest bone"
    },
    {
      "question": "Which of these is an example of a reflex action?",
      "options": [
        "Writing",
        "Singing",
        "Reading",
        "Blinking"
      ],
      "correct": 3,
      "explanation": "Blinking is a reflex action"
    },
    {
      "question": "The part of the plant that produces seeds is the?",
      "options": [
        "Root",
        "Flower",
        "Stem",
        "Leaf"
      ],
      "correct": 1,
      "explanation": "Flowers produce seeds after fertilization"
    },
    {
      "question": "Which of these animals undergoes metamorphosis?",
      "options": [
        "Cat",
        "Dog",
        "Butterfly",
        "Cow"
      ],
      "correct": 2,
      "explanation": "Butterflies undergo complete metamorphosis"
    },
    {
      "question": "The organ that produces insulin is the?",
      "options": [
        "Pancreas",
        "Liver",
        "Kidney",
        "Heart"
      ],
      "correct": 0,
      "explanation": "The pancreas produces insulin"
    },
    {
      "question": "Which of these is a vector of malaria?",
      "options": [
        "Female Anopheles mosquito",
        "Tsetse fly",
        "Cockroach",
        "Housefly"
      ],
      "correct": 0,
      "explanation": "Female Anopheles transmits malaria"
    },
    {
      "question": "The process of water movement in plants is?",
      "options": [
        "Digestion",
        "Transpiration pull",
        "Photosynthesis",
        "Respiration"
      ],
      "correct": 1,
      "explanation": "Transpiration helps pull water up"
    },
    {
      "question": "Which of these is a storage organ?",
      "options": [
        "Yam tuber",
        "Stem tip",
        "Leaf",
        "Flower"
      ],
      "correct": 0,
      "explanation": "Yam stores food"
    },
    {
      "question": "The pigment that gives blood its red colour is?",
      "options": [
        "Carotene",
        "Chlorophyll",
        "Melanin",
        "Haemoglobin"
      ],
      "correct": 3,
      "explanation": "Haemoglobin makes blood red"
    },
    {
      "question": "Which of these is a social insect?",
      "options": [
        "Mosquito",
        "Butterfly",
        "Housefly",
        "Bee"
      ],
      "correct": 3,
      "explanation": "Bees live in colonies"
    },
    {
      "question": "The joint that allows movement in one direction is?",
      "options": [
        "Pivot joint",
        "Ball and socket",
        "Gliding joint",
        "Hinge joint"
      ],
      "correct": 3,
      "explanation": "Hinge joints move in one plane"
    },
    {
      "question": "Which of these is an example of vegetative propagation?",
      "options": [
        "Seed",
        "Pollen",
        "Potato tuber",
        "Ovule"
      ],
      "correct": 2,
      "explanation": "Potato tubers grow new plants"
    },
    {
      "question": "The organ of balance is located in the?",
      "options": [
        "Eye",
        "Nose",
        "Tongue",
        "Ear"
      ],
      "correct": 3,
      "explanation": "The ear contains the organs of balance"
    },
    {
      "question": "Which of these is a primary consumer?",
      "options": [
        "Lion",
        "Hawk",
        "Goat",
        "Eagle"
      ],
      "correct": 2,
      "explanation": "Goats eat plants (primary consumers)"
    },
    {
      "question": "The deficiency of vitamin C causes?",
      "options": [
        "Night blindness",
        "Rickets",
        "Beriberi",
        "Scurvy"
      ],
      "correct": 3,
      "explanation": "Lack of vitamin C causes scurvy"
    },
    {
      "question": "Which of these is a excretory organ?",
      "options": [
        "Skin",
        "Stomach",
        "Heart",
        "Intestine mainly"
      ],
      "correct": 0,
      "explanation": "Skin excretes sweat"
    },
    {
      "question": "The male part of a flower is the?",
      "options": [
        "Ovary",
        "Stamen",
        "Pistil",
        "Stigma"
      ],
      "correct": 1,
      "explanation": "Stamen is the male part"
    },
    {
      "question": "Which of these is a communicable disease?",
      "options": [
        "Cancer",
        "Hypertension",
        "Diabetes",
        "Tuberculosis"
      ],
      "correct": 3,
      "explanation": "TB can be transmitted"
    },
    {
      "question": "The process of cell division that produces gametes is?",
      "options": [
        "Mitosis",
        "Meiosis",
        "Binary fission",
        "Budding"
      ],
      "correct": 1,
      "explanation": "Meiosis produces gametes"
    },
    {
      "question": "Which of these is found in plant cells but not animal cells?",
      "options": [
        "Cell wall",
        "Nucleus",
        "Mitochondria",
        "Cytoplasm"
      ],
      "correct": 0,
      "explanation": "Plant cells have cell walls"
    },
    {
      "question": "The hormone that regulates blood sugar is?",
      "options": [
        "Oestrogen",
        "Insulin",
        "Adrenaline",
        "Thyroxine"
      ],
      "correct": 1,
      "explanation": "Insulin regulates blood sugar"
    },
    {
      "question": "Which of these is a method of asexual reproduction?",
      "options": [
        "Copulation",
        "Budding",
        "Pollination",
        "Fertilization"
      ],
      "correct": 1,
      "explanation": "Budding is asexual"
    },
    {
      "question": "The largest artery in the body is the?",
      "options": [
        "Aorta",
        "Carotid artery",
        "Renal artery",
        "Pulmonary artery"
      ],
      "correct": 0,
      "explanation": "The aorta is the largest artery"
    },
    {
      "question": "Which of these is a characteristic of mammals?",
      "options": [
        "They are cold-blooded",
        "They lay eggs only",
        "They have scales",
        "They suckle their young"
      ],
      "correct": 3,
      "explanation": "Mammals feed their young with milk"
    },
    {
      "question": "Which of these is a function of the stem?",
      "options": [
        "Absorption of water",
        "Production of seeds only",
        "Support and transport",
        "Photosynthesis only"
      ],
      "correct": 2,
      "explanation": "Stems support the plant and transport materials"
    },
    {
      "question": "The liquid that lubricates joints is?",
      "options": [
        "Plasma",
        "Lymph",
        "Synovial fluid",
        "Blood"
      ],
      "correct": 2,
      "explanation": "Synovial fluid lubricates joints"
    },
    {
      "question": "Which of these is an example of a conditioned reflex?",
      "options": [
        "Blinking",
        "Sneezing",
        "Salivating at the sight of food",
        "Knee jerk"
      ],
      "correct": 2,
      "explanation": "Salivating at sight of food is learned"
    },
    {
      "question": "The part of the seed that develops into the shoot is?",
      "options": [
        "Testa",
        "Radicle",
        "Plumule",
        "Cotyledon"
      ],
      "correct": 2,
      "explanation": "Plumule becomes the shoot"
    },
    {
      "question": "Which of these animals is cold-blooded?",
      "options": [
        "Bat",
        "Whale",
        "Fish",
        "Bird"
      ],
      "correct": 2,
      "explanation": "Fish are cold-blooded"
    },
    {
      "question": "The organ that stores bile is the?",
      "options": [
        "Liver",
        "Gall bladder",
        "Pancreas",
        "Stomach"
      ],
      "correct": 1,
      "explanation": "Gall bladder stores bile"
    },
    {
      "question": "Which of these transmits sleeping sickness?",
      "options": [
        "Tsetse fly",
        "Housefly",
        "Cockroach",
        "Mosquito"
      ],
      "correct": 0,
      "explanation": "Tsetse fly transmits sleeping sickness"
    },
    {
      "question": "The loss of water vapour from leaves is?",
      "options": [
        "Photosynthesis",
        "Transpiration",
        "Guttation only",
        "Respiration"
      ],
      "correct": 1,
      "explanation": "Transpiration is loss of water vapour"
    },
    {
      "question": "Which of these is a modified root?",
      "options": [
        "Carrot",
        "Potato",
        "Ginger",
        "Onion"
      ],
      "correct": 0,
      "explanation": "Carrot is a modified root"
    },
    {
      "question": "The protein that helps in blood clotting is?",
      "options": [
        "Pepsin",
        "Insulin",
        "Haemoglobin",
        "Fibrinogen"
      ],
      "correct": 3,
      "explanation": "Fibrinogen is involved in clotting"
    },
    {
      "question": "Which of these is a colonial insect?",
      "options": [
        "Termite",
        "Butterfly",
        "Mosquito",
        "Housefly"
      ],
      "correct": 0,
      "explanation": "Termites live in colonies"
    },
    {
      "question": "The joint at the shoulder is?",
      "options": [
        "Pivot",
        "Hinge",
        "Ball and socket",
        "Gliding"
      ],
      "correct": 2,
      "explanation": "Shoulder is a ball and socket joint"
    },
    {
      "question": "Which of these is an example of budding?",
      "options": [
        "Yeast",
        "Bacteria",
        "Amoeba",
        "Spirogyra"
      ],
      "correct": 0,
      "explanation": "Yeast reproduces by budding"
    },
    {
      "question": "The part of the ear that detects sound is?",
      "options": [
        "Eardrum only",
        "Pinna",
        "Eustachian tube",
        "Cochlea"
      ],
      "correct": 3,
      "explanation": "Cochlea contains the hearing receptors"
    },
    {
      "question": "Which of these is a secondary consumer?",
      "options": [
        "Rabbit",
        "Snake",
        "Goat",
        "Cow"
      ],
      "correct": 1,
      "explanation": "Snakes eat primary consumers"
    },
    {
      "question": "The deficiency of vitamin D causes?",
      "options": [
        "Scurvy",
        "Beriberi",
        "Rickets",
        "Night blindness"
      ],
      "correct": 2,
      "explanation": "Lack of vitamin D causes rickets"
    },
    {
      "question": "Which of these is an excretory product in plants?",
      "options": [
        "Oxygen",
        "Protein",
        "Glucose",
        "Starch"
      ],
      "correct": 0,
      "explanation": "Oxygen is released during photosynthesis"
    },
    {
      "question": "The female part of a flower is the?",
      "options": [
        "Pistil",
        "Anther",
        "Filament",
        "Stamen"
      ],
      "correct": 0,
      "explanation": "Pistil is the female part"
    },
    {
      "question": "Which of these is a non-communicable disease?",
      "options": [
        "Malaria",
        "Cholera",
        "Tuberculosis",
        "Diabetes"
      ],
      "correct": 3,
      "explanation": "Diabetes is not transmitted from person to person"
    },
    {
      "question": "The process of cell division for growth is?",
      "options": [
        "Mitosis",
        "Budding",
        "Meiosis",
        "Fertilization"
      ],
      "correct": 0,
      "explanation": "Mitosis is for growth"
    },
    {
      "question": "Which of these is present in animal cells but not plant cells?",
      "options": [
        "Large vacuole",
        "Centriole",
        "Cell wall",
        "Chloroplast"
      ],
      "correct": 1,
      "explanation": "Centrioles are typical of animal cells"
    },
    {
      "question": "The hormone that prepares the body for fight or flight is?",
      "options": [
        "Adrenaline",
        "Insulin",
        "Oestrogen",
        "Thyroxine"
      ],
      "correct": 0,
      "explanation": "Adrenaline prepares for emergency"
    },
    {
      "question": "Which of these is a method of sexual reproduction?",
      "options": [
        "Budding",
        "Fragmentation",
        "Binary fission",
        "Fertilization"
      ],
      "correct": 3,
      "explanation": "Fertilization is sexual"
    },
    {
      "question": "The blood vessel that carries blood away from the heart is?",
      "options": [
        "Artery",
        "Capillary",
        "Venule",
        "Vein"
      ],
      "correct": 0,
      "explanation": "Arteries carry blood away from the heart"
    },
    {
      "question": "Which of these is a characteristic of birds?",
      "options": [
        "They have scales only",
        "They have feathers",
        "They suckle their young",
        "They are cold-blooded"
      ],
      "correct": 1,
      "explanation": "Birds have feathers"
    },
    {
      "question": "Which of these is a function of the xylem?",
      "options": [
        "Transport of water",
        "Reproduction",
        "Photosynthesis",
        "Transport of food only"
      ],
      "correct": 0,
      "explanation": "Xylem transports water and minerals"
    },
    {
      "question": "The muscle that pumps blood is the?",
      "options": [
        "Skeletal muscle",
        "Smooth muscle",
        "Voluntary muscle",
        "Cardiac muscle"
      ],
      "correct": 3,
      "explanation": "The heart is made of cardiac muscle"
    },
    {
      "question": "Which of these is an example of a tropism?",
      "options": [
        "Phototropism",
        "Excretion",
        "Respiration",
        "Digestion"
      ],
      "correct": 0,
      "explanation": "Phototropism is growth towards light"
    },
    {
      "question": "The part of the seed that stores food is the?",
      "options": [
        "Radicle",
        "Testa",
        "Cotyledon",
        "Plumule"
      ],
      "correct": 2,
      "explanation": "Cotyledons store food in many seeds"
    },
    {
      "question": "Which of these animals is warm-blooded?",
      "options": [
        "Bat",
        "Lizard",
        "Frog",
        "Snake"
      ],
      "correct": 0,
      "explanation": "Bats are mammals and warm-blooded"
    },
    {
      "question": "The organ that produces urine is the?",
      "options": [
        "Liver",
        "Heart",
        "Lungs",
        "Kidney"
      ],
      "correct": 3,
      "explanation": "Kidneys produce urine"
    },
    {
      "question": "Which of these transmits yellow fever?",
      "options": [
        "Anopheles mosquito",
        "Housefly",
        "Aedes mosquito",
        "Tsetse fly"
      ],
      "correct": 2,
      "explanation": "Aedes mosquito transmits yellow fever"
    },
    {
      "question": "The process by which plants make glucose is?",
      "options": [
        "Translocation",
        "Photosynthesis",
        "Transpiration",
        "Respiration"
      ],
      "correct": 1,
      "explanation": "Photosynthesis produces glucose"
    },
    {
      "question": "Which of these is a modified stem?",
      "options": [
        "Radish",
        "Potato",
        "Turnip",
        "Carrot"
      ],
      "correct": 1,
      "explanation": "Potato is a modified stem (tuber)"
    },
    {
      "question": "The component of blood that fights infection is?",
      "options": [
        "Platelets",
        "Plasma",
        "White blood cells",
        "Red blood cells"
      ],
      "correct": 2,
      "explanation": "White blood cells fight infection"
    },
    {
      "question": "Which of these is a solitary insect?",
      "options": [
        "Termite",
        "Butterfly",
        "Ant",
        "Bee"
      ],
      "correct": 1,
      "explanation": "Butterflies do not live in colonies"
    },
    {
      "question": "The joint that allows rotation is?",
      "options": [
        "Hinge joint",
        "Ball and socket only",
        "Pivot joint",
        "Gliding joint"
      ],
      "correct": 2,
      "explanation": "Pivot joints allow rotation"
    },
    {
      "question": "Which of these reproduces by binary fission?",
      "options": [
        "Amoeba",
        "Spirogyra mainly",
        "Yeast",
        "Mucor"
      ],
      "correct": 0,
      "explanation": "Amoeba divides by binary fission"
    },
    {
      "question": "The part of the eye that focuses light is the?",
      "options": [
        "Lens",
        "Iris",
        "Pupil",
        "Retina"
      ],
      "correct": 0,
      "explanation": "The lens focuses light on the retina"
    },
    {
      "question": "Which of these is a tertiary consumer?",
      "options": [
        "Eagle",
        "Grasshopper",
        "Rabbit",
        "Goat"
      ],
      "correct": 0,
      "explanation": "Eagles feed on secondary consumers"
    },
    {
      "question": "The deficiency of vitamin A causes?",
      "options": [
        "Scurvy",
        "Beriberi",
        "Night blindness",
        "Rickets"
      ],
      "correct": 2,
      "explanation": "Lack of vitamin A causes night blindness"
    },
    {
      "question": "Which of these is an organ of excretion in humans?",
      "options": [
        "Intestine mainly for egestion",
        "Heart",
        "Stomach",
        "Lungs"
      ],
      "correct": 3,
      "explanation": "Lungs excrete carbon dioxide"
    },
    {
      "question": "The transfer of pollen from anther to stigma is?",
      "options": [
        "Dispersal",
        "Pollination",
        "Fertilization",
        "Germination"
      ],
      "correct": 1,
      "explanation": "Pollination is transfer of pollen"
    },
    {
      "question": "Which of these is a viral disease?",
      "options": [
        "Tuberculosis",
        "Malaria",
        "Cholera",
        "Measles"
      ],
      "correct": 3,
      "explanation": "Measles is caused by a virus"
    },
    {
      "question": "The type of cell division that produces identical cells is?",
      "options": [
        "Mitosis",
        "Budding",
        "Fertilization",
        "Meiosis"
      ],
      "correct": 0,
      "explanation": "Mitosis produces identical cells"
    },
    {
      "question": "Which of these is found only in plant cells?",
      "options": [
        "Mitochondria",
        "Ribosome",
        "Chloroplast",
        "Nucleus"
      ],
      "correct": 2,
      "explanation": "Chloroplasts are in plant cells"
    },
    {
      "question": "The hormone that controls metamorphosis in insects is?",
      "options": [
        "Thyroxine",
        "Ecdysone",
        "Adrenaline",
        "Insulin"
      ],
      "correct": 1,
      "explanation": "Ecdysone is involved in insect metamorphosis"
    },
    {
      "question": "Which of these is a form of asexual reproduction in plants?",
      "options": [
        "Double fertilization",
        "Pollination",
        "Fertilization",
        "Vegetative propagation"
      ],
      "correct": 3,
      "explanation": "Vegetative propagation is asexual"
    },
    {
      "question": "The blood vessel that carries blood to the heart is?",
      "options": [
        "Vein",
        "Artery",
        "Capillary",
        "Aorta"
      ],
      "correct": 0,
      "explanation": "Veins carry blood to the heart"
    },
    {
      "question": "Which of these is a characteristic of amphibians?",
      "options": [
        "They have feathers",
        "They are warm-blooded only",
        "They suckle their young",
        "They live both on land and in water"
      ],
      "correct": 3,
      "explanation": "Amphibians live in both environments"
    },
    {
      "question": "Which of these transports food in plants?",
      "options": [
        "Xylem",
        "Phloem",
        "Cambium",
        "Epidermis"
      ],
      "correct": 1,
      "explanation": "Phloem transports food"
    },
    {
      "question": "The largest part of the human brain is?",
      "options": [
        "Cerebrum",
        "Medulla oblongata",
        "Spinal cord",
        "Cerebellum"
      ],
      "correct": 0,
      "explanation": "Cerebrum is the largest part"
    },
    {
      "question": "Which of these is a tropic movement?",
      "options": [
        "Respiration",
        "Transpiration",
        "Geotropism",
        "Photosynthesis"
      ],
      "correct": 2,
      "explanation": "Geotropism is growth in response to gravity"
    },
    {
      "question": "The protective covering of a seed is the?",
      "options": [
        "Testa",
        "Plumule",
        "Cotyledon",
        "Radicle"
      ],
      "correct": 0,
      "explanation": "Testa is the seed coat"
    },
    {
      "question": "Which of these is a mammal that lays eggs?",
      "options": [
        "Cat",
        "Dog",
        "Cow",
        "Platypus"
      ],
      "correct": 3,
      "explanation": "Platypus is an egg-laying mammal"
    },
    {
      "question": "The organ that detoxifies the blood is the?",
      "options": [
        "Heart",
        "Lungs",
        "Liver",
        "Kidney"
      ],
      "correct": 2,
      "explanation": "The liver detoxifies the blood"
    },
    {
      "question": "Which of these causes malaria?",
      "options": [
        "Fungus",
        "Plasmodium",
        "Bacterium",
        "Virus"
      ],
      "correct": 1,
      "explanation": "Plasmodium causes malaria"
    },
    {
      "question": "The process of releasing energy from food is?",
      "options": [
        "Respiration",
        "Photosynthesis",
        "Excretion",
        "Digestion"
      ],
      "correct": 0,
      "explanation": "Respiration releases energy"
    },
    {
      "question": "Which of these is a bulb?",
      "options": [
        "Potato",
        "Carrot",
        "Onion",
        "Ginger"
      ],
      "correct": 2,
      "explanation": "Onion is a bulb"
    },
    {
      "question": "The liquid part of the blood is?",
      "options": [
        "Serum only",
        "Lymph",
        "Haemoglobin",
        "Plasma"
      ],
      "correct": 3,
      "explanation": "Plasma is the liquid part"
    },
    {
      "question": "Which of these insects undergoes complete metamorphosis?",
      "options": [
        "Cockroach",
        "Dragonfly (incomplete)",
        "Grasshopper",
        "Butterfly"
      ],
      "correct": 3,
      "explanation": "Butterfly has complete metamorphosis"
    },
    {
      "question": "The type of joint in the knee is?",
      "options": [
        "Pivot",
        "Ball and socket",
        "Hinge joint",
        "Gliding"
      ],
      "correct": 2,
      "explanation": "Knee is a hinge joint"
    },
    {
      "question": "Which of these reproduces by spore formation?",
      "options": [
        "Yeast mainly",
        "Mucor",
        "Hydra",
        "Amoeba"
      ],
      "correct": 1,
      "explanation": "Mucor produces spores"
    },
    {
      "question": "The light-sensitive layer of the eye is the?",
      "options": [
        "Retina",
        "Iris",
        "Lens",
        "Cornea"
      ],
      "correct": 0,
      "explanation": "Retina is light-sensitive"
    },
    {
      "question": "Which of these is a producer?",
      "options": [
        "Eagle",
        "Lion",
        "Green algae",
        "Snake"
      ],
      "correct": 2,
      "explanation": "Green algae produce food"
    },
    {
      "question": "The deficiency of iodine causes?",
      "options": [
        "Rickets",
        "Scurvy",
        "Goitre",
        "Night blindness"
      ],
      "correct": 2,
      "explanation": "Iodine deficiency causes goitre"
    },
    {
      "question": "Which of these is an organ of respiration in fish?",
      "options": [
        "Skin only",
        "Lungs",
        "Gills",
        "Spiracles"
      ],
      "correct": 2,
      "explanation": "Fish breathe through gills"
    },
    {
      "question": "The fusion of male and female gametes is?",
      "options": [
        "Germination",
        "Fertilization",
        "Pollination",
        "Dispersal"
      ],
      "correct": 1,
      "explanation": "Fertilization is fusion of gametes"
    },
    {
      "question": "Which of these is a bacterial disease?",
      "options": [
        "Measles",
        "Cholera",
        "Influenza",
        "Malaria"
      ],
      "correct": 1,
      "explanation": "Cholera is bacterial"
    },
    {
      "question": "The cell division that reduces chromosome number is?",
      "options": [
        "Mitosis",
        "Binary fission",
        "Budding",
        "Meiosis"
      ],
      "correct": 3,
      "explanation": "Meiosis reduces chromosome number"
    },
    {
      "question": "Which of these structures is in plant cells?",
      "options": [
        "Flagellum mainly",
        "Cell wall",
        "Centriole",
        "Lysosome mainly"
      ],
      "correct": 1,
      "explanation": "Plant cells have cell walls"
    },
    {
      "question": "The hormone produced by the thyroid gland is?",
      "options": [
        "Insulin",
        "Oestrogen",
        "Thyroxine",
        "Adrenaline"
      ],
      "correct": 2,
      "explanation": "Thyroid produces thyroxine"
    },
    {
      "question": "Which of these is a method of artificial vegetative propagation?",
      "options": [
        "Pollination",
        "Seed formation",
        "Fertilization",
        "Cutting"
      ],
      "correct": 3,
      "explanation": "Cutting is artificial vegetative propagation"
    },
    {
      "question": "The blood vessel with thick walls is?",
      "options": [
        "Capillary",
        "Venule",
        "Vein",
        "Artery"
      ],
      "correct": 3,
      "explanation": "Arteries have thick walls"
    },
    {
      "question": "Which of these is a characteristic of reptiles?",
      "options": [
        "They have feathers",
        "They are warm-blooded",
        "They have dry scaly skin",
        "They suckle their young"
      ],
      "correct": 2,
      "explanation": "Reptiles have dry scaly skin"
    },
    {
      "question": "Which of these is a function of the stomata?",
      "options": [
        "Reproduction",
        "Gas exchange",
        "Absorption of water",
        "Support"
      ],
      "correct": 1,
      "explanation": "Stomata allow gas exchange"
    },
    {
      "question": "The part of the brain that controls balance is?",
      "options": [
        "Cerebrum",
        "Cerebellum",
        "Spinal cord",
        "Medulla"
      ],
      "correct": 1,
      "explanation": "Cerebellum controls balance"
    },
    {
      "question": "Which of these is a nastic movement?",
      "options": [
        "Phototropism",
        "Hydrotropism",
        "Geotropism",
        "Sleep movement of leaves"
      ],
      "correct": 3,
      "explanation": "Nastic movements are non-directional"
    },
    {
      "question": "The embryonic root is called?",
      "options": [
        "Testa",
        "Cotyledon",
        "Plumule",
        "Radicle"
      ],
      "correct": 3,
      "explanation": "Radicle develops into the root"
    },
    {
      "question": "Which of these is a pouched mammal?",
      "options": [
        "Cow",
        "Kangaroo",
        "Dog",
        "Cat"
      ],
      "correct": 1,
      "explanation": "Kangaroos are marsupials"
    },
    {
      "question": "The organ that produces digestive enzymes is the?",
      "options": [
        "Kidney",
        "Heart",
        "Pancreas",
        "Lung"
      ],
      "correct": 2,
      "explanation": "Pancreas produces digestive enzymes"
    },
    {
      "question": "Which of these causes elephantiasis?",
      "options": [
        "Trypanosome",
        "Filarial worm",
        "Plasmodium",
        "Virus"
      ],
      "correct": 1,
      "explanation": "Filarial worms cause elephantiasis"
    },
    {
      "question": "The process of using oxygen to break down food is?",
      "options": [
        "Photosynthesis",
        "Fermentation only",
        "Anaerobic only",
        "Aerobic respiration"
      ],
      "correct": 3,
      "explanation": "Aerobic respiration uses oxygen"
    },
    {
      "question": "Which of these is a rhizome?",
      "options": [
        "Potato",
        "Onion",
        "Carrot",
        "Ginger"
      ],
      "correct": 3,
      "explanation": "Ginger is a rhizome"
    },
    {
      "question": "The cells that carry oxygen are?",
      "options": [
        "Plasma cells",
        "Platelets",
        "Red blood cells",
        "White blood cells"
      ],
      "correct": 2,
      "explanation": "Red blood cells carry oxygen"
    },
    {
      "question": "Which of these insects has incomplete metamorphosis?",
      "options": [
        "Butterfly",
        "Mosquito",
        "Cockroach",
        "Housefly"
      ],
      "correct": 2,
      "explanation": "Cockroach has incomplete metamorphosis"
    },
    {
      "question": "The joint in the neck that allows turning is?",
      "options": [
        "Pivot joint",
        "Hinge joint",
        "Ball and socket",
        "Gliding"
      ],
      "correct": 0,
      "explanation": "Pivot joint allows rotation of the head"
    },
    {
      "question": "Which of these reproduces by fragmentation?",
      "options": [
        "Hydra mainly",
        "Yeast",
        "Spirogyra",
        "Amoeba"
      ],
      "correct": 2,
      "explanation": "Spirogyra can reproduce by fragmentation"
    },
    {
      "question": "The coloured part of the eye is the?",
      "options": [
        "Iris",
        "Cornea",
        "Retina",
        "Pupil"
      ],
      "correct": 0,
      "explanation": "The iris is the coloured part"
    },
    {
      "question": "Which of these is a detritivore?",
      "options": [
        "Lion",
        "Earthworm",
        "Goat",
        "Eagle"
      ],
      "correct": 1,
      "explanation": "Earthworms feed on dead organic matter"
    },
    {
      "question": "The deficiency of vitamin B1 causes?",
      "options": [
        "Scurvy",
        "Night blindness",
        "Beriberi",
        "Rickets"
      ],
      "correct": 2,
      "explanation": "Lack of vitamin B1 causes beriberi"
    },
    {
      "question": "Which of these is an organ of gaseous exchange in insects?",
      "options": [
        "Skin only",
        "Gills",
        "Lungs",
        "Spiracles"
      ],
      "correct": 3,
      "explanation": "Insects breathe through spiracles"
    },
    {
      "question": "The process after pollination that forms a zygote is?",
      "options": [
        "Dispersal",
        "Germination",
        "Photosynthesis",
        "Fertilization"
      ],
      "correct": 3,
      "explanation": "Fertilization follows pollination"
    },
    {
      "question": "Which of these is a fungal disease?",
      "options": [
        "Malaria",
        "Ringworm",
        "Measles",
        "Cholera"
      ],
      "correct": 1,
      "explanation": "Ringworm is caused by a fungus"
    },
    {
      "question": "The cell division in body cells is?",
      "options": [
        "Mitosis",
        "Budding",
        "Fertilization",
        "Meiosis"
      ],
      "correct": 0,
      "explanation": "Body cells divide by mitosis"
    },
    {
      "question": "Which of these is absent in animal cells?",
      "options": [
        "Cell membrane",
        "Mitochondria",
        "Chloroplast",
        "Nucleus"
      ],
      "correct": 2,
      "explanation": "Animal cells lack chloroplasts"
    },
    {
      "question": "The hormone that regulates metamorphosis in frogs is?",
      "options": [
        "Thyroxine",
        "Oestrogen",
        "Insulin",
        "Adrenaline"
      ],
      "correct": 0,
      "explanation": "Thyroxine influences frog metamorphosis"
    },
    {
      "question": "Which of these is a natural vegetative propagation method?",
      "options": [
        "Cutting",
        "Grafting",
        "Runner",
        "Budding artificially"
      ],
      "correct": 2,
      "explanation": "Runners are natural"
    },
    {
      "question": "The smallest blood vessels are?",
      "options": [
        "Veins",
        "Arteries",
        "Capillaries",
        "Aorta"
      ],
      "correct": 2,
      "explanation": "Capillaries are the smallest"
    },
    {
      "question": "Which of these is a characteristic of fish?",
      "options": [
        "They have lungs only",
        "They have feathers",
        "They have gills",
        "They are warm-blooded"
      ],
      "correct": 2,
      "explanation": "Fish breathe with gills"
    },
    {
      "question": "Which of these is a function of the root hairs?",
      "options": [
        "Support only",
        "Absorption of water and minerals",
        "Reproduction",
        "Photosynthesis"
      ],
      "correct": 1,
      "explanation": "Root hairs absorb water and minerals"
    },
    {
      "question": "The part of the brain that controls breathing is?",
      "options": [
        "Cerebrum",
        "Medulla oblongata",
        "Cerebellum",
        "Spinal cord"
      ],
      "correct": 1,
      "explanation": "Medulla controls involuntary actions like breathing"
    },
    {
      "question": "Which of these is a growth movement towards water?",
      "options": [
        "Thigmotropism",
        "Geotropism",
        "Phototropism",
        "Hydrotropism"
      ],
      "correct": 3,
      "explanation": "Hydrotropism is response to water"
    },
    {
      "question": "The embryonic shoot is called?",
      "options": [
        "Radicle",
        "Testa",
        "Cotyledon",
        "Plumule"
      ],
      "correct": 3,
      "explanation": "Plumule develops into the shoot"
    },
    {
      "question": "Which of these is a flying mammal?",
      "options": [
        "Bat",
        "Mosquito",
        "Butterfly",
        "Eagle"
      ],
      "correct": 0,
      "explanation": "Bats are flying mammals"
    },
    {
      "question": "The organ that produces bile is the?",
      "options": [
        "Pancreas",
        "Gall bladder",
        "Stomach",
        "Liver"
      ],
      "correct": 3,
      "explanation": "The liver produces bile"
    },
    {
      "question": "Which of these causes river blindness?",
      "options": [
        "Anopheles mosquito",
        "Simulium fly",
        "Tsetse fly",
        "Housefly"
      ],
      "correct": 1,
      "explanation": "Simulium (blackfly) transmits river blindness"
    },
    {
      "question": "The process of breaking down glucose without oxygen is?",
      "options": [
        "Photosynthesis",
        "Transpiration",
        "Anaerobic respiration",
        "Aerobic respiration"
      ],
      "correct": 2,
      "explanation": "Anaerobic respiration occurs without oxygen"
    },
    {
      "question": "Which of these is a tuber?",
      "options": [
        "Onion",
        "Yam",
        "Ginger",
        "Cabbage"
      ],
      "correct": 1,
      "explanation": "Yam is a tuber"
    },
    {
      "question": "The cells that help in blood clotting are?",
      "options": [
        "Plasma",
        "Red blood cells",
        "Platelets",
        "White blood cells"
      ],
      "correct": 2,
      "explanation": "Platelets help in clotting"
    },
    {
      "question": "Which of these insects undergoes complete metamorphosis?",
      "options": [
        "Mosquito",
        "Cockroach",
        "Grasshopper",
        "Dragonfly"
      ],
      "correct": 0,
      "explanation": "Mosquito has complete metamorphosis"
    },
    {
      "question": "The joint that allows movement in all directions is?",
      "options": [
        "Gliding",
        "Hinge",
        "Ball and socket",
        "Pivot"
      ],
      "correct": 2,
      "explanation": "Ball and socket allows wide movement"
    },
    {
      "question": "Which of these reproduces by budding?",
      "options": [
        "Spirogyra",
        "Amoeba",
        "Mucor mainly",
        "Hydra"
      ],
      "correct": 3,
      "explanation": "Hydra reproduces by budding"
    },
    {
      "question": "The transparent front part of the eye is the?",
      "options": [
        "Lens",
        "Retina",
        "Iris",
        "Cornea"
      ],
      "correct": 3,
      "explanation": "Cornea is the transparent front part"
    },
    {
      "question": "Which of these is a herbivore?",
      "options": [
        "Rabbit",
        "Lion",
        "Eagle",
        "Snake"
      ],
      "correct": 0,
      "explanation": "Rabbits eat plants"
    },
    {
      "question": "The deficiency of iron causes?",
      "options": [
        "Scurvy",
        "Anaemia",
        "Goitre",
        "Rickets"
      ],
      "correct": 1,
      "explanation": "Iron deficiency causes anaemia"
    },
    {
      "question": "Which of these is an excretory organ in humans?",
      "options": [
        "Heart",
        "Stomach",
        "Kidney",
        "Intestine mainly"
      ],
      "correct": 2,
      "explanation": "Kidneys are excretory organs"
    },
    {
      "question": "The transfer of pollen by insects is?",
      "options": [
        "Anemophily",
        "Autogamy only",
        "Hydrophily",
        "Entomophily"
      ],
      "correct": 3,
      "explanation": "Entomophily is insect pollination"
    },
    {
      "question": "Which of these is a protozoan disease?",
      "options": [
        "Cholera",
        "Measles",
        "Tuberculosis",
        "Malaria"
      ],
      "correct": 3,
      "explanation": "Malaria is caused by a protozoan"
    },
    {
      "question": "The type of cell division in gamete formation is?",
      "options": [
        "Budding",
        "Binary fission",
        "Mitosis",
        "Meiosis"
      ],
      "correct": 3,
      "explanation": "Meiosis produces gametes"
    },
    {
      "question": "Which of these is present in both plant and animal cells?",
      "options": [
        "Cell wall",
        "Chloroplast",
        "Large permanent vacuole",
        "Mitochondria"
      ],
      "correct": 3,
      "explanation": "Mitochondria are in both"
    },
    {
      "question": "The hormone that increases heart rate is?",
      "options": [
        "Thyroxine",
        "Oestrogen",
        "Adrenaline",
        "Insulin"
      ],
      "correct": 2,
      "explanation": "Adrenaline increases heart rate"
    },
    {
      "question": "Which of these is an artificial method of vegetative propagation?",
      "options": [
        "Runner",
        "Grafting",
        "Sucker",
        "Offset"
      ],
      "correct": 1,
      "explanation": "Grafting is artificial"
    },
    {
      "question": "The blood vessel that carries oxygenated blood is mainly?",
      "options": [
        "Venule",
        "Capillary only",
        "Artery",
        "Vein"
      ],
      "correct": 2,
      "explanation": "Most arteries carry oxygenated blood"
    },
    {
      "question": "Which of these is a characteristic of amphibians?",
      "options": [
        "Hair",
        "Feathers",
        "Dry scaly skin",
        "Moist skin"
      ],
      "correct": 3,
      "explanation": "Amphibians have moist skin"
    }
  ],
  "agr": [
    {
      "question": "The rearing of animals is called?",
      "options": [
        "Crop production",
        "Fishery",
        "Animal husbandry",
        "Forestry"
      ],
      "correct": 2,
      "explanation": "Animal husbandry is the rearing of animals"
    },
    {
      "question": "Which of these is a cash crop?",
      "options": [
        "Yam",
        "Cocoa",
        "Maize",
        "Cassava"
      ],
      "correct": 1,
      "explanation": "Cocoa is mainly grown for sale"
    },
    {
      "question": "The practice of growing crops and rearing animals is?",
      "options": [
        "Trading",
        "Mining",
        "Manufacturing",
        "Agriculture"
      ],
      "correct": 3,
      "explanation": "Agriculture involves crops and animals"
    },
    {
      "question": "Which soil is best for farming?",
      "options": [
        "Clay soil",
        "Rocky soil",
        "Loamy soil",
        "Sandy soil"
      ],
      "correct": 2,
      "explanation": "Loamy soil is ideal for most crops"
    },
    {
      "question": "The process of removing unwanted plants is?",
      "options": [
        "Planting",
        "Harvesting",
        "Weeding",
        "Watering"
      ],
      "correct": 2,
      "explanation": "Weeding removes unwanted plants"
    },
    {
      "question": "Which of these is a farm tool?",
      "options": [
        "Knife only",
        "Plate",
        "Spoon",
        "Hoe"
      ],
      "correct": 3,
      "explanation": "Hoe is a common farm tool"
    },
    {
      "question": "The young of a cow is called?",
      "options": [
        "Lamb",
        "Piglet",
        "Calf",
        "Kid"
      ],
      "correct": 2,
      "explanation": "A young cow is a calf"
    },
    {
      "question": "Which of these is a cereal crop?",
      "options": [
        "Cocoa",
        "Orange",
        "Maize",
        "Tomato"
      ],
      "correct": 2,
      "explanation": "Maize is a cereal"
    },
    {
      "question": "The process of gathering mature crops is?",
      "options": [
        "Weeding",
        "Irrigation",
        "Planting",
        "Harvesting"
      ],
      "correct": 3,
      "explanation": "Harvesting is gathering crops"
    },
    {
      "question": "Which animal gives us milk?",
      "options": [
        "Dog",
        "Cow",
        "Lion",
        "Cat"
      ],
      "correct": 1,
      "explanation": "Cows are reared for milk"
    },
    {
      "question": "The system of farming for family use only is?",
      "options": [
        "Commercial farming",
        "Mixed farming",
        "Subsistence farming",
        "Plantation farming"
      ],
      "correct": 2,
      "explanation": "Subsistence farming is for family consumption"
    },
    {
      "question": "Which of these is a legume?",
      "options": [
        "Maize",
        "Yam",
        "Cowpea",
        "Rice"
      ],
      "correct": 2,
      "explanation": "Cowpea is a legume"
    },
    {
      "question": "The act of supplying water to crops is?",
      "options": [
        "Drainage",
        "Mulching",
        "Irrigation",
        "Weeding"
      ],
      "correct": 2,
      "explanation": "Irrigation supplies water to crops"
    },
    {
      "question": "Which of these is a poultry bird?",
      "options": [
        "Sheep",
        "Cow",
        "Chicken",
        "Goat"
      ],
      "correct": 2,
      "explanation": "Chicken is a poultry bird"
    },
    {
      "question": "The top layer of the soil is called?",
      "options": [
        "Parent material",
        "Topsoil",
        "Subsoil",
        "Bedrock"
      ],
      "correct": 1,
      "explanation": "Topsoil is the uppermost layer"
    },
    {
      "question": "Which of these is used for ploughing?",
      "options": [
        "Basket",
        "Tractor",
        "Cutlass only",
        "Rake only"
      ],
      "correct": 1,
      "explanation": "Tractors are used for ploughing"
    },
    {
      "question": "The young of a goat is called?",
      "options": [
        "Calf",
        "Lamb",
        "Foal",
        "Kid"
      ],
      "correct": 3,
      "explanation": "A young goat is a kid"
    },
    {
      "question": "Which crop is used to make flour?",
      "options": [
        "Wheat",
        "Cotton",
        "Rubber",
        "Cocoa"
      ],
      "correct": 0,
      "explanation": "Wheat is used for flour"
    },
    {
      "question": "The removal of excess water from farmland is?",
      "options": [
        "Mulching",
        "Irrigation",
        "Drainage",
        "Terracing"
      ],
      "correct": 2,
      "explanation": "Drainage removes excess water"
    },
    {
      "question": "Which of these is a root crop?",
      "options": [
        "Beans",
        "Maize",
        "Rice",
        "Cassava"
      ],
      "correct": 3,
      "explanation": "Cassava is a root crop"
    },
    {
      "question": "The practice of keeping bees is called?",
      "options": [
        "Apiculture",
        "Aquaculture",
        "Sericulture",
        "Horticulture"
      ],
      "correct": 0,
      "explanation": "Apiculture is beekeeping"
    },
    {
      "question": "Which of these animals is reared for meat?",
      "options": [
        "Horse mainly",
        "Cat",
        "Pig",
        "Dog"
      ],
      "correct": 2,
      "explanation": "Pigs are commonly reared for meat"
    },
    {
      "question": "The process of preparing the soil for planting is?",
      "options": [
        "Harvesting",
        "Tillage",
        "Storage",
        "Marketing"
      ],
      "correct": 1,
      "explanation": "Tillage prepares the soil"
    },
    {
      "question": "Which of these is a fruit crop?",
      "options": [
        "Cassava",
        "Rice",
        "Orange",
        "Yam"
      ],
      "correct": 2,
      "explanation": "Orange is a fruit crop"
    },
    {
      "question": "The science of crop production is called?",
      "options": [
        "Botany only",
        "Agronomy",
        "Zoology",
        "Ecology"
      ],
      "correct": 1,
      "explanation": "Agronomy deals with crop production"
    },
    {
      "question": "Which of these is a farm implement?",
      "options": [
        "Plate",
        "Plough",
        "Spoon",
        "Cup"
      ],
      "correct": 1,
      "explanation": "Plough is a farm implement"
    },
    {
      "question": "The young of a sheep is called?",
      "options": [
        "Calf",
        "Piglet",
        "Lamb",
        "Kid"
      ],
      "correct": 2,
      "explanation": "A young sheep is a lamb"
    },
    {
      "question": "Which of these is a tuber crop?",
      "options": [
        "Rice",
        "Yam",
        "Beans",
        "Maize"
      ],
      "correct": 1,
      "explanation": "Yam is a tuber"
    },
    {
      "question": "The practice of growing only one type of crop is?",
      "options": [
        "Crop rotation",
        "Monocropping",
        "Intercropping",
        "Mixed farming"
      ],
      "correct": 1,
      "explanation": "Monocropping is growing one crop"
    },
    {
      "question": "Which animal is reared for wool?",
      "options": [
        "Cow",
        "Pig",
        "Sheep",
        "Goat"
      ],
      "correct": 2,
      "explanation": "Sheep provide wool"
    },
    {
      "question": "The process of transferring pollen is?",
      "options": [
        "Pollination",
        "Photosynthesis",
        "Germination",
        "Fertilization"
      ],
      "correct": 0,
      "explanation": "Pollination is transfer of pollen"
    },
    {
      "question": "Which of these is a source of protein?",
      "options": [
        "Cassava",
        "Yam",
        "Beans",
        "Sugarcane"
      ],
      "correct": 2,
      "explanation": "Beans are rich in protein"
    },
    {
      "question": "The removal of some plants to reduce competition is?",
      "options": [
        "Mulching",
        "Weeding",
        "Harvesting",
        "Thinning"
      ],
      "correct": 3,
      "explanation": "Thinning reduces competition"
    },
    {
      "question": "Which of these is a poultry product?",
      "options": [
        "Milk",
        "Hide",
        "Wool",
        "Egg"
      ],
      "correct": 3,
      "explanation": "Eggs come from poultry"
    },
    {
      "question": "The system of farming that combines crops and animals is?",
      "options": [
        "Monocropping",
        "Shifting cultivation",
        "Mixed farming",
        "Pastoral farming"
      ],
      "correct": 2,
      "explanation": "Mixed farming combines both"
    },
    {
      "question": "Which of these is used for cutting grass?",
      "options": [
        "Watering can",
        "Rake",
        "Hoe",
        "Cutlass"
      ],
      "correct": 3,
      "explanation": "Cutlass is used for cutting"
    },
    {
      "question": "The young of a pig is called?",
      "options": [
        "Piglet",
        "Kid",
        "Lamb",
        "Calf"
      ],
      "correct": 0,
      "explanation": "A young pig is a piglet"
    },
    {
      "question": "Which crop is used to produce oil?",
      "options": [
        "Oil palm",
        "Cassava",
        "Yam",
        "Maize mainly"
      ],
      "correct": 0,
      "explanation": "Oil palm produces palm oil"
    },
    {
      "question": "The covering of soil surface with materials is?",
      "options": [
        "Tillage",
        "Mulching",
        "Irrigation",
        "Drainage"
      ],
      "correct": 1,
      "explanation": "Mulching covers the soil"
    },
    {
      "question": "Which of these is a disease of plants?",
      "options": [
        "Cholera",
        "Malaria",
        "Typhoid",
        "Blight"
      ],
      "correct": 3,
      "explanation": "Blight affects plants"
    },
    {
      "question": "The rearing of fish is called?",
      "options": [
        "Horticulture",
        "Aquaculture",
        "Apiculture",
        "Sericulture"
      ],
      "correct": 1,
      "explanation": "Aquaculture is fish farming"
    },
    {
      "question": "Which of these is a vegetable crop?",
      "options": [
        "Cocoa",
        "Tomato",
        "Rubber",
        "Cotton"
      ],
      "correct": 1,
      "explanation": "Tomato is a vegetable"
    },
    {
      "question": "The process of keeping the farm clean is?",
      "options": [
        "Processing",
        "Sanitation",
        "Marketing",
        "Harvesting"
      ],
      "correct": 1,
      "explanation": "Sanitation keeps the farm clean"
    },
    {
      "question": "Which animal provides both milk and meat?",
      "options": [
        "Goat",
        "Cat",
        "Chicken",
        "Dog"
      ],
      "correct": 0,
      "explanation": "Goats provide milk and meat"
    },
    {
      "question": "The growing of fruits and vegetables is?",
      "options": [
        "Aquaculture",
        "Apiculture",
        "Sericulture",
        "Horticulture"
      ],
      "correct": 3,
      "explanation": "Horticulture deals with fruits and vegetables"
    },
    {
      "question": "Which of these is a pest of crops?",
      "options": [
        "Locust",
        "Bee",
        "Butterfly (adult mainly)",
        "Earthworm"
      ],
      "correct": 0,
      "explanation": "Locusts destroy crops"
    },
    {
      "question": "The method of farming that moves from place to place is?",
      "options": [
        "Mixed farming",
        "Commercial farming",
        "Shifting cultivation",
        "Plantation farming"
      ],
      "correct": 2,
      "explanation": "Shifting cultivation involves moving"
    },
    {
      "question": "Which of these is a storage structure?",
      "options": [
        "Silo",
        "Cutlass",
        "Rake",
        "Hoe"
      ],
      "correct": 0,
      "explanation": "Silos store grains"
    },
    {
      "question": "The act of putting seeds into the soil is?",
      "options": [
        "Planting",
        "Threshing",
        "Harvesting",
        "Weeding"
      ],
      "correct": 0,
      "explanation": "Planting puts seeds in the soil"
    },
    {
      "question": "Which of these is a fibre crop?",
      "options": [
        "Tomato",
        "Yam",
        "Cotton",
        "Maize"
      ],
      "correct": 2,
      "explanation": "Cotton provides fibre"
    },
    {
      "question": "Which of these is a farm structure?",
      "options": [
        "Barn",
        "Hoe",
        "Cutlass",
        "Rake"
      ],
      "correct": 0,
      "explanation": "A barn is a farm structure"
    },
    {
      "question": "The young of a horse is called?",
      "options": [
        "Kid",
        "Foal",
        "Lamb",
        "Calf"
      ],
      "correct": 1,
      "explanation": "A young horse is a foal"
    },
    {
      "question": "Which of these is a spice crop?",
      "options": [
        "Maize",
        "Yam",
        "Cassava",
        "Pepper"
      ],
      "correct": 3,
      "explanation": "Pepper is used as a spice"
    },
    {
      "question": "The system of farming on a large scale for sale is?",
      "options": [
        "Commercial farming",
        "Nomadic farming",
        "Shifting cultivation",
        "Subsistence farming"
      ],
      "correct": 0,
      "explanation": "Commercial farming is for sale"
    },
    {
      "question": "Which animal is used for drought power?",
      "options": [
        "Ox",
        "Goat mainly",
        "Chicken",
        "Rabbit"
      ],
      "correct": 0,
      "explanation": "Oxen are used for ploughing"
    },
    {
      "question": "The process of removing harvested crops from the field is?",
      "options": [
        "Weeding",
        "Fertilizing",
        "Harvesting",
        "Planting"
      ],
      "correct": 2,
      "explanation": "Harvesting removes mature crops"
    },
    {
      "question": "Which of these is a source of carbohydrates?",
      "options": [
        "Beans",
        "Fish",
        "Yam",
        "Meat"
      ],
      "correct": 2,
      "explanation": "Yam is rich in carbohydrates"
    },
    {
      "question": "The addition of nutrients to the soil is?",
      "options": [
        "Fertilization",
        "Irrigation",
        "Drainage",
        "Weeding"
      ],
      "correct": 0,
      "explanation": "Fertilizers add nutrients"
    },
    {
      "question": "Which of these is a ruminant animal?",
      "options": [
        "Pig",
        "Chicken",
        "Cow",
        "Dog"
      ],
      "correct": 2,
      "explanation": "Cows are ruminants"
    },
    {
      "question": "The practice of growing different crops on the same land in sequence is?",
      "options": [
        "Mixed cropping",
        "Intercropping",
        "Crop rotation",
        "Monocropping"
      ],
      "correct": 2,
      "explanation": "Crop rotation changes crops over seasons"
    },
    {
      "question": "Which of these is used for watering crops?",
      "options": [
        "Cutlass",
        "Rake",
        "Watering can",
        "Hoe"
      ],
      "correct": 2,
      "explanation": "Watering can is used for irrigation on small scale"
    },
    {
      "question": "The young of a rabbit is called?",
      "options": [
        "Foal",
        "Kit",
        "Calf",
        "Kid"
      ],
      "correct": 1,
      "explanation": "A young rabbit is a kit"
    },
    {
      "question": "Which crop is used for making sugar?",
      "options": [
        "Rubber",
        "Sugarcane",
        "Cotton",
        "Cocoa"
      ],
      "correct": 1,
      "explanation": "Sugarcane produces sugar"
    },
    {
      "question": "The protection of crops from pests is?",
      "options": [
        "Pest control",
        "Storage only",
        "Harvesting",
        "Marketing"
      ],
      "correct": 0,
      "explanation": "Pest control protects crops"
    },
    {
      "question": "Which of these is a leafy vegetable?",
      "options": [
        "Yam",
        "Cocoa",
        "Cassava",
        "Spinach"
      ],
      "correct": 3,
      "explanation": "Spinach is a leafy vegetable"
    },
    {
      "question": "The rearing of silk worms is called?",
      "options": [
        "Apiculture",
        "Sericulture",
        "Aquaculture",
        "Horticulture"
      ],
      "correct": 1,
      "explanation": "Sericulture is silk farming"
    },
    {
      "question": "Which of these is a soil conservation method?",
      "options": [
        "Terracing",
        "Bush burning",
        "Overgrazing",
        "Deforestation"
      ],
      "correct": 0,
      "explanation": "Terracing conserves soil"
    },
    {
      "question": "The process of separating grains from chaff is?",
      "options": [
        "Winnowing",
        "Harvesting",
        "Planting",
        "Threshing"
      ],
      "correct": 0,
      "explanation": "Winnowing separates grains from chaff"
    },
    {
      "question": "Which animal is reared mainly for eggs?",
      "options": [
        "Chicken",
        "Goat",
        "Cow",
        "Sheep"
      ],
      "correct": 0,
      "explanation": "Chickens are reared for eggs"
    },
    {
      "question": "The growing of crops in water is?",
      "options": [
        "Apiculture",
        "Sericulture",
        "Hydroponics",
        "Aquaculture only"
      ],
      "correct": 2,
      "explanation": "Hydroponics grows plants in water"
    },
    {
      "question": "Which of these is a fungal disease of crops?",
      "options": [
        "Blight only",
        "Mosaic",
        "Wilt only",
        "Rust"
      ],
      "correct": 3,
      "explanation": "Rust is a fungal disease"
    },
    {
      "question": "The system where farmers move with their animals is?",
      "options": [
        "Plantation farming",
        "Nomadic herding",
        "Mixed farming",
        "Commercial farming"
      ],
      "correct": 1,
      "explanation": "Nomadic herding involves moving with animals"
    },
    {
      "question": "Which of these is a processing activity?",
      "options": [
        "Harvesting only",
        "Milling of rice",
        "Planting",
        "Weeding"
      ],
      "correct": 1,
      "explanation": "Milling is a processing activity"
    },
    {
      "question": "The act of putting seedlings into the field is?",
      "options": [
        "Transplanting",
        "Direct sowing",
        "Broadcasting",
        "Dibbling only"
      ],
      "correct": 0,
      "explanation": "Transplanting moves seedlings to the field"
    },
    {
      "question": "Which of these is a tree crop?",
      "options": [
        "Maize",
        "Pepper",
        "Cocoa",
        "Tomato"
      ],
      "correct": 2,
      "explanation": "Cocoa is a tree crop"
    },
    {
      "question": "Which of these is a farm building?",
      "options": [
        "Rake",
        "Hoe",
        "Cutlass",
        "Poultry house"
      ],
      "correct": 3,
      "explanation": "Poultry house is a farm building"
    },
    {
      "question": "The young of a duck is called?",
      "options": [
        "Gosling",
        "Chick",
        "Poult",
        "Duckling"
      ],
      "correct": 3,
      "explanation": "A young duck is a duckling"
    },
    {
      "question": "Which of these is a beverage crop?",
      "options": [
        "Yam",
        "Cocoa",
        "Maize",
        "Cassava"
      ],
      "correct": 1,
      "explanation": "Cocoa is used for beverages"
    },
    {
      "question": "The farming system that involves growing crops and keeping animals is?",
      "options": [
        "Mixed farming",
        "Shifting cultivation",
        "Monocropping",
        "Pastoral farming"
      ],
      "correct": 0,
      "explanation": "Mixed farming combines crops and animals"
    },
    {
      "question": "Which animal is mainly reared for meat in Nigeria?",
      "options": [
        "Horse",
        "Goat",
        "Cat",
        "Dog"
      ],
      "correct": 1,
      "explanation": "Goats are commonly reared for meat"
    },
    {
      "question": "The process of collecting mature fruits is?",
      "options": [
        "Harvesting",
        "Planting",
        "Pruning",
        "Weeding"
      ],
      "correct": 0,
      "explanation": "Harvesting is collecting mature crops"
    },
    {
      "question": "Which of these is a source of vitamins?",
      "options": [
        "Salt",
        "Oil only",
        "Sugar",
        "Fruits"
      ],
      "correct": 3,
      "explanation": "Fruits provide vitamins"
    },
    {
      "question": "The addition of organic matter to the soil is?",
      "options": [
        "Manuring",
        "Drainage",
        "Weeding",
        "Irrigation"
      ],
      "correct": 0,
      "explanation": "Manuring adds organic matter"
    },
    {
      "question": "Which of these animals has a four-chambered stomach?",
      "options": [
        "Chicken",
        "Cow",
        "Dog",
        "Pig"
      ],
      "correct": 1,
      "explanation": "Cows are ruminants with four chambers"
    },
    {
      "question": "The growing of two or more crops together is?",
      "options": [
        "Monocropping",
        "Shifting cultivation",
        "Intercropping",
        "Crop rotation"
      ],
      "correct": 2,
      "explanation": "Intercropping grows crops together"
    },
    {
      "question": "Which of these is used for digging?",
      "options": [
        "Hoe",
        "Rake",
        "Cutlass",
        "Watering can"
      ],
      "correct": 0,
      "explanation": "Hoe is used for digging"
    },
    {
      "question": "The young of a turkey is called?",
      "options": [
        "Poult",
        "Chick",
        "Gosling",
        "Duckling"
      ],
      "correct": 0,
      "explanation": "A young turkey is a poult"
    },
    {
      "question": "Which crop is used for making chocolate?",
      "options": [
        "Coffee",
        "Tea",
        "Sugarcane",
        "Cocoa"
      ],
      "correct": 3,
      "explanation": "Cocoa is used for chocolate"
    },
    {
      "question": "The control of weeds is?",
      "options": [
        "Pest control only",
        "Harvesting",
        "Disease control only",
        "Weed control"
      ],
      "correct": 3,
      "explanation": "Weed control removes unwanted plants"
    },
    {
      "question": "Which of these is a fruit vegetable?",
      "options": [
        "Cabbage",
        "Lettuce",
        "Tomato",
        "Spinach"
      ],
      "correct": 2,
      "explanation": "Tomato is a fruit used as vegetable"
    },
    {
      "question": "The keeping of honey bees is?",
      "options": [
        "Apiculture",
        "Horticulture",
        "Aquaculture",
        "Sericulture"
      ],
      "correct": 0,
      "explanation": "Apiculture is beekeeping"
    },
    {
      "question": "Which of these helps to prevent soil erosion?",
      "options": [
        "Cover crops",
        "Deforestation",
        "Overgrazing",
        "Bush burning"
      ],
      "correct": 0,
      "explanation": "Cover crops protect the soil"
    },
    {
      "question": "The process of removing grains from the panicle is?",
      "options": [
        "Threshing",
        "Harvesting",
        "Winnowing",
        "Milling"
      ],
      "correct": 0,
      "explanation": "Threshing separates grains"
    },
    {
      "question": "Which animal is reared for milk in Nigeria?",
      "options": [
        "Pig",
        "Chicken",
        "Rabbit",
        "Cow"
      ],
      "correct": 3,
      "explanation": "Cows are the main source of milk"
    },
    {
      "question": "The growing of plants without soil is?",
      "options": [
        "Apiculture",
        "Aquaculture",
        "Sericulture",
        "Hydroponics"
      ],
      "correct": 3,
      "explanation": "Hydroponics grows plants in nutrient solution"
    },
    {
      "question": "Which of these is a bacterial disease of plants?",
      "options": [
        "Rust",
        "Mosaic",
        "Blight",
        "Smut"
      ],
      "correct": 2,
      "explanation": "Some blights are bacterial"
    },
    {
      "question": "The system of farming that depends on rainfall is?",
      "options": [
        "Greenhouse farming",
        "Rain-fed agriculture",
        "Hydroponics",
        "Irrigation farming"
      ],
      "correct": 1,
      "explanation": "Rain-fed depends on rainfall"
    },
    {
      "question": "Which of these is a post-harvest activity?",
      "options": [
        "Planting",
        "Weeding",
        "Land preparation",
        "Storage"
      ],
      "correct": 3,
      "explanation": "Storage is done after harvest"
    },
    {
      "question": "The act of cutting branches of trees is?",
      "options": [
        "Harvesting",
        "Thinning only",
        "Weeding",
        "Pruning"
      ],
      "correct": 3,
      "explanation": "Pruning is cutting branches"
    },
    {
      "question": "Which of these is a plantation crop?",
      "options": [
        "Rubber",
        "Pepper",
        "Maize",
        "Tomato"
      ],
      "correct": 0,
      "explanation": "Rubber is grown on plantations"
    },
    {
      "question": "Which of these is a storage structure for grains?",
      "options": [
        "Hoe",
        "Silo",
        "Rake",
        "Cutlass"
      ],
      "correct": 1,
      "explanation": "Silos store grains"
    },
    {
      "question": "The young of a goose is called?",
      "options": [
        "Poult",
        "Chick",
        "Duckling",
        "Gosling"
      ],
      "correct": 3,
      "explanation": "A young goose is a gosling"
    },
    {
      "question": "Which of these is a stimulant crop?",
      "options": [
        "Tea",
        "Cassava",
        "Yam",
        "Maize"
      ],
      "correct": 0,
      "explanation": "Tea is a stimulant crop"
    },
    {
      "question": "The farming system practised in areas with low rainfall is?",
      "options": [
        "Hydroponics",
        "Dry farming",
        "Greenhouse only",
        "Irrigation farming only"
      ],
      "correct": 1,
      "explanation": "Dry farming is used in low rainfall areas"
    },
    {
      "question": "Which animal is mainly used for transportation in some areas?",
      "options": [
        "Donkey",
        "Rabbit",
        "Chicken",
        "Pig"
      ],
      "correct": 0,
      "explanation": "Donkeys are used for transport"
    },
    {
      "question": "The process of preparing land for planting is?",
      "options": [
        "Land preparation",
        "Harvesting",
        "Storage",
        "Marketing"
      ],
      "correct": 0,
      "explanation": "Land preparation gets the soil ready"
    },
    {
      "question": "Which of these is a source of fats and oils?",
      "options": [
        "Groundnut",
        "Cassava",
        "Yam",
        "Rice"
      ],
      "correct": 0,
      "explanation": "Groundnut is rich in oil"
    },
    {
      "question": "The use of chemicals to control pests is?",
      "options": [
        "Mechanical control only",
        "Biological control",
        "Cultural control",
        "Chemical control"
      ],
      "correct": 3,
      "explanation": "Chemical control uses pesticides"
    },
    {
      "question": "Which of these animals is a monogastric?",
      "options": [
        "Sheep",
        "Cow",
        "Goat",
        "Pig"
      ],
      "correct": 3,
      "explanation": "Pigs have a simple stomach"
    },
    {
      "question": "The practice of growing crops in a definite pattern is?",
      "options": [
        "Shifting cultivation",
        "Crop geometry",
        "Monocropping only",
        "Mixed farming"
      ],
      "correct": 1,
      "explanation": "Crop geometry refers to arrangement of crops"
    },
    {
      "question": "Which of these is used for levelling the soil?",
      "options": [
        "Cutlass",
        "Rake",
        "Axe",
        "Hoe"
      ],
      "correct": 1,
      "explanation": "Rake is used for levelling"
    },
    {
      "question": "The young of a hen is called?",
      "options": [
        "Duckling",
        "Chick",
        "Poult",
        "Gosling"
      ],
      "correct": 1,
      "explanation": "A young hen is a chick"
    },
    {
      "question": "Which crop is used for making coffee?",
      "options": [
        "Tea",
        "Coffee",
        "Kola",
        "Cocoa"
      ],
      "correct": 1,
      "explanation": "Coffee is made from coffee beans"
    },
    {
      "question": "The removal of diseased plants is?",
      "options": [
        "Weeding only",
        "Pruning only",
        "Rouging",
        "Harvesting"
      ],
      "correct": 2,
      "explanation": "Rouging removes diseased plants"
    },
    {
      "question": "Which of these is a root vegetable?",
      "options": [
        "Tomato",
        "Carrot",
        "Lettuce",
        "Cabbage"
      ],
      "correct": 1,
      "explanation": "Carrot is a root vegetable"
    },
    {
      "question": "The rearing of snails is called?",
      "options": [
        "Aquaculture",
        "Apiculture",
        "Heliculture",
        "Sericulture"
      ],
      "correct": 2,
      "explanation": "Heliculture is snail farming"
    },
    {
      "question": "Which of these is a soil conservation practice?",
      "options": [
        "Bush burning",
        "Contour ploughing",
        "Overgrazing",
        "Deforestation"
      ],
      "correct": 1,
      "explanation": "Contour ploughing reduces erosion"
    },
    {
      "question": "The process of cleaning grains is?",
      "options": [
        "Harvesting",
        "Threshing",
        "Planting",
        "Winnowing"
      ],
      "correct": 3,
      "explanation": "Winnowing cleans the grains"
    },
    {
      "question": "Which animal is mainly reared for eggs and meat?",
      "options": [
        "Cow",
        "Chicken",
        "Goat",
        "Sheep"
      ],
      "correct": 1,
      "explanation": "Chickens provide both eggs and meat"
    },
    {
      "question": "The growing of crops under controlled environment is?",
      "options": [
        "Nomadic farming",
        "Rain-fed farming",
        "Greenhouse farming",
        "Shifting cultivation"
      ],
      "correct": 2,
      "explanation": "Greenhouse farming is controlled"
    },
    {
      "question": "Which of these is a viral disease of plants?",
      "options": [
        "Rust",
        "Mosaic",
        "Blight only",
        "Smut"
      ],
      "correct": 1,
      "explanation": "Mosaic diseases are often viral"
    },
    {
      "question": "The system of farming near urban areas is?",
      "options": [
        "Nomadic farming",
        "Shifting cultivation",
        "Pastoral farming",
        "Urban agriculture"
      ],
      "correct": 3,
      "explanation": "Urban agriculture is near cities"
    },
    {
      "question": "Which of these is a marketing activity?",
      "options": [
        "Weeding",
        "Selling of produce",
        "Planting",
        "Land preparation"
      ],
      "correct": 1,
      "explanation": "Selling is a marketing activity"
    },
    {
      "question": "The act of removing excess seedlings is?",
      "options": [
        "Pruning",
        "Thinning",
        "Mulching",
        "Harvesting"
      ],
      "correct": 1,
      "explanation": "Thinning removes excess plants"
    },
    {
      "question": "Which of these is an industrial crop?",
      "options": [
        "Tomato",
        "Lettuce",
        "Cabbage",
        "Cotton"
      ],
      "correct": 3,
      "explanation": "Cotton is used in industry"
    },
    {
      "question": "Which of these is used for storing yams?",
      "options": [
        "Basket only",
        "Silo only",
        "Refrigerator only",
        "Yam barn"
      ],
      "correct": 3,
      "explanation": "Yam barns are used for storing yams"
    },
    {
      "question": "The male chicken is called?",
      "options": [
        "Cock",
        "Hen",
        "Chick",
        "Pullet"
      ],
      "correct": 0,
      "explanation": "A male chicken is a cock"
    },
    {
      "question": "Which of these is a cereal crop?",
      "options": [
        "Cocoa",
        "Rice",
        "Cotton",
        "Rubber"
      ],
      "correct": 1,
      "explanation": "Rice is a cereal"
    },
    {
      "question": "The farming system that involves moving to new land is?",
      "options": [
        "Plantation farming",
        "Mixed farming",
        "Shifting cultivation",
        "Commercial farming"
      ],
      "correct": 2,
      "explanation": "Shifting cultivation involves moving"
    },
    {
      "question": "Which animal is mainly reared in the northern part of Nigeria?",
      "options": [
        "Cattle",
        "Fish mainly",
        "Pig mainly",
        "Snail"
      ],
      "correct": 0,
      "explanation": "Cattle rearing is common in the north"
    },
    {
      "question": "The process of applying fertilizer is?",
      "options": [
        "Planting only",
        "Weeding",
        "Harvesting",
        "Fertilizer application"
      ],
      "correct": 3,
      "explanation": "Fertilizer application adds nutrients"
    },
    {
      "question": "Which of these is a protein-rich crop?",
      "options": [
        "Soybean",
        "Sugarcane",
        "Cassava",
        "Yam"
      ],
      "correct": 0,
      "explanation": "Soybean is rich in protein"
    },
    {
      "question": "The use of natural enemies to control pests is?",
      "options": [
        "Mechanical control",
        "Chemical control",
        "Biological control",
        "Cultural control"
      ],
      "correct": 2,
      "explanation": "Biological control uses natural enemies"
    },
    {
      "question": "Which of these animals chews the cud?",
      "options": [
        "Chicken",
        "Goat",
        "Pig",
        "Dog"
      ],
      "correct": 1,
      "explanation": "Goats are ruminants"
    },
    {
      "question": "The practice of growing crops and trees together is?",
      "options": [
        "Pastoral farming",
        "Monocropping",
        "Agroforestry",
        "Shifting cultivation"
      ],
      "correct": 2,
      "explanation": "Agroforestry combines crops and trees"
    },
    {
      "question": "Which of these is used for transplanting seedlings?",
      "options": [
        "Tractor only",
        "Cutlass mainly",
        "Axe",
        "Trowel"
      ],
      "correct": 3,
      "explanation": "Trowel is used for transplanting"
    },
    {
      "question": "The female chicken is called?",
      "options": [
        "Hen",
        "Cockerel",
        "Rooster",
        "Cock"
      ],
      "correct": 0,
      "explanation": "A female chicken is a hen"
    },
    {
      "question": "Which crop is used for making tea?",
      "options": [
        "Coffee",
        "Kola",
        "Tea",
        "Cocoa"
      ],
      "correct": 2,
      "explanation": "Tea is made from tea leaves"
    },
    {
      "question": "The removal of weeds by hand is?",
      "options": [
        "Manual weeding",
        "Mechanical only",
        "Chemical weeding",
        "Biological weeding"
      ],
      "correct": 0,
      "explanation": "Manual weeding is by hand"
    },
    {
      "question": "Which of these is a leafy vegetable?",
      "options": [
        "Yam",
        "Bitter leaf",
        "Cocoa",
        "Cassava"
      ],
      "correct": 1,
      "explanation": "Bitter leaf is a leafy vegetable"
    },
    {
      "question": "The rearing of fish in ponds is?",
      "options": [
        "Apiculture",
        "Sericulture",
        "Fish farming",
        "Heliculture"
      ],
      "correct": 2,
      "explanation": "Fish farming is aquaculture"
    },
    {
      "question": "Which of these prevents soil erosion on slopes?",
      "options": [
        "Terracing",
        "Bush burning",
        "Overgrazing",
        "Deforestation"
      ],
      "correct": 0,
      "explanation": "Terracing reduces erosion on slopes"
    },
    {
      "question": "The process of removing the husk from rice is?",
      "options": [
        "Threshing",
        "Milling",
        "Winnowing",
        "Harvesting"
      ],
      "correct": 1,
      "explanation": "Milling removes the husk"
    },
    {
      "question": "Which animal provides both milk and meat?",
      "options": [
        "Dog",
        "Cat",
        "Sheep",
        "Chicken"
      ],
      "correct": 2,
      "explanation": "Sheep provide milk and meat"
    },
    {
      "question": "The growing of crops in water culture is?",
      "options": [
        "Sericulture",
        "Aquaculture",
        "Apiculture",
        "Hydroponics"
      ],
      "correct": 3,
      "explanation": "Hydroponics is water culture"
    },
    {
      "question": "Which of these is a fungal disease?",
      "options": [
        "Mosaic",
        "Viral disease",
        "Bacterial blight only",
        "Smut"
      ],
      "correct": 3,
      "explanation": "Smut is a fungal disease"
    },
    {
      "question": "The system of intensive farming near cities is?",
      "options": [
        "Nomadic farming",
        "Shifting cultivation",
        "Pastoral farming",
        "Peri-urban agriculture"
      ],
      "correct": 3,
      "explanation": "Peri-urban is near cities"
    },
    {
      "question": "Which of these is a value addition activity?",
      "options": [
        "Planting",
        "Weeding",
        "Processing of cassava into garri",
        "Land preparation"
      ],
      "correct": 2,
      "explanation": "Processing adds value"
    },
    {
      "question": "The act of reducing plant population is?",
      "options": [
        "Pruning",
        "Mulching",
        "Harvesting",
        "Thinning"
      ],
      "correct": 3,
      "explanation": "Thinning reduces plant population"
    },
    {
      "question": "Which of these is a fibre crop?",
      "options": [
        "Jute",
        "Maize",
        "Tomato",
        "Pepper"
      ],
      "correct": 0,
      "explanation": "Jute is a fibre crop"
    },
    {
      "question": "Which of these is a traditional storage method?",
      "options": [
        "Cold room only",
        "Rhumbus",
        "Refrigerator",
        "Silo only"
      ],
      "correct": 1,
      "explanation": "Rhumbus is a traditional storage structure"
    },
    {
      "question": "The young female chicken is called?",
      "options": [
        "Pullet",
        "Cock",
        "Cockerel",
        "Hen"
      ],
      "correct": 0,
      "explanation": "A young female chicken is a pullet"
    },
    {
      "question": "Which of these is an oil crop?",
      "options": [
        "Oil palm",
        "Rice",
        "Cassava",
        "Yam"
      ],
      "correct": 0,
      "explanation": "Oil palm produces oil"
    },
    {
      "question": "The farming system that depends on family labour is?",
      "options": [
        "Subsistence farming",
        "Mechanized farming",
        "Plantation farming",
        "Commercial farming"
      ],
      "correct": 0,
      "explanation": "Subsistence farming uses family labour"
    },
    {
      "question": "Which animal is mainly found in the riverine areas?",
      "options": [
        "Sheep mainly",
        "Cattle mainly",
        "Camel",
        "Fish"
      ],
      "correct": 3,
      "explanation": "Fish are common in riverine areas"
    },
    {
      "question": "The process of putting seeds in the soil is?",
      "options": [
        "Sowing",
        "Storage",
        "Weeding",
        "Harvesting"
      ],
      "correct": 0,
      "explanation": "Sowing is putting seeds in the soil"
    },
    {
      "question": "Which of these is rich in carbohydrates?",
      "options": [
        "Cassava",
        "Beans",
        "Meat",
        "Fish"
      ],
      "correct": 0,
      "explanation": "Cassava is rich in carbohydrates"
    },
    {
      "question": "The control of pests by changing farming practices is?",
      "options": [
        "Mechanical control only",
        "Biological control",
        "Chemical control",
        "Cultural control"
      ],
      "correct": 3,
      "explanation": "Cultural control uses farming practices"
    },
    {
      "question": "Which of these animals has a simple stomach?",
      "options": [
        "Sheep",
        "Goat",
        "Cow",
        "Pig"
      ],
      "correct": 3,
      "explanation": "Pigs are monogastric"
    },
    {
      "question": "The growing of crops in pure stands is?",
      "options": [
        "Relay cropping",
        "Sole cropping",
        "Mixed cropping",
        "Intercropping"
      ],
      "correct": 1,
      "explanation": "Sole cropping is one crop alone"
    },
    {
      "question": "Which of these is used for harvesting rice?",
      "options": [
        "Watering can",
        "Hoe",
        "Sickle",
        "Rake"
      ],
      "correct": 2,
      "explanation": "Sickle is used for harvesting"
    },
    {
      "question": "The male young chicken is called?",
      "options": [
        "Cockerel",
        "Duck",
        "Pullet",
        "Hen"
      ],
      "correct": 0,
      "explanation": "A young male chicken is a cockerel"
    },
    {
      "question": "Which crop is used for making chocolate and beverages?",
      "options": [
        "Tea",
        "Kola only",
        "Coffee only",
        "Cocoa"
      ],
      "correct": 3,
      "explanation": "Cocoa is used for chocolate"
    },
    {
      "question": "The removal of weeds using chemicals is?",
      "options": [
        "Manual weeding",
        "Biological control",
        "Chemical weed control",
        "Mechanical only"
      ],
      "correct": 2,
      "explanation": "Herbicides are used in chemical control"
    },
    {
      "question": "Which of these is a fruit?",
      "options": [
        "Yam",
        "Orange",
        "Cassava",
        "Potato"
      ],
      "correct": 1,
      "explanation": "Orange is a fruit"
    },
    {
      "question": "The rearing of domestic animals is?",
      "options": [
        "Crop production",
        "Fishery only",
        "Animal husbandry",
        "Forestry"
      ],
      "correct": 2,
      "explanation": "Animal husbandry is rearing animals"
    },
    {
      "question": "Which of these is a mechanical soil conservation method?",
      "options": [
        "Deforestation",
        "Overgrazing",
        "Bush burning",
        "Contour bunding"
      ],
      "correct": 3,
      "explanation": "Contour bunding is mechanical"
    },
    {
      "question": "The process of separating seeds from the fruit is?",
      "options": [
        "Winnowing only",
        "Milling only",
        "Threshing only",
        "Extraction"
      ],
      "correct": 3,
      "explanation": "Extraction separates seeds"
    },
    {
      "question": "Which animal is mainly reared in the south for meat?",
      "options": [
        "Pig",
        "Camel",
        "Yak",
        "Cattle mainly in north"
      ],
      "correct": 0,
      "explanation": "Pigs are more common in the south"
    },
    {
      "question": "The system of farming with high input is?",
      "options": [
        "Extensive farming",
        "Shifting cultivation",
        "Nomadic farming",
        "Intensive farming"
      ],
      "correct": 3,
      "explanation": "Intensive farming uses high inputs"
    },
    {
      "question": "Which of these is a pest of stored produce?",
      "options": [
        "Locust only",
        "Army worm only",
        "Stem borer only",
        "Weevil"
      ],
      "correct": 3,
      "explanation": "Weevils attack stored grains"
    },
    {
      "question": "The farming system practised in forests is?",
      "options": [
        "Pastoral farming",
        "Taungya system",
        "Nomadic farming",
        "Urban agriculture"
      ],
      "correct": 1,
      "explanation": "Taungya combines forestry and crops"
    },
    {
      "question": "Which of these is a packaging material?",
      "options": [
        "Rake",
        "Hoe",
        "Cutlass",
        "Sack"
      ],
      "correct": 3,
      "explanation": "Sacks are used for packaging"
    },
    {
      "question": "The act of cutting excess branches is?",
      "options": [
        "Harvesting",
        "Pruning",
        "Weeding",
        "Thinning"
      ],
      "correct": 1,
      "explanation": "Pruning cuts excess branches"
    },
    {
      "question": "Which of these is a latex crop?",
      "options": [
        "Rubber",
        "Maize",
        "Cotton",
        "Cocoa"
      ],
      "correct": 0,
      "explanation": "Rubber produces latex"
    },
    {
      "question": "Which of these is a modern storage structure?",
      "options": [
        "Rhumbus only",
        "Basket only",
        "Silo",
        "Clay pot only"
      ],
      "correct": 2,
      "explanation": "Silos are modern storage structures"
    },
    {
      "question": "The adult female chicken is called?",
      "options": [
        "Hen",
        "Pullet",
        "Cock",
        "Cockerel"
      ],
      "correct": 0,
      "explanation": "An adult female chicken is a hen"
    },
    {
      "question": "Which of these is a tuber crop?",
      "options": [
        "Maize",
        "Cocoa",
        "Rice",
        "Sweet potato"
      ],
      "correct": 3,
      "explanation": "Sweet potato is a tuber"
    },
    {
      "question": "The farming system that uses machines is?",
      "options": [
        "Nomadic farming",
        "Subsistence farming",
        "Mechanized farming",
        "Shifting cultivation"
      ],
      "correct": 2,
      "explanation": "Mechanized farming uses machines"
    },
    {
      "question": "Which animal is mainly reared for wool?",
      "options": [
        "Goat",
        "Cow",
        "Sheep",
        "Pig"
      ],
      "correct": 2,
      "explanation": "Sheep are reared for wool"
    },
    {
      "question": "The process of gathering mature crops is?",
      "options": [
        "Fertilizing",
        "Planting",
        "Weeding",
        "Harvesting"
      ],
      "correct": 3,
      "explanation": "Harvesting is gathering crops"
    },
    {
      "question": "Which of these is a leguminous crop?",
      "options": [
        "Cassava",
        "Groundnut",
        "Maize",
        "Yam"
      ],
      "correct": 1,
      "explanation": "Groundnut is a legume"
    },
    {
      "question": "The use of traps to control pests is?",
      "options": [
        "Cultural control",
        "Mechanical control",
        "Biological control",
        "Chemical control"
      ],
      "correct": 1,
      "explanation": "Traps are mechanical control"
    },
    {
      "question": "Which of these animals is a ruminant?",
      "options": [
        "Sheep",
        "Chicken",
        "Dog",
        "Pig"
      ],
      "correct": 0,
      "explanation": "Sheep are ruminants"
    },
    {
      "question": "The growing of crops and rearing of animals together is?",
      "options": [
        "Plantation farming",
        "Mixed farming",
        "Monocropping",
        "Sole cropping"
      ],
      "correct": 1,
      "explanation": "Mixed farming combines both"
    },
    {
      "question": "Which of these is used for weeding?",
      "options": [
        "Axe",
        "Hoe",
        "Sickle mainly",
        "Watering can"
      ],
      "correct": 1,
      "explanation": "Hoe is used for weeding"
    },
    {
      "question": "The young male chicken is called?",
      "options": [
        "Pullet",
        "Cockerel",
        "Duck",
        "Hen"
      ],
      "correct": 1,
      "explanation": "A young male is a cockerel"
    },
    {
      "question": "Which crop is used for making palm oil?",
      "options": [
        "Cocoa",
        "Cotton",
        "Rubber",
        "Oil palm"
      ],
      "correct": 3,
      "explanation": "Oil palm produces palm oil"
    },
    {
      "question": "The removal of weeds by machines is?",
      "options": [
        "Mechanical weeding",
        "Manual weeding",
        "Chemical weeding",
        "Biological control"
      ],
      "correct": 0,
      "explanation": "Machines are used in mechanical weeding"
    },
    {
      "question": "Which of these is a vegetable crop?",
      "options": [
        "Cocoa",
        "Okra",
        "Cotton",
        "Rubber"
      ],
      "correct": 1,
      "explanation": "Okra is a vegetable"
    },
    {
      "question": "The keeping of bees for honey is?",
      "options": [
        "Sericulture",
        "Heliculture",
        "Aquaculture",
        "Apiculture"
      ],
      "correct": 3,
      "explanation": "Apiculture is beekeeping"
    },
    {
      "question": "Which of these helps to conserve soil water?",
      "options": [
        "Deforestation",
        "Mulching",
        "Overgrazing",
        "Bush burning"
      ],
      "correct": 1,
      "explanation": "Mulching conserves soil water"
    },
    {
      "question": "The process of removing chaff from grains is?",
      "options": [
        "Milling",
        "Harvesting",
        "Threshing",
        "Winnowing"
      ],
      "correct": 3,
      "explanation": "Winnowing removes chaff"
    },
    {
      "question": "Which animal is mainly reared for eggs?",
      "options": [
        "Chicken",
        "Cow",
        "Goat",
        "Sheep"
      ],
      "correct": 0,
      "explanation": "Chickens are reared for eggs"
    },
    {
      "question": "The growing of plants in nutrient solution is?",
      "options": [
        "Aquaculture",
        "Sericulture",
        "Apiculture",
        "Hydroponics"
      ],
      "correct": 3,
      "explanation": "Hydroponics uses nutrient solution"
    },
    {
      "question": "Which of these is a disease of maize?",
      "options": [
        "Cocoa black pod only",
        "Cassava mosaic only",
        "Rice blast only",
        "Smut"
      ],
      "correct": 3,
      "explanation": "Smut affects maize"
    },
    {
      "question": "The system of farming for sale is?",
      "options": [
        "Subsistence farming",
        "Commercial farming",
        "Nomadic farming",
        "Shifting cultivation"
      ],
      "correct": 1,
      "explanation": "Commercial farming is for sale"
    },
    {
      "question": "Which of these is a processing activity?",
      "options": [
        "Smoking of fish",
        "Land preparation",
        "Planting",
        "Weeding"
      ],
      "correct": 0,
      "explanation": "Smoking is a processing activity"
    },
    {
      "question": "The act of removing some plants to give others space is?",
      "options": [
        "Thinning",
        "Harvesting",
        "Pruning",
        "Mulching"
      ],
      "correct": 0,
      "explanation": "Thinning gives space to remaining plants"
    },
    {
      "question": "Which of these is a stimulant crop?",
      "options": [
        "Yam",
        "Kola",
        "Cassava",
        "Maize"
      ],
      "correct": 1,
      "explanation": "Kola is a stimulant crop"
    }
  ],
  "geo": [
    {
      "question": "The imaginary line that divides the earth into Northern and Southern hemispheres is?",
      "options": [
        "Prime Meridian",
        "Arctic Circle",
        "Tropic of Cancer",
        "Equator"
      ],
      "correct": 3,
      "explanation": "The Equator divides the earth into two hemispheres"
    },
    {
      "question": "Which of these is a continent?",
      "options": [
        "Sahara",
        "Lagos",
        "Nigeria",
        "Africa"
      ],
      "correct": 3,
      "explanation": "Africa is a continent"
    },
    {
      "question": "The largest ocean in the world is?",
      "options": [
        "Arctic Ocean",
        "Pacific Ocean",
        "Indian Ocean",
        "Atlantic Ocean"
      ],
      "correct": 1,
      "explanation": "The Pacific is the largest ocean"
    },
    {
      "question": "Which instrument is used to measure rainfall?",
      "options": [
        "Rain gauge",
        "Thermometer",
        "Barometer",
        "Wind vane"
      ],
      "correct": 0,
      "explanation": "Rain gauge measures rainfall"
    },
    {
      "question": "The capital of Nigeria is?",
      "options": [
        "Lagos",
        "Port Harcourt",
        "Abuja",
        "Kano"
      ],
      "correct": 2,
      "explanation": "Abuja is the capital of Nigeria"
    },
    {
      "question": "Which of these is a river in Nigeria?",
      "options": [
        "River Thames",
        "River Niger",
        "River Amazon",
        "River Nile"
      ],
      "correct": 1,
      "explanation": "River Niger flows through Nigeria"
    },
    {
      "question": "The study of weather is called?",
      "options": [
        "Biology",
        "Geology",
        "Meteorology",
        "Ecology"
      ],
      "correct": 2,
      "explanation": "Meteorology is the study of weather"
    },
    {
      "question": "Which of these is a desert?",
      "options": [
        "Congo",
        "Amazon",
        "Sahara",
        "Nile"
      ],
      "correct": 2,
      "explanation": "The Sahara is a desert"
    },
    {
      "question": "The line of longitude 0° is called?",
      "options": [
        "Tropic of Capricorn",
        "Prime Meridian",
        "International Date Line",
        "Equator"
      ],
      "correct": 1,
      "explanation": "The Prime Meridian is 0° longitude"
    },
    {
      "question": "Which of these is a highland in Nigeria?",
      "options": [
        "Jos Plateau",
        "Chad Basin",
        "Niger Delta",
        "Sokoto Plains"
      ],
      "correct": 0,
      "explanation": "Jos Plateau is a highland"
    },
    {
      "question": "The layer of air surrounding the earth is?",
      "options": [
        "Lithosphere",
        "Biosphere",
        "Hydrosphere",
        "Atmosphere"
      ],
      "correct": 3,
      "explanation": "Atmosphere is the layer of air"
    },
    {
      "question": "Which instrument measures wind direction?",
      "options": [
        "Wind vane",
        "Rain gauge",
        "Anemometer",
        "Thermometer"
      ],
      "correct": 0,
      "explanation": "Wind vane shows wind direction"
    },
    {
      "question": "The largest continent is?",
      "options": [
        "Australia",
        "Asia",
        "Europe",
        "Africa"
      ],
      "correct": 1,
      "explanation": "Asia is the largest continent"
    },
    {
      "question": "Which of these is a natural resource?",
      "options": [
        "Crude oil",
        "Plastic",
        "Glass",
        "Cement"
      ],
      "correct": 0,
      "explanation": "Crude oil is a natural resource"
    },
    {
      "question": "The process by which water vapour turns to liquid is?",
      "options": [
        "Precipitation",
        "Evaporation",
        "Condensation",
        "Transpiration"
      ],
      "correct": 2,
      "explanation": "Condensation is vapour to liquid"
    },
    {
      "question": "Which of these is a type of rainfall?",
      "options": [
        "Convectional rainfall",
        "Desert rainfall",
        "Ocean rainfall only",
        "Mountain only"
      ],
      "correct": 0,
      "explanation": "Convectional is a type of rainfall"
    },
    {
      "question": "The earth rotates from?",
      "options": [
        "East to West",
        "West to East",
        "South to North",
        "North to South"
      ],
      "correct": 1,
      "explanation": "Earth rotates from West to East"
    },
    {
      "question": "Which of these is a vegetation type in Nigeria?",
      "options": [
        "Mediterranean",
        "Rainforest",
        "Taiga",
        "Tundra"
      ],
      "correct": 1,
      "explanation": "Rainforest is found in Nigeria"
    },
    {
      "question": "The scale of a map shows?",
      "options": [
        "Relationship between map distance and actual distance",
        "Only direction",
        "Only height",
        "Only colour"
      ],
      "correct": 0,
      "explanation": "Scale relates map to actual distance"
    },
    {
      "question": "Which of these is a lagoon in Nigeria?",
      "options": [
        "Atlantic Ocean",
        "Lake Chad",
        "Lagos Lagoon",
        "River Benue"
      ],
      "correct": 2,
      "explanation": "Lagos Lagoon is in Nigeria"
    },
    {
      "question": "The movement of people from one place to another is?",
      "options": [
        "Urbanization",
        "Migration",
        "Industrialization",
        "Colonization"
      ],
      "correct": 1,
      "explanation": "Migration is movement of people"
    },
    {
      "question": "Which of these is a mineral resource in Nigeria?",
      "options": [
        "Wheat",
        "Rubber",
        "Coal",
        "Cocoa"
      ],
      "correct": 2,
      "explanation": "Coal is a mineral resource"
    },
    {
      "question": "The instrument used to measure atmospheric pressure is?",
      "options": [
        "Rain gauge",
        "Hygrometer",
        "Thermometer",
        "Barometer"
      ],
      "correct": 3,
      "explanation": "Barometer measures pressure"
    },
    {
      "question": "Which of these is an island country?",
      "options": [
        "Mali",
        "Ghana",
        "Madagascar",
        "Nigeria"
      ],
      "correct": 2,
      "explanation": "Madagascar is an island"
    },
    {
      "question": "The water cycle involves?",
      "options": [
        "Evaporation, condensation and precipitation",
        "Only oceans",
        "Only rainfall",
        "Only rivers"
      ],
      "correct": 0,
      "explanation": "Water cycle includes those three processes"
    },
    {
      "question": "Which of these is a line of latitude?",
      "options": [
        "Greenwich Meridian",
        "Prime Meridian",
        "Equator",
        "International Date Line"
      ],
      "correct": 2,
      "explanation": "The Equator is a line of latitude"
    },
    {
      "question": "The largest desert in the world is?",
      "options": [
        "Kalahari",
        "Sahara",
        "Gobi",
        "Arabian"
      ],
      "correct": 1,
      "explanation": "Sahara is the largest hot desert"
    },
    {
      "question": "Which of these is a highland feature?",
      "options": [
        "Mountain",
        "Delta",
        "Plain",
        "Valley"
      ],
      "correct": 0,
      "explanation": "Mountains are highlands"
    },
    {
      "question": "The instrument used to measure temperature is?",
      "options": [
        "Barometer",
        "Rain gauge",
        "Wind vane",
        "Thermometer"
      ],
      "correct": 3,
      "explanation": "Thermometer measures temperature"
    },
    {
      "question": "Which of these is a state in Nigeria?",
      "options": [
        "Nairobi",
        "Lagos",
        "Accra",
        "Cairo"
      ],
      "correct": 1,
      "explanation": "Lagos is a state in Nigeria"
    },
    {
      "question": "The process by which rivers wear away rocks is?",
      "options": [
        "Erosion",
        "Condensation",
        "Deposition",
        "Evaporation"
      ],
      "correct": 0,
      "explanation": "Erosion is the wearing away of rocks"
    },
    {
      "question": "Which of these is a type of map?",
      "options": [
        "Topographical map",
        "Calendar",
        "Dictionary",
        "Newspaper"
      ],
      "correct": 0,
      "explanation": "Topographical maps show relief"
    },
    {
      "question": "The daily condition of the atmosphere is?",
      "options": [
        "Season",
        "Climate",
        "Vegetation",
        "Weather"
      ],
      "correct": 3,
      "explanation": "Weather is the daily atmospheric condition"
    },
    {
      "question": "Which of these is a lowland feature?",
      "options": [
        "Mountain",
        "Plain",
        "Plateau",
        "Hill"
      ],
      "correct": 1,
      "explanation": "Plains are lowlands"
    },
    {
      "question": "The movement of the earth around the sun is?",
      "options": [
        "Orbiting only",
        "Revolution",
        "Spinning only",
        "Rotation"
      ],
      "correct": 1,
      "explanation": "Revolution is movement around the sun"
    },
    {
      "question": "Which of these is a human-made feature?",
      "options": [
        "Mountain",
        "River",
        "Lake (natural)",
        "Road"
      ],
      "correct": 3,
      "explanation": "Roads are made by humans"
    },
    {
      "question": "The scale 1:50,000 means?",
      "options": [
        "1 cm = 500 m only",
        "1 cm = 50 km",
        "1 cm on map = 50,000 cm on ground",
        "1 cm = 5 km only"
      ],
      "correct": 2,
      "explanation": "The ratio shows map to ground distance"
    },
    {
      "question": "Which of these is a climatic region in Nigeria?",
      "options": [
        "Tundra",
        "Mediterranean",
        "Tropical rainforest",
        "Polar"
      ],
      "correct": 2,
      "explanation": "Nigeria has tropical rainforest regions"
    },
    {
      "question": "The process of water changing to vapour is?",
      "options": [
        "Infiltration",
        "Condensation",
        "Evaporation",
        "Precipitation"
      ],
      "correct": 2,
      "explanation": "Evaporation is liquid to vapour"
    },
    {
      "question": "Which of these is a tributary of River Niger?",
      "options": [
        "River Zambezi",
        "River Benue",
        "River Nile",
        "River Congo"
      ],
      "correct": 1,
      "explanation": "River Benue joins River Niger"
    },
    {
      "question": "The layer of the earth we live on is?",
      "options": [
        "Crust",
        "Core",
        "Mantle",
        "Inner core"
      ],
      "correct": 0,
      "explanation": "We live on the earth's crust"
    },
    {
      "question": "Which instrument measures wind speed?",
      "options": [
        "Wind vane",
        "Anemometer",
        "Thermometer",
        "Barometer"
      ],
      "correct": 1,
      "explanation": "Anemometer measures wind speed"
    },
    {
      "question": "The average weather condition over a long period is?",
      "options": [
        "Weather",
        "Forecast",
        "Season",
        "Climate"
      ],
      "correct": 3,
      "explanation": "Climate is long-term average weather"
    },
    {
      "question": "Which of these is a delta in Nigeria?",
      "options": [
        "Mississippi Delta",
        "Niger Delta",
        "Ganges Delta",
        "Nile Delta"
      ],
      "correct": 1,
      "explanation": "Niger Delta is in Nigeria"
    },
    {
      "question": "The direction shown by the north arrow on a map is?",
      "options": [
        "North",
        "East",
        "West",
        "South"
      ],
      "correct": 0,
      "explanation": "The north arrow points north"
    },
    {
      "question": "Which of these is a renewable resource?",
      "options": [
        "Forest",
        "Coal",
        "Natural gas",
        "Crude oil"
      ],
      "correct": 0,
      "explanation": "Forests can regrow"
    },
    {
      "question": "The process of laying down eroded materials is?",
      "options": [
        "Transportation",
        "Erosion",
        "Deposition",
        "Weathering"
      ],
      "correct": 2,
      "explanation": "Deposition is laying down of materials"
    },
    {
      "question": "Which of these is a population concept?",
      "options": [
        "Rainfall",
        "Census",
        "Temperature",
        "Wind"
      ],
      "correct": 1,
      "explanation": "Census counts population"
    },
    {
      "question": "The Tropic of Cancer is at?",
      "options": [
        "0°",
        "66½°N",
        "23½°N",
        "23½°S"
      ],
      "correct": 2,
      "explanation": "Tropic of Cancer is 23½° North"
    },
    {
      "question": "Which of these is an economic activity?",
      "options": [
        "Sleeping",
        "Dreaming",
        "Farming",
        "Playing only"
      ],
      "correct": 2,
      "explanation": "Farming is an economic activity"
    },
    {
      "question": "Which of these is a line of longitude?",
      "options": [
        "Equator",
        "Prime Meridian",
        "Arctic Circle",
        "Tropic of Cancer"
      ],
      "correct": 1,
      "explanation": "The Prime Meridian is a line of longitude"
    },
    {
      "question": "The smallest continent is?",
      "options": [
        "Antarctica",
        "South America",
        "Europe",
        "Australia"
      ],
      "correct": 3,
      "explanation": "Australia is the smallest continent"
    },
    {
      "question": "Which of these is a lowland?",
      "options": [
        "Valley",
        "Mountain",
        "Hill",
        "Plateau"
      ],
      "correct": 0,
      "explanation": "Valleys are lowlands"
    },
    {
      "question": "The instrument used to show direction is?",
      "options": [
        "Thermometer",
        "Compass",
        "Rain gauge",
        "Barometer"
      ],
      "correct": 1,
      "explanation": "Compass shows direction"
    },
    {
      "question": "Which of these is a city in Nigeria?",
      "options": [
        "Nairobi",
        "Accra",
        "Cairo",
        "Kano"
      ],
      "correct": 3,
      "explanation": "Kano is in Nigeria"
    },
    {
      "question": "The wearing away of the earth's surface is?",
      "options": [
        "Folding",
        "Deposition",
        "Weathering only",
        "Erosion"
      ],
      "correct": 3,
      "explanation": "Erosion wears away the surface"
    },
    {
      "question": "Which of these shows height on a map?",
      "options": [
        "Rivers only",
        "Contour lines",
        "Towns only",
        "Roads"
      ],
      "correct": 1,
      "explanation": "Contours show height"
    },
    {
      "question": "The condition of the atmosphere at a particular time is?",
      "options": [
        "Season",
        "Climate",
        "Vegetation",
        "Weather"
      ],
      "correct": 3,
      "explanation": "Weather is the short-term condition"
    },
    {
      "question": "Which of these is a highland?",
      "options": [
        "Plain",
        "Plateau",
        "Delta",
        "Valley"
      ],
      "correct": 1,
      "explanation": "Plateaus are elevated"
    },
    {
      "question": "The spinning of the earth on its axis is?",
      "options": [
        "Orbit",
        "Rotation",
        "Revolution",
        "Tilt"
      ],
      "correct": 1,
      "explanation": "Rotation is spinning on its axis"
    },
    {
      "question": "Which of these is a natural feature?",
      "options": [
        "River",
        "Road",
        "Dam (man-made)",
        "Bridge"
      ],
      "correct": 0,
      "explanation": "Rivers are natural"
    },
    {
      "question": "A map scale of 1:100,000 means 1 cm represents?",
      "options": [
        "10 km",
        "1 km",
        "1000 km",
        "100 km"
      ],
      "correct": 1,
      "explanation": "1 cm = 100,000 cm = 1 km"
    },
    {
      "question": "Which vegetation is found in the far north of Nigeria?",
      "options": [
        "Freshwater swamp",
        "Rainforest",
        "Sudan savanna",
        "Mangrove"
      ],
      "correct": 2,
      "explanation": "Sudan savanna is in the north"
    },
    {
      "question": "The process of water vapour turning into clouds is?",
      "options": [
        "Condensation",
        "Evaporation",
        "Precipitation",
        "Infiltration"
      ],
      "correct": 0,
      "explanation": "Condensation forms clouds"
    },
    {
      "question": "Which river forms a boundary between Nigeria and another country?",
      "options": [
        "River Amazon",
        "Cross River (partly)",
        "River Nile",
        "River Thames"
      ],
      "correct": 1,
      "explanation": "Cross River is in the southeast"
    },
    {
      "question": "The innermost part of the earth is the?",
      "options": [
        "Crust",
        "Core",
        "Atmosphere",
        "Mantle"
      ],
      "correct": 1,
      "explanation": "The core is the innermost layer"
    },
    {
      "question": "Which instrument measures humidity?",
      "options": [
        "Thermometer",
        "Hygrometer",
        "Barometer",
        "Anemometer"
      ],
      "correct": 1,
      "explanation": "Hygrometer measures humidity"
    },
    {
      "question": "The long-term average of weather is?",
      "options": [
        "Climate",
        "Weather",
        "Season only",
        "Forecast"
      ],
      "correct": 0,
      "explanation": "Climate is the long-term average"
    },
    {
      "question": "Which of these is a coastal feature?",
      "options": [
        "Mountain",
        "Valley inland",
        "Beach",
        "Plateau"
      ],
      "correct": 2,
      "explanation": "Beaches are coastal"
    },
    {
      "question": "The direction opposite to north is?",
      "options": [
        "West",
        "Northeast",
        "East",
        "South"
      ],
      "correct": 3,
      "explanation": "South is opposite north"
    },
    {
      "question": "Which of these is a non-renewable resource?",
      "options": [
        "Coal",
        "Fish",
        "Solar energy",
        "Forest"
      ],
      "correct": 0,
      "explanation": "Coal cannot be replaced quickly"
    },
    {
      "question": "The dropping of eroded materials is?",
      "options": [
        "Weathering",
        "Erosion",
        "Deposition",
        "Transportation"
      ],
      "correct": 2,
      "explanation": "Deposition is the dropping of materials"
    },
    {
      "question": "A count of the population is called?",
      "options": [
        "Census",
        "Survey only",
        "Estimation only",
        "Sampling"
      ],
      "correct": 0,
      "explanation": "Census is an official population count"
    },
    {
      "question": "The Tropic of Capricorn is at?",
      "options": [
        "23½°S",
        "66½°S",
        "0°",
        "23½°N"
      ],
      "correct": 0,
      "explanation": "Tropic of Capricorn is 23½° South"
    },
    {
      "question": "Which of these is a primary economic activity?",
      "options": [
        "Teaching",
        "Trading in shops",
        "Banking",
        "Farming"
      ],
      "correct": 3,
      "explanation": "Farming is a primary activity"
    },
    {
      "question": "Which of these is the longest river in the world?",
      "options": [
        "Amazon",
        "Nile",
        "Congo",
        "Niger"
      ],
      "correct": 1,
      "explanation": "The Nile is generally regarded as the longest"
    },
    {
      "question": "The largest country in Africa by area is?",
      "options": [
        "Algeria",
        "South Africa",
        "Egypt",
        "Nigeria"
      ],
      "correct": 0,
      "explanation": "Algeria is the largest by area"
    },
    {
      "question": "Which of these is a mountain range?",
      "options": [
        "Sahara",
        "Himalayas",
        "Amazon",
        "Nile"
      ],
      "correct": 1,
      "explanation": "Himalayas are mountains"
    },
    {
      "question": "The instrument used to measure air pressure is?",
      "options": [
        "Hygrometer",
        "Thermometer",
        "Anemometer",
        "Barometer"
      ],
      "correct": 3,
      "explanation": "Barometer measures air pressure"
    },
    {
      "question": "Which of these is a local government area feature?",
      "options": [
        "Continent",
        "Ocean",
        "Planet",
        "Ward"
      ],
      "correct": 3,
      "explanation": "Wards are local divisions"
    },
    {
      "question": "The breaking down of rocks in place is?",
      "options": [
        "Deposition",
        "Erosion",
        "Weathering",
        "Transportation"
      ],
      "correct": 2,
      "explanation": "Weathering breaks rocks in place"
    },
    {
      "question": "Which of these is used to show direction on a map?",
      "options": [
        "Title only",
        "Scale only",
        "Key only",
        "North arrow"
      ],
      "correct": 3,
      "explanation": "North arrow shows direction"
    },
    {
      "question": "The short-term state of the atmosphere is?",
      "options": [
        "Season",
        "Weather",
        "Climate",
        "Vegetation"
      ],
      "correct": 1,
      "explanation": "Weather is short-term"
    },
    {
      "question": "Which of these is an elevated flat land?",
      "options": [
        "Plateau",
        "Plain",
        "Delta",
        "Valley"
      ],
      "correct": 0,
      "explanation": "Plateau is elevated and relatively flat"
    },
    {
      "question": "The movement of the earth around the sun takes?",
      "options": [
        "One week",
        "One month",
        "One year",
        "One day"
      ],
      "correct": 2,
      "explanation": "Revolution takes about one year"
    },
    {
      "question": "Which of these is a cultural feature?",
      "options": [
        "Mountain",
        "Town",
        "River",
        "Lake"
      ],
      "correct": 1,
      "explanation": "Towns are cultural (human) features"
    },
    {
      "question": "A scale of 1:25,000 means 1 cm represents?",
      "options": [
        "25 m",
        "250 m",
        "2.5 km",
        "25 km"
      ],
      "correct": 1,
      "explanation": "1 cm = 25,000 cm = 250 m"
    },
    {
      "question": "Which vegetation belt is closest to the coast in Nigeria?",
      "options": [
        "Mangrove swamp",
        "Sahel savanna",
        "Montane",
        "Sudan savanna"
      ],
      "correct": 0,
      "explanation": "Mangrove is found along the coast"
    },
    {
      "question": "The falling of water droplets from clouds is?",
      "options": [
        "Evaporation",
        "Condensation",
        "Transpiration",
        "Precipitation"
      ],
      "correct": 3,
      "explanation": "Precipitation includes rain"
    },
    {
      "question": "Which of these is a major river in Nigeria?",
      "options": [
        "River Thames",
        "River Amazon",
        "River Nile",
        "River Benue"
      ],
      "correct": 3,
      "explanation": "River Benue is in Nigeria"
    },
    {
      "question": "The outer layer of the earth is the?",
      "options": [
        "Inner core",
        "Core",
        "Crust",
        "Mantle"
      ],
      "correct": 2,
      "explanation": "The crust is the outer layer"
    },
    {
      "question": "Which instrument measures rainfall amount?",
      "options": [
        "Wind vane",
        "Thermometer",
        "Rain gauge",
        "Barometer"
      ],
      "correct": 2,
      "explanation": "Rain gauge measures rainfall"
    },
    {
      "question": "The general weather pattern of a place is?",
      "options": [
        "Season only",
        "Forecast",
        "Weather",
        "Climate"
      ],
      "correct": 3,
      "explanation": "Climate is the general pattern"
    },
    {
      "question": "Which of these is formed at the mouth of a river?",
      "options": [
        "Delta",
        "Valley",
        "Plateau",
        "Mountain"
      ],
      "correct": 0,
      "explanation": "Deltas form at river mouths"
    },
    {
      "question": "The direction to the right of north is?",
      "options": [
        "East",
        "West",
        "North",
        "South"
      ],
      "correct": 0,
      "explanation": "East is to the right of north"
    },
    {
      "question": "Which of these is a renewable natural resource?",
      "options": [
        "Petroleum",
        "Natural gas",
        "Water",
        "Coal"
      ],
      "correct": 2,
      "explanation": "Water is renewable"
    },
    {
      "question": "The laying down of sediments is?",
      "options": [
        "Deposition",
        "Folding",
        "Weathering",
        "Erosion"
      ],
      "correct": 0,
      "explanation": "Deposition lays down sediments"
    },
    {
      "question": "An official counting of people is?",
      "options": [
        "Election",
        "Census",
        "Sampling only",
        "Survey only"
      ],
      "correct": 1,
      "explanation": "Census counts the population"
    },
    {
      "question": "The Arctic Circle is at?",
      "options": [
        "23½°N",
        "66½°N",
        "0°",
        "66½°S"
      ],
      "correct": 1,
      "explanation": "Arctic Circle is 66½° North"
    },
    {
      "question": "Which of these is a tertiary economic activity?",
      "options": [
        "Teaching",
        "Farming",
        "Fishing",
        "Mining"
      ],
      "correct": 0,
      "explanation": "Teaching is a service (tertiary)"
    },
    {
      "question": "Which of these is the largest ocean?",
      "options": [
        "Pacific Ocean",
        "Arctic Ocean",
        "Atlantic Ocean",
        "Indian Ocean"
      ],
      "correct": 0,
      "explanation": "The Pacific is the largest ocean"
    },
    {
      "question": "The capital city of Nigeria is?",
      "options": [
        "Kano",
        "Ibadan",
        "Lagos",
        "Abuja"
      ],
      "correct": 3,
      "explanation": "Abuja is the capital"
    },
    {
      "question": "Which of these is a fold mountain?",
      "options": [
        "Jos Plateau",
        "Kilimanjaro only",
        "Everest only",
        "Himalayas"
      ],
      "correct": 3,
      "explanation": "Himalayas are fold mountains"
    },
    {
      "question": "The instrument used to measure wind direction is?",
      "options": [
        "Barometer",
        "Wind vane",
        "Anemometer",
        "Thermometer"
      ],
      "correct": 1,
      "explanation": "Wind vane shows direction"
    },
    {
      "question": "Which of these is a state capital in Nigeria?",
      "options": [
        "Paris",
        "Cairo",
        "London",
        "Ibadan"
      ],
      "correct": 3,
      "explanation": "Ibadan is the capital of Oyo State"
    },
    {
      "question": "The process of wearing away by rivers is?",
      "options": [
        "River erosion",
        "Weathering only",
        "Folding",
        "Deposition"
      ],
      "correct": 0,
      "explanation": "Rivers cause erosion"
    },
    {
      "question": "Which of these is found on a map?",
      "options": [
        "Dictionary",
        "Key (legend)",
        "Calendar",
        "Newspaper"
      ],
      "correct": 1,
      "explanation": "Maps have a key or legend"
    },
    {
      "question": "The daily atmospheric condition is?",
      "options": [
        "Vegetation",
        "Season",
        "Climate",
        "Weather"
      ],
      "correct": 3,
      "explanation": "Weather is daily condition"
    },
    {
      "question": "Which of these is a type of rainfall?",
      "options": [
        "Desert rainfall",
        "Polar rainfall",
        "Equatorial only",
        "Relief rainfall"
      ],
      "correct": 3,
      "explanation": "Relief (orographic) rainfall is a type"
    },
    {
      "question": "The earth completes one rotation in?",
      "options": [
        "30 days",
        "365 days",
        "24 hours",
        "7 days"
      ],
      "correct": 2,
      "explanation": "One rotation takes about 24 hours"
    },
    {
      "question": "Which of these is a physical feature?",
      "options": [
        "Road",
        "Mountain",
        "Building",
        "Bridge"
      ],
      "correct": 1,
      "explanation": "Mountains are physical features"
    },
    {
      "question": "A map scale of 1:10,000 means 1 cm represents?",
      "options": [
        "100 m",
        "10 m",
        "1 km",
        "10 km"
      ],
      "correct": 0,
      "explanation": "1 cm = 10,000 cm = 100 m"
    },
    {
      "question": "Which vegetation is found in the Niger Delta?",
      "options": [
        "Mangrove",
        "Montane forest only",
        "Sudan savanna",
        "Sahel"
      ],
      "correct": 0,
      "explanation": "Mangrove is common in the Delta"
    },
    {
      "question": "The process of water changing to vapour is?",
      "options": [
        "Infiltration",
        "Condensation",
        "Precipitation",
        "Evaporation"
      ],
      "correct": 3,
      "explanation": "Evaporation is liquid to vapour"
    },
    {
      "question": "Which of these is a tributary of River Niger?",
      "options": [
        "River Zambezi",
        "River Congo",
        "River Nile",
        "River Kaduna"
      ],
      "correct": 3,
      "explanation": "River Kaduna is a tributary"
    },
    {
      "question": "The middle layer of the earth is the?",
      "options": [
        "Crust",
        "Atmosphere",
        "Core",
        "Mantle"
      ],
      "correct": 3,
      "explanation": "The mantle is the middle layer"
    },
    {
      "question": "Which instrument measures temperature?",
      "options": [
        "Barometer",
        "Anemometer",
        "Hygrometer",
        "Thermometer"
      ],
      "correct": 3,
      "explanation": "Thermometer measures temperature"
    },
    {
      "question": "The average weather over many years is?",
      "options": [
        "Forecast",
        "Weather",
        "Climate",
        "Season"
      ],
      "correct": 2,
      "explanation": "Climate is the long-term average"
    },
    {
      "question": "Which of these is a coastal landform?",
      "options": [
        "Valley inland",
        "Plateau inland",
        "Cliff",
        "Mountain inland"
      ],
      "correct": 2,
      "explanation": "Cliffs are coastal features"
    },
    {
      "question": "The direction opposite to east is?",
      "options": [
        "West",
        "North",
        "South",
        "Northeast"
      ],
      "correct": 0,
      "explanation": "West is opposite east"
    },
    {
      "question": "Which of these is a non-renewable resource?",
      "options": [
        "Solar energy",
        "Petroleum",
        "Fish",
        "Forest"
      ],
      "correct": 1,
      "explanation": "Petroleum is non-renewable"
    },
    {
      "question": "The process of sediments being dropped is?",
      "options": [
        "Transportation",
        "Erosion",
        "Deposition",
        "Weathering"
      ],
      "correct": 2,
      "explanation": "Deposition is dropping of sediments"
    },
    {
      "question": "A population count is called?",
      "options": [
        "Registration only",
        "Election",
        "Census",
        "Survey only"
      ],
      "correct": 2,
      "explanation": "Census is a population count"
    },
    {
      "question": "The Antarctic Circle is at?",
      "options": [
        "66½°S",
        "66½°N",
        "0°",
        "23½°S"
      ],
      "correct": 0,
      "explanation": "Antarctic Circle is 66½° South"
    },
    {
      "question": "Which of these is a secondary economic activity?",
      "options": [
        "Fishing",
        "Farming",
        "Mining",
        "Manufacturing"
      ],
      "correct": 3,
      "explanation": "Manufacturing is secondary"
    },
    {
      "question": "Which of these is the second largest ocean?",
      "options": [
        "Indian Ocean",
        "Arctic Ocean",
        "Pacific Ocean",
        "Atlantic Ocean"
      ],
      "correct": 3,
      "explanation": "The Atlantic is the second largest"
    },
    {
      "question": "The former capital of Nigeria was?",
      "options": [
        "Kano",
        "Enugu",
        "Abuja",
        "Lagos"
      ],
      "correct": 3,
      "explanation": "Lagos was the former capital"
    },
    {
      "question": "Which of these is a volcanic mountain?",
      "options": [
        "Everest only",
        "Alps only",
        "Kilimanjaro",
        "Himalayas"
      ],
      "correct": 2,
      "explanation": "Kilimanjaro is volcanic"
    },
    {
      "question": "The instrument used to measure wind speed is?",
      "options": [
        "Wind vane",
        "Thermometer",
        "Barometer",
        "Anemometer"
      ],
      "correct": 3,
      "explanation": "Anemometer measures wind speed"
    },
    {
      "question": "Which of these is a local government headquarters?",
      "options": [
        "Depends on the area",
        "Always Lagos",
        "Always Abuja",
        "Always Kano"
      ],
      "correct": 0,
      "explanation": "Headquarters vary by local government"
    },
    {
      "question": "The process of rocks breaking down is?",
      "options": [
        "Deposition",
        "Transportation",
        "Erosion only",
        "Weathering"
      ],
      "correct": 3,
      "explanation": "Weathering breaks down rocks"
    },
    {
      "question": "Which of these shows the meaning of symbols on a map?",
      "options": [
        "Title only",
        "North arrow only",
        "Scale only",
        "Key/Legend"
      ],
      "correct": 3,
      "explanation": "The key explains symbols"
    },
    {
      "question": "The long-term weather pattern is?",
      "options": [
        "Weather",
        "Climate",
        "Season",
        "Forecast"
      ],
      "correct": 1,
      "explanation": "Climate is long-term"
    },
    {
      "question": "Which of these is a type of cloud?",
      "options": [
        "Mountain",
        "Valley",
        "Desert",
        "Cumulus"
      ],
      "correct": 3,
      "explanation": "Cumulus is a type of cloud"
    },
    {
      "question": "The earth completes one revolution in?",
      "options": [
        "365¼ days",
        "30 days",
        "7 days",
        "24 hours"
      ],
      "correct": 0,
      "explanation": "One revolution takes about 365¼ days"
    },
    {
      "question": "Which of these is a human feature?",
      "options": [
        "Settlement",
        "River",
        "Mountain",
        "Lake"
      ],
      "correct": 0,
      "explanation": "Settlements are human features"
    },
    {
      "question": "A scale of 1:100 means 1 cm represents?",
      "options": [
        "100 m",
        "1 m",
        "1000 m",
        "10 m"
      ],
      "correct": 1,
      "explanation": "1 cm = 100 cm = 1 m"
    },
    {
      "question": "Which vegetation is found in the savannah?",
      "options": [
        "Desert only",
        "Dense forest only",
        "Grassland with scattered trees",
        "Mangrove only"
      ],
      "correct": 2,
      "explanation": "Savannah has grass and scattered trees"
    },
    {
      "question": "The process of clouds forming is mainly by?",
      "options": [
        "Infiltration",
        "Evaporation only",
        "Precipitation",
        "Condensation"
      ],
      "correct": 3,
      "explanation": "Condensation forms clouds"
    },
    {
      "question": "Which of these is a major river basin in Nigeria?",
      "options": [
        "Amazon Basin",
        "Niger Basin",
        "Nile Basin",
        "Congo Basin only"
      ],
      "correct": 1,
      "explanation": "Niger Basin is in Nigeria"
    },
    {
      "question": "The hottest layer of the earth is the?",
      "options": [
        "Core",
        "Mantle",
        "Atmosphere",
        "Crust"
      ],
      "correct": 0,
      "explanation": "The core is the hottest"
    },
    {
      "question": "Which instrument measures atmospheric pressure?",
      "options": [
        "Hygrometer",
        "Anemometer",
        "Thermometer",
        "Barometer"
      ],
      "correct": 3,
      "explanation": "Barometer measures pressure"
    },
    {
      "question": "The weather condition over a short period is?",
      "options": [
        "Weather",
        "Season",
        "Vegetation",
        "Climate"
      ],
      "correct": 0,
      "explanation": "Weather is short-term"
    },
    {
      "question": "Which of these is formed by river deposition?",
      "options": [
        "Plateau",
        "Volcano",
        "Mountain",
        "Flood plain"
      ],
      "correct": 3,
      "explanation": "Flood plains are formed by deposition"
    },
    {
      "question": "The direction opposite to west is?",
      "options": [
        "South",
        "West",
        "North",
        "East"
      ],
      "correct": 3,
      "explanation": "East is opposite west"
    },
    {
      "question": "Which of these is a renewable resource?",
      "options": [
        "Solar energy",
        "Petroleum",
        "Natural gas",
        "Coal"
      ],
      "correct": 0,
      "explanation": "Solar energy is renewable"
    },
    {
      "question": "The process of transporting eroded materials is?",
      "options": [
        "Transportation",
        "Erosion only",
        "Weathering",
        "Deposition"
      ],
      "correct": 0,
      "explanation": "Transportation moves eroded materials"
    },
    {
      "question": "The study of population is?",
      "options": [
        "Demography",
        "Meteorology",
        "Ecology only",
        "Geology"
      ],
      "correct": 0,
      "explanation": "Demography is the study of population"
    },
    {
      "question": "The Tropic of Cancer is located in the?",
      "options": [
        "Both equally",
        "Northern Hemisphere",
        "Poles only",
        "Southern Hemisphere"
      ],
      "correct": 1,
      "explanation": "Tropic of Cancer is in the Northern Hemisphere"
    },
    {
      "question": "Which of these is a quaternary activity?",
      "options": [
        "Research and development",
        "Farming",
        "Manufacturing",
        "Trading"
      ],
      "correct": 0,
      "explanation": "Research is a quaternary activity"
    },
    {
      "question": "Which of these is the deepest ocean?",
      "options": [
        "Pacific Ocean",
        "Arctic Ocean",
        "Atlantic Ocean",
        "Indian Ocean"
      ],
      "correct": 0,
      "explanation": "The Pacific has the deepest trenches"
    },
    {
      "question": "Nigeria is located in which continent?",
      "options": [
        "Africa",
        "Europe",
        "Asia",
        "South America"
      ],
      "correct": 0,
      "explanation": "Nigeria is in Africa"
    },
    {
      "question": "Which of these is a block mountain?",
      "options": [
        "Vosges",
        "Rockies",
        "Himalayas",
        "Andes"
      ],
      "correct": 0,
      "explanation": "Vosges are an example of block mountains"
    },
    {
      "question": "The instrument used to measure humidity is?",
      "options": [
        "Anemometer",
        "Hygrometer",
        "Thermometer",
        "Barometer"
      ],
      "correct": 1,
      "explanation": "Hygrometer measures humidity"
    },
    {
      "question": "Which of these is a commercial city in Nigeria?",
      "options": [
        "Lagos",
        "A desert",
        "A forest",
        "A small village"
      ],
      "correct": 0,
      "explanation": "Lagos is a major commercial city"
    },
    {
      "question": "The process of moving weathered materials is?",
      "options": [
        "Erosion",
        "Deposition only",
        "Weathering",
        "Folding"
      ],
      "correct": 0,
      "explanation": "Erosion moves weathered materials"
    },
    {
      "question": "Which of these is used to measure distance on a map?",
      "options": [
        "Key only",
        "Scale",
        "Title only",
        "North arrow only"
      ],
      "correct": 1,
      "explanation": "Scale is used to measure distance"
    },
    {
      "question": "The condition of the atmosphere day by day is?",
      "options": [
        "Climate",
        "Vegetation",
        "Weather",
        "Season"
      ],
      "correct": 2,
      "explanation": "Weather changes day by day"
    },
    {
      "question": "Which of these is a form of precipitation?",
      "options": [
        "Sunshine",
        "Cloud only",
        "Wind",
        "Rain"
      ],
      "correct": 3,
      "explanation": "Rain is a form of precipitation"
    },
    {
      "question": "The earth rotates on its?",
      "options": [
        "Orbit",
        "Axis",
        "Meridian",
        "Equator"
      ],
      "correct": 1,
      "explanation": "Earth rotates on its axis"
    },
    {
      "question": "Which of these is a drainage feature?",
      "options": [
        "River",
        "Building",
        "Road",
        "Railway"
      ],
      "correct": 0,
      "explanation": "Rivers are drainage features"
    },
    {
      "question": "A representative fraction of 1:50,000 means?",
      "options": [
        "1 unit on map = 50,000 units on ground",
        "1 unit = 500 units",
        "1 unit = 50 units",
        "1 unit = 5,000 units"
      ],
      "correct": 0,
      "explanation": "RF shows the ratio clearly"
    },
    {
      "question": "Which vegetation belt has tall grasses?",
      "options": [
        "Rainforest only",
        "Guinea savanna",
        "Desert",
        "Mangrove"
      ],
      "correct": 1,
      "explanation": "Guinea savanna has tall grasses"
    },
    {
      "question": "The process of water seeping into the ground is?",
      "options": [
        "Precipitation",
        "Evaporation",
        "Condensation",
        "Infiltration"
      ],
      "correct": 3,
      "explanation": "Infiltration is seeping into the ground"
    },
    {
      "question": "Which of these is a man-made lake in Nigeria?",
      "options": [
        "River Niger only",
        "Atlantic Ocean",
        "Kainji Lake",
        "Lake Chad"
      ],
      "correct": 2,
      "explanation": "Kainji is a man-made lake"
    },
    {
      "question": "The solid outer part of the earth is the?",
      "options": [
        "Hydrosphere",
        "Biosphere",
        "Lithosphere",
        "Atmosphere"
      ],
      "correct": 2,
      "explanation": "Lithosphere is the solid outer part"
    },
    {
      "question": "Which instrument measures the amount of rainfall?",
      "options": [
        "Rain gauge",
        "Barometer",
        "Wind vane",
        "Thermometer"
      ],
      "correct": 0,
      "explanation": "Rain gauge measures rainfall"
    },
    {
      "question": "The general pattern of weather is?",
      "options": [
        "Weather",
        "Climate",
        "Forecast only",
        "Season only"
      ],
      "correct": 1,
      "explanation": "Climate is the general pattern"
    },
    {
      "question": "Which of these is formed by glacial action?",
      "options": [
        "Flood plain only",
        "V-shaped valley only",
        "Delta",
        "U-shaped valley"
      ],
      "correct": 3,
      "explanation": "Glaciers form U-shaped valleys"
    },
    {
      "question": "The direction between north and east is?",
      "options": [
        "Northeast",
        "Southeast",
        "Northwest",
        "Southwest"
      ],
      "correct": 0,
      "explanation": "Northeast is between north and east"
    },
    {
      "question": "Which of these is an inexhaustible resource?",
      "options": [
        "Natural gas",
        "Solar energy",
        "Coal",
        "Petroleum"
      ],
      "correct": 1,
      "explanation": "Solar energy is inexhaustible"
    },
    {
      "question": "The process of rocks being worn away is?",
      "options": [
        "Folding",
        "Erosion",
        "Faulting only",
        "Deposition"
      ],
      "correct": 1,
      "explanation": "Erosion wears away rocks"
    },
    {
      "question": "The number of people living in an area is?",
      "options": [
        "Migration only",
        "Census only",
        "Population",
        "Density only"
      ],
      "correct": 2,
      "explanation": "Population is the number of people"
    },
    {
      "question": "The Equator is at?",
      "options": [
        "0° longitude",
        "66½°N",
        "23½°N",
        "0° latitude"
      ],
      "correct": 3,
      "explanation": "Equator is 0° latitude"
    },
    {
      "question": "Which of these is a primary activity?",
      "options": [
        "Trading in finished goods",
        "Teaching",
        "Mining",
        "Banking"
      ],
      "correct": 2,
      "explanation": "Mining is a primary activity"
    },
    {
      "question": "Which of these is the smallest ocean?",
      "options": [
        "Arctic Ocean",
        "Indian Ocean",
        "Atlantic Ocean",
        "Pacific Ocean"
      ],
      "correct": 0,
      "explanation": "The Arctic is the smallest ocean"
    },
    {
      "question": "Nigeria shares a border with which of these countries?",
      "options": [
        "Egypt",
        "Benin",
        "South Africa",
        "Ghana"
      ],
      "correct": 1,
      "explanation": "Nigeria borders Benin"
    },
    {
      "question": "Which of these is a residual mountain?",
      "options": [
        "Himalayas",
        "Rockies",
        "Andes",
        "Plateau remnants"
      ],
      "correct": 3,
      "explanation": "Residual mountains are remnants of old highlands"
    },
    {
      "question": "The instrument used to measure temperature is?",
      "options": [
        "Anemometer",
        "Hygrometer",
        "Thermometer",
        "Barometer"
      ],
      "correct": 2,
      "explanation": "Thermometer measures temperature"
    },
    {
      "question": "Which of these is an industrial city in Nigeria?",
      "options": [
        "A forest reserve",
        "Port Harcourt",
        "A small village",
        "A desert area"
      ],
      "correct": 1,
      "explanation": "Port Harcourt is an industrial city"
    },
    {
      "question": "The process of wearing away of the land is?",
      "options": [
        "Weathering only",
        "Deposition",
        "Erosion",
        "Folding"
      ],
      "correct": 2,
      "explanation": "Erosion wears away the land"
    },
    {
      "question": "Which of these is found on almost every map?",
      "options": [
        "Title",
        "Climate data only",
        "Population figure only",
        "Economic data only"
      ],
      "correct": 0,
      "explanation": "Maps usually have a title"
    },
    {
      "question": "The atmospheric condition over a long period is?",
      "options": [
        "Season only",
        "Forecast",
        "Climate",
        "Weather"
      ],
      "correct": 2,
      "explanation": "Climate is long-term"
    },
    {
      "question": "Which of these is a type of rainfall associated with mountains?",
      "options": [
        "Relief rainfall",
        "Cyclonic only",
        "Convectional only",
        "Desert rainfall"
      ],
      "correct": 0,
      "explanation": "Relief rainfall is caused by mountains"
    },
    {
      "question": "The earth revolves around the?",
      "options": [
        "Sun",
        "Moon",
        "Jupiter",
        "Mars"
      ],
      "correct": 0,
      "explanation": "Earth revolves around the sun"
    },
    {
      "question": "Which of these is a natural drainage feature?",
      "options": [
        "Irrigation channel",
        "River",
        "Dam",
        "Canal"
      ],
      "correct": 1,
      "explanation": "Rivers are natural"
    },
    {
      "question": "A map scale of 1:200,000 means 1 cm represents?",
      "options": [
        "20 km",
        "2 km",
        "200 m",
        "0.2 km"
      ],
      "correct": 1,
      "explanation": "1 cm = 200,000 cm = 2 km"
    },
    {
      "question": "Which vegetation is found in swampy coastal areas?",
      "options": [
        "Sudan savanna",
        "Montane",
        "Sahel",
        "Mangrove"
      ],
      "correct": 3,
      "explanation": "Mangrove grows in coastal swamps"
    },
    {
      "question": "The process of water vapour turning into liquid is?",
      "options": [
        "Evaporation",
        "Infiltration",
        "Condensation",
        "Precipitation"
      ],
      "correct": 2,
      "explanation": "Condensation is vapour to liquid"
    },
    {
      "question": "Which of these is a major river in West Africa?",
      "options": [
        "River Nile",
        "River Thames",
        "River Niger",
        "River Amazon"
      ],
      "correct": 2,
      "explanation": "River Niger is in West Africa"
    },
    {
      "question": "The gaseous layer of the earth is the?",
      "options": [
        "Hydrosphere",
        "Atmosphere",
        "Biosphere",
        "Lithosphere"
      ],
      "correct": 1,
      "explanation": "Atmosphere is the gaseous layer"
    },
    {
      "question": "Which instrument measures wind direction?",
      "options": [
        "Wind vane",
        "Barometer",
        "Anemometer",
        "Thermometer"
      ],
      "correct": 0,
      "explanation": "Wind vane shows direction"
    },
    {
      "question": "The average weather of a place is?",
      "options": [
        "Forecast",
        "Weather",
        "Climate",
        "Season"
      ],
      "correct": 2,
      "explanation": "Climate is the average weather"
    },
    {
      "question": "Which of these is formed at the lower course of a river?",
      "options": [
        "Gorge",
        "V-shaped valley",
        "Waterfall",
        "Delta"
      ],
      "correct": 3,
      "explanation": "Deltas form at the lower course"
    },
    {
      "question": "The direction opposite to south is?",
      "options": [
        "Southeast",
        "North",
        "East",
        "West"
      ],
      "correct": 1,
      "explanation": "North is opposite south"
    },
    {
      "question": "Which of these is a renewable resource?",
      "options": [
        "Forest",
        "Natural gas",
        "Coal",
        "Petroleum"
      ],
      "correct": 0,
      "explanation": "Forests can regenerate"
    },
    {
      "question": "The process of laying down eroded materials is?",
      "options": [
        "Weathering",
        "Erosion",
        "Transportation",
        "Deposition"
      ],
      "correct": 3,
      "explanation": "Deposition lays down materials"
    },
    {
      "question": "The official counting of a population is?",
      "options": [
        "Sampling",
        "Estimation",
        "Survey only",
        "Census"
      ],
      "correct": 3,
      "explanation": "Census is the official count"
    },
    {
      "question": "The Tropic of Capricorn is in the?",
      "options": [
        "Northern Hemisphere",
        "Poles only",
        "Southern Hemisphere",
        "Both equally"
      ],
      "correct": 2,
      "explanation": "Tropic of Capricorn is in the Southern Hemisphere"
    },
    {
      "question": "Which of these is a tertiary activity?",
      "options": [
        "Mining",
        "Fishing",
        "Farming",
        "Banking"
      ],
      "correct": 3,
      "explanation": "Banking is a service (tertiary) activity"
    }
  ],
  "eng": [
    {
      "question": "Choose the word nearest in meaning to 'happy':",
      "options": [
        "Tired",
        "Joyful",
        "Sad",
        "Angry"
      ],
      "correct": 1,
      "explanation": "Joyful means happy"
    },
    {
      "question": "The opposite of 'brave' is?",
      "options": [
        "Cowardly",
        "Bold",
        "Strong",
        "Fearless"
      ],
      "correct": 0,
      "explanation": "Cowardly is the opposite of brave"
    },
    {
      "question": "Choose the correctly spelt word:",
      "options": [
        "Acommodation",
        "Accomodation",
        "Accommodation",
        "Accomadation"
      ],
      "correct": 2,
      "explanation": "The correct spelling is Accommodation"
    },
    {
      "question": "Fill in: She is good ___ English.",
      "options": [
        "in",
        "on",
        "for",
        "at"
      ],
      "correct": 3,
      "explanation": "We say 'good at' a subject"
    },
    {
      "question": "The plural of 'child' is?",
      "options": [
        "Childs",
        "Childes",
        "Children",
        "Childrens"
      ],
      "correct": 2,
      "explanation": "The plural of child is children"
    },
    {
      "question": "Choose the word that rhymes with 'cat':",
      "options": [
        "Kit",
        "Cut",
        "Hat",
        "Cot"
      ],
      "correct": 2,
      "explanation": "Hat rhymes with cat"
    },
    {
      "question": "He has been here ___ Monday.",
      "options": [
        "since",
        "from",
        "in",
        "for"
      ],
      "correct": 0,
      "explanation": "We use 'since' with a point in time"
    },
    {
      "question": "The synonym of 'big' is?",
      "options": [
        "Small",
        "Tiny",
        "Little",
        "Large"
      ],
      "correct": 3,
      "explanation": "Large means big"
    },
    {
      "question": "Choose the correct sentence:",
      "options": [
        "She doesn't like rice",
        "She don't like rice",
        "She don't likes rice",
        "She doesn't likes rice"
      ],
      "correct": 0,
      "explanation": "Correct form is 'doesn't like'"
    },
    {
      "question": "The past tense of 'go' is?",
      "options": [
        "Going",
        "Goes",
        "Gone",
        "Went"
      ],
      "correct": 3,
      "explanation": "Past tense of go is went"
    },
    {
      "question": "Fill in: If I ___ you, I would help.",
      "options": [
        "am",
        "were",
        "was",
        "is"
      ],
      "correct": 1,
      "explanation": "In second conditional we use 'were'"
    },
    {
      "question": "The opposite of 'hot' is?",
      "options": [
        "Cold",
        "Warm",
        "Heat",
        "Cool"
      ],
      "correct": 0,
      "explanation": "Cold is the opposite of hot"
    },
    {
      "question": "Choose the odd one out:",
      "options": [
        "Run",
        "Apple",
        "Jump",
        "Walk"
      ],
      "correct": 1,
      "explanation": "Apple is not a verb of movement"
    },
    {
      "question": "The comparative of 'good' is?",
      "options": [
        "Gooder",
        "Better",
        "More good",
        "Best"
      ],
      "correct": 1,
      "explanation": "Comparative of good is better"
    },
    {
      "question": "Fill in: The book is ___ the table.",
      "options": [
        "on",
        "at",
        "in",
        "by"
      ],
      "correct": 0,
      "explanation": "We say 'on the table'"
    },
    {
      "question": "The plural of 'mouse' is?",
      "options": [
        "Meese",
        "Mouse",
        "Mouses",
        "Mice"
      ],
      "correct": 3,
      "explanation": "Plural of mouse is mice"
    },
    {
      "question": "Choose the correct question tag: She is coming, ___?",
      "options": [
        "isn't she",
        "doesn't she",
        "wasn't she",
        "is she"
      ],
      "correct": 0,
      "explanation": "Positive statement takes negative tag"
    },
    {
      "question": "The synonym of 'start' is?",
      "options": [
        "Finish",
        "Begin",
        "End",
        "Stop"
      ],
      "correct": 1,
      "explanation": "Begin means start"
    },
    {
      "question": "Fill in: I am interested ___ music.",
      "options": [
        "on",
        "at",
        "for",
        "in"
      ],
      "correct": 3,
      "explanation": "Interested in"
    },
    {
      "question": "The past participle of 'write' is?",
      "options": [
        "Wrote",
        "Writes",
        "Writing",
        "Written"
      ],
      "correct": 3,
      "explanation": "Past participle of write is written"
    },
    {
      "question": "Choose the correctly punctuated sentence:",
      "options": [
        "Where are you going?",
        "where are you going?",
        "Where are you going.",
        "Where are you going"
      ],
      "correct": 0,
      "explanation": "Questions end with a question mark and start with capital"
    },
    {
      "question": "The opposite of 'love' is?",
      "options": [
        "Hate",
        "Admire",
        "Like",
        "Enjoy"
      ],
      "correct": 0,
      "explanation": "Hate is the opposite of love"
    },
    {
      "question": "Fill in: Neither John nor his friends ___ present.",
      "options": [
        "are",
        "has",
        "was",
        "is"
      ],
      "correct": 0,
      "explanation": "Verb agrees with the nearer subject (friends)"
    },
    {
      "question": "The superlative of 'bad' is?",
      "options": [
        "Most bad",
        "Worst",
        "Badder",
        "Worse"
      ],
      "correct": 1,
      "explanation": "Superlative of bad is worst"
    },
    {
      "question": "Choose the word nearest in meaning to 'begin':",
      "options": [
        "Stop",
        "Commence",
        "Finish",
        "End"
      ],
      "correct": 1,
      "explanation": "Commence means begin"
    },
    {
      "question": "Choose the word opposite in meaning to 'ancient':",
      "options": [
        "Modern",
        "Historic",
        "Old",
        "Past"
      ],
      "correct": 0,
      "explanation": "Modern is the opposite of ancient"
    },
    {
      "question": "The plural of 'knife' is?",
      "options": [
        "Knive",
        "Knives",
        "Knife",
        "Knifes"
      ],
      "correct": 1,
      "explanation": "Plural of knife is knives"
    },
    {
      "question": "Fill in: He is senior ___ me.",
      "options": [
        "with",
        "to",
        "from",
        "than"
      ],
      "correct": 1,
      "explanation": "We say 'senior to'"
    },
    {
      "question": "Choose the correctly spelt word:",
      "options": [
        "Necesary",
        "Neceserry",
        "Necessary",
        "Neccessary"
      ],
      "correct": 2,
      "explanation": "The correct spelling is Necessary"
    },
    {
      "question": "The past tense of 'teach' is?",
      "options": [
        "Teaching",
        "Teaches",
        "Teached",
        "Taught"
      ],
      "correct": 3,
      "explanation": "Past tense of teach is taught"
    },
    {
      "question": "Choose the word nearest in meaning to '//':",
      "options": [
        "Lazy",
        "Quick",
        "Weak",
        "Slow"
      ],
      "correct": 1,
      "explanation": "Rapid means quick"
    },
    {
      "question": "Fill in: Neither of the boys ___ present.",
      "options": [
        "were",
        "was",
        "are",
        "have"
      ],
      "correct": 1,
      "explanation": "'Neither' takes a singular verb"
    },
    {
      "question": "The comparative of 'beautiful' is?",
      "options": [
        "Beauty",
        "More beautiful",
        "Most beautiful",
        "Beautifuler"
      ],
      "correct": 1,
      "explanation": "Comparative is more beautiful"
    },
    {
      "question": "Choose the odd one out:",
      "options": [
        "Desk",
        "Chair",
        "Table",
        "Run"
      ],
      "correct": 3,
      "explanation": "Run is a verb; others are nouns"
    },
    {
      "question": "Fill in: She has been working here ___ five years.",
      "options": [
        "from",
        "in",
        "since",
        "for"
      ],
      "correct": 3,
      "explanation": "We use 'for' with a period of time"
    },
    {
      "question": "The opposite of 'success' is?",
      "options": [
        "Victory",
        "Failure",
        "Achievement",
        "Win"
      ],
      "correct": 1,
      "explanation": "Failure is the opposite of success"
    },
    {
      "question": "Choose the correct sentence:",
      "options": [
        "The boys are playing",
        "The boys am playing",
        "The boys be playing",
        "The boys is playing"
      ],
      "correct": 0,
      "explanation": "Plural subject takes 'are'"
    },
    {
      "question": "The past participle of 'see' is?",
      "options": [
        "Seeing",
        "Sees",
        "Seen",
        "Saw"
      ],
      "correct": 2,
      "explanation": "Past participle of see is seen"
    },
    {
      "question": "Fill in: He is afraid ___ dogs.",
      "options": [
        "with",
        "by",
        "from",
        "of"
      ],
      "correct": 3,
      "explanation": "Afraid of"
    },
    {
      "question": "The synonym of 'end' is?",
      "options": [
        "Start",
        "Finish",
        "Open",
        "Begin"
      ],
      "correct": 1,
      "explanation": "Finish means end"
    },
    {
      "question": "Choose the word that rhymes with 'light':",
      "options": [
        "Lit",
        "Lot",
        "Late",
        "Night"
      ],
      "correct": 3,
      "explanation": "Night rhymes with light"
    },
    {
      "question": "Fill in: The news ___ good.",
      "options": [
        "is",
        "have",
        "were",
        "are"
      ],
      "correct": 0,
      "explanation": "'News' is singular"
    },
    {
      "question": "The superlative of 'far' is?",
      "options": [
        "Farer",
        "Farest",
        "Farthest/Furthest",
        "More far"
      ],
      "correct": 2,
      "explanation": "Superlative of far is farthest/furthest"
    },
    {
      "question": "Choose the correctly punctuated sentence:",
      "options": [
        "What is your name",
        "what is your name?",
        "What is your name.",
        "What is your name?"
      ],
      "correct": 3,
      "explanation": "Questions need capital and question mark"
    },
    {
      "question": "The opposite of 'early' is?",
      "options": [
        "Fast",
        "Quick",
        "Soon",
        "Late"
      ],
      "correct": 3,
      "explanation": "Late is the opposite of early"
    },
    {
      "question": "Fill in: I prefer tea ___ coffee.",
      "options": [
        "for",
        "than",
        "from",
        "to"
      ],
      "correct": 3,
      "explanation": "Prefer... to"
    },
    {
      "question": "The plural of 'ox' is?",
      "options": [
        "Oxen",
        "Oxes",
        "Oxens",
        "Ox"
      ],
      "correct": 0,
      "explanation": "Plural of ox is oxen"
    },
    {
      "question": "Choose the word nearest in meaning to 'tiny':",
      "options": [
        "Small",
        "Big",
        "Huge",
        "Large"
      ],
      "correct": 0,
      "explanation": "Tiny means very small"
    },
    {
      "question": "Fill in: She is the ___ girl in the class.",
      "options": [
        "more tall",
        "tallest",
        "taller",
        "tall"
      ],
      "correct": 1,
      "explanation": "Superlative is used for more than two"
    },
    {
      "question": "The past tense of 'buy' is?",
      "options": [
        "Bought",
        "Buys",
        "Buyed",
        "Buying"
      ],
      "correct": 0,
      "explanation": "Past tense of buy is bought"
    },
    {
      "question": "Choose the word opposite in meaning to 'generous':",
      "options": [
        "Stingy",
        "Helpful",
        "Kind",
        "Friendly"
      ],
      "correct": 0,
      "explanation": "Stingy is the opposite of generous"
    },
    {
      "question": "The plural of 'leaf' is?",
      "options": [
        "Leafes",
        "Leaves",
        "Leave",
        "Leafs"
      ],
      "correct": 1,
      "explanation": "Plural of leaf is leaves"
    },
    {
      "question": "Fill in: She is married ___ a doctor.",
      "options": [
        "to",
        "for",
        "by",
        "with"
      ],
      "correct": 0,
      "explanation": "Married to"
    },
    {
      "question": "Choose the correctly spelt word:",
      "options": [
        "Definitely",
        "Definatly",
        "Definately",
        "Definitley"
      ],
      "correct": 0,
      "explanation": "The correct spelling is Definitely"
    },
    {
      "question": "The past tense of 'catch' is?",
      "options": [
        "Catched",
        "Catches",
        "Caught",
        "Catching"
      ],
      "correct": 2,
      "explanation": "Past tense of catch is caught"
    },
    {
      "question": "Choose the word nearest in meaning to 'difficult':",
      "options": [
        "Simple",
        "Clear",
        "Easy",
        "Hard"
      ],
      "correct": 3,
      "explanation": "Hard means difficult"
    },
    {
      "question": "Fill in: Each of the students ___ a book.",
      "options": [
        "has",
        "were",
        "are",
        "have"
      ],
      "correct": 0,
      "explanation": "'Each' takes a singular verb"
    },
    {
      "question": "The comparative of 'little' is?",
      "options": [
        "More little",
        "Least",
        "Littler",
        "Less"
      ],
      "correct": 3,
      "explanation": "Comparative of little is less"
    },
    {
      "question": "Choose the odd one out:",
      "options": [
        "Write",
        "Dance",
        "Sing",
        "Book"
      ],
      "correct": 3,
      "explanation": "Book is a noun; others are verbs"
    },
    {
      "question": "Fill in: He has lived here ___ 2010.",
      "options": [
        "in",
        "from",
        "for",
        "since"
      ],
      "correct": 3,
      "explanation": "Since is used with a point in time"
    },
    {
      "question": "The opposite of 'victory' is?",
      "options": [
        "Success",
        "Win",
        "Defeat",
        "Triumph"
      ],
      "correct": 2,
      "explanation": "Defeat is the opposite of victory"
    },
    {
      "question": "Choose the correct sentence:",
      "options": [
        "He doesn't knows the answer",
        "He don't know the answer",
        "He doesn't know the answer",
        "He don't knows the answer"
      ],
      "correct": 2,
      "explanation": "Correct form is doesn't know"
    },
    {
      "question": "The past participle of 'take' is?",
      "options": [
        "Takes",
        "Taking",
        "Taken",
        "Took"
      ],
      "correct": 2,
      "explanation": "Past participle of take is taken"
    },
    {
      "question": "Fill in: She is good ___ dancing.",
      "options": [
        "for",
        "on",
        "in",
        "at"
      ],
      "correct": 3,
      "explanation": "Good at"
    },
    {
      "question": "The synonym of 'happy' is?",
      "options": [
        "Tired",
        "Sad",
        "Angry",
        "Glad"
      ],
      "correct": 3,
      "explanation": "Glad means happy"
    },
    {
      "question": "Choose the word that rhymes with 'day':",
      "options": [
        "Den",
        "Did",
        "Say",
        "Dog"
      ],
      "correct": 2,
      "explanation": "Say rhymes with day"
    },
    {
      "question": "Fill in: Mathematics ___ my favourite subject.",
      "options": [
        "is",
        "were",
        "have",
        "are"
      ],
      "correct": 0,
      "explanation": "Mathematics is treated as singular"
    },
    {
      "question": "The superlative of 'good' is?",
      "options": [
        "Best",
        "Goodest",
        "Better",
        "Most good"
      ],
      "correct": 0,
      "explanation": "Superlative of good is best"
    },
    {
      "question": "Choose the correctly punctuated sentence:",
      "options": [
        "how are you?",
        "How are you?",
        "How are you.",
        "How are you"
      ],
      "correct": 1,
      "explanation": "Questions need capital letter and question mark"
    },
    {
      "question": "The opposite of 'strong' is?",
      "options": [
        "Mighty",
        "Weak",
        "Powerful",
        "Tough"
      ],
      "correct": 1,
      "explanation": "Weak is the opposite of strong"
    },
    {
      "question": "Fill in: He is different ___ his brother.",
      "options": [
        "to",
        "than",
        "with",
        "from"
      ],
      "correct": 3,
      "explanation": "Different from"
    },
    {
      "question": "The plural of 'man' is?",
      "options": [
        "Mans",
        "Mens",
        "Men",
        "Manes"
      ],
      "correct": 2,
      "explanation": "Plural of man is men"
    },
    {
      "question": "Choose the word nearest in meaning to 'angry':",
      "options": [
        "Calm",
        "Happy",
        "Peaceful",
        "Furious"
      ],
      "correct": 3,
      "explanation": "Furious means very angry"
    },
    {
      "question": "Fill in: This is the ___ book I have ever read.",
      "options": [
        "more good",
        "better",
        "good",
        "best"
      ],
      "correct": 3,
      "explanation": "Superlative is used with 'ever'"
    },
    {
      "question": "The past tense of 'run' is?",
      "options": [
        "Running",
        "Runned",
        "Runs",
        "Ran"
      ],
      "correct": 3,
      "explanation": "Past tense of run is ran"
    },
    {
      "question": "Choose the word opposite in meaning to 'cruel':",
      "options": [
        "Harsh",
        "Brutal",
        "Wicked",
        "Kind"
      ],
      "correct": 3,
      "explanation": "Kind is the opposite of cruel"
    },
    {
      "question": "The plural of 'tooth' is?",
      "options": [
        "Teeths",
        "Toothes",
        "Tooths",
        "Teeth"
      ],
      "correct": 3,
      "explanation": "Plural of tooth is teeth"
    },
    {
      "question": "Fill in: He is proud ___ his success.",
      "options": [
        "for",
        "with",
        "at",
        "of"
      ],
      "correct": 3,
      "explanation": "Proud of"
    },
    {
      "question": "Choose the correctly spelt word:",
      "options": [
        "Separete",
        "Separate",
        "Seperate",
        "Seperete"
      ],
      "correct": 1,
      "explanation": "The correct spelling is Separate"
    },
    {
      "question": "The past tense of 'speak' is?",
      "options": [
        "Spoke",
        "Speaking",
        "Speaks",
        "Spoken"
      ],
      "correct": 0,
      "explanation": "Past tense of speak is spoke"
    },
    {
      "question": "Choose the word nearest in meaning to 'brave':",
      "options": [
        "Courageous",
        "Timid",
        "Fearful",
        "Cowardly"
      ],
      "correct": 0,
      "explanation": "Courageous means brave"
    },
    {
      "question": "Fill in: One of the boys ___ missing.",
      "options": [
        "is",
        "were",
        "are",
        "have"
      ],
      "correct": 0,
      "explanation": "'One' takes a singular verb"
    },
    {
      "question": "The comparative of 'much' is?",
      "options": [
        "More",
        "Most",
        "Mucher",
        "Many"
      ],
      "correct": 0,
      "explanation": "Comparative of much is more"
    },
    {
      "question": "Choose the odd one out:",
      "options": [
        "Green",
        "Blue",
        "Red",
        "Run"
      ],
      "correct": 3,
      "explanation": "Run is a verb; others are colours"
    },
    {
      "question": "Fill in: They have been friends ___ childhood.",
      "options": [
        "for",
        "in",
        "from",
        "since"
      ],
      "correct": 3,
      "explanation": "Since childhood (point in time)"
    },
    {
      "question": "The opposite of 'rich' is?",
      "options": [
        "Prosperous",
        "Wealthy",
        "Affluent",
        "Poor"
      ],
      "correct": 3,
      "explanation": "Poor is the opposite of rich"
    },
    {
      "question": "Choose the correct sentence:",
      "options": [
        "She has finished her works",
        "She has finish her work",
        "She have finished her work",
        "She has finished her work"
      ],
      "correct": 3,
      "explanation": "Correct form is has finished"
    },
    {
      "question": "The past participle of 'break' is?",
      "options": [
        "Breaking",
        "Breaks",
        "Broke",
        "Broken"
      ],
      "correct": 3,
      "explanation": "Past participle of break is broken"
    },
    {
      "question": "Fill in: He is keen ___ sports.",
      "options": [
        "at",
        "on",
        "for",
        "in"
      ],
      "correct": 1,
      "explanation": "Keen on"
    },
    {
      "question": "The synonym of 'sad' is?",
      "options": [
        "Unhappy",
        "Joyful",
        "Excited",
        "Happy"
      ],
      "correct": 0,
      "explanation": "Unhappy means sad"
    },
    {
      "question": "Choose the word that rhymes with 'ball':",
      "options": [
        "Call",
        "Bill",
        "Bell",
        "Bull"
      ],
      "correct": 0,
      "explanation": "Call rhymes with ball"
    },
    {
      "question": "Fill in: The furniture ___ new.",
      "options": [
        "is",
        "were",
        "have",
        "are"
      ],
      "correct": 0,
      "explanation": "Furniture is uncountable/singular"
    },
    {
      "question": "The superlative of 'bad' is?",
      "options": [
        "Badder",
        "Most bad",
        "Worst",
        "Worse"
      ],
      "correct": 2,
      "explanation": "Superlative of bad is worst"
    },
    {
      "question": "Choose the correctly punctuated sentence:",
      "options": [
        "Where do you live.",
        "where do you live?",
        "Where do you live",
        "Where do you live?"
      ],
      "correct": 3,
      "explanation": "Questions need capital and question mark"
    },
    {
      "question": "The opposite of 'fast' is?",
      "options": [
        "Swift",
        "Slow",
        "Quick",
        "Rapid"
      ],
      "correct": 1,
      "explanation": "Slow is the opposite of fast"
    },
    {
      "question": "Fill in: She is similar ___ her sister.",
      "options": [
        "to",
        "as",
        "with",
        "from"
      ],
      "correct": 0,
      "explanation": "Similar to"
    },
    {
      "question": "The plural of 'woman' is?",
      "options": [
        "Women",
        "Womanes",
        "Womans",
        "Womens"
      ],
      "correct": 0,
      "explanation": "Plural of woman is women"
    },
    {
      "question": "Choose the word nearest in meaning to 'intelligent':",
      "options": [
        "Clever",
        "Dull",
        "Foolish",
        "Stupid"
      ],
      "correct": 0,
      "explanation": "Clever means intelligent"
    },
    {
      "question": "Fill in: This is ___ interesting story.",
      "options": [
        "the",
        "any",
        "a",
        "an"
      ],
      "correct": 3,
      "explanation": "'Interesting' starts with a vowel sound"
    },
    {
      "question": "The past tense of 'swim' is?",
      "options": [
        "Swimmed",
        "Swam",
        "Swimming",
        "Swum"
      ],
      "correct": 1,
      "explanation": "Past tense of swim is swam"
    },
    {
      "question": "Choose the word opposite in meaning to 'beautiful':",
      "options": [
        "Ugly",
        "Attractive",
        "Lovely",
        "Pretty"
      ],
      "correct": 0,
      "explanation": "Ugly is the opposite of beautiful"
    },
    {
      "question": "The plural of 'foot' is?",
      "options": [
        "Foots",
        "Feets",
        "Footes",
        "Feet"
      ],
      "correct": 3,
      "explanation": "Plural of foot is feet"
    },
    {
      "question": "Fill in: He is responsible ___ the accident.",
      "options": [
        "for",
        "with",
        "to",
        "of"
      ],
      "correct": 0,
      "explanation": "Responsible for"
    },
    {
      "question": "Choose the correctly spelt word:",
      "options": [
        "Begininng",
        "Beginning",
        "Beginnig",
        "Begining"
      ],
      "correct": 1,
      "explanation": "The correct spelling is Beginning"
    },
    {
      "question": "The past tense of 'drink' is?",
      "options": [
        "Drunk",
        "Drinking",
        "Drinked",
        "Drank"
      ],
      "correct": 3,
      "explanation": "Past tense of drink is drank"
    },
    {
      "question": "Choose the word nearest in meaning to 'clever':",
      "options": [
        "Foolish",
        "Dull",
        "Stupid",
        "Intelligent"
      ],
      "correct": 3,
      "explanation": "Intelligent means clever"
    },
    {
      "question": "Fill in: Everybody ___ present yesterday.",
      "options": [
        "was",
        "were",
        "are",
        "have"
      ],
      "correct": 0,
      "explanation": "'Everybody' takes a singular verb"
    },
    {
      "question": "The comparative of 'far' is?",
      "options": [
        "More far",
        "Farest",
        "Farther/Further",
        "Farer"
      ],
      "correct": 2,
      "explanation": "Comparative of far is farther/further"
    },
    {
      "question": "Choose the odd one out:",
      "options": [
        "Apple",
        "Banana",
        "Orange",
        "Run"
      ],
      "correct": 3,
      "explanation": "Run is a verb; others are fruits"
    },
    {
      "question": "Fill in: She has been ill ___ last week.",
      "options": [
        "from",
        "for",
        "since",
        "in"
      ],
      "correct": 2,
      "explanation": "Since last week"
    },
    {
      "question": "The opposite of 'wide' is?",
      "options": [
        "Large",
        "Broad",
        "Big",
        "Narrow"
      ],
      "correct": 3,
      "explanation": "Narrow is the opposite of wide"
    },
    {
      "question": "Choose the correct sentence:",
      "options": [
        "The dog am barking",
        "The dog be barking",
        "The dog is barking",
        "The dog are barking"
      ],
      "correct": 2,
      "explanation": "Singular subject takes 'is'"
    },
    {
      "question": "The past participle of 'eat' is?",
      "options": [
        "Eaten",
        "Ate",
        "Eating",
        "Eats"
      ],
      "correct": 0,
      "explanation": "Past participle of eat is eaten"
    },
    {
      "question": "Fill in: He is fond ___ music.",
      "options": [
        "for",
        "at",
        "with",
        "of"
      ],
      "correct": 3,
      "explanation": "Fond of"
    },
    {
      "question": "The synonym of 'quick' is?",
      "options": [
        "Fast",
        "Slow",
        "Lazy",
        "Late"
      ],
      "correct": 0,
      "explanation": "Fast means quick"
    },
    {
      "question": "Choose the word that rhymes with 'pen':",
      "options": [
        "Pin",
        "Ten",
        "Pan",
        "Pun"
      ],
      "correct": 1,
      "explanation": "Ten rhymes with pen"
    },
    {
      "question": "Fill in: The scissors ___ sharp.",
      "options": [
        "are",
        "is",
        "was",
        "has"
      ],
      "correct": 0,
      "explanation": "Scissors is treated as plural"
    },
    {
      "question": "The superlative of 'little' is?",
      "options": [
        "Most little",
        "Less",
        "Least",
        "Littlest"
      ],
      "correct": 2,
      "explanation": "Superlative of little is least"
    },
    {
      "question": "Choose the correctly punctuated sentence:",
      "options": [
        "What time is it?",
        "what time is it?",
        "What time is it",
        "What time is it."
      ],
      "correct": 0,
      "explanation": "Questions need capital and question mark"
    },
    {
      "question": "The opposite of 'full' is?",
      "options": [
        "Whole",
        "Filled",
        "Complete",
        "Empty"
      ],
      "correct": 3,
      "explanation": "Empty is the opposite of full"
    },
    {
      "question": "Fill in: She is aware ___ the problem.",
      "options": [
        "of",
        "with",
        "at",
        "for"
      ],
      "correct": 0,
      "explanation": "Aware of"
    },
    {
      "question": "The plural of 'goose' is?",
      "options": [
        "Gooses",
        "Geese",
        "Goose",
        "Geeses"
      ],
      "correct": 1,
      "explanation": "Plural of goose is geese"
    },
    {
      "question": "Choose the word nearest in meaning to 'huge':",
      "options": [
        "Small",
        "Tiny",
        "Enormous",
        "Little"
      ],
      "correct": 2,
      "explanation": "Enormous means huge"
    },
    {
      "question": "Fill in: He is the ___ student in the school.",
      "options": [
        "more good",
        "best",
        "better",
        "good"
      ],
      "correct": 1,
      "explanation": "Superlative is used for the highest degree"
    },
    {
      "question": "The past tense of 'sing' is?",
      "options": [
        "Singing",
        "Singed",
        "Sang",
        "Sung"
      ],
      "correct": 2,
      "explanation": "Past tense of sing is sang"
    },
    {
      "question": "Choose the word opposite in meaning to 'honest':",
      "options": [
        "Dishonest",
        "Upright",
        "Sincere",
        "Truthful"
      ],
      "correct": 0,
      "explanation": "Dishonest is the opposite of honest"
    },
    {
      "question": "The plural of 'mouse' is?",
      "options": [
        "Mouse",
        "Mice",
        "Meese",
        "Mouses"
      ],
      "correct": 1,
      "explanation": "Plural of mouse is mice"
    },
    {
      "question": "Fill in: He is capable ___ doing the work.",
      "options": [
        "with",
        "of",
        "for",
        "to"
      ],
      "correct": 1,
      "explanation": "Capable of"
    },
    {
      "question": "Choose the correctly spelt word:",
      "options": [
        "Receve",
        "Recieve",
        "Receeve",
        "Receive"
      ],
      "correct": 3,
      "explanation": "The correct spelling is Receive"
    },
    {
      "question": "The past tense of 'write' is?",
      "options": [
        "Wrote",
        "Written",
        "Writing",
        "Writes"
      ],
      "correct": 0,
      "explanation": "Past tense of write is wrote"
    },
    {
      "question": "Choose the word nearest in meaning to 'ancient':",
      "options": [
        "Modern",
        "Old",
        "Recent",
        "New"
      ],
      "correct": 1,
      "explanation": "Ancient means very old"
    },
    {
      "question": "Fill in: Neither of them ___ available.",
      "options": [
        "have",
        "are",
        "is",
        "were"
      ],
      "correct": 2,
      "explanation": "'Neither' takes singular verb"
    },
    {
      "question": "The comparative of 'good' is?",
      "options": [
        "Better",
        "More good",
        "Gooder",
        "Best"
      ],
      "correct": 0,
      "explanation": "Comparative of good is better"
    },
    {
      "question": "Choose the odd one out:",
      "options": [
        "Sad",
        "Angry",
        "Table",
        "Happy"
      ],
      "correct": 2,
      "explanation": "Table is a noun; others are adjectives"
    },
    {
      "question": "Fill in: I have known him ___ ten years.",
      "options": [
        "from",
        "since",
        "for",
        "in"
      ],
      "correct": 2,
      "explanation": "For is used with a period of time"
    },
    {
      "question": "The opposite of 'thick' is?",
      "options": [
        "Thin",
        "Wide",
        "Broad",
        "Fat"
      ],
      "correct": 0,
      "explanation": "Thin is the opposite of thick"
    },
    {
      "question": "Choose the correct sentence:",
      "options": [
        "She does not like apples",
        "She do not likes apples",
        "She do not like apples",
        "She does not likes apples"
      ],
      "correct": 0,
      "explanation": "Correct form is does not like"
    },
    {
      "question": "The past participle of 'give' is?",
      "options": [
        "Gave",
        "Given",
        "Gives",
        "Giving"
      ],
      "correct": 1,
      "explanation": "Past participle of give is given"
    },
    {
      "question": "Fill in: He is interested ___ science.",
      "options": [
        "in",
        "for",
        "on",
        "at"
      ],
      "correct": 0,
      "explanation": "Interested in"
    },
    {
      "question": "The synonym of 'begin' is?",
      "options": [
        "Finish",
        "Stop",
        "Start",
        "End"
      ],
      "correct": 2,
      "explanation": "Start means begin"
    },
    {
      "question": "Choose the word that rhymes with 'cake':",
      "options": [
        "Coke",
        "Kick",
        "Bake",
        "Cook"
      ],
      "correct": 2,
      "explanation": "Bake rhymes with cake"
    },
    {
      "question": "Fill in: The police ___ investigating the case.",
      "options": [
        "has",
        "is",
        "was",
        "are"
      ],
      "correct": 3,
      "explanation": "Police is treated as plural"
    },
    {
      "question": "The superlative of 'many' is?",
      "options": [
        "Most many",
        "More",
        "Manyest",
        "Most"
      ],
      "correct": 3,
      "explanation": "Superlative of many is most"
    },
    {
      "question": "Choose the correctly punctuated sentence:",
      "options": [
        "are you coming?",
        "Are you coming.",
        "Are you coming?",
        "Are you coming"
      ],
      "correct": 2,
      "explanation": "Questions need capital and question mark"
    },
    {
      "question": "The opposite of 'heavy' is?",
      "options": [
        "Hard",
        "Strong",
        "Light",
        "Big"
      ],
      "correct": 2,
      "explanation": "Light is the opposite of heavy"
    },
    {
      "question": "Fill in: She is good ___ mathematics.",
      "options": [
        "at",
        "on",
        "in",
        "for"
      ],
      "correct": 0,
      "explanation": "Good at"
    },
    {
      "question": "The plural of 'child' is?",
      "options": [
        "Childs",
        "Childrens",
        "Childes",
        "Children"
      ],
      "correct": 3,
      "explanation": "Plural of child is children"
    },
    {
      "question": "Choose the word nearest in meaning to 'wealthy':",
      "options": [
        "Needy",
        "Poor",
        "Broke",
        "Rich"
      ],
      "correct": 3,
      "explanation": "Rich means wealthy"
    },
    {
      "question": "Fill in: This is ___ useful book.",
      "options": [
        "any",
        "the",
        "a",
        "an"
      ],
      "correct": 2,
      "explanation": "'Useful' starts with a consonant sound"
    },
    {
      "question": "The past tense of 'come' is?",
      "options": [
        "Come",
        "Coming",
        "Comes",
        "Came"
      ],
      "correct": 3,
      "explanation": "Past tense of come is came"
    },
    {
      "question": "Choose the word opposite in meaning to 'strong':",
      "options": [
        "Weak",
        "Powerful",
        "Tough",
        "Mighty"
      ],
      "correct": 0,
      "explanation": "Weak is the opposite of strong"
    },
    {
      "question": "The plural of 'sheep' is?",
      "options": [
        "Sheepes",
        "Sheeps",
        "Sheep",
        "Shoop"
      ],
      "correct": 2,
      "explanation": "Plural of sheep is sheep"
    },
    {
      "question": "Fill in: He is accustomed ___ hard work.",
      "options": [
        "for",
        "at",
        "with",
        "to"
      ],
      "correct": 3,
      "explanation": "Accustomed to"
    },
    {
      "question": "Choose the correctly spelt word:",
      "options": [
        "Grateful",
        "Grateful",
        "Greatful",
        "Greatfull"
      ],
      "correct": 0,
      "explanation": "The correct spelling is Grateful"
    },
    {
      "question": "The past tense of 'know' is?",
      "options": [
        "Knew",
        "Knows",
        "Knowing",
        "Known"
      ],
      "correct": 0,
      "explanation": "Past tense of know is knew"
    },
    {
      "question": "Choose the word nearest in meaning to 'brave':",
      "options": [
        "Timid",
        "Afraid",
        "Fearless",
        "Cowardly"
      ],
      "correct": 2,
      "explanation": "Fearless means brave"
    },
    {
      "question": "Fill in: Each student ___ a pen.",
      "options": [
        "are",
        "has",
        "were",
        "have"
      ],
      "correct": 1,
      "explanation": "'Each' takes singular verb"
    },
    {
      "question": "The comparative of 'bad' is?",
      "options": [
        "Badder",
        "Worse",
        "Worst",
        "More bad"
      ],
      "correct": 1,
      "explanation": "Comparative of bad is worse"
    },
    {
      "question": "Choose the odd one out:",
      "options": [
        "Jump",
        "Walk",
        "Book",
        "Run"
      ],
      "correct": 2,
      "explanation": "Book is a noun; others are verbs"
    },
    {
      "question": "Fill in: We have lived here ___ 2015.",
      "options": [
        "for",
        "from",
        "in",
        "since"
      ],
      "correct": 3,
      "explanation": "Since is used with a point in time"
    },
    {
      "question": "The opposite of 'clean' is?",
      "options": [
        "Dirty",
        "Pure",
        "Neat",
        "Tidy"
      ],
      "correct": 0,
      "explanation": "Dirty is the opposite of clean"
    },
    {
      "question": "Choose the correct sentence:",
      "options": [
        "He have gone to school",
        "He has go to school",
        "He has went to school",
        "He has gone to school"
      ],
      "correct": 3,
      "explanation": "Correct form is has gone"
    },
    {
      "question": "The past participle of 'see' is?",
      "options": [
        "Sees",
        "Seen",
        "Saw",
        "Seeing"
      ],
      "correct": 1,
      "explanation": "Past participle of see is seen"
    },
    {
      "question": "Fill in: She is afraid ___ the dark.",
      "options": [
        "with",
        "by",
        "from",
        "of"
      ],
      "correct": 3,
      "explanation": "Afraid of"
    },
    {
      "question": "The synonym of 'end' is?",
      "options": [
        "Finish",
        "Open",
        "Start",
        "Begin"
      ],
      "correct": 0,
      "explanation": "Finish means end"
    },
    {
      "question": "Choose the word that rhymes with 'hat':",
      "options": [
        "Hut",
        "Cat",
        "Hot",
        "Hit"
      ],
      "correct": 1,
      "explanation": "Cat rhymes with hat"
    },
    {
      "question": "Fill in: The news ___ true.",
      "options": [
        "are",
        "have",
        "were",
        "is"
      ],
      "correct": 3,
      "explanation": "News is singular"
    },
    {
      "question": "The superlative of 'good' is?",
      "options": [
        "Better",
        "Goodest",
        "Best",
        "Most good"
      ],
      "correct": 2,
      "explanation": "Superlative of good is best"
    },
    {
      "question": "Choose the correctly punctuated sentence:",
      "options": [
        "who is there?",
        "Who is there.",
        "Who is there",
        "Who is there?"
      ],
      "correct": 3,
      "explanation": "Questions need capital and question mark"
    },
    {
      "question": "The opposite of 'young' is?",
      "options": [
        "Fresh",
        "Early",
        "New",
        "Old"
      ],
      "correct": 3,
      "explanation": "Old is the opposite of young"
    },
    {
      "question": "Fill in: He is different ___ his brother.",
      "options": [
        "from",
        "than",
        "with",
        "to"
      ],
      "correct": 0,
      "explanation": "Different from"
    },
    {
      "question": "The plural of 'deer' is?",
      "options": [
        "Deeres",
        "Deer",
        "Deers",
        "Dear"
      ],
      "correct": 1,
      "explanation": "Plural of deer is deer"
    },
    {
      "question": "Choose the word nearest in meaning to 'happy':",
      "options": [
        "Joyful",
        "Sad",
        "Angry",
        "Tired"
      ],
      "correct": 0,
      "explanation": "Joyful means happy"
    },
    {
      "question": "Fill in: This is the ___ day of my life.",
      "options": [
        "happiest",
        "happy",
        "more happy",
        "happier"
      ],
      "correct": 0,
      "explanation": "Superlative is used for the highest degree"
    },
    {
      "question": "The past tense of 'take' is?",
      "options": [
        "Took",
        "Takes",
        "Taken",
        "Taking"
      ],
      "correct": 0,
      "explanation": "Past tense of take is took"
    },
    {
      "question": "Choose the word opposite in meaning to 'happy':",
      "options": [
        "Cheerful",
        "Sad",
        "Glad",
        "Joyful"
      ],
      "correct": 1,
      "explanation": "Sad is the opposite of happy"
    },
    {
      "question": "The plural of 'fish' is?",
      "options": [
        "Fishen",
        "Fishs",
        "Fishies",
        "Fish/Fishes"
      ],
      "correct": 3,
      "explanation": "Both fish and fishes are acceptable"
    },
    {
      "question": "Fill in: He is senior ___ me by two years.",
      "options": [
        "than",
        "to",
        "with",
        "from"
      ],
      "correct": 1,
      "explanation": "Senior to"
    },
    {
      "question": "Choose the correctly spelt word:",
      "options": [
        "Occasion",
        "Ocassion",
        "Occassion",
        "Ocasion"
      ],
      "correct": 0,
      "explanation": "The correct spelling is Occasion"
    },
    {
      "question": "The past tense of 'bring' is?",
      "options": [
        "Brings",
        "Bringing",
        "Brought",
        "Bringed"
      ],
      "correct": 2,
      "explanation": "Past tense of bring is brought"
    },
    {
      "question": "Choose the word nearest in meaning to 'difficult':",
      "options": [
        "Simple",
        "Hard",
        "Easy",
        "Clear"
      ],
      "correct": 1,
      "explanation": "Hard means difficult"
    },
    {
      "question": "Fill in: One of the girls ___ absent.",
      "options": [
        "were",
        "are",
        "is",
        "have"
      ],
      "correct": 2,
      "explanation": "'One' takes singular verb"
    },
    {
      "question": "The comparative of 'little' is?",
      "options": [
        "Less",
        "More little",
        "Littler",
        "Least"
      ],
      "correct": 0,
      "explanation": "Comparative of little is less"
    },
    {
      "question": "Choose the odd one out:",
      "options": [
        "Dance",
        "Write",
        "Sing",
        "Table"
      ],
      "correct": 3,
      "explanation": "Table is a noun; others are verbs"
    },
    {
      "question": "Fill in: She has been here ___ Monday.",
      "options": [
        "in",
        "for",
        "since",
        "from"
      ],
      "correct": 2,
      "explanation": "Since Monday"
    },
    {
      "question": "The opposite of 'success' is?",
      "options": [
        "Achievement",
        "Win",
        "Failure",
        "Victory"
      ],
      "correct": 2,
      "explanation": "Failure is the opposite of success"
    },
    {
      "question": "Choose the correct sentence:",
      "options": [
        "They is playing football",
        "They are playing football",
        "They be playing football",
        "They am playing football"
      ],
      "correct": 1,
      "explanation": "Plural subject takes 'are'"
    },
    {
      "question": "The past participle of 'write' is?",
      "options": [
        "Writing",
        "Wrote",
        "Writes",
        "Written"
      ],
      "correct": 3,
      "explanation": "Past participle of write is written"
    },
    {
      "question": "Fill in: He is good ___ English.",
      "options": [
        "at",
        "for",
        "in",
        "on"
      ],
      "correct": 0,
      "explanation": "Good at"
    },
    {
      "question": "The synonym of 'start' is?",
      "options": [
        "Begin",
        "Stop",
        "Finish",
        "End"
      ],
      "correct": 0,
      "explanation": "Begin means start"
    },
    {
      "question": "Choose the word that rhymes with 'light':",
      "options": [
        "Lot",
        "Night",
        "Late",
        "Lit"
      ],
      "correct": 1,
      "explanation": "Night rhymes with light"
    },
    {
      "question": "Fill in: Mathematics ___ easy for her.",
      "options": [
        "were",
        "are",
        "have",
        "is"
      ],
      "correct": 3,
      "explanation": "Mathematics is singular"
    },
    {
      "question": "The superlative of 'bad' is?",
      "options": [
        "Most bad",
        "Worst",
        "Badder",
        "Worse"
      ],
      "correct": 1,
      "explanation": "Superlative of bad is worst"
    },
    {
      "question": "Choose the correctly punctuated sentence:",
      "options": [
        "where is my book?",
        "Where is my book.",
        "Where is my book",
        "Where is my book?"
      ],
      "correct": 3,
      "explanation": "Questions need capital and question mark"
    },
    {
      "question": "The opposite of 'early' is?",
      "options": [
        "Late",
        "Soon",
        "Fast",
        "Quick"
      ],
      "correct": 0,
      "explanation": "Late is the opposite of early"
    },
    {
      "question": "Fill in: I prefer coffee ___ tea.",
      "options": [
        "than",
        "from",
        "to",
        "for"
      ],
      "correct": 2,
      "explanation": "Prefer... to"
    },
    {
      "question": "The plural of 'ox' is?",
      "options": [
        "Oxens",
        "Oxen",
        "Oxes",
        "Ox"
      ],
      "correct": 1,
      "explanation": "Plural of ox is oxen"
    },
    {
      "question": "Choose the word nearest in meaning to 'tiny':",
      "options": [
        "Large",
        "Big",
        "Huge",
        "Small"
      ],
      "correct": 3,
      "explanation": "Tiny means very small"
    },
    {
      "question": "Fill in: She is the ___ girl in the class.",
      "options": [
        "tallest",
        "tall",
        "more tall",
        "taller"
      ],
      "correct": 0,
      "explanation": "Superlative for more than two"
    },
    {
      "question": "The past tense of 'buy' is?",
      "options": [
        "Buying",
        "Buyed",
        "Bought",
        "Buys"
      ],
      "correct": 2,
      "explanation": "Past tense of buy is bought"
    }
  ],
  "eco": [
    {
      "question": "Economics is best defined as the study of?",
      "options": [
        "Trade only",
        "Government only",
        "Money only",
        "How man uses scarce resources to satisfy unlimited wants"
      ],
      "correct": 3,
      "explanation": "Economics studies the allocation of scarce resources"
    },
    {
      "question": "The basic economic problem is?",
      "options": [
        "Unemployment",
        "Inflation",
        "Poverty",
        "Scarcity"
      ],
      "correct": 3,
      "explanation": "Scarcity is the basic economic problem"
    },
    {
      "question": "Opportunity cost is?",
      "options": [
        "The next best alternative forgone",
        "Money spent only",
        "The cost of raw materials",
        "The total cost of production"
      ],
      "correct": 0,
      "explanation": "Opportunity cost is the value of the next best alternative"
    },
    {
      "question": "Which of these is a factor of production?",
      "options": [
        "Market",
        "Money",
        "Profit",
        "Land"
      ],
      "correct": 3,
      "explanation": "Land is a factor of production"
    },
    {
      "question": "The reward for labour is?",
      "options": [
        "Interest",
        "Profit",
        "Rent",
        "Wages"
      ],
      "correct": 3,
      "explanation": "Labour is rewarded with wages"
    },
    {
      "question": "Demand is?",
      "options": [
        "Willingness and ability to buy",
        "Ability only",
        "Willingness only",
        "Need only"
      ],
      "correct": 0,
      "explanation": "Demand requires both willingness and ability"
    },
    {
      "question": "The law of demand states that?",
      "options": [
        "Demand is always constant",
        "As price rises, quantity demanded rises",
        "As price rises, quantity demanded falls",
        "Price and demand are not related"
      ],
      "correct": 2,
      "explanation": "Higher price leads to lower quantity demanded"
    },
    {
      "question": "Supply is?",
      "options": [
        "Ability only",
        "Willingness and ability to sell",
        "Production only",
        "Willingness only"
      ],
      "correct": 1,
      "explanation": "Supply requires willingness and ability to sell"
    },
    {
      "question": "Which of these is a type of economic system?",
      "options": [
        "Capitalism",
        "Recession",
        "Deflation",
        "Inflation"
      ],
      "correct": 0,
      "explanation": "Capitalism is an economic system"
    },
    {
      "question": "The market where buyers and sellers meet is?",
      "options": [
        "School",
        "Market",
        "Bank",
        "Factory"
      ],
      "correct": 1,
      "explanation": "A market is where buyers and sellers interact"
    },
    {
      "question": "Inflation is?",
      "options": [
        "Fall in prices",
        "Increase in production",
        "Persistent rise in general price level",
        "Decrease in money supply"
      ],
      "correct": 2,
      "explanation": "Inflation is a sustained rise in prices"
    },
    {
      "question": "Which of these is a direct tax?",
      "options": [
        "Customs duty",
        "Income tax",
        "Excise duty",
        "VAT"
      ],
      "correct": 1,
      "explanation": "Income tax is a direct tax"
    },
    {
      "question": "The central bank of Nigeria is?",
      "options": [
        "GTBank",
        "Central Bank of Nigeria (CBN)",
        "First Bank",
        "Zenith Bank"
      ],
      "correct": 1,
      "explanation": "CBN is Nigeria's central bank"
    },
    {
      "question": "Unemployment means?",
      "options": [
        "Children not working",
        "Retired people",
        "People willing and able to work but without jobs",
        "People who do not want to work"
      ],
      "correct": 2,
      "explanation": "Unemployment is lack of jobs for those willing to work"
    },
    {
      "question": "Which of these is a function of money?",
      "options": [
        "Source of inflation only",
        "Medium of exchange",
        "Measure of population",
        "Cause of poverty"
      ],
      "correct": 1,
      "explanation": "Money serves as a medium of exchange"
    },
    {
      "question": "The production of goods in large quantities is?",
      "options": [
        "Mass production",
        "Small scale only",
        "Hand production",
        "Subsistence production"
      ],
      "correct": 0,
      "explanation": "Mass production is large scale"
    },
    {
      "question": "Which of these is a source of government revenue?",
      "options": [
        "Inflation",
        "Poverty",
        "Taxation",
        "Unemployment"
      ],
      "correct": 2,
      "explanation": "Taxation is a major source of revenue"
    },
    {
      "question": "The price at which demand equals supply is?",
      "options": [
        "Minimum price",
        "Maximum price",
        "Equilibrium price",
        "Fixed price"
      ],
      "correct": 2,
      "explanation": "Equilibrium is where demand equals supply"
    },
    {
      "question": "Which of these is a characteristic of perfect competition?",
      "options": [
        "No freedom of entry",
        "One seller only",
        "Government control only",
        "Many buyers and sellers"
      ],
      "correct": 3,
      "explanation": "Perfect competition has many buyers and sellers"
    },
    {
      "question": "National income is?",
      "options": [
        "Income of a company",
        "Income of one person",
        "Income of a bank",
        "Total income earned by a country"
      ],
      "correct": 3,
      "explanation": "National income is the total income of a country"
    },
    {
      "question": "Which of these is a barrier to international trade?",
      "options": [
        "No restrictions",
        "Tariff",
        "Open market",
        "Free trade"
      ],
      "correct": 1,
      "explanation": "Tariffs restrict trade"
    },
    {
      "question": "The reward for capital is?",
      "options": [
        "Profit",
        "Wages",
        "Interest",
        "Rent"
      ],
      "correct": 2,
      "explanation": "Capital is rewarded with interest"
    },
    {
      "question": "Which of these is a type of unemployment?",
      "options": [
        "Self employment only",
        "Over employment",
        "Structural unemployment",
        "Full employment"
      ],
      "correct": 2,
      "explanation": "Structural is a type of unemployment"
    },
    {
      "question": "The budget is?",
      "options": [
        "A bank statement",
        "Only expenditure",
        "Only income",
        "Estimate of government income and expenditure"
      ],
      "correct": 3,
      "explanation": "A budget estimates income and expenditure"
    },
    {
      "question": "Which of these is a function of the Central Bank?",
      "options": [
        "Issuing currency",
        "Teaching students",
        "Selling goods",
        "Giving loans to individuals only"
      ],
      "correct": 0,
      "explanation": "Central Bank issues currency"
    },
    {
      "question": "Which of these is a characteristic of land as a factor of production?",
      "options": [
        "It is mobile",
        "It can be increased easily",
        "It is man-made",
        "It is a free gift of nature"
      ],
      "correct": 3,
      "explanation": "Land is a free gift of nature"
    },
    {
      "question": "The reward for entrepreneurship is?",
      "options": [
        "Rent",
        "Wages",
        "Interest",
        "Profit"
      ],
      "correct": 3,
      "explanation": "Entrepreneurs earn profit"
    },
    {
      "question": "A normal good is one whose demand?",
      "options": [
        "Is not related to income",
        "Decreases as income increases",
        "Increases as income increases",
        "Remains constant"
      ],
      "correct": 2,
      "explanation": "Demand for normal goods rises with income"
    },
    {
      "question": "Which of these is a cause of inflation?",
      "options": [
        "Fall in demand",
        "Decrease in money supply",
        "Increase in money supply",
        "Increase in production only"
      ],
      "correct": 2,
      "explanation": "Too much money can cause inflation"
    },
    {
      "question": "The Central Bank controls money supply through?",
      "options": [
        "Trade policy only",
        "Fiscal policy only",
        "Monetary policy",
        "Foreign policy"
      ],
      "correct": 2,
      "explanation": "Monetary policy controls money supply"
    },
    {
      "question": "Which of these is a type of market structure?",
      "options": [
        "Inflation",
        "Deflation",
        "Unemployment",
        "Monopoly"
      ],
      "correct": 3,
      "explanation": "Monopoly is a market structure"
    },
    {
      "question": "In a monopoly, there is?",
      "options": [
        "Many sellers",
        "No seller",
        "Two sellers only",
        "One seller"
      ],
      "correct": 3,
      "explanation": "Monopoly has one seller"
    },
    {
      "question": "Which of these is a function of price?",
      "options": [
        "Causing inflation only",
        "Rationing scarce goods",
        "Reducing production",
        "Creating unemployment"
      ],
      "correct": 1,
      "explanation": "Price helps ration scarce resources"
    },
    {
      "question": "The total value of goods and services produced in a country is?",
      "options": [
        "Gross Domestic Product (GDP)",
        "Inflation rate",
        "National debt",
        "Budget deficit"
      ],
      "correct": 0,
      "explanation": "GDP measures total production"
    },
    {
      "question": "Which of these is an indirect tax?",
      "options": [
        "Income tax",
        "Capital gains tax",
        "Company tax",
        "Value Added Tax (VAT)"
      ],
      "correct": 3,
      "explanation": "VAT is an indirect tax"
    },
    {
      "question": "A progressive tax is one where?",
      "options": [
        "No one pays tax",
        "Lower income earners pay more",
        "Everyone pays the same amount",
        "Higher income earners pay higher percentage"
      ],
      "correct": 3,
      "explanation": "Progressive tax rises with income"
    },
    {
      "question": "Which of these is a problem of unemployment?",
      "options": [
        "Poverty",
        "Higher standard of living",
        "Increase in production",
        "Economic growth"
      ],
      "correct": 0,
      "explanation": "Unemployment can lead to poverty"
    },
    {
      "question": "Money serves as a?",
      "options": [
        "Cause of poverty",
        "Measure of population",
        "Source of inflation only",
        "Store of value"
      ],
      "correct": 3,
      "explanation": "Money stores value"
    },
    {
      "question": "Which of these is a source of public revenue?",
      "options": [
        "Unemployment benefit",
        "Subsidy",
        "Royalties",
        "Public debt only"
      ],
      "correct": 2,
      "explanation": "Royalties are a source of revenue"
    },
    {
      "question": "The law of supply states that?",
      "options": [
        "As price rises, quantity supplied rises",
        "As price rises, quantity supplied falls",
        "Supply is always constant",
        "Price and supply are not related"
      ],
      "correct": 0,
      "explanation": "Higher price encourages more supply"
    },
    {
      "question": "Which of these is a characteristic of money?",
      "options": [
        "Indivisibility",
        "Bulkiness",
        "Durability",
        "Perishability"
      ],
      "correct": 2,
      "explanation": "Money should be durable"
    },
    {
      "question": "A budget deficit occurs when?",
      "options": [
        "Revenue exceeds expenditure",
        "Expenditure exceeds revenue",
        "There is no budget",
        "Revenue equals expenditure"
      ],
      "correct": 1,
      "explanation": "Deficit means spending more than income"
    },
    {
      "question": "Which of these is a type of economic activity?",
      "options": [
        "Deflation",
        "Inflation",
        "Primary production",
        "Recession"
      ],
      "correct": 2,
      "explanation": "Primary production is an economic activity"
    },
    {
      "question": "The concept of scale of preference is related to?",
      "options": [
        "Money only",
        "Unemployment",
        "Choice",
        "Inflation"
      ],
      "correct": 2,
      "explanation": "Scale of preference helps in making choices"
    },
    {
      "question": "Which of these is a function of commercial banks?",
      "options": [
        "Making laws",
        "Controlling inflation only",
        "Accepting deposits",
        "Issuing currency"
      ],
      "correct": 2,
      "explanation": "Commercial banks accept deposits"
    },
    {
      "question": "International trade is based on?",
      "options": [
        "Inflation only",
        "Unemployment",
        "Absolute poverty",
        "Comparative advantage"
      ],
      "correct": 3,
      "explanation": "Comparative advantage encourages trade"
    },
    {
      "question": "Which of these is a barrier to economic development?",
      "options": [
        "Abundant resources",
        "High education",
        "Lack of capital",
        "Good infrastructure"
      ],
      "correct": 2,
      "explanation": "Lack of capital hinders development"
    },
    {
      "question": "The population of a country is?",
      "options": [
        "The total number of workers only",
        "The total number of children only",
        "The total number of people",
        "The total number of old people only"
      ],
      "correct": 2,
      "explanation": "Population is the total number of people"
    },
    {
      "question": "Which of these is a measure of economic growth?",
      "options": [
        "Increase in inflation",
        "Increase in poverty",
        "Increase in GDP",
        "Increase in unemployment"
      ],
      "correct": 2,
      "explanation": "Rising GDP indicates growth"
    },
    {
      "question": "A mixed economy has?",
      "options": [
        "Only private sector",
        "No economic activity",
        "Both private and public sectors",
        "Only public sector"
      ],
      "correct": 2,
      "explanation": "Mixed economy combines both sectors"
    },
    {
      "question": "Which of these is a feature of free market economy?",
      "options": [
        "Private ownership of resources",
        "Fixed prices by government only",
        "Government ownership of all resources",
        "No competition"
      ],
      "correct": 0,
      "explanation": "Free market has private ownership"
    },
    {
      "question": "The basic needs of man are?",
      "options": [
        "Cars and luxury goods",
        "Only entertainment",
        "Food, clothing and shelter",
        "Only education"
      ],
      "correct": 2,
      "explanation": "Basic needs are food, clothing and shelter"
    },
    {
      "question": "Which of these is a cause of unemployment?",
      "options": [
        "Economic boom only",
        "Full employment",
        "Lack of skills",
        "High demand for labour"
      ],
      "correct": 2,
      "explanation": "Lack of skills can cause unemployment"
    },
    {
      "question": "A progressive tax system is designed to?",
      "options": [
        "Eliminate all taxes",
        "Increase inequality",
        "Tax only the poor",
        "Reduce income inequality"
      ],
      "correct": 3,
      "explanation": "Progressive tax reduces inequality"
    },
    {
      "question": "Which of these is a function of money?",
      "options": [
        "Source of poverty",
        "Unit of account",
        "Cause of inflation only",
        "Measure of population"
      ],
      "correct": 1,
      "explanation": "Money serves as a unit of account"
    },
    {
      "question": "The total market value of all final goods and services produced in a country is?",
      "options": [
        "Budget",
        "National debt",
        "GNP only",
        "GDP"
      ],
      "correct": 3,
      "explanation": "GDP measures total production"
    },
    {
      "question": "Which of these is a type of inflation?",
      "options": [
        "Demand-pull inflation",
        "Full employment",
        "Economic growth",
        "Price stability"
      ],
      "correct": 0,
      "explanation": "Demand-pull is a type of inflation"
    },
    {
      "question": "In a monopoly, the firm is?",
      "options": [
        "A price taker",
        "Unable to set price",
        "Forced to accept market price",
        "A price maker"
      ],
      "correct": 3,
      "explanation": "Monopolist is a price maker"
    },
    {
      "question": "Which of these is a source of government borrowing?",
      "options": [
        "Foreign aid only",
        "Bonds",
        "Printing money only",
        "Taxation only"
      ],
      "correct": 1,
      "explanation": "Government can borrow through bonds"
    },
    {
      "question": "The law of diminishing returns states that?",
      "options": [
        "Additional output eventually falls as more variable input is added",
        "Input has no effect",
        "Output never changes",
        "Output always increases"
      ],
      "correct": 0,
      "explanation": "Diminishing returns set in eventually"
    },
    {
      "question": "Which of these is a characteristic of perfect competition?",
      "options": [
        "Price control by one firm",
        "Barriers to entry",
        "Free entry and exit",
        "One seller"
      ],
      "correct": 2,
      "explanation": "Perfect competition allows free entry"
    },
    {
      "question": "National income is useful for?",
      "options": [
        "Measuring rainfall",
        "Measuring economic performance",
        "Counting population only",
        "Counting schools"
      ],
      "correct": 1,
      "explanation": "National income measures economic performance"
    },
    {
      "question": "Which of these is a trade barrier?",
      "options": [
        "Free trade agreement",
        "Quota",
        "Open market",
        "No restriction"
      ],
      "correct": 1,
      "explanation": "Quota limits imports"
    },
    {
      "question": "The reward for land is?",
      "options": [
        "Interest",
        "Rent",
        "Wages",
        "Profit"
      ],
      "correct": 1,
      "explanation": "Land earns rent"
    },
    {
      "question": "Which of these is a type of unemployment?",
      "options": [
        "Self employment only",
        "Frictional unemployment",
        "Over employment",
        "Full employment"
      ],
      "correct": 1,
      "explanation": "Frictional is a type of unemployment"
    },
    {
      "question": "A surplus budget means?",
      "options": [
        "No revenue",
        "Expenditure exceeds revenue",
        "Revenue equals expenditure",
        "Revenue exceeds expenditure"
      ],
      "correct": 3,
      "explanation": "Surplus means more revenue than spending"
    },
    {
      "question": "Which of these is a function of the Central Bank?",
      "options": [
        "Running schools",
        "Giving personal loans only",
        "Banker to the government",
        "Selling goods"
      ],
      "correct": 2,
      "explanation": "Central Bank is banker to government"
    },
    {
      "question": "Division of labour leads to?",
      "options": [
        "Decreased output",
        "No specialisation",
        "Lower quality always",
        "Increased efficiency"
      ],
      "correct": 3,
      "explanation": "Division of labour increases efficiency"
    },
    {
      "question": "Which of these is a problem of rapid population growth?",
      "options": [
        "Increase in resources",
        "Pressure on resources",
        "Higher standard of living automatically",
        "No effect"
      ],
      "correct": 1,
      "explanation": "Rapid growth pressures resources"
    },
    {
      "question": "The concept of opportunity cost is important in?",
      "options": [
        "Avoiding all choices",
        "Ignoring alternatives",
        "Decision making",
        "Random selection"
      ],
      "correct": 2,
      "explanation": "Opportunity cost helps decision making"
    },
    {
      "question": "Which of these is a feature of capitalism?",
      "options": [
        "No private property",
        "No competition",
        "Profit motive",
        "Government ownership of all"
      ],
      "correct": 2,
      "explanation": "Capitalism is driven by profit motive"
    },
    {
      "question": "Inflation benefits?",
      "options": [
        "Savers always",
        "Fixed income earners always",
        "Debtors",
        "Creditors always"
      ],
      "correct": 2,
      "explanation": "Debtors benefit as real value of debt falls"
    },
    {
      "question": "Which of these is a measure to control inflation?",
      "options": [
        "Decrease in interest rate",
        "Increase in money supply",
        "Reduction in taxes always",
        "Increase in interest rate"
      ],
      "correct": 3,
      "explanation": "Higher interest rates can reduce inflation"
    },
    {
      "question": "A country’s balance of trade is?",
      "options": [
        "Total population",
        "Only exports",
        "Only imports",
        "Difference between exports and imports of goods"
      ],
      "correct": 3,
      "explanation": "Balance of trade is exports minus imports of goods"
    },
    {
      "question": "Which of these is a factor that affects demand?",
      "options": [
        "Price of the commodity",
        "Name of the seller only",
        "Day of the week only",
        "Colour of the sky"
      ],
      "correct": 0,
      "explanation": "Price affects demand"
    },
    {
      "question": "Which of these is a factor that affects demand?",
      "options": [
        "Price of the commodity",
        "Name of the shop",
        "Height of the buyer",
        "Colour of the seller"
      ],
      "correct": 0,
      "explanation": "Price is a major determinant of demand"
    },
    {
      "question": "A decrease in supply will lead to?",
      "options": [
        "No change in price",
        "Lower price",
        "Higher price",
        "Increase in demand only"
      ],
      "correct": 2,
      "explanation": "Less supply tends to raise price"
    },
    {
      "question": "Which of these is a type of cost?",
      "options": [
        "Market cost",
        "Supply cost",
        "Fixed cost",
        "Demand cost"
      ],
      "correct": 2,
      "explanation": "Fixed cost does not change with output"
    },
    {
      "question": "Variable cost changes with?",
      "options": [
        "Government only",
        "Level of output",
        "Weather only",
        "Time only"
      ],
      "correct": 1,
      "explanation": "Variable cost changes with output"
    },
    {
      "question": "Which of these is a function of an entrepreneur?",
      "options": [
        "Buying only",
        "Selling only",
        "Risk bearing",
        "Paying taxes only"
      ],
      "correct": 2,
      "explanation": "Entrepreneurs bear risks"
    },
    {
      "question": "The market for labour is?",
      "options": [
        "Capital market only",
        "Money market only",
        "Product market only",
        "Factor market"
      ],
      "correct": 3,
      "explanation": "Labour is a factor of production"
    },
    {
      "question": "Which of these is a cause of unemployment?",
      "options": [
        "Lack of skills",
        "Economic boom only",
        "Too many jobs",
        "High demand for labour"
      ],
      "correct": 0,
      "explanation": "Lack of skills can cause unemployment"
    },
    {
      "question": "Inflation benefits?",
      "options": [
        "Fixed income earners",
        "Creditors",
        "Savers only",
        "Debtors"
      ],
      "correct": 3,
      "explanation": "Debtors benefit because they repay with less valuable money"
    },
    {
      "question": "Which of these is a tool of fiscal policy?",
      "options": [
        "Interest rate only",
        "Taxation",
        "Reserve requirement only",
        "Open market operation only"
      ],
      "correct": 1,
      "explanation": "Taxation is a fiscal policy tool"
    },
    {
      "question": "The total amount of money in circulation is?",
      "options": [
        "Money supply",
        "Budget",
        "Money demand",
        "National income"
      ],
      "correct": 0,
      "explanation": "Money supply is the total money in circulation"
    },
    {
      "question": "Which of these is a characteristic of a perfect market?",
      "options": [
        "One seller only",
        "Free entry and exit",
        "Government control of price",
        "No knowledge of market"
      ],
      "correct": 1,
      "explanation": "Perfect market allows free entry and exit"
    },
    {
      "question": "A public good is?",
      "options": [
        "Only for the rich",
        "Sold in the market only",
        "Non-excludable and non-rivalrous",
        "Only for the government"
      ],
      "correct": 2,
      "explanation": "Public goods are non-excludable and non-rivalrous"
    },
    {
      "question": "Which of these is a source of economic growth?",
      "options": [
        "Increase in capital",
        "Increase in unemployment",
        "Decrease in investment",
        "Increase in inflation"
      ],
      "correct": 0,
      "explanation": "More capital aids growth"
    },
    {
      "question": "The population that is working is?",
      "options": [
        "Labour force",
        "Children only",
        "Dependants only",
        "Retired people only"
      ],
      "correct": 0,
      "explanation": "Labour force is the working population"
    },
    {
      "question": "Which of these is a type of inflation?",
      "options": [
        "Supply-pull only",
        "Demand-pull inflation",
        "Demand-push only",
        "Cost-pull only"
      ],
      "correct": 1,
      "explanation": "Demand-pull is a type of inflation"
    },
    {
      "question": "Terms of trade refer to?",
      "options": [
        "Only import volume",
        "Balance of payment only",
        "Only export volume",
        "Ratio of export prices to import prices"
      ],
      "correct": 3,
      "explanation": "Terms of trade compare export and import prices"
    },
    {
      "question": "Which of these is a benefit of international trade?",
      "options": [
        "Reduction in quality",
        "Access to wider variety of goods",
        "Increase in unemployment only",
        "Isolation of countries"
      ],
      "correct": 1,
      "explanation": "Trade gives access to more goods"
    },
    {
      "question": "A progressive tax system is designed to?",
      "options": [
        "Tax only the poor",
        "Tax nobody",
        "Reduce income inequality",
        "Increase inequality"
      ],
      "correct": 2,
      "explanation": "Progressive tax reduces inequality"
    },
    {
      "question": "Which of these is a function of money?",
      "options": [
        "Cause of inflation only",
        "Source of poverty",
        "Unit of account",
        "Measure of population"
      ],
      "correct": 2,
      "explanation": "Money serves as a unit of account"
    },
    {
      "question": "The Central Bank is the?",
      "options": [
        "Merchant bank only",
        "Microfinance bank only",
        "Bankers' bank",
        "Commercial bank only"
      ],
      "correct": 2,
      "explanation": "Central Bank is the bankers' bank"
    },
    {
      "question": "Which of these is a type of unemployment?",
      "options": [
        "Self employment only",
        "Over employment",
        "Frictional unemployment",
        "Full employment"
      ],
      "correct": 2,
      "explanation": "Frictional is a type of unemployment"
    },
    {
      "question": "Economic development includes?",
      "options": [
        "Only increase in population",
        "Only increase in prices",
        "Only increase in money supply",
        "Improvement in standard of living"
      ],
      "correct": 3,
      "explanation": "Development improves living standards"
    },
    {
      "question": "Which of these is a barrier to trade?",
      "options": [
        "Free trade agreement",
        "No restriction",
        "Quota",
        "Open market"
      ],
      "correct": 2,
      "explanation": "Quota limits the quantity of imports"
    },
    {
      "question": "The reward for land is?",
      "options": [
        "Interest",
        "Rent",
        "Wages",
        "Profit"
      ],
      "correct": 1,
      "explanation": "Land earns rent"
    },
    {
      "question": "Which of these is a feature of capitalism?",
      "options": [
        "Central planning only",
        "Private ownership of resources",
        "Government ownership of all resources",
        "No private property"
      ],
      "correct": 1,
      "explanation": "Capitalism features private ownership"
    },
    {
      "question": "Which of these is a determinant of supply?",
      "options": [
        "Name of the seller",
        "Colour of the product only",
        "Height of the factory",
        "Cost of production"
      ],
      "correct": 3,
      "explanation": "Cost of production affects supply"
    },
    {
      "question": "An increase in demand with supply constant leads to?",
      "options": [
        "Higher equilibrium price",
        "Decrease in quantity",
        "No change in price",
        "Lower equilibrium price"
      ],
      "correct": 0,
      "explanation": "Higher demand raises price"
    },
    {
      "question": "Which of these is a fixed cost?",
      "options": [
        "Raw materials",
        "Rent of factory",
        "Electricity for production",
        "Wages of casual workers"
      ],
      "correct": 1,
      "explanation": "Rent is fixed in the short run"
    },
    {
      "question": "Marginal cost is?",
      "options": [
        "Average cost",
        "Fixed cost only",
        "Total cost",
        "Additional cost of producing one more unit"
      ],
      "correct": 3,
      "explanation": "Marginal cost is the cost of one extra unit"
    },
    {
      "question": "Which of these is a feature of monopoly?",
      "options": [
        "Price taker",
        "Many sellers",
        "Free entry",
        "Price maker"
      ],
      "correct": 3,
      "explanation": "Monopolist is a price maker"
    },
    {
      "question": "The demand for labour is?",
      "options": [
        "Composite demand only",
        "Direct demand only",
        "Derived demand",
        "Joint demand only"
      ],
      "correct": 2,
      "explanation": "Labour is demanded for what it produces"
    },
    {
      "question": "Which of these is a type of inflation?",
      "options": [
        "Wage-pull only",
        "Demand-push only",
        "Cost-push inflation",
        "Supply-pull only"
      ],
      "correct": 2,
      "explanation": "Cost-push is a type of inflation"
    },
    {
      "question": "Fiscal policy involves?",
      "options": [
        "Only foreign exchange",
        "Only interest rates",
        "Only money supply",
        "Government spending and taxation"
      ],
      "correct": 3,
      "explanation": "Fiscal policy uses spending and taxes"
    },
    {
      "question": "Which of these is a function of the Central Bank?",
      "options": [
        "Giving personal loans only",
        "Lender of last resort",
        "Selling retail goods",
        "Teaching in schools"
      ],
      "correct": 1,
      "explanation": "Central Bank is lender of last resort"
    },
    {
      "question": "Gross National Product (GNP) includes?",
      "options": [
        "Only GDP",
        "GDP plus net income from abroad",
        "Only domestic production",
        "Only government spending"
      ],
      "correct": 1,
      "explanation": "GNP = GDP + net factor income from abroad"
    },
    {
      "question": "Which of these is a progressive tax?",
      "options": [
        "Personal income tax",
        "VAT",
        "Customs duty",
        "Excise duty"
      ],
      "correct": 0,
      "explanation": "Income tax is usually progressive"
    },
    {
      "question": "Structural unemployment is caused by?",
      "options": [
        "Friction in job search only",
        "Cyclical downturn only",
        "Changes in the structure of the economy",
        "Seasonal factors only"
      ],
      "correct": 2,
      "explanation": "Structural changes cause this type"
    },
    {
      "question": "Which of these is a characteristic of money?",
      "options": [
        "Indivisibility",
        "Bulkiness",
        "Portability",
        "Perishability"
      ],
      "correct": 2,
      "explanation": "Money should be portable"
    },
    {
      "question": "A budget surplus occurs when?",
      "options": [
        "Revenue equals expenditure",
        "Revenue exceeds expenditure",
        "There is no revenue",
        "Expenditure exceeds revenue"
      ],
      "correct": 1,
      "explanation": "Surplus means revenue > expenditure"
    },
    {
      "question": "Which of these is a primary economic activity?",
      "options": [
        "Banking",
        "Agriculture",
        "Manufacturing",
        "Teaching"
      ],
      "correct": 1,
      "explanation": "Agriculture is primary"
    },
    {
      "question": "The concept of opportunity cost arises because of?",
      "options": [
        "Scarcity",
        "Unlimited resources",
        "Abundance",
        "Free goods"
      ],
      "correct": 0,
      "explanation": "Scarcity forces choice and opportunity cost"
    },
    {
      "question": "Which of these is a function of commercial banks?",
      "options": [
        "Money creation through credit",
        "Making government laws",
        "Controlling inflation directly",
        "Issuing currency notes"
      ],
      "correct": 0,
      "explanation": "Banks create credit"
    },
    {
      "question": "Comparative advantage theory was developed by?",
      "options": [
        "John Maynard Keynes",
        "Karl Marx",
        "Adam Smith only",
        "David Ricardo"
      ],
      "correct": 3,
      "explanation": "Ricardo developed comparative advantage"
    },
    {
      "question": "Which of these hinders economic development?",
      "options": [
        "High level of education",
        "Low level of technology",
        "Good infrastructure",
        "Political stability"
      ],
      "correct": 1,
      "explanation": "Low technology hinders development"
    },
    {
      "question": "The dependency ratio is?",
      "options": [
        "Ratio of children to adults only",
        "Ratio of workers to total population only",
        "Ratio of old to young only",
        "Ratio of dependants to working population"
      ],
      "correct": 3,
      "explanation": "Dependency ratio measures dependants relative to workers"
    },
    {
      "question": "Which of these is a measure to control inflation?",
      "options": [
        "Increasing money supply",
        "Reducing taxes always",
        "Increasing government spending always",
        "Increasing interest rates"
      ],
      "correct": 3,
      "explanation": "Higher interest rates can reduce inflation"
    },
    {
      "question": "Balance of trade is?",
      "options": [
        "Only services",
        "Only capital account",
        "Only current transfers",
        "Difference between visible exports and imports"
      ],
      "correct": 3,
      "explanation": "Balance of trade covers visible goods"
    },
    {
      "question": "Which of these is a feature of a mixed economy?",
      "options": [
        "Only private sector",
        "Co-existence of private and public sectors",
        "No economic planning",
        "Only public sector"
      ],
      "correct": 1,
      "explanation": "Mixed economy has both sectors"
    },
    {
      "question": "The reward for organisation is?",
      "options": [
        "Interest",
        "Wages",
        "Rent",
        "Profit"
      ],
      "correct": 3,
      "explanation": "Organisation (entrepreneurship) earns profit"
    },
    {
      "question": "Which of these is a cause of demand-pull inflation?",
      "options": [
        "Excess aggregate demand",
        "Decrease in money supply",
        "Increase in cost of production only",
        "Fall in wages"
      ],
      "correct": 0,
      "explanation": "Too much demand pulls prices up"
    },
    {
      "question": "Liquidity preference theory is associated with?",
      "options": [
        "Ricardo",
        "Malthus",
        "Keynes",
        "Adam Smith"
      ],
      "correct": 2,
      "explanation": "Keynes developed liquidity preference theory"
    },
    {
      "question": "Which of these is a direct tax?",
      "options": [
        "Excise duty",
        "VAT",
        "Company income tax",
        "Import duty"
      ],
      "correct": 2,
      "explanation": "Company tax is direct"
    },
    {
      "question": "Cyclical unemployment is associated with?",
      "options": [
        "Trade cycles",
        "Seasonal changes only",
        "Friction only",
        "Technological change only"
      ],
      "correct": 0,
      "explanation": "Cyclical unemployment follows the business cycle"
    },
    {
      "question": "Which of these is a function of money?",
      "options": [
        "Cause of unemployment",
        "Standard of deferred payment",
        "Source of inflation only",
        "Measure of land size"
      ],
      "correct": 1,
      "explanation": "Money allows deferred payments"
    },
    {
      "question": "Public debt is?",
      "options": [
        "Debt owed by the government",
        "Debt owed by companies only",
        "Debt owed by individuals only",
        "Private debt only"
      ],
      "correct": 0,
      "explanation": "Public debt is government debt"
    },
    {
      "question": "Which of these is a secondary economic activity?",
      "options": [
        "Manufacturing",
        "Agriculture",
        "Fishing",
        "Mining"
      ],
      "correct": 0,
      "explanation": "Manufacturing is secondary"
    },
    {
      "question": "The production possibility curve illustrates?",
      "options": [
        "Only unemployment",
        "Opportunity cost and scarcity",
        "Only inflation",
        "Only money supply"
      ],
      "correct": 1,
      "explanation": "PPC shows trade-offs due to scarcity"
    },
    {
      "question": "Which of these is a credit instrument?",
      "options": [
        "Waybill only",
        "Invoice only",
        "Receipt only",
        "Bill of exchange"
      ],
      "correct": 3,
      "explanation": "Bill of exchange is a credit instrument"
    },
    {
      "question": "Absolute advantage theory is associated with?",
      "options": [
        "Marx",
        "Keynes",
        "David Ricardo",
        "Adam Smith"
      ],
      "correct": 3,
      "explanation": "Adam Smith developed absolute advantage"
    },
    {
      "question": "Which of these promotes economic development?",
      "options": [
        "Political instability",
        "High illiteracy",
        "Investment in education",
        "Poor health facilities"
      ],
      "correct": 2,
      "explanation": "Education aids development"
    },
    {
      "question": "The working population is also called?",
      "options": [
        "Labour force",
        "Dependent population",
        "Inactive population",
        "Total population"
      ],
      "correct": 0,
      "explanation": "Labour force is the working population"
    },
    {
      "question": "Which of these is a contractionary monetary policy?",
      "options": [
        "Reducing reserve ratio",
        "Raising the bank rate",
        "Buying securities",
        "Lowering the bank rate"
      ],
      "correct": 1,
      "explanation": "Higher bank rate is contractionary"
    },
    {
      "question": "Terms of trade improve when?",
      "options": [
        "Volume of trade falls",
        "Export prices rise relative to import prices",
        "Both remain constant",
        "Import prices rise relative to export prices"
      ],
      "correct": 1,
      "explanation": "Better terms when exports fetch more"
    },
    {
      "question": "Which of these is a feature of socialism?",
      "options": [
        "No government role",
        "Public ownership of major resources",
        "Complete free market only",
        "Private ownership of all resources"
      ],
      "correct": 1,
      "explanation": "Socialism features public ownership"
    },
    {
      "question": "The incidence of a tax refers to?",
      "options": [
        "The tax base only",
        "Who collects the tax",
        "The tax rate only",
        "Who finally bears the tax burden"
      ],
      "correct": 3,
      "explanation": "Incidence is the final burden"
    },
    {
      "question": "Which of these is a type of market?",
      "options": [
        "Oligopoly",
        "Inflation market",
        "Poverty market",
        "Unemployment market"
      ],
      "correct": 0,
      "explanation": "Oligopoly is a market structure"
    },
    {
      "question": "In oligopoly there are?",
      "options": [
        "Few sellers",
        "One seller",
        "Many sellers",
        "No sellers"
      ],
      "correct": 0,
      "explanation": "Oligopoly has few sellers"
    },
    {
      "question": "Which of these is a component of aggregate demand?",
      "options": [
        "Inflation",
        "Population only",
        "Unemployment",
        "Consumption"
      ],
      "correct": 3,
      "explanation": "Consumption is part of aggregate demand"
    },
    {
      "question": "The multiplier effect refers to?",
      "options": [
        "Only tax changes",
        "Only price changes",
        "Magnified effect of investment on income",
        "Only employment changes"
      ],
      "correct": 2,
      "explanation": "Investment has a multiplied effect on income"
    },
    {
      "question": "Which of these is a source of government borrowing?",
      "options": [
        "VAT only",
        "Income tax only",
        "Treasury bills",
        "Customs duty only"
      ],
      "correct": 2,
      "explanation": "Treasury bills are used for borrowing"
    },
    {
      "question": "Economic growth is measured by?",
      "options": [
        "Increase in prices only",
        "Increase in money supply only",
        "Increase in population only",
        "Increase in real GDP"
      ],
      "correct": 3,
      "explanation": "Real GDP growth measures economic growth"
    },
    {
      "question": "Which of these is a tertiary activity?",
      "options": [
        "Mining",
        "Banking",
        "Manufacturing",
        "Farming"
      ],
      "correct": 1,
      "explanation": "Banking is a service (tertiary)"
    },
    {
      "question": "The problem of what to produce is solved by?",
      "options": [
        "Only government order",
        "The price mechanism in a market economy",
        "Only chance",
        "Only tradition"
      ],
      "correct": 1,
      "explanation": "Prices guide production decisions"
    },
    {
      "question": "Which of these is a leakage from the circular flow?",
      "options": [
        "Savings",
        "Exports",
        "Government spending",
        "Investment"
      ],
      "correct": 0,
      "explanation": "Savings is a leakage"
    },
    {
      "question": "Human capital refers to?",
      "options": [
        "Skills and education of the workforce",
        "Only money",
        "Only physical machines",
        "Only land"
      ],
      "correct": 0,
      "explanation": "Human capital is the quality of labour"
    },
    {
      "question": "Which of these is a benefit of economic planning?",
      "options": [
        "Increase in waste",
        "Increase in unemployment always",
        "Better allocation of resources",
        "Reduction in growth"
      ],
      "correct": 2,
      "explanation": "Planning can improve resource allocation"
    },
    {
      "question": "The Phillips curve shows the relationship between?",
      "options": [
        "Growth and population",
        "Tax and revenue",
        "Export and import",
        "Unemployment and inflation"
      ],
      "correct": 3,
      "explanation": "Phillips curve links unemployment and inflation"
    },
    {
      "question": "Which of these is a type of foreign exchange rate system?",
      "options": [
        "Floating exchange rate",
        "Fixed demand only",
        "Floating supply only",
        "Fixed unemployment"
      ],
      "correct": 0,
      "explanation": "Floating rate is market-determined"
    },
    {
      "question": "A country has comparative advantage when?",
      "options": [
        "It has no resources",
        "It has higher absolute cost",
        "It has lower opportunity cost in production",
        "It produces less of everything"
      ],
      "correct": 2,
      "explanation": "Lower opportunity cost gives comparative advantage"
    },
    {
      "question": "Which of these is a goal of economic policy?",
      "options": [
        "Increase in unemployment",
        "Reduction in growth",
        "Increase in inflation",
        "Price stability"
      ],
      "correct": 3,
      "explanation": "Price stability is a policy goal"
    },
    {
      "question": "The accelerator principle relates?",
      "options": [
        "Investment to changes in income",
        "Only tax to revenue",
        "Only consumption to income",
        "Only saving to interest"
      ],
      "correct": 0,
      "explanation": "Accelerator links investment to income changes"
    },
    {
      "question": "Which of these is a characteristic of developing countries?",
      "options": [
        "Low per capita income",
        "High per capita income",
        "Low population growth always",
        "High industrialization only"
      ],
      "correct": 0,
      "explanation": "Low per capita income is common"
    },
    {
      "question": "Deficit financing means?",
      "options": [
        "Balanced budget",
        "Surplus budget",
        "Government saving more",
        "Government spending more than its revenue"
      ],
      "correct": 3,
      "explanation": "Deficit financing covers the gap by borrowing"
    },
    {
      "question": "Which of these is a function of the price system?",
      "options": [
        "Signalling",
        "Causing inflation only",
        "Reducing production only",
        "Creating unemployment only"
      ],
      "correct": 0,
      "explanation": "Prices signal scarcity and preferences"
    },
    {
      "question": "The quantity theory of money relates?",
      "options": [
        "Only tax to spending",
        "Only employment to wages",
        "Only export to import",
        "Money supply to price level"
      ],
      "correct": 3,
      "explanation": "Quantity theory links money and prices"
    },
    {
      "question": "Which of these is an instrument of monetary policy?",
      "options": [
        "Open market operations",
        "Taxation only",
        "Import duties only",
        "Government spending only"
      ],
      "correct": 0,
      "explanation": "Open market operations are monetary tools"
    },
    {
      "question": "National disposable income is?",
      "options": [
        "Only GDP",
        "Only GNP",
        "Income available to households after taxes and transfers",
        "Only personal income before tax"
      ],
      "correct": 2,
      "explanation": "Disposable income is after taxes and transfers"
    },
    {
      "question": "Which of these is a type of cost in the long run?",
      "options": [
        "Only marginal costs",
        "Only average costs",
        "Only fixed costs",
        "All costs are variable"
      ],
      "correct": 3,
      "explanation": "In the long run all costs are variable"
    },
    {
      "question": "A cartel is associated with?",
      "options": [
        "Monopolistic competition only",
        "Pure monopoly only",
        "Perfect competition",
        "Oligopoly"
      ],
      "correct": 3,
      "explanation": "Cartels are common in oligopoly"
    },
    {
      "question": "Which of these is a component of the current account?",
      "options": [
        "Only foreign investment",
        "Only loans",
        "Trade in goods and services",
        "Only capital transfers"
      ],
      "correct": 2,
      "explanation": "Current account includes goods and services"
    },
    {
      "question": "Economic integration includes?",
      "options": [
        "Only bilateral talks",
        "Complete isolation",
        "Only military alliances",
        "Free trade area"
      ],
      "correct": 3,
      "explanation": "Free trade area is a form of integration"
    },
    {
      "question": "Which of these is a measure of income inequality?",
      "options": [
        "GDP only",
        "GNP only",
        "Gini coefficient",
        "Inflation rate only"
      ],
      "correct": 2,
      "explanation": "Gini coefficient measures inequality"
    },
    {
      "question": "The liquidity ratio is used by?",
      "options": [
        "Only individuals",
        "Only commercial banks internally",
        "Only foreign banks",
        "Central Bank to control commercial banks"
      ],
      "correct": 3,
      "explanation": "Central Bank sets liquidity ratios"
    },
    {
      "question": "Which of these is a feature of perfect competition?",
      "options": [
        "Barriers to entry",
        "Homogeneous products",
        "Differentiated products",
        "One seller"
      ],
      "correct": 1,
      "explanation": "Products are homogeneous"
    },
    {
      "question": "Induced investment depends on?",
      "options": [
        "Only interest rate always",
        "Only weather",
        "Changes in income or demand",
        "Only government policy"
      ],
      "correct": 2,
      "explanation": "Induced investment responds to income changes"
    },
    {
      "question": "Which of these is a type of public debt?",
      "options": [
        "Internal debt",
        "Private debt only",
        "Personal loan only",
        "Company loan only"
      ],
      "correct": 0,
      "explanation": "Internal debt is owed within the country"
    },
    {
      "question": "The production function shows?",
      "options": [
        "Only money and prices",
        "Only cost and price",
        "Relationship between inputs and output",
        "Only demand and supply"
      ],
      "correct": 2,
      "explanation": "Production function links inputs to output"
    },
    {
      "question": "Which of these is a benefit of free trade?",
      "options": [
        "Efficient allocation of resources",
        "Increase in unemployment always",
        "Protection of infant industries only",
        "Reduction in consumer choice"
      ],
      "correct": 0,
      "explanation": "Free trade promotes efficiency"
    },
    {
      "question": "A regressive tax takes?",
      "options": [
        "Higher percentage from low income earners",
        "No tax from anyone",
        "Same percentage from all",
        "Higher percentage from high income earners"
      ],
      "correct": 0,
      "explanation": "Regressive tax burdens the poor more relatively"
    },
    {
      "question": "Which of these is a cause of balance of payments deficit?",
      "options": [
        "High import relative to export",
        "Balanced trade",
        "Only capital inflow",
        "High export relative to import"
      ],
      "correct": 0,
      "explanation": "More imports than exports can cause deficit"
    },
    {
      "question": "The concept of elasticity measures?",
      "options": [
        "Only total cost",
        "Only total revenue",
        "Responsiveness of quantity to price change",
        "Only profit"
      ],
      "correct": 2,
      "explanation": "Elasticity measures responsiveness"
    },
    {
      "question": "Which of these is a macroeconomic objective?",
      "options": [
        "Only firm growth",
        "Full employment",
        "Only individual profit",
        "Only household saving"
      ],
      "correct": 1,
      "explanation": "Full employment is a macro objective"
    },
    {
      "question": "Devaluation of currency makes exports?",
      "options": [
        "Prohibited",
        "Unchanged in price",
        "Cheaper to foreigners",
        "More expensive to foreigners"
      ],
      "correct": 2,
      "explanation": "Devaluation cheapens exports"
    },
    {
      "question": "Which of these is a type of unemployment in developing countries?",
      "options": [
        "Only frictional",
        "Disguised unemployment",
        "Only cyclical",
        "Only seasonal"
      ],
      "correct": 1,
      "explanation": "Disguised unemployment is common in developing countries"
    },
    {
      "question": "The circular flow of income involves?",
      "options": [
        "Households and firms",
        "Only banks",
        "Only foreign sector",
        "Only government"
      ],
      "correct": 0,
      "explanation": "Basic circular flow is between households and firms"
    },
    {
      "question": "Which of these is a tool to promote exports?",
      "options": [
        "Export subsidy",
        "Ban on exports",
        "High export tax",
        "Import subsidy only"
      ],
      "correct": 0,
      "explanation": "Export subsidy encourages exports"
    },
    {
      "question": "The marginal propensity to consume is?",
      "options": [
        "Total consumption divided by total income",
        "Change in saving divided by income",
        "Change in consumption divided by change in income",
        "Total saving divided by income"
      ],
      "correct": 2,
      "explanation": "MPC is ΔC / ΔY"
    },
    {
      "question": "Which of these is a characteristic of land?",
      "options": [
        "Man-made",
        "Immobility",
        "High mobility",
        "Easy to increase supply"
      ],
      "correct": 1,
      "explanation": "Land is geographically immobile"
    },
    {
      "question": "An inferior good has?",
      "options": [
        "Negative income elasticity",
        "Infinite elasticity",
        "Zero income elasticity",
        "Positive income elasticity"
      ],
      "correct": 0,
      "explanation": "Demand falls as income rises for inferior goods"
    },
    {
      "question": "Which of these is a function of the financial market?",
      "options": [
        "Producing goods",
        "Mining",
        "Mobilising savings",
        "Farming"
      ],
      "correct": 2,
      "explanation": "Financial markets mobilise savings"
    },
    {
      "question": "The balance of payments is?",
      "options": [
        "Only government transactions",
        "Only capital flows",
        "Record of all economic transactions with the rest of the world",
        "Only trade in goods"
      ],
      "correct": 2,
      "explanation": "BOP records all external transactions"
    },
    {
      "question": "Which of these is a type of economic system?",
      "options": [
        "Traditional economy",
        "Inflation economy",
        "Poverty economy",
        "Unemployment economy"
      ],
      "correct": 0,
      "explanation": "Traditional economy is a system"
    },
    {
      "question": "In a traditional economy, decisions are based on?",
      "options": [
        "Price mechanism only",
        "Computer models only",
        "Government planning only",
        "Customs and traditions"
      ],
      "correct": 3,
      "explanation": "Customs guide traditional economies"
    },
    {
      "question": "Which of these is a benefit of specialization?",
      "options": [
        "Decreased skill",
        "Increased waste",
        "Increased productivity",
        "Reduced output"
      ],
      "correct": 2,
      "explanation": "Specialization raises productivity"
    },
    {
      "question": "The law of diminishing returns applies in?",
      "options": [
        "The long run only",
        "Both always equally",
        "Neither",
        "The short run"
      ],
      "correct": 3,
      "explanation": "Diminishing returns occur in the short run"
    },
    {
      "question": "Which of these is a type of market failure?",
      "options": [
        "Perfect competition",
        "Full employment",
        "Efficient allocation",
        "Externalities"
      ],
      "correct": 3,
      "explanation": "Externalities cause market failure"
    },
    {
      "question": "A positive externality is?",
      "options": [
        "Only private cost",
        "Only private benefit",
        "Cost to third parties",
        "Benefit to third parties"
      ],
      "correct": 3,
      "explanation": "Positive externality benefits others"
    },
    {
      "question": "Which of these is used to measure economic welfare?",
      "options": [
        "Only tax rate",
        "Only money supply",
        "Only total population",
        "Per capita income"
      ],
      "correct": 3,
      "explanation": "Per capita income indicates welfare"
    },
    {
      "question": "The International Monetary Fund (IMF) aims to?",
      "options": [
        "Only regulate world trade",
        "Only give long-term project loans",
        "Promote global monetary cooperation",
        "Only provide military aid"
      ],
      "correct": 2,
      "explanation": "IMF promotes monetary cooperation"
    },
    {
      "question": "Which of these is a feature of monopolistic competition?",
      "options": [
        "Product differentiation",
        "No free entry",
        "One seller",
        "Homogeneous products"
      ],
      "correct": 0,
      "explanation": "Products are differentiated"
    },
    {
      "question": "Autonomous investment is?",
      "options": [
        "Dependent on income only",
        "Only private investment",
        "Only government investment",
        "Independent of income level"
      ],
      "correct": 3,
      "explanation": "Autonomous investment does not depend on income"
    },
    {
      "question": "Which of these is a source of capital formation?",
      "options": [
        "Unemployment",
        "Savings",
        "Consumption only",
        "Imports only"
      ],
      "correct": 1,
      "explanation": "Savings lead to capital formation"
    },
    {
      "question": "The World Bank mainly provides?",
      "options": [
        "Only food aid",
        "Only short-term balance of payments support",
        "Only military aid",
        "Long-term loans for development"
      ],
      "correct": 3,
      "explanation": "World Bank focuses on development loans"
    },
    {
      "question": "Which of these is a type of elasticity?",
      "options": [
        "Supply rigidity only",
        "Price elasticity of demand",
        "Income inelasticity only",
        "Cross inelasticity only"
      ],
      "correct": 1,
      "explanation": "Price elasticity is a common type"
    },
    {
      "question": "A perfectly inelastic demand curve is?",
      "options": [
        "Downward sloping gently",
        "Upward sloping",
        "Horizontal",
        "Vertical"
      ],
      "correct": 3,
      "explanation": "Perfectly inelastic is vertical"
    },
    {
      "question": "Which of these is a goal of the Sustainable Development Goals?",
      "options": [
        "Environmental degradation",
        "Increase in inequality",
        "Increase in poverty",
        "No poverty"
      ],
      "correct": 3,
      "explanation": "Ending poverty is a key SDG"
    }
  ],
  "com": [
    {
      "question": "Commerce is best defined as?",
      "options": [
        "Trade and aids to trade",
        "Only production",
        "Only transportation",
        "Only buying and selling"
      ],
      "correct": 0,
      "explanation": "Commerce includes trade and aids to trade"
    },
    {
      "question": "Which of these is an aid to trade?",
      "options": [
        "Farming",
        "Banking",
        "Fishing",
        "Mining"
      ],
      "correct": 1,
      "explanation": "Banking is an aid to trade"
    },
    {
      "question": "Trade between two countries is?",
      "options": [
        "Wholesale trade",
        "International trade",
        "Retail trade",
        "Home trade"
      ],
      "correct": 1,
      "explanation": "International trade is between countries"
    },
    {
      "question": "The person who sells in small quantities is?",
      "options": [
        "Importer",
        "Producer",
        "Wholesaler",
        "Retailer"
      ],
      "correct": 3,
      "explanation": "Retailers sell in small quantities"
    },
    {
      "question": "Which of these is a document used in home trade?",
      "options": [
        "Consular invoice",
        "Invoice",
        "Certificate of origin",
        "Bill of lading"
      ],
      "correct": 1,
      "explanation": "Invoice is used in home trade"
    },
    {
      "question": "The function of a wholesaler is?",
      "options": [
        "Importing only",
        "Buying in bulk and selling to retailers",
        "Selling to final consumers only",
        "Producing goods"
      ],
      "correct": 1,
      "explanation": "Wholesalers buy bulk and sell to retailers"
    },
    {
      "question": "Which of these is a type of retail outlet?",
      "options": [
        "Warehouse",
        "Farm",
        "Factory",
        "Supermarket"
      ],
      "correct": 3,
      "explanation": "Supermarket is a retail outlet"
    },
    {
      "question": "Insurance is?",
      "options": [
        "A type of transport",
        "Protection against risk",
        "A bank loan",
        "A type of tax"
      ],
      "correct": 1,
      "explanation": "Insurance protects against risk"
    },
    {
      "question": "Which of these is a principle of insurance?",
      "options": [
        "Free trade",
        "Open market",
        "Maximum profit",
        "Utmost good faith"
      ],
      "correct": 3,
      "explanation": "Utmost good faith is a principle of insurance"
    },
    {
      "question": "The document that serves as a receipt for goods shipped is?",
      "options": [
        "Invoice",
        "Receipt",
        "Cheque",
        "Bill of lading"
      ],
      "correct": 3,
      "explanation": "Bill of lading is used in shipping"
    },
    {
      "question": "Which of these is a form of money?",
      "options": [
        "Invoice",
        "Receipt",
        "Cheque",
        "Waybill"
      ],
      "correct": 2,
      "explanation": "Cheque is a form of money"
    },
    {
      "question": "Advertising is?",
      "options": [
        "Storing goods",
        "Transporting goods",
        "Making goods known to the public",
        "Producing goods"
      ],
      "correct": 2,
      "explanation": "Advertising promotes goods"
    },
    {
      "question": "Which of these is a type of transport?",
      "options": [
        "Warehousing",
        "Insurance",
        "Road transport",
        "Banking"
      ],
      "correct": 2,
      "explanation": "Road is a type of transport"
    },
    {
      "question": "The place where goods are stored is?",
      "options": [
        "Market",
        "Bank",
        "Office",
        "Warehouse"
      ],
      "correct": 3,
      "explanation": "Warehouse is for storage"
    },
    {
      "question": "Which of these is a document of title to goods?",
      "options": [
        "Receipt",
        "Invoice",
        "Cheque",
        "Bill of lading"
      ],
      "correct": 3,
      "explanation": "Bill of lading is a document of title"
    },
    {
      "question": "Hire purchase is?",
      "options": [
        "Borrowing money",
        "Buying and paying in instalments",
        "Buying and paying at once",
        "Hiring only"
      ],
      "correct": 1,
      "explanation": "Hire purchase involves instalment payments"
    },
    {
      "question": "Which of these is a type of bank account?",
      "options": [
        "Waybill account",
        "Current account",
        "Invoice account",
        "Receipt account"
      ],
      "correct": 1,
      "explanation": "Current account is a bank account"
    },
    {
      "question": "The person who buys goods from abroad is?",
      "options": [
        "Retailer",
        "Importer",
        "Exporter",
        "Wholesaler"
      ],
      "correct": 1,
      "explanation": "Importer buys from abroad"
    },
    {
      "question": "Which of these is an advantage of advertising?",
      "options": [
        "Increases sales",
        "Reduces quality",
        "Causes unemployment",
        "Increases cost only"
      ],
      "correct": 0,
      "explanation": "Advertising can increase sales"
    },
    {
      "question": "The contract of carriage of goods by sea is?",
      "options": [
        "Invoice",
        "Bill of lading",
        "Receipt",
        "Cheque"
      ],
      "correct": 1,
      "explanation": "Bill of lading is the contract of carriage by sea"
    },
    {
      "question": "Which of these is a middleman?",
      "options": [
        "Manufacturer",
        "Consumer",
        "Wholesaler",
        "Producer"
      ],
      "correct": 2,
      "explanation": "Wholesaler is a middleman"
    },
    {
      "question": "E-commerce is?",
      "options": [
        "Buying and selling through the internet",
        "Traditional trade only",
        "Selling in shops only",
        "Buying in the market only"
      ],
      "correct": 0,
      "explanation": "E-commerce is online trade"
    },
    {
      "question": "Which of these is a function of warehousing?",
      "options": [
        "Storage of goods",
        "Advertising",
        "Insurance only",
        "Production of goods"
      ],
      "correct": 0,
      "explanation": "Warehousing stores goods"
    },
    {
      "question": "The document that shows the price of goods is?",
      "options": [
        "Certificate of origin",
        "Price list",
        "Consular invoice",
        "Bill of lading"
      ],
      "correct": 1,
      "explanation": "Price list shows prices"
    },
    {
      "question": "Which of these is a type of insurance?",
      "options": [
        "Waybill insurance",
        "Life insurance",
        "Invoice insurance",
        "Receipt insurance"
      ],
      "correct": 1,
      "explanation": "Life insurance is a type of insurance"
    },
    {
      "question": "Which of these is a type of trade?",
      "options": [
        "Advertising",
        "Insurance",
        "Home trade",
        "Banking"
      ],
      "correct": 2,
      "explanation": "Home trade is a type of trade"
    },
    {
      "question": "The person who sells in large quantities is?",
      "options": [
        "Retailer",
        "Wholesaler",
        "Producer only",
        "Consumer"
      ],
      "correct": 1,
      "explanation": "Wholesalers sell in large quantities"
    },
    {
      "question": "Which of these is a document used in foreign trade?",
      "options": [
        "Cash book",
        "Bill of lading",
        "Receipt only",
        "Local invoice only"
      ],
      "correct": 1,
      "explanation": "Bill of lading is used in foreign trade"
    },
    {
      "question": "A supermarket is an example of?",
      "options": [
        "Manufacturing",
        "Primary production",
        "Wholesale trade",
        "Large scale retail trade"
      ],
      "correct": 3,
      "explanation": "Supermarket is large scale retail"
    },
    {
      "question": "Which of these is a function of insurance?",
      "options": [
        "Spreading of risk",
        "Creating risk",
        "Increasing prices only",
        "Reducing production"
      ],
      "correct": 0,
      "explanation": "Insurance spreads risk"
    },
    {
      "question": "The principle of indemnity means?",
      "options": [
        "Paying more than the loss",
        "No compensation",
        "Making profit from insurance",
        "Compensation for actual loss"
      ],
      "correct": 3,
      "explanation": "Indemnity restores the insured to original position"
    },
    {
      "question": "Which of these is a type of advertising?",
      "options": [
        "Informative advertising",
        "Hidden advertising",
        "Silent advertising",
        "Secret advertising"
      ],
      "correct": 0,
      "explanation": "Informative advertising gives information"
    },
    {
      "question": "The document that acknowledges receipt of goods is?",
      "options": [
        "Bill of lading",
        "Invoice",
        "Receipt",
        "Cheque"
      ],
      "correct": 2,
      "explanation": "Receipt acknowledges payment or goods"
    },
    {
      "question": "Which of these is an advantage of road transport?",
      "options": [
        "Very cheap for long distances always",
        "No accidents",
        "No traffic",
        "Door to door delivery"
      ],
      "correct": 3,
      "explanation": "Road transport offers door to door service"
    },
    {
      "question": "A warehouse is used for?",
      "options": [
        "Advertising",
        "Storage",
        "Production",
        "Insurance only"
      ],
      "correct": 1,
      "explanation": "Warehouses store goods"
    },
    {
      "question": "Which of these is a type of bank?",
      "options": [
        "Invoice bank",
        "Receipt bank",
        "Commercial bank",
        "Waybill bank"
      ],
      "correct": 2,
      "explanation": "Commercial bank is a type of bank"
    },
    {
      "question": "Hire purchase allows the buyer to?",
      "options": [
        "Return goods anytime without payment",
        "Use the goods while paying instalments",
        "Own the goods immediately without payment",
        "Avoid payment completely"
      ],
      "correct": 1,
      "explanation": "Buyer uses goods while paying"
    },
    {
      "question": "Which of these is a disadvantage of advertising?",
      "options": [
        "It eliminates competition",
        "It always reduces prices",
        "It always improves quality",
        "It increases cost of goods"
      ],
      "correct": 3,
      "explanation": "Advertising costs may increase prices"
    },
    {
      "question": "The person who sells goods to other countries is?",
      "options": [
        "Retailer",
        "Importer",
        "Wholesaler only",
        "Exporter"
      ],
      "correct": 3,
      "explanation": "Exporter sells abroad"
    },
    {
      "question": "Which of these is a function of a retailer?",
      "options": [
        "Importing only",
        "Selling to final consumers",
        "Producing goods",
        "Exporting only"
      ],
      "correct": 1,
      "explanation": "Retailers sell to final consumers"
    },
    {
      "question": "E-commerce involves?",
      "options": [
        "Electronic transactions",
        "Only local trade",
        "Only face to face trade",
        "Only cash transactions"
      ],
      "correct": 0,
      "explanation": "E-commerce uses electronic means"
    },
    {
      "question": "Which of these is a type of insurance policy?",
      "options": [
        "Invoice insurance",
        "Waybill insurance",
        "Fire insurance",
        "Receipt insurance"
      ],
      "correct": 2,
      "explanation": "Fire insurance is a common policy"
    },
    {
      "question": "The document used to order goods is?",
      "options": [
        "Order form",
        "Consular invoice",
        "Certificate of origin",
        "Bill of lading"
      ],
      "correct": 0,
      "explanation": "Order form is used to order goods"
    },
    {
      "question": "Which of these is an aid to trade?",
      "options": [
        "Mining",
        "Farming",
        "Fishing",
        "Transportation"
      ],
      "correct": 3,
      "explanation": "Transportation is an aid to trade"
    },
    {
      "question": "A current account allows?",
      "options": [
        "Only cash deposit",
        "No withdrawal",
        "Withdrawal by cheque",
        "Only long-term savings"
      ],
      "correct": 2,
      "explanation": "Current accounts allow cheque withdrawals"
    },
    {
      "question": "Which of these is a middleman in distribution?",
      "options": [
        "Agent",
        "Consumer only",
        "Producer only",
        "Manufacturer only"
      ],
      "correct": 0,
      "explanation": "Agents are middlemen"
    },
    {
      "question": "The contract between the insured and insurer is?",
      "options": [
        "Insurance policy",
        "Invoice",
        "Receipt",
        "Cheque"
      ],
      "correct": 0,
      "explanation": "Insurance policy is the contract"
    },
    {
      "question": "Which of these is a type of wholesale trade?",
      "options": [
        "Manufacturing only",
        "General wholesale",
        "Retail only",
        "Primary production"
      ],
      "correct": 1,
      "explanation": "General wholesale is a type"
    },
    {
      "question": "Advertising media include?",
      "options": [
        "Television",
        "Hoe",
        "Cutlass",
        "Rake"
      ],
      "correct": 0,
      "explanation": "Television is an advertising medium"
    },
    {
      "question": "Which of these is a function of commerce?",
      "options": [
        "Mining only",
        "Producing goods only",
        "Bridging the gap between producer and consumer",
        "Farming only"
      ],
      "correct": 2,
      "explanation": "Commerce links producers and consumers"
    },
    {
      "question": "Which of these is a type of home trade?",
      "options": [
        "Entrepot trade",
        "Import trade",
        "Wholesale trade",
        "Export trade"
      ],
      "correct": 2,
      "explanation": "Wholesale is a type of home trade"
    },
    {
      "question": "The retailer sells goods to?",
      "options": [
        "Producers only",
        "Importers only",
        "Wholesalers only",
        "Final consumers"
      ],
      "correct": 3,
      "explanation": "Retailers sell to final consumers"
    },
    {
      "question": "Which of these is a document used in international trade?",
      "options": [
        "Local receipt only",
        "Certificate of origin",
        "Personal letter",
        "Cash book"
      ],
      "correct": 1,
      "explanation": "Certificate of origin is used in foreign trade"
    },
    {
      "question": "A department store is an example of?",
      "options": [
        "Small scale retailing only",
        "Manufacturing",
        "Wholesale only",
        "Large scale retailing"
      ],
      "correct": 3,
      "explanation": "Department store is large scale retail"
    },
    {
      "question": "Which of these is a principle of insurance?",
      "options": [
        "Insurable interest",
        "Open competition",
        "Free entry",
        "Maximum profit"
      ],
      "correct": 0,
      "explanation": "Insurable interest is a principle"
    },
    {
      "question": "The principle of proximate cause means?",
      "options": [
        "Any cause is accepted",
        "No cause is needed",
        "Only distant causes",
        "The nearest cause of the loss is considered"
      ],
      "correct": 3,
      "explanation": "Proximate cause is the nearest cause"
    },
    {
      "question": "Which of these is a medium of advertising?",
      "options": [
        "Rake",
        "Radio",
        "Cutlass",
        "Hoe"
      ],
      "correct": 1,
      "explanation": "Radio is an advertising medium"
    },
    {
      "question": "The document that shows goods have been received is?",
      "options": [
        "Bill of lading only",
        "Invoice only",
        "Delivery note",
        "Cheque"
      ],
      "correct": 2,
      "explanation": "Delivery note confirms receipt of goods"
    },
    {
      "question": "Which of these is an advantage of air transport?",
      "options": [
        "Speed",
        "Unlimited capacity",
        "Very cheap always",
        "No weather effect"
      ],
      "correct": 0,
      "explanation": "Air transport is fast"
    },
    {
      "question": "Bonded warehouse is used for?",
      "options": [
        "Storing imported goods awaiting duty payment",
        "Advertising",
        "Storing local goods only",
        "Production"
      ],
      "correct": 0,
      "explanation": "Bonded warehouse holds goods pending duty"
    },
    {
      "question": "Which of these is a type of bank account?",
      "options": [
        "Savings account",
        "Invoice account",
        "Receipt account",
        "Waybill account"
      ],
      "correct": 0,
      "explanation": "Savings account is a bank account"
    },
    {
      "question": "Deferred payment means?",
      "options": [
        "Paying later for goods already received",
        "Paying double",
        "Not paying at all",
        "Paying before receiving goods"
      ],
      "correct": 0,
      "explanation": "Deferred payment is later payment"
    },
    {
      "question": "Which of these is a disadvantage of advertising?",
      "options": [
        "It always reduces prices",
        "It can be misleading",
        "It eliminates all competition",
        "It always tells the truth"
      ],
      "correct": 1,
      "explanation": "Advertising can sometimes mislead"
    },
    {
      "question": "The person who brings goods into a country is?",
      "options": [
        "Retailer only",
        "Wholesaler only",
        "Importer",
        "Exporter"
      ],
      "correct": 2,
      "explanation": "Importer brings goods in"
    },
    {
      "question": "Which of these is a function of a wholesaler?",
      "options": [
        "Farming",
        "Mining",
        "Breaking bulk",
        "Producing goods"
      ],
      "correct": 2,
      "explanation": "Wholesalers break bulk"
    },
    {
      "question": "Online shopping is an example of?",
      "options": [
        "E-commerce",
        "Traditional market only",
        "Local trade only",
        "Barter trade"
      ],
      "correct": 0,
      "explanation": "Online shopping is e-commerce"
    },
    {
      "question": "Which of these is a type of life insurance?",
      "options": [
        "Whole life policy",
        "Fire policy only",
        "Marine policy only",
        "Motor policy only"
      ],
      "correct": 0,
      "explanation": "Whole life is a type of life insurance"
    },
    {
      "question": "The document used by a buyer to request for goods is?",
      "options": [
        "Purchase order",
        "Bill of lading",
        "Certificate of origin",
        "Consular invoice"
      ],
      "correct": 0,
      "explanation": "Purchase order requests goods"
    },
    {
      "question": "Which of these is an aid to trade?",
      "options": [
        "Farming",
        "Fishing",
        "Mining",
        "Insurance"
      ],
      "correct": 3,
      "explanation": "Insurance is an aid to trade"
    },
    {
      "question": "A fixed deposit account is suitable for?",
      "options": [
        "Long-term savings",
        "Daily transactions",
        "No interest",
        "Frequent withdrawals"
      ],
      "correct": 0,
      "explanation": "Fixed deposit is for long-term savings"
    },
    {
      "question": "Which of these is a middleman?",
      "options": [
        "Broker",
        "Farmer only",
        "Consumer only",
        "Producer only"
      ],
      "correct": 0,
      "explanation": "Broker is a middleman"
    },
    {
      "question": "The insurance policy document is?",
      "options": [
        "An invoice",
        "A receipt only",
        "A cheque",
        "Evidence of the contract"
      ],
      "correct": 3,
      "explanation": "Policy is evidence of the insurance contract"
    },
    {
      "question": "Which of these is a type of retail trade?",
      "options": [
        "Itinerant trading",
        "Wholesale only",
        "Primary production",
        "Manufacturing"
      ],
      "correct": 0,
      "explanation": "Itinerant trading is a form of retailing"
    },
    {
      "question": "Advertising helps to?",
      "options": [
        "Hide products",
        "Eliminate all competition",
        "Reduce quality",
        "Create awareness"
      ],
      "correct": 3,
      "explanation": "Advertising creates awareness"
    },
    {
      "question": "Which of these is a function of commerce?",
      "options": [
        "Mining only",
        "Producing raw materials only",
        "Farming only",
        "Facilitating exchange"
      ],
      "correct": 3,
      "explanation": "Commerce facilitates exchange"
    },
    {
      "question": "Which of these is a type of retail trade?",
      "options": [
        "Itinerant trading",
        "Wholesale only",
        "Manufacturing",
        "Primary production"
      ],
      "correct": 0,
      "explanation": "Itinerant trading is a form of retail"
    },
    {
      "question": "The person who buys goods for resale is?",
      "options": [
        "Government only",
        "Producer only",
        "Middleman",
        "Final consumer only"
      ],
      "correct": 2,
      "explanation": "Middlemen buy for resale"
    },
    {
      "question": "Which of these is a document used in international trade?",
      "options": [
        "Certificate of origin",
        "Cash book",
        "Personal letter",
        "Local receipt only"
      ],
      "correct": 0,
      "explanation": "Certificate of origin is used in foreign trade"
    },
    {
      "question": "A department store is an example of?",
      "options": [
        "Large scale retailing",
        "Primary production",
        "Wholesale trade",
        "Manufacturing only"
      ],
      "correct": 0,
      "explanation": "Department store is large scale retail"
    },
    {
      "question": "Which of these is a principle of insurance?",
      "options": [
        "Insurable interest",
        "Maximum loss",
        "Free cover",
        "No compensation"
      ],
      "correct": 0,
      "explanation": "Insurable interest is required"
    },
    {
      "question": "The document that serves as evidence of a contract of insurance is?",
      "options": [
        "Cheque",
        "Policy document",
        "Receipt only",
        "Invoice"
      ],
      "correct": 1,
      "explanation": "Policy document is the insurance contract"
    },
    {
      "question": "Which of these is a type of transport by water?",
      "options": [
        "Road transport",
        "Shipping",
        "Air transport only",
        "Rail transport"
      ],
      "correct": 1,
      "explanation": "Shipping is water transport"
    },
    {
      "question": "A bonded warehouse is used for?",
      "options": [
        "Storing imported goods awaiting duty payment",
        "Advertising",
        "Storing local goods only",
        "Production of goods"
      ],
      "correct": 0,
      "explanation": "Bonded warehouses hold goods pending duty"
    },
    {
      "question": "Which of these is a function of advertising?",
      "options": [
        "Storing goods",
        "Creating awareness",
        "Producing goods",
        "Transporting goods only"
      ],
      "correct": 1,
      "explanation": "Advertising creates awareness"
    },
    {
      "question": "The document used when goods are returned is?",
      "options": [
        "Credit note",
        "Debit note only",
        "Invoice only",
        "Receipt only"
      ],
      "correct": 0,
      "explanation": "Credit note is issued for returned goods"
    },
    {
      "question": "Which of these is a type of bank account for saving?",
      "options": [
        "Current account only",
        "Fixed deposit only",
        "Domiciliary only",
        "Savings account"
      ],
      "correct": 3,
      "explanation": "Savings account is for saving"
    },
    {
      "question": "Hire purchase is different from credit sale because?",
      "options": [
        "Ownership passes immediately",
        "Ownership passes after final payment",
        "No payment is required",
        "Goods cannot be used"
      ],
      "correct": 1,
      "explanation": "In hire purchase, ownership passes after full payment"
    },
    {
      "question": "Which of these is a medium of advertising?",
      "options": [
        "Newspaper",
        "Rake",
        "Hoe",
        "Cutlass"
      ],
      "correct": 0,
      "explanation": "Newspaper is an advertising medium"
    },
    {
      "question": "The person who specializes in a particular line of goods is?",
      "options": [
        "Specialist wholesaler",
        "Consumer only",
        "Producer only",
        "General retailer only"
      ],
      "correct": 0,
      "explanation": "Specialist wholesalers deal in specific goods"
    },
    {
      "question": "Which of these is an advantage of warehousing?",
      "options": [
        "Increase in risk only",
        "Reduction in quality",
        "Increase in price only",
        "Price stability"
      ],
      "correct": 3,
      "explanation": "Warehousing helps stabilize prices"
    },
    {
      "question": "E-commerce can be carried out through?",
      "options": [
        "Only physical shops",
        "Only markets",
        "Internet",
        "Only farms"
      ],
      "correct": 2,
      "explanation": "E-commerce uses the internet"
    },
    {
      "question": "Which of these is a type of life insurance?",
      "options": [
        "Motor policy only",
        "Whole life policy",
        "Marine policy only",
        "Fire policy only"
      ],
      "correct": 1,
      "explanation": "Whole life is a type of life insurance"
    },
    {
      "question": "The document that shows details of goods sent is?",
      "options": [
        "Delivery note",
        "Bank statement",
        "Cheque",
        "Receipt only"
      ],
      "correct": 0,
      "explanation": "Delivery note accompanies goods"
    },
    {
      "question": "Which of these is an aid to trade?",
      "options": [
        "Fishing",
        "Communication",
        "Mining",
        "Farming"
      ],
      "correct": 1,
      "explanation": "Communication aids trade"
    },
    {
      "question": "A fixed deposit account is suitable for?",
      "options": [
        "Daily withdrawal",
        "Cheque payment only",
        "No interest",
        "Long-term saving"
      ],
      "correct": 3,
      "explanation": "Fixed deposit is for long-term saving"
    },
    {
      "question": "Which of these is a function of a wholesaler?",
      "options": [
        "Consuming goods",
        "Producing goods",
        "Making laws",
        "Breaking bulk"
      ],
      "correct": 3,
      "explanation": "Wholesalers break bulk"
    },
    {
      "question": "The contract of insurance is based on?",
      "options": [
        "Hidden information",
        "Utmost good faith",
        "Maximum profit",
        "False declaration"
      ],
      "correct": 1,
      "explanation": "Insurance requires utmost good faith"
    },
    {
      "question": "Which of these is a type of foreign trade?",
      "options": [
        "Wholesale trade only",
        "Retail trade only",
        "Import trade",
        "Home trade only"
      ],
      "correct": 2,
      "explanation": "Import is a type of foreign trade"
    },
    {
      "question": "Advertising that compares products is?",
      "options": [
        "Competitive advertising",
        "Informative only",
        "Persuasive only",
        "Institutional only"
      ],
      "correct": 0,
      "explanation": "Competitive advertising compares products"
    },
    {
      "question": "Which of these is a benefit of commerce?",
      "options": [
        "Reduces production",
        "Reduces variety of goods",
        "Raises standard of living",
        "Increases isolation"
      ],
      "correct": 2,
      "explanation": "Commerce improves standard of living"
    },
    {
      "question": "Which of these is a type of itinerant trader?",
      "options": [
        "Supermarket",
        "Hypermarket",
        "Department store",
        "Hawker"
      ],
      "correct": 3,
      "explanation": "Hawkers are itinerant traders"
    },
    {
      "question": "The document that transfers ownership of goods in transit is?",
      "options": [
        "Receipt",
        "Bill of lading",
        "Invoice",
        "Cheque"
      ],
      "correct": 1,
      "explanation": "Bill of lading can transfer title"
    },
    {
      "question": "Which of these is a large-scale retail outlet?",
      "options": [
        "Kiosk",
        "Street trader",
        "Mobile van only",
        "Hypermarket"
      ],
      "correct": 3,
      "explanation": "Hypermarket is large-scale"
    },
    {
      "question": "The principle that the insured must not profit from insurance is?",
      "options": [
        "Utmost good faith",
        "Indemnity",
        "Contribution",
        "Insurable interest"
      ],
      "correct": 1,
      "explanation": "Indemnity prevents profit from loss"
    },
    {
      "question": "Which of these is a type of marine insurance?",
      "options": [
        "Motor insurance",
        "Life insurance",
        "Fire insurance",
        "Hull insurance"
      ],
      "correct": 3,
      "explanation": "Hull insurance covers the ship"
    },
    {
      "question": "The document used in air transport is?",
      "options": [
        "Railway consignment note",
        "Bill of lading",
        "Air waybill",
        "Road waybill only"
      ],
      "correct": 2,
      "explanation": "Air waybill is for air freight"
    },
    {
      "question": "Which of these is a function of packaging?",
      "options": [
        "Protection of goods",
        "Advertising only",
        "Production of goods",
        "Insurance only"
      ],
      "correct": 0,
      "explanation": "Packaging protects goods"
    },
    {
      "question": "A credit sale means?",
      "options": [
        "Goods hired",
        "Goods sold for cash only",
        "Goods sold with payment later",
        "Goods given free"
      ],
      "correct": 2,
      "explanation": "Credit sale allows later payment"
    },
    {
      "question": "Which of these is a type of warehouse?",
      "options": [
        "Public warehouse",
        "Private school",
        "Public hospital",
        "Private house"
      ],
      "correct": 0,
      "explanation": "Public warehouse is a type"
    },
    {
      "question": "The process of making goods attractive is?",
      "options": [
        "Insurance only",
        "Production only",
        "Transportation only",
        "Branding and packaging"
      ],
      "correct": 3,
      "explanation": "Branding and packaging enhance appeal"
    },
    {
      "question": "Which of these is a commercial bank service?",
      "options": [
        "Controlling money supply",
        "Making laws",
        "Issuing currency",
        "Granting loans"
      ],
      "correct": 3,
      "explanation": "Commercial banks grant loans"
    },
    {
      "question": "Deferred payment is a feature of?",
      "options": [
        "Hire purchase",
        "Gift",
        "Cash sale",
        "Barter"
      ],
      "correct": 0,
      "explanation": "Hire purchase involves deferred payment"
    },
    {
      "question": "Which of these is a form of outdoor advertising?",
      "options": [
        "Billboard",
        "Television only",
        "Radio only",
        "Newspaper only"
      ],
      "correct": 0,
      "explanation": "Billboard is outdoor advertising"
    },
    {
      "question": "The person who acts on behalf of another in trade is?",
      "options": [
        "Agent",
        "Principal only",
        "Consumer only",
        "Producer only"
      ],
      "correct": 0,
      "explanation": "Agent represents another party"
    },
    {
      "question": "Which of these is an advantage of air transport?",
      "options": [
        "Very low cost always",
        "No weather effect",
        "Speed",
        "No weight limit"
      ],
      "correct": 2,
      "explanation": "Air transport is fast"
    },
    {
      "question": "Entrepot trade involves?",
      "options": [
        "Only local trade",
        "Only wholesale trade",
        "Only retail trade",
        "Import and re-export of goods"
      ],
      "correct": 3,
      "explanation": "Entrepot is re-export trade"
    },
    {
      "question": "Which of these is a type of life assurance?",
      "options": [
        "Fire policy",
        "Marine policy",
        "Endowment policy",
        "Motor policy"
      ],
      "correct": 2,
      "explanation": "Endowment is a life assurance policy"
    },
    {
      "question": "The document that lists goods in a container is?",
      "options": [
        "Receipt only",
        "Bill of lading only",
        "Invoice only",
        "Packing list"
      ],
      "correct": 3,
      "explanation": "Packing list details the contents"
    },
    {
      "question": "Which of these is an aid to trade?",
      "options": [
        "Farming",
        "Mining",
        "Tourism",
        "Fishing"
      ],
      "correct": 2,
      "explanation": "Tourism can aid trade"
    },
    {
      "question": "A savings account typically offers?",
      "options": [
        "Only cheque facility",
        "Interest on deposits",
        "Overdraft always",
        "No interest"
      ],
      "correct": 1,
      "explanation": "Savings accounts earn interest"
    },
    {
      "question": "Which of these is a function of a retailer?",
      "options": [
        "Providing after-sales service",
        "Importing only",
        "Producing goods",
        "Exporting only"
      ],
      "correct": 0,
      "explanation": "Retailers often provide after-sales service"
    },
    {
      "question": "The insurance principle that requires sharing of loss among insurers is?",
      "options": [
        "Contribution",
        "Utmost good faith",
        "Subrogation",
        "Indemnity"
      ],
      "correct": 0,
      "explanation": "Contribution applies when multiple policies exist"
    },
    {
      "question": "Which of these is a type of home trade?",
      "options": [
        "Entrepot trade",
        "Export trade",
        "Import trade",
        "Wholesale trade"
      ],
      "correct": 3,
      "explanation": "Wholesale is part of home trade"
    },
    {
      "question": "Persuasive advertising aims to?",
      "options": [
        "Only remind",
        "Only compare",
        "Only inform",
        "Convince consumers to buy"
      ],
      "correct": 3,
      "explanation": "Persuasive ads aim to convince"
    },
    {
      "question": "Which of these is a benefit of international trade?",
      "options": [
        "Isolation of countries",
        "Increase in prices always",
        "Reduction in variety",
        "Specialization and efficiency"
      ],
      "correct": 3,
      "explanation": "Trade allows specialization"
    },
    {
      "question": "A consignment note is used in?",
      "options": [
        "Only air transport",
        "Road or rail transport",
        "Only sea transport",
        "Only pipeline"
      ],
      "correct": 1,
      "explanation": "Consignment note is common in road/rail"
    },
    {
      "question": "Which of these is a type of retail cooperative?",
      "options": [
        "Producers' only",
        "Credit only",
        "Housing only",
        "Consumers' cooperative"
      ],
      "correct": 3,
      "explanation": "Consumers' cooperatives engage in retail"
    },
    {
      "question": "The document that demands payment is?",
      "options": [
        "Credit note",
        "Receipt",
        "Debit note",
        "Cheque"
      ],
      "correct": 2,
      "explanation": "Debit note demands payment"
    },
    {
      "question": "Which of these is a function of the Stock Exchange?",
      "options": [
        "Mining",
        "Producing goods",
        "Providing market for securities",
        "Farming"
      ],
      "correct": 2,
      "explanation": "Stock Exchange trades securities"
    },
    {
      "question": "Self-service is a feature of?",
      "options": [
        "Itinerant traders only",
        "Traditional markets only",
        "Supermarkets",
        "Hawkers only"
      ],
      "correct": 2,
      "explanation": "Supermarkets use self-service"
    },
    {
      "question": "Which of these is a type of risk in insurance?",
      "options": [
        "Pure risk",
        "No risk",
        "Certain loss",
        "Speculative risk only"
      ],
      "correct": 0,
      "explanation": "Pure risk is insurable"
    },
    {
      "question": "The process of buying and selling of shares is?",
      "options": [
        "Retailing",
        "Wholesaling",
        "Stockbroking",
        "Manufacturing"
      ],
      "correct": 2,
      "explanation": "Stockbroking deals with shares"
    },
    {
      "question": "Which of these is an advantage of water transport?",
      "options": [
        "Door to door always",
        "No weather effect",
        "Very fast always",
        "Suitable for bulky goods"
      ],
      "correct": 3,
      "explanation": "Water transport suits bulky goods"
    },
    {
      "question": "A proforma invoice is?",
      "options": [
        "A quotation in invoice form",
        "A final invoice",
        "A cheque",
        "A receipt"
      ],
      "correct": 0,
      "explanation": "Proforma is a preliminary invoice"
    },
    {
      "question": "Which of these is a type of advertising appeal?",
      "options": [
        "Hidden appeal only",
        "No appeal",
        "Emotional appeal",
        "Silent appeal"
      ],
      "correct": 2,
      "explanation": "Emotional appeal is common"
    },
    {
      "question": "The middleman who does not take title to goods is?",
      "options": [
        "Wholesaler",
        "Merchant",
        "Retailer",
        "Agent"
      ],
      "correct": 3,
      "explanation": "Agents usually do not take title"
    },
    {
      "question": "Which of these is a document in export trade?",
      "options": [
        "Personal cheque only",
        "Consular invoice",
        "Local cash receipt",
        "Internal memo"
      ],
      "correct": 1,
      "explanation": "Consular invoice is used in exports"
    },
    {
      "question": "Multiple shops are also known as?",
      "options": [
        "Chain stores",
        "Department stores only",
        "Supermarkets only",
        "Hypermarkets only"
      ],
      "correct": 0,
      "explanation": "Chain stores are multiple shops"
    },
    {
      "question": "Which of these is a function of communication in commerce?",
      "options": [
        "Facilitating exchange of information",
        "Storing goods",
        "Producing goods",
        "Insuring goods only"
      ],
      "correct": 0,
      "explanation": "Communication aids information exchange"
    },
    {
      "question": "A current account holder can?",
      "options": [
        "Not withdraw money",
        "Issue cheques",
        "Only save long-term",
        "Only deposit cash"
      ],
      "correct": 1,
      "explanation": "Current accounts allow cheque issue"
    },
    {
      "question": "Which of these is a type of foreign trade document?",
      "options": [
        "Bill of entry",
        "Personal letter",
        "Cash book",
        "Local invoice only"
      ],
      "correct": 0,
      "explanation": "Bill of entry is used in customs"
    },
    {
      "question": "The insurance that covers goods in transit is?",
      "options": [
        "Health insurance",
        "Fire insurance only",
        "Life insurance",
        "Marine or transit insurance"
      ],
      "correct": 3,
      "explanation": "Transit insurance covers goods on the move"
    },
    {
      "question": "Which of these is a modern retail trend?",
      "options": [
        "Only open markets",
        "Only hawkers",
        "Only door-to-door",
        "Online shopping"
      ],
      "correct": 3,
      "explanation": "Online shopping is modern"
    },
    {
      "question": "The document that serves as a contract of affreightment is?",
      "options": [
        "Charter party",
        "Invoice",
        "Cheque",
        "Receipt"
      ],
      "correct": 0,
      "explanation": "Charter party is for hiring a ship"
    },
    {
      "question": "Which of these is a type of cooperative society?",
      "options": [
        "Pressure group",
        "Credit and thrift",
        "Trade union only",
        "Political party"
      ],
      "correct": 1,
      "explanation": "Credit and thrift is a cooperative type"
    },
    {
      "question": "Branding helps to?",
      "options": [
        "Hide the product",
        "Reduce quality",
        "Identify and differentiate products",
        "Increase cost only"
      ],
      "correct": 2,
      "explanation": "Branding identifies products"
    },
    {
      "question": "Which of these is an advantage of rail transport?",
      "options": [
        "Suitable for heavy goods over long distances",
        "No fixed schedule",
        "Door to door always",
        "Very flexible routes"
      ],
      "correct": 0,
      "explanation": "Rail suits heavy long-distance goods"
    },
    {
      "question": "A statement of account is sent by?",
      "options": [
        "Seller to buyer",
        "Government to all",
        "Buyer to seller only",
        "Bank to nobody"
      ],
      "correct": 0,
      "explanation": "Seller sends statement to buyer"
    },
    {
      "question": "Which of these is a type of trade restriction?",
      "options": [
        "Embargo",
        "Open market",
        "No tariff",
        "Free trade"
      ],
      "correct": 0,
      "explanation": "Embargo restricts trade"
    },
    {
      "question": "The process of turning prospects into customers is?",
      "options": [
        "Production",
        "Storage",
        "Selling",
        "Insurance"
      ],
      "correct": 2,
      "explanation": "Selling converts prospects"
    },
    {
      "question": "Which of these is a feature of a good road?",
      "options": [
        "Poor surface",
        "Durability",
        "Narrow always",
        "No drainage"
      ],
      "correct": 1,
      "explanation": "Good roads are durable"
    },
    {
      "question": "An indent is used in?",
      "options": [
        "Import trade",
        "Domestic trade only",
        "Local wholesale only",
        "Local retail only"
      ],
      "correct": 0,
      "explanation": "Indent is an order in import trade"
    },
    {
      "question": "Which of these is a type of media advertising?",
      "options": [
        "Hoe advertising",
        "Radio advertising",
        "Rake advertising",
        "Cutlass advertising"
      ],
      "correct": 1,
      "explanation": "Radio is a media channel"
    },
    {
      "question": "The person who guarantees payment is?",
      "options": [
        "Debtor only",
        "Creditor only",
        "Buyer only",
        "Guarantor"
      ],
      "correct": 3,
      "explanation": "Guarantor stands surety"
    },
    {
      "question": "Which of these is a benefit of advertising to consumers?",
      "options": [
        "Higher prices always",
        "Lower quality always",
        "Information about products",
        "Less choice"
      ],
      "correct": 2,
      "explanation": "Ads provide product information"
    },
    {
      "question": "A bonded warehouse is under the control of?",
      "options": [
        "Private individuals only",
        "Local government only",
        "Customs authority",
        "No authority"
      ],
      "correct": 2,
      "explanation": "Customs control bonded warehouses"
    },
    {
      "question": "Which of these is a type of sea transport vessel?",
      "options": [
        "Goods train",
        "Cargo plane only",
        "Cargo ship",
        "Passenger bus"
      ],
      "correct": 2,
      "explanation": "Cargo ships carry goods by sea"
    },
    {
      "question": "The document that shows the terms of a loan is?",
      "options": [
        "Invoice",
        "Waybill",
        "Loan agreement",
        "Receipt"
      ],
      "correct": 2,
      "explanation": "Loan agreement sets the terms"
    },
    {
      "question": "Which of these is a function of the Nigerian Ports Authority?",
      "options": [
        "Management of railways only",
        "Management of seaports",
        "Management of roads only",
        "Management of airports only"
      ],
      "correct": 1,
      "explanation": "NPA manages seaports"
    },
    {
      "question": "Self-service reduces?",
      "options": [
        "Labour cost for the retailer",
        "Product quality",
        "Sales always",
        "Customer choice"
      ],
      "correct": 0,
      "explanation": "Self-service lowers labour costs"
    },
    {
      "question": "Which of these is a type of risk not usually insured?",
      "options": [
        "Pure risk",
        "Speculative risk",
        "Fire risk",
        "Accident risk"
      ],
      "correct": 1,
      "explanation": "Speculative risks are not ordinarily insured"
    },
    {
      "question": "The process of arranging transport for goods is?",
      "options": [
        "Freight forwarding",
        "Retailing",
        "Wholesaling",
        "Manufacturing"
      ],
      "correct": 0,
      "explanation": "Freight forwarders arrange transport"
    },
    {
      "question": "Which of these is an advantage of pipeline transport?",
      "options": [
        "Suitable for all solids",
        "Suitable for liquids and gases",
        "Very flexible routes",
        "Door to door for all goods"
      ],
      "correct": 1,
      "explanation": "Pipelines suit liquids and gases"
    },
    {
      "question": "A quotation is?",
      "options": [
        "A cheque",
        "A receipt",
        "A statement of price for goods or services",
        "A final invoice"
      ],
      "correct": 2,
      "explanation": "Quotation states the price offer"
    },
    {
      "question": "Which of these is a type of cooperative?",
      "options": [
        "Trade union only",
        "Political party",
        "Pressure group only",
        "Producers' cooperative"
      ],
      "correct": 3,
      "explanation": "Producers' cooperative is a type"
    },
    {
      "question": "After-sales service helps to?",
      "options": [
        "Build customer loyalty",
        "Lower quality",
        "Reduce sales",
        "Increase complaints only"
      ],
      "correct": 0,
      "explanation": "After-sales service builds loyalty"
    },
    {
      "question": "Which of these is a document in rail transport?",
      "options": [
        "Railway consignment note",
        "Bill of lading only",
        "Road waybill only",
        "Air waybill"
      ],
      "correct": 0,
      "explanation": "Railway uses consignment note"
    },
    {
      "question": "The act of selling goods abroad is?",
      "options": [
        "Retailing",
        "Exporting",
        "Wholesaling only",
        "Importing"
      ],
      "correct": 1,
      "explanation": "Exporting is selling abroad"
    },
    {
      "question": "Which of these is a type of advertising according to purpose?",
      "options": [
        "No purpose advertising",
        "Silent advertising",
        "Hidden advertising",
        "Institutional advertising"
      ],
      "correct": 3,
      "explanation": "Institutional advertising promotes the organisation"
    },
    {
      "question": "A factor that affects the choice of transport is?",
      "options": [
        "Nature of the goods",
        "Name of the driver",
        "Age of the vehicle only",
        "Colour of the vehicle only"
      ],
      "correct": 0,
      "explanation": "Nature of goods influences transport choice"
    },
    {
      "question": "Which of these is a commercial activity?",
      "options": [
        "Mining only",
        "Insurance",
        "Farming only",
        "Fishing only"
      ],
      "correct": 1,
      "explanation": "Insurance is a commercial activity"
    },
    {
      "question": "The document that acknowledges a debt is?",
      "options": [
        "Invoice only",
        "Receipt only",
        "Waybill only",
        "Promissory note"
      ],
      "correct": 3,
      "explanation": "Promissory note acknowledges debt"
    },
    {
      "question": "Which of these is an advantage of departmental stores?",
      "options": [
        "One-stop shopping",
        "High prices always",
        "No credit facility ever",
        "Very limited variety"
      ],
      "correct": 0,
      "explanation": "Departmental stores offer many goods under one roof"
    },
    {
      "question": "Subrogation in insurance means?",
      "options": [
        "Insurer takes over the rights of the insured after settlement",
        "Insured profits from loss",
        "No compensation",
        "Double compensation"
      ],
      "correct": 0,
      "explanation": "Subrogation transfers rights to the insurer"
    },
    {
      "question": "Which of these is a type of trade by the nature of goods?",
      "options": [
        "Only service trade",
        "Commodity trade",
        "Only invisible trade",
        "Only entrepot"
      ],
      "correct": 1,
      "explanation": "Commodity trade deals in goods"
    },
    {
      "question": "The process of storing goods until needed is?",
      "options": [
        "Warehousing",
        "Banking",
        "Advertising",
        "Insurance"
      ],
      "correct": 0,
      "explanation": "Warehousing is storage"
    },
    {
      "question": "Which of these is a feature of a good advertisement?",
      "options": [
        "Being boring",
        "Being misleading",
        "Being unclear",
        "Attracting attention"
      ],
      "correct": 3,
      "explanation": "Good ads attract attention"
    },
    {
      "question": "A letter of credit is used in?",
      "options": [
        "Domestic trade only",
        "Local cash sales only",
        "International trade",
        "Local retail only"
      ],
      "correct": 2,
      "explanation": "Letter of credit is common in foreign trade"
    },
    {
      "question": "Which of these is a type of middleman?",
      "options": [
        "Consumer",
        "Producer",
        "Broker",
        "Manufacturer only"
      ],
      "correct": 2,
      "explanation": "Broker is a middleman"
    },
    {
      "question": "The document that shows the route of a ship is?",
      "options": [
        "Cheque",
        "Invoice",
        "Receipt",
        "Shipping note"
      ],
      "correct": 3,
      "explanation": "Shipping note relates to shipment details"
    },
    {
      "question": "Which of these is a benefit of branding?",
      "options": [
        "Reducing quality",
        "Product identification",
        "Hiding the product",
        "Increasing confusion"
      ],
      "correct": 1,
      "explanation": "Branding identifies the product"
    },
    {
      "question": "Containerisation in transport helps to?",
      "options": [
        "Slow down transport",
        "Reduce handling and damage",
        "Increase damage",
        "Increase cost always"
      ],
      "correct": 1,
      "explanation": "Containers reduce handling damage"
    },
    {
      "question": "Which of these is a type of bank advance?",
      "options": [
        "Transfer only",
        "Deposit only",
        "Overdraft",
        "Withdrawal only"
      ],
      "correct": 2,
      "explanation": "Overdraft is a form of bank advance"
    },
    {
      "question": "The act of buying goods from abroad is?",
      "options": [
        "Wholesaling only",
        "Importing",
        "Exporting",
        "Retailing"
      ],
      "correct": 1,
      "explanation": "Importing is buying from abroad"
    },
    {
      "question": "Which of these is a form of sales promotion?",
      "options": [
        "Discounts and free gifts",
        "Only personal selling",
        "Only publicity",
        "Only advertising"
      ],
      "correct": 0,
      "explanation": "Discounts and gifts are sales promotion"
    },
    {
      "question": "A factor that influences the location of a retail shop is?",
      "options": [
        "Poor access",
        "Far from customers",
        "Nearness to customers",
        "No population"
      ],
      "correct": 2,
      "explanation": "Nearness to customers is important"
    },
    {
      "question": "Which of these is a type of insurance according to risk?",
      "options": [
        "Property insurance",
        "Certain loss insurance",
        "Speculative only",
        "No risk insurance"
      ],
      "correct": 0,
      "explanation": "Property insurance covers property risks"
    },
    {
      "question": "The document used to clear goods at the port is?",
      "options": [
        "Internal memo",
        "Personal cheque",
        "Bill of entry",
        "Local receipt"
      ],
      "correct": 2,
      "explanation": "Bill of entry is for customs clearance"
    },
    {
      "question": "Which of these is an advantage of multiple shops?",
      "options": [
        "Economies of scale",
        "High cost always",
        "No brand identity",
        "Limited market"
      ],
      "correct": 0,
      "explanation": "Chain stores enjoy economies of scale"
    },
    {
      "question": "Communication in commerce includes?",
      "options": [
        "Only face to face",
        "Only messengers",
        "Only letters",
        "Telephone and internet"
      ],
      "correct": 3,
      "explanation": "Modern communication includes phone and internet"
    },
    {
      "question": "Which of these is a type of account in a bank?",
      "options": [
        "Waybill account",
        "Receipt account",
        "Invoice account",
        "Domiciliary account"
      ],
      "correct": 3,
      "explanation": "Domiciliary account holds foreign currency"
    },
    {
      "question": "The process of persuading a customer to buy is?",
      "options": [
        "Production",
        "Insurance",
        "Storage",
        "Personal selling"
      ],
      "correct": 3,
      "explanation": "Personal selling involves persuasion"
    },
    {
      "question": "Which of these is a document in road transport?",
      "options": [
        "Railway note only",
        "Waybill",
        "Bill of lading only",
        "Air waybill only"
      ],
      "correct": 1,
      "explanation": "Waybill is used in road transport"
    },
    {
      "question": "A unique feature of hire purchase is?",
      "options": [
        "Ownership passes immediately",
        "Ownership remains with seller until full payment",
        "Goods cannot be used",
        "No payment plan"
      ],
      "correct": 1,
      "explanation": "Ownership transfers after final payment"
    },
    {
      "question": "Which of these is a type of trade association?",
      "options": [
        "Political party",
        "Pressure group only",
        "Trade union only",
        "Chamber of Commerce"
      ],
      "correct": 3,
      "explanation": "Chamber of Commerce is a trade association"
    },
    {
      "question": "The main aim of commerce is to?",
      "options": [
        "Only store goods",
        "Bridge the gap between production and consumption",
        "Only produce goods",
        "Only consume goods"
      ],
      "correct": 1,
      "explanation": "Commerce links production to consumption"
    }
  ],
  "acc": [
    {
      "question": "Accounting is best defined as?",
      "options": [
        "Only trading",
        "Recording, classifying and summarizing financial transactions",
        "Only counting money",
        "Only banking"
      ],
      "correct": 1,
      "explanation": "Accounting records and summarizes financial transactions"
    },
    {
      "question": "The book of original entry is?",
      "options": [
        "Balance sheet",
        "Journal",
        "Trial balance",
        "Ledger"
      ],
      "correct": 1,
      "explanation": "Journal is the book of original entry"
    },
    {
      "question": "Which of these is an asset?",
      "options": [
        "Creditor",
        "Cash",
        "Capital",
        "Loan"
      ],
      "correct": 1,
      "explanation": "Cash is an asset"
    },
    {
      "question": "A liability is?",
      "options": [
        "What the business owns",
        "What the business owes",
        "Capital only",
        "Profit"
      ],
      "correct": 1,
      "explanation": "Liability is what is owed"
    },
    {
      "question": "The accounting equation is?",
      "options": [
        "Assets = Capital + Liabilities",
        "Capital = Assets only",
        "Assets = Liabilities only",
        "Assets = Capital - Liabilities"
      ],
      "correct": 0,
      "explanation": "Assets = Capital + Liabilities"
    },
    {
      "question": "Which of these is a current asset?",
      "options": [
        "Stock",
        "Building",
        "Machinery",
        "Land"
      ],
      "correct": 0,
      "explanation": "Stock is a current asset"
    },
    {
      "question": "A debit entry is recorded on the?",
      "options": [
        "Both sides",
        "Neither side",
        "Right side",
        "Left side"
      ],
      "correct": 3,
      "explanation": "Debit is on the left side"
    },
    {
      "question": "A credit entry is recorded on the?",
      "options": [
        "Neither side",
        "Right side",
        "Both sides",
        "Left side"
      ],
      "correct": 1,
      "explanation": "Credit is on the right side"
    },
    {
      "question": "The trial balance is used to?",
      "options": [
        "Show liabilities only",
        "Check the arithmetic accuracy of the ledger",
        "Show assets only",
        "Calculate profit only"
      ],
      "correct": 1,
      "explanation": "Trial balance checks arithmetic accuracy"
    },
    {
      "question": "Which of these is a fixed asset?",
      "options": [
        "Building",
        "Debtors",
        "Stock",
        "Cash"
      ],
      "correct": 0,
      "explanation": "Building is a fixed asset"
    },
    {
      "question": "Capital is?",
      "options": [
        "Loss only",
        "What the business owes",
        "What the owner invests in the business",
        "Profit only"
      ],
      "correct": 2,
      "explanation": "Capital is the owner's investment"
    },
    {
      "question": "Which of these is a book of account?",
      "options": [
        "Cheque",
        "Receipt",
        "Invoice",
        "Ledger"
      ],
      "correct": 3,
      "explanation": "Ledger is a book of account"
    },
    {
      "question": "The document that shows goods sold on credit is?",
      "options": [
        "Receipt",
        "Cheque",
        "Invoice",
        "Waybill"
      ],
      "correct": 2,
      "explanation": "Invoice is used for credit sales"
    },
    {
      "question": "Which of these is an expense?",
      "options": [
        "Asset",
        "Capital",
        "Liability",
        "Rent"
      ],
      "correct": 3,
      "explanation": "Rent is an expense"
    },
    {
      "question": "Gross profit is?",
      "options": [
        "Sales minus all expenses",
        "Sales minus cost of goods sold",
        "Capital minus liabilities",
        "Assets minus liabilities"
      ],
      "correct": 1,
      "explanation": "Gross profit = Sales - Cost of goods sold"
    },
    {
      "question": "Net profit is?",
      "options": [
        "Assets only",
        "Capital only",
        "Sales only",
        "Gross profit minus expenses"
      ],
      "correct": 3,
      "explanation": "Net profit = Gross profit - Expenses"
    },
    {
      "question": "Which of these is a source document?",
      "options": [
        "Trial balance",
        "Journal",
        "Receipt",
        "Ledger"
      ],
      "correct": 2,
      "explanation": "Receipt is a source document"
    },
    {
      "question": "The balance sheet shows?",
      "options": [
        "Only expenses",
        "Only profit",
        "Only sales",
        "Assets, liabilities and capital"
      ],
      "correct": 3,
      "explanation": "Balance sheet shows financial position"
    },
    {
      "question": "Which of these is a liability?",
      "options": [
        "Creditors",
        "Cash",
        "Stock",
        "Building"
      ],
      "correct": 0,
      "explanation": "Creditors are a liability"
    },
    {
      "question": "Double entry means?",
      "options": [
        "Only debit entries",
        "Only credit entries",
        "Every transaction has debit and credit",
        "No recording"
      ],
      "correct": 2,
      "explanation": "Double entry has both debit and credit"
    },
    {
      "question": "Which of these is a current liability?",
      "options": [
        "Creditors",
        "Long-term loan",
        "Building",
        "Capital"
      ],
      "correct": 0,
      "explanation": "Creditors are current liabilities"
    },
    {
      "question": "Depreciation is?",
      "options": [
        "Fall in the value of fixed assets",
        "Increase in value",
        "Profit",
        "Capital"
      ],
      "correct": 0,
      "explanation": "Depreciation is the fall in value of assets"
    },
    {
      "question": "Which of these is recorded in the cash book?",
      "options": [
        "Only credit sales",
        "Only purchases",
        "Only expenses",
        "Cash and bank transactions"
      ],
      "correct": 3,
      "explanation": "Cash book records cash and bank transactions"
    },
    {
      "question": "The owner of a sole proprietorship is?",
      "options": [
        "The company",
        "The bank",
        "The government",
        "The proprietor"
      ],
      "correct": 3,
      "explanation": "The proprietor owns a sole business"
    },
    {
      "question": "Which of these is a final account?",
      "options": [
        "Invoice",
        "Receipt",
        "Trading, profit and loss account",
        "Cheque"
      ],
      "correct": 2,
      "explanation": "Trading and profit & loss are final accounts"
    },
    {
      "question": "Which of these is a liability?",
      "options": [
        "Stock",
        "Cash",
        "Bank overdraft",
        "Furniture"
      ],
      "correct": 2,
      "explanation": "Bank overdraft is a liability"
    },
    {
      "question": "The journal is also known as?",
      "options": [
        "Balance sheet",
        "Book of original entry",
        "Book of final entry",
        "Trial balance"
      ],
      "correct": 1,
      "explanation": "Journal is the book of original entry"
    },
    {
      "question": "Which of these is an example of a current asset?",
      "options": [
        "Land",
        "Debtors",
        "Machinery",
        "Building"
      ],
      "correct": 1,
      "explanation": "Debtors are current assets"
    },
    {
      "question": "Capital can be increased by?",
      "options": [
        "Drawing cash for personal use",
        "Buying assets on credit",
        "Paying creditors",
        "Additional investment by the owner"
      ],
      "correct": 3,
      "explanation": "Additional investment increases capital"
    },
    {
      "question": "Which of these is recorded on the debit side?",
      "options": [
        "Assets and expenses",
        "Income only",
        "Capital only",
        "Liabilities only"
      ],
      "correct": 0,
      "explanation": "Assets and expenses are debited"
    },
    {
      "question": "The trial balance is prepared from?",
      "options": [
        "Cheques only",
        "Ledger balances",
        "Receipts only",
        "Invoices only"
      ],
      "correct": 1,
      "explanation": "Trial balance is from ledger balances"
    },
    {
      "question": "Which of these is a fixed asset?",
      "options": [
        "Cash",
        "Motor vehicle",
        "Stock",
        "Debtors"
      ],
      "correct": 1,
      "explanation": "Motor vehicle is a fixed asset"
    },
    {
      "question": "Drawings are?",
      "options": [
        "Additional capital",
        "Liability",
        "Profit",
        "Goods or cash taken by the owner for personal use"
      ],
      "correct": 3,
      "explanation": "Drawings are personal withdrawals"
    },
    {
      "question": "Which of these is a source document for credit sales?",
      "options": [
        "Receipt",
        "Sales invoice",
        "Debit note only",
        "Cheque"
      ],
      "correct": 1,
      "explanation": "Sales invoice is for credit sales"
    },
    {
      "question": "Gross profit is calculated in the?",
      "options": [
        "Balance sheet",
        "Trading account",
        "Cash book",
        "Journal only"
      ],
      "correct": 1,
      "explanation": "Trading account shows gross profit"
    },
    {
      "question": "Which of these is an expense?",
      "options": [
        "Debtors",
        "Capital",
        "Creditors",
        "Salaries"
      ],
      "correct": 3,
      "explanation": "Salaries are expenses"
    },
    {
      "question": "The balance sheet is prepared to show?",
      "options": [
        "Only expenses",
        "Financial position",
        "Only profit",
        "Only sales"
      ],
      "correct": 1,
      "explanation": "Balance sheet shows financial position"
    },
    {
      "question": "Which of these is a long-term liability?",
      "options": [
        "Bank loan (long-term)",
        "Creditors",
        "Bank overdraft",
        "Accrued expenses"
      ],
      "correct": 0,
      "explanation": "Long-term bank loan is a long-term liability"
    },
    {
      "question": "Double entry principle states that?",
      "options": [
        "Only debit entries are made",
        "Only credit entries are made",
        "No entries are needed",
        "For every debit there is a corresponding credit"
      ],
      "correct": 3,
      "explanation": "Every debit has a credit"
    },
    {
      "question": "Which of these is a current liability?",
      "options": [
        "Capital",
        "Long-term loan",
        "Building",
        "Accrued expenses"
      ],
      "correct": 3,
      "explanation": "Accrued expenses are current liabilities"
    },
    {
      "question": "Depreciation is charged on?",
      "options": [
        "Liabilities",
        "Capital",
        "Fixed assets",
        "Current assets"
      ],
      "correct": 2,
      "explanation": "Depreciation is on fixed assets"
    },
    {
      "question": "Which of these is recorded in the purchases day book?",
      "options": [
        "Credit sales",
        "Cash purchases",
        "Cash sales",
        "Credit purchases"
      ],
      "correct": 3,
      "explanation": "Purchases day book records credit purchases"
    },
    {
      "question": "The owner of a business is called?",
      "options": [
        "Proprietor",
        "Creditor",
        "Employee",
        "Debtor"
      ],
      "correct": 0,
      "explanation": "The owner is the proprietor"
    },
    {
      "question": "Which of these is a final account?",
      "options": [
        "Profit and loss account",
        "Receipt",
        "Invoice",
        "Cheque"
      ],
      "correct": 0,
      "explanation": "Profit and loss is a final account"
    },
    {
      "question": "Cash book records?",
      "options": [
        "Only credit transactions",
        "Cash and bank transactions",
        "Only non-cash items",
        "Only stock"
      ],
      "correct": 1,
      "explanation": "Cash book is for cash and bank"
    },
    {
      "question": "Which of these increases capital?",
      "options": [
        "Loss",
        "Net profit",
        "Paying expenses",
        "Drawings"
      ],
      "correct": 1,
      "explanation": "Net profit increases capital"
    },
    {
      "question": "A debit note is used to?",
      "options": [
        "Decrease the amount",
        "Increase the amount charged to a customer",
        "Record receipt",
        "Record payment"
      ],
      "correct": 1,
      "explanation": "Debit note increases the amount owed"
    },
    {
      "question": "Which of these is an asset?",
      "options": [
        "Creditors",
        "Capital",
        "Loan",
        "Premises"
      ],
      "correct": 3,
      "explanation": "Premises is an asset"
    },
    {
      "question": "The accounting concept that treats the business as separate from the owner is?",
      "options": [
        "Accrual concept",
        "Going concern",
        "Consistency",
        "Business entity concept"
      ],
      "correct": 3,
      "explanation": "Business entity separates business from owner"
    },
    {
      "question": "Which of these is used to correct errors?",
      "options": [
        "Cash book only",
        "Purchases day book",
        "Sales day book",
        "Journal proper"
      ],
      "correct": 3,
      "explanation": "Journal proper is used for corrections"
    },
    {
      "question": "Which of these is an asset?",
      "options": [
        "Creditors",
        "Capital",
        "Inventory",
        "Loan payable"
      ],
      "correct": 2,
      "explanation": "Inventory is an asset"
    },
    {
      "question": "The ledger is?",
      "options": [
        "A receipt",
        "A source document",
        "The principal book of account",
        "An invoice"
      ],
      "correct": 2,
      "explanation": "Ledger is the principal book"
    },
    {
      "question": "Which of these is a current asset?",
      "options": [
        "Land",
        "Machinery",
        "Building",
        "Prepaid expenses"
      ],
      "correct": 3,
      "explanation": "Prepaid expenses are current assets"
    },
    {
      "question": "Capital decreases when there is?",
      "options": [
        "Revaluation gain",
        "Net loss",
        "Net profit",
        "Additional investment"
      ],
      "correct": 1,
      "explanation": "Net loss decreases capital"
    },
    {
      "question": "Which of these is recorded on the credit side?",
      "options": [
        "Liabilities and income",
        "Assets only",
        "Drawings only",
        "Expenses only"
      ],
      "correct": 0,
      "explanation": "Liabilities and income are credited"
    },
    {
      "question": "The trial balance helps to?",
      "options": [
        "Replace the balance sheet",
        "Calculate tax only",
        "Detect arithmetic errors",
        "Show only assets"
      ],
      "correct": 2,
      "explanation": "Trial balance detects arithmetic errors"
    },
    {
      "question": "Which of these is a fixed asset?",
      "options": [
        "Cash at bank",
        "Equipment",
        "Debtors",
        "Stock"
      ],
      "correct": 1,
      "explanation": "Equipment is a fixed asset"
    },
    {
      "question": "Drawings reduce?",
      "options": [
        "Liabilities",
        "Expenses",
        "Assets only",
        "Capital"
      ],
      "correct": 3,
      "explanation": "Drawings reduce capital"
    },
    {
      "question": "Which of these is a source document for cash sales?",
      "options": [
        "Sales invoice only",
        "Purchase order",
        "Debit note",
        "Cash receipt"
      ],
      "correct": 3,
      "explanation": "Cash receipt is for cash sales"
    },
    {
      "question": "Cost of goods sold is used to calculate?",
      "options": [
        "Only liabilities",
        "Gross profit",
        "Only capital",
        "Only cash"
      ],
      "correct": 1,
      "explanation": "COGS is used for gross profit"
    },
    {
      "question": "Which of these is an expense?",
      "options": [
        "Creditors",
        "Debtors",
        "Capital",
        "Electricity bill"
      ],
      "correct": 3,
      "explanation": "Electricity is an expense"
    },
    {
      "question": "The balance sheet equation is?",
      "options": [
        "Assets = Capital + Liabilities",
        "Assets = Capital - Liabilities",
        "Assets = Liabilities only",
        "Capital = Assets only"
      ],
      "correct": 0,
      "explanation": "Assets equal capital plus liabilities"
    },
    {
      "question": "Which of these is a long-term liability?",
      "options": [
        "Trade creditors",
        "Accrued rent",
        "Mortgage loan",
        "Bank overdraft"
      ],
      "correct": 2,
      "explanation": "Mortgage is long-term"
    },
    {
      "question": "In double entry, every transaction affects?",
      "options": [
        "Only one account",
        "Only cash",
        "At least two accounts",
        "No account"
      ],
      "correct": 2,
      "explanation": "At least two accounts are affected"
    },
    {
      "question": "Which of these is a current liability?",
      "options": [
        "Capital",
        "Long-term loan",
        "Trade payables",
        "Premises"
      ],
      "correct": 2,
      "explanation": "Trade payables are current liabilities"
    },
    {
      "question": "Depreciation is an example of?",
      "options": [
        "Cash expense",
        "Liability",
        "Non-cash expense",
        "Asset"
      ],
      "correct": 2,
      "explanation": "Depreciation is a non-cash expense"
    },
    {
      "question": "Which of these is recorded in the sales day book?",
      "options": [
        "Credit purchases",
        "Cash purchases",
        "Credit sales",
        "Cash sales"
      ],
      "correct": 2,
      "explanation": "Sales day book records credit sales"
    },
    {
      "question": "The person to whom the business owes money is?",
      "options": [
        "Creditor",
        "Debtor",
        "Employee",
        "Proprietor"
      ],
      "correct": 0,
      "explanation": "Creditor is owed money"
    },
    {
      "question": "Which of these is a final account?",
      "options": [
        "Balance sheet",
        "Receipt",
        "Invoice",
        "Cheque"
      ],
      "correct": 0,
      "explanation": "Balance sheet is a final account"
    },
    {
      "question": "Petty cash book is used for?",
      "options": [
        "Large payments only",
        "Credit transactions only",
        "Small cash payments",
        "Bank transactions only"
      ],
      "correct": 2,
      "explanation": "Petty cash is for small payments"
    },
    {
      "question": "Which of these increases assets?",
      "options": [
        "Paying expenses",
        "Drawings",
        "Payment to creditors",
        "Purchase of goods for cash"
      ],
      "correct": 3,
      "explanation": "Buying goods increases stock (asset)"
    },
    {
      "question": "A credit note is used to?",
      "options": [
        "Record receipt of cash",
        "Increase the amount",
        "Record payment",
        "Reduce the amount charged to a customer"
      ],
      "correct": 3,
      "explanation": "Credit note reduces the amount owed"
    },
    {
      "question": "Which of these is an asset?",
      "options": [
        "Loan",
        "Creditors",
        "Cash at bank",
        "Capital"
      ],
      "correct": 2,
      "explanation": "Cash at bank is an asset"
    },
    {
      "question": "The going concern concept assumes that?",
      "options": [
        "The business will continue operating",
        "The business has no assets",
        "The business has no liabilities",
        "The business will close soon"
      ],
      "correct": 0,
      "explanation": "Going concern assumes continuity"
    },
    {
      "question": "Which of these is used to record rare transactions?",
      "options": [
        "Cash book only",
        "Journal proper",
        "Sales day book",
        "Purchases day book"
      ],
      "correct": 1,
      "explanation": "Journal proper records rare transactions"
    },
    {
      "question": "Which of these is an example of a current liability?",
      "options": [
        "Premises",
        "Capital",
        "Long-term loan",
        "Trade creditors"
      ],
      "correct": 3,
      "explanation": "Trade creditors are current liabilities"
    },
    {
      "question": "The ledger is?",
      "options": [
        "Source document",
        "Book of original entry only",
        "Invoice",
        "Book of final entry"
      ],
      "correct": 3,
      "explanation": "Ledger is the book of final entry"
    },
    {
      "question": "Which of these is a non-current asset?",
      "options": [
        "Cash",
        "Stock",
        "Debtors",
        "Land and buildings"
      ],
      "correct": 3,
      "explanation": "Land and buildings are non-current assets"
    },
    {
      "question": "Capital decreases when?",
      "options": [
        "There is a net profit",
        "There is a net loss",
        "Owner invests more",
        "Assets increase"
      ],
      "correct": 1,
      "explanation": "Net loss reduces capital"
    },
    {
      "question": "Which of these is recorded on the credit side?",
      "options": [
        "Liabilities and income",
        "Expenses only",
        "Drawings only",
        "Assets only"
      ],
      "correct": 0,
      "explanation": "Liabilities and income are credited"
    },
    {
      "question": "A trial balance will not balance if?",
      "options": [
        "No transactions occurred",
        "There is an error of commission",
        "All entries are correct",
        "Double entry is complete"
      ],
      "correct": 1,
      "explanation": "Some errors do not affect the trial balance, but others do"
    },
    {
      "question": "Which of these is a tangible asset?",
      "options": [
        "Machinery",
        "Patent",
        "Goodwill",
        "Trademark"
      ],
      "correct": 0,
      "explanation": "Machinery is tangible"
    },
    {
      "question": "Drawings are deducted from?",
      "options": [
        "Assets only",
        "Expenses",
        "Liabilities",
        "Capital"
      ],
      "correct": 3,
      "explanation": "Drawings reduce capital"
    },
    {
      "question": "Which of these is a source document for cash sales?",
      "options": [
        "Credit note",
        "Sales invoice only",
        "Debit note",
        "Cash receipt"
      ],
      "correct": 3,
      "explanation": "Cash receipt is for cash sales"
    },
    {
      "question": "Net profit is transferred to?",
      "options": [
        "Liability account only",
        "Capital account",
        "Expense account",
        "Asset account only"
      ],
      "correct": 1,
      "explanation": "Net profit is added to capital"
    },
    {
      "question": "Which of these is a direct expense?",
      "options": [
        "Rent of office",
        "Carriage inwards",
        "Salaries of office staff",
        "Advertising"
      ],
      "correct": 1,
      "explanation": "Carriage inwards is a direct expense"
    },
    {
      "question": "The balance sheet equation is based on?",
      "options": [
        "No entry",
        "Single entry only",
        "Memorandum only",
        "Double entry principle"
      ],
      "correct": 3,
      "explanation": "Balance sheet follows double entry"
    },
    {
      "question": "Which of these is a long-term liability?",
      "options": [
        "Trade creditors",
        "Accrued rent",
        "Bank overdraft",
        "Debentures"
      ],
      "correct": 3,
      "explanation": "Debentures are long-term"
    },
    {
      "question": "An error of omission occurs when?",
      "options": [
        "Entries are reversed",
        "A transaction is completely left out",
        "Wrong amount is recorded",
        "Wrong account is used"
      ],
      "correct": 1,
      "explanation": "Omission means the transaction is not recorded"
    },
    {
      "question": "Which of these is a current asset?",
      "options": [
        "Building",
        "Motor vehicle",
        "Prepaid expenses",
        "Machinery"
      ],
      "correct": 2,
      "explanation": "Prepaid expenses are current assets"
    },
    {
      "question": "Depreciation is an example of?",
      "options": [
        "Asset",
        "Liability",
        "Cash expense",
        "Non-cash expense"
      ],
      "correct": 3,
      "explanation": "Depreciation does not involve cash outflow"
    },
    {
      "question": "Which of these is recorded in the sales day book?",
      "options": [
        "Cash purchases",
        "Credit purchases",
        "Credit sales",
        "Cash sales"
      ],
      "correct": 2,
      "explanation": "Sales day book records credit sales"
    },
    {
      "question": "The person to whom money is owed is?",
      "options": [
        "Proprietor",
        "Employee",
        "Creditor",
        "Debtor"
      ],
      "correct": 2,
      "explanation": "Creditor is owed money"
    },
    {
      "question": "Which of these is a final account?",
      "options": [
        "Cheque",
        "Balance sheet",
        "Receipt",
        "Invoice"
      ],
      "correct": 1,
      "explanation": "Balance sheet is a final account"
    },
    {
      "question": "A bank reconciliation statement is prepared to?",
      "options": [
        "Show assets only",
        "Calculate profit",
        "Agree cash book with bank statement",
        "Show liabilities only"
      ],
      "correct": 2,
      "explanation": "It reconciles cash book and bank statement"
    },
    {
      "question": "Which of these reduces capital?",
      "options": [
        "Net profit",
        "Drawings",
        "Additional investment",
        "Revaluation gain"
      ],
      "correct": 1,
      "explanation": "Drawings reduce capital"
    },
    {
      "question": "A credit note is issued when?",
      "options": [
        "Goods are purchased",
        "Goods are returned by a customer",
        "Goods are sold",
        "Payment is made"
      ],
      "correct": 1,
      "explanation": "Credit note is for returns inwards"
    },
    {
      "question": "Which of these is an intangible asset?",
      "options": [
        "Stock",
        "Goodwill",
        "Furniture",
        "Cash"
      ],
      "correct": 1,
      "explanation": "Goodwill is intangible"
    },
    {
      "question": "The going concern concept assumes that?",
      "options": [
        "The business has no assets",
        "The business will continue operating",
        "The business has no liabilities",
        "The business will close soon"
      ],
      "correct": 1,
      "explanation": "Going concern assumes continuity"
    },
    {
      "question": "Which of these is used to record rare transactions?",
      "options": [
        "Purchases day book",
        "Cash book only",
        "Sales day book",
        "Journal proper"
      ],
      "correct": 3,
      "explanation": "Journal proper records uncommon transactions"
    },
    {
      "question": "Which of these is an example of a non-current liability?",
      "options": [
        "Long-term bank loan",
        "Trade creditors",
        "Accrued expenses",
        "Bank overdraft"
      ],
      "correct": 0,
      "explanation": "Long-term loan is non-current"
    },
    {
      "question": "The sales ledger contains accounts of?",
      "options": [
        "Creditors",
        "Expenses only",
        "Assets only",
        "Debtors"
      ],
      "correct": 3,
      "explanation": "Sales ledger is for debtors"
    },
    {
      "question": "Which of these is a real account?",
      "options": [
        "Rent account",
        "Furniture account",
        "Salaries account",
        "Commission account"
      ],
      "correct": 1,
      "explanation": "Furniture is a real account"
    },
    {
      "question": "Capital is increased by?",
      "options": [
        "Drawings only",
        "Net profit and additional investment",
        "Paying liabilities",
        "Net loss"
      ],
      "correct": 1,
      "explanation": "Profit and extra investment increase capital"
    },
    {
      "question": "Which of these is recorded in the journal proper?",
      "options": [
        "Cash transactions only",
        "Correction of errors",
        "Credit purchases only",
        "Credit sales only"
      ],
      "correct": 1,
      "explanation": "Journal proper is for corrections and rare entries"
    },
    {
      "question": "A trial balance is a?",
      "options": [
        "Final account",
        "List of ledger balances",
        "Invoice",
        "Source document"
      ],
      "correct": 1,
      "explanation": "Trial balance lists ledger balances"
    },
    {
      "question": "Which of these is a nominal account?",
      "options": [
        "Wages account",
        "Debtors account",
        "Cash account",
        "Bank account"
      ],
      "correct": 0,
      "explanation": "Wages is a nominal account"
    },
    {
      "question": "Prepaid rent is?",
      "options": [
        "An expense",
        "A liability",
        "A capital item",
        "A current asset"
      ],
      "correct": 3,
      "explanation": "Prepaid rent is a current asset"
    },
    {
      "question": "Which of these is a source document for purchases returns?",
      "options": [
        "Credit note received",
        "Receipt",
        "Sales invoice",
        "Debit note received"
      ],
      "correct": 0,
      "explanation": "Credit note is received for returns outwards"
    },
    {
      "question": "Gross loss occurs when?",
      "options": [
        "Expenses are low",
        "Cost of goods sold exceeds sales",
        "Capital is high",
        "Sales exceed cost of goods sold"
      ],
      "correct": 1,
      "explanation": "Gross loss when COGS > Sales"
    },
    {
      "question": "Which of these is an indirect expense?",
      "options": [
        "Carriage inwards",
        "Purchases",
        "Office rent",
        "Wages of factory workers"
      ],
      "correct": 2,
      "explanation": "Office rent is indirect"
    },
    {
      "question": "The balance sheet shows the position as at?",
      "options": [
        "A period of time",
        "Only the beginning of the year",
        "Only the end of the month",
        "A particular date"
      ],
      "correct": 3,
      "explanation": "Balance sheet is at a point in time"
    },
    {
      "question": "Which of these is a current liability?",
      "options": [
        "Bills payable",
        "Premises",
        "Long-term loan",
        "Capital"
      ],
      "correct": 0,
      "explanation": "Bills payable are current"
    },
    {
      "question": "An error of principle occurs when?",
      "options": [
        "Wrong amount is used",
        "Transaction is omitted",
        "An item is posted to the wrong class of account",
        "Entries are reversed"
      ],
      "correct": 2,
      "explanation": "Error of principle is wrong class of account"
    },
    {
      "question": "Which of these is a current asset?",
      "options": [
        "Bills receivable",
        "Building",
        "Motor vehicle",
        "Machinery"
      ],
      "correct": 0,
      "explanation": "Bills receivable are current assets"
    },
    {
      "question": "Accumulated depreciation is?",
      "options": [
        "A capital item",
        "A contra asset",
        "A liability",
        "An expense"
      ],
      "correct": 1,
      "explanation": "Accumulated depreciation reduces the asset"
    },
    {
      "question": "Which of these is recorded in the returns inwards book?",
      "options": [
        "Goods returned to suppliers",
        "Cash sales",
        "Goods returned by customers",
        "Credit purchases"
      ],
      "correct": 2,
      "explanation": "Returns inwards are from customers"
    },
    {
      "question": "The person who owes money to the business is?",
      "options": [
        "Employee",
        "Debtor",
        "Creditor",
        "Proprietor"
      ],
      "correct": 1,
      "explanation": "Debtor owes the business"
    },
    {
      "question": "Which of these is a final account?",
      "options": [
        "Invoice",
        "Trading account",
        "Cheque",
        "Receipt"
      ],
      "correct": 1,
      "explanation": "Trading account is a final account"
    },
    {
      "question": "Bank reconciliation is necessary because of?",
      "options": [
        "Only asset valuation",
        "Only liability measurement",
        "Timing differences and errors",
        "Only profit calculation"
      ],
      "correct": 2,
      "explanation": "Timing differences and errors cause differences"
    },
    {
      "question": "Which of these increases assets and capital?",
      "options": [
        "Payment of expenses",
        "Introduction of additional capital in cash",
        "Drawings of cash",
        "Payment of creditors"
      ],
      "correct": 1,
      "explanation": "Cash introduced increases both"
    },
    {
      "question": "A debit note is sent by?",
      "options": [
        "Seller to buyer when undercharged",
        "Buyer to seller always",
        "Bank to customer",
        "Government to all"
      ],
      "correct": 0,
      "explanation": "Seller sends debit note if undercharged"
    },
    {
      "question": "Which of these is an intangible asset?",
      "options": [
        "Cash",
        "Furniture",
        "Stock",
        "Patent"
      ],
      "correct": 3,
      "explanation": "Patent is intangible"
    },
    {
      "question": "The consistency concept requires?",
      "options": [
        "Same accounting methods over time",
        "Changing methods every year",
        "Different methods for each transaction",
        "No methods"
      ],
      "correct": 0,
      "explanation": "Consistency means same methods"
    },
    {
      "question": "Which of these is used for adjusting entries?",
      "options": [
        "Sales day book",
        "Cash book only",
        "Purchases day book",
        "Journal proper"
      ],
      "correct": 3,
      "explanation": "Journal proper is used for adjustments"
    },
    {
      "question": "Carriage outwards is?",
      "options": [
        "A liability",
        "A selling expense",
        "A direct cost",
        "An asset"
      ],
      "correct": 1,
      "explanation": "Carriage outwards is a selling expense"
    },
    {
      "question": "Which of these is a personal account?",
      "options": [
        "Furniture account",
        "Debtors account",
        "Wages account",
        "Cash account"
      ],
      "correct": 1,
      "explanation": "Debtors account is personal"
    },
    {
      "question": "Accrued expenses are?",
      "options": [
        "Expenses paid in advance",
        "Expenses incurred but not yet paid",
        "Capital",
        "Assets"
      ],
      "correct": 1,
      "explanation": "Accrued expenses are outstanding"
    },
    {
      "question": "Which of these is a source document for bank transactions?",
      "options": [
        "Bank statement",
        "Purchases invoice",
        "Credit note",
        "Sales invoice"
      ],
      "correct": 0,
      "explanation": "Bank statement shows bank transactions"
    },
    {
      "question": "Net loss is deducted from?",
      "options": [
        "Assets only",
        "Expenses",
        "Liabilities",
        "Capital"
      ],
      "correct": 3,
      "explanation": "Net loss reduces capital"
    },
    {
      "question": "Which of these is a direct cost?",
      "options": [
        "Rent of office",
        "Office salaries",
        "Direct materials",
        "Advertising"
      ],
      "correct": 2,
      "explanation": "Direct materials are direct costs"
    },
    {
      "question": "The matching concept requires?",
      "options": [
        "Only liability recording",
        "Only cash recording",
        "Only asset recording",
        "Expenses to be matched with related revenues"
      ],
      "correct": 3,
      "explanation": "Matching matches expenses to revenues"
    },
    {
      "question": "Which of these is a long-term asset?",
      "options": [
        "Stock",
        "Cash",
        "Debtors",
        "Plant and machinery"
      ],
      "correct": 3,
      "explanation": "Plant and machinery is long-term"
    },
    {
      "question": "An error of commission occurs when?",
      "options": [
        "Wrong amount is used",
        "Wrong personal account is used",
        "Transaction is omitted",
        "Wrong class of account is used"
      ],
      "correct": 1,
      "explanation": "Commission is wrong personal account"
    },
    {
      "question": "Which of these is a current asset?",
      "options": [
        "Land",
        "Motor vehicle",
        "Closing stock",
        "Building"
      ],
      "correct": 2,
      "explanation": "Closing stock is a current asset"
    },
    {
      "question": "Provision for doubtful debts is?",
      "options": [
        "A reduction in debtors",
        "A liability",
        "An increase in debtors",
        "A capital item"
      ],
      "correct": 0,
      "explanation": "It reduces the value of debtors"
    },
    {
      "question": "Which of these is recorded in the returns outwards book?",
      "options": [
        "Credit sales",
        "Goods returned to suppliers",
        "Cash purchases",
        "Goods returned by customers"
      ],
      "correct": 1,
      "explanation": "Returns outwards are to suppliers"
    },
    {
      "question": "The owner of a partnership is called?",
      "options": [
        "Shareholder only",
        "Partner",
        "Sole proprietor",
        "Director only"
      ],
      "correct": 1,
      "explanation": "Partners own a partnership"
    },
    {
      "question": "Which of these is a final account for a sole trader?",
      "options": [
        "Invoice",
        "Profit and loss account",
        "Receipt",
        "Cheque"
      ],
      "correct": 1,
      "explanation": "Profit and loss is a final account"
    },
    {
      "question": "A dishonoured cheque is?",
      "options": [
        "A cash payment",
        "A bank draft",
        "A cheque rejected by the bank",
        "A valid cheque"
      ],
      "correct": 2,
      "explanation": "Dishonoured cheque is not paid by the bank"
    },
    {
      "question": "Which of these reduces assets and capital?",
      "options": [
        "Drawings of stock",
        "Net profit",
        "Revaluation gain",
        "Additional capital"
      ],
      "correct": 0,
      "explanation": "Drawings reduce assets and capital"
    },
    {
      "question": "A credit note is sent by?",
      "options": [
        "Government to all",
        "Buyer to seller always",
        "Seller to buyer when overcharged or for returns",
        "Bank to customer"
      ],
      "correct": 2,
      "explanation": "Seller issues credit note for returns or overcharge"
    },
    {
      "question": "Which of these is a tangible non-current asset?",
      "options": [
        "Patent",
        "Goodwill",
        "Trademark",
        "Motor vehicle"
      ],
      "correct": 3,
      "explanation": "Motor vehicle is tangible"
    },
    {
      "question": "The materiality concept allows?",
      "options": [
        "Only large items",
        "Ignoring insignificant items",
        "Recording every small item in detail always",
        "No recording"
      ],
      "correct": 1,
      "explanation": "Materiality permits ignoring trivial items"
    },
    {
      "question": "Which of these is used to open the books?",
      "options": [
        "Opening journal entries",
        "Cash book only",
        "Purchases day book",
        "Sales day book"
      ],
      "correct": 0,
      "explanation": "Opening entries start the books"
    },
    {
      "question": "Carriage inwards is added to?",
      "options": [
        "Purchases",
        "Capital",
        "Expenses only",
        "Sales"
      ],
      "correct": 0,
      "explanation": "Carriage inwards is part of cost of purchases"
    },
    {
      "question": "Which of these is a real account?",
      "options": [
        "Rent account",
        "Building account",
        "Salaries account",
        "Discount account"
      ],
      "correct": 1,
      "explanation": "Building is a real account"
    },
    {
      "question": "Unearned income is?",
      "options": [
        "An asset",
        "A capital item",
        "An expense",
        "A liability"
      ],
      "correct": 3,
      "explanation": "Unearned income is a liability"
    },
    {
      "question": "Which of these is a source document for credit purchases?",
      "options": [
        "Receipt",
        "Purchases invoice",
        "Cheque",
        "Sales invoice"
      ],
      "correct": 1,
      "explanation": "Purchases invoice is for credit purchases"
    },
    {
      "question": "Net profit is?",
      "options": [
        "Capital less drawings",
        "Assets less liabilities",
        "Gross profit less expenses",
        "Sales less purchases"
      ],
      "correct": 2,
      "explanation": "Net profit = Gross profit − Expenses"
    },
    {
      "question": "Which of these is an overhead expense?",
      "options": [
        "Direct materials",
        "Factory rent",
        "Direct labour",
        "Direct expenses"
      ],
      "correct": 1,
      "explanation": "Factory rent is an overhead"
    },
    {
      "question": "The dual aspect concept is the basis of?",
      "options": [
        "Single entry",
        "Double entry bookkeeping",
        "No entry",
        "Memorandum records only"
      ],
      "correct": 1,
      "explanation": "Dual aspect underlies double entry"
    },
    {
      "question": "Which of these is a non-current asset?",
      "options": [
        "Bank",
        "Equipment",
        "Debtors",
        "Stock"
      ],
      "correct": 1,
      "explanation": "Equipment is non-current"
    },
    {
      "question": "A compensating error is one that?",
      "options": [
        "Is never corrected",
        "Is always detected by trial balance",
        "Cancels out another error",
        "Affects only one account"
      ],
      "correct": 2,
      "explanation": "Compensating errors cancel each other"
    },
    {
      "question": "Which of these is a current asset?",
      "options": [
        "Land",
        "Plant",
        "Building",
        "Marketable securities"
      ],
      "correct": 3,
      "explanation": "Marketable securities are current"
    },
    {
      "question": "Bad debts are?",
      "options": [
        "Debts that cannot be recovered",
        "Debts that are paid",
        "Liabilities that decrease",
        "Assets that increase"
      ],
      "correct": 0,
      "explanation": "Bad debts are irrecoverable"
    },
    {
      "question": "Which of these is recorded in the journal?",
      "options": [
        "Only cash sales",
        "Only credit purchases",
        "Only bank transactions",
        "Opening entries"
      ],
      "correct": 3,
      "explanation": "Opening entries go through the journal"
    },
    {
      "question": "The proprietor of a business is entitled to?",
      "options": [
        "Capital and profit",
        "Only interest",
        "Only salary",
        "Only rent"
      ],
      "correct": 0,
      "explanation": "Owner gets capital and profit"
    },
    {
      "question": "Which of these is a final account?",
      "options": [
        "Invoice",
        "Receipt",
        "Income statement",
        "Cheque"
      ],
      "correct": 2,
      "explanation": "Income statement is a final account"
    },
    {
      "question": "A bank draft is?",
      "options": [
        "A cash payment",
        "A personal cheque",
        "A cheque drawn by a bank on itself",
        "A credit note"
      ],
      "correct": 2,
      "explanation": "Bank draft is drawn by the bank"
    },
    {
      "question": "Which of these increases assets and liabilities?",
      "options": [
        "Drawings",
        "Purchase of goods on credit",
        "Payment of creditors",
        "Cash sales"
      ],
      "correct": 1,
      "explanation": "Credit purchase increases stock and creditors"
    },
    {
      "question": "A statement of affairs is used in?",
      "options": [
        "Single entry system",
        "Final accounts only",
        "Source documents only",
        "Double entry only"
      ],
      "correct": 0,
      "explanation": "Statement of affairs is used when records are incomplete"
    },
    {
      "question": "Which of these is an intangible asset?",
      "options": [
        "Cash",
        "Stock",
        "Copyright",
        "Furniture"
      ],
      "correct": 2,
      "explanation": "Copyright is intangible"
    },
    {
      "question": "The prudence concept requires?",
      "options": [
        "To record only gains",
        "To ignore losses",
        "Not to overstate assets or profits",
        "To overstate profits"
      ],
      "correct": 2,
      "explanation": "Prudence means caution in reporting"
    },
    {
      "question": "Which of these is used for year-end adjustments?",
      "options": [
        "Journal proper",
        "Cash book only",
        "Purchases day book",
        "Sales day book"
      ],
      "correct": 0,
      "explanation": "Adjustments are made through journal proper"
    },
    {
      "question": "Discount allowed is?",
      "options": [
        "An income",
        "An expense",
        "An asset",
        "A liability"
      ],
      "correct": 1,
      "explanation": "Discount allowed is an expense"
    },
    {
      "question": "Which of these is a personal account?",
      "options": [
        "Building account",
        "Cash account",
        "Creditors account",
        "Wages account"
      ],
      "correct": 2,
      "explanation": "Creditors account is personal"
    },
    {
      "question": "Income received in advance is?",
      "options": [
        "An asset",
        "A liability",
        "An expense",
        "A capital item"
      ],
      "correct": 1,
      "explanation": "Income received in advance is a liability"
    },
    {
      "question": "Which of these is a source document?",
      "options": [
        "Trial balance",
        "Journal",
        "Ledger",
        "Payment voucher"
      ],
      "correct": 3,
      "explanation": "Payment voucher is a source document"
    },
    {
      "question": "Gross profit percentage is?",
      "options": [
        "Gross profit divided by sales times 100",
        "Expenses divided by sales",
        "Net profit divided by sales",
        "Capital divided by assets"
      ],
      "correct": 0,
      "explanation": "Gross profit % = (GP/Sales) × 100"
    },
    {
      "question": "Which of these is a production cost?",
      "options": [
        "Advertising",
        "Direct labour",
        "Office salaries",
        "Delivery van expenses"
      ],
      "correct": 1,
      "explanation": "Direct labour is a production cost"
    },
    {
      "question": "The separate entity concept means?",
      "options": [
        "No assets",
        "No capital",
        "Business is distinct from the owner",
        "Business and owner are the same"
      ],
      "correct": 2,
      "explanation": "Business is separate from owner"
    },
    {
      "question": "Which of these is a non-current asset?",
      "options": [
        "Bank balance",
        "Debtors",
        "Stock",
        "Furniture and fittings"
      ],
      "correct": 3,
      "explanation": "Furniture is non-current"
    },
    {
      "question": "A trial balance helps to detect?",
      "options": [
        "Arithmetic errors in the ledger",
        "Only errors of principle",
        "Only errors of omission",
        "All types of errors"
      ],
      "correct": 0,
      "explanation": "It detects many arithmetic errors"
    },
    {
      "question": "Which of these is a current asset?",
      "options": [
        "Inventory",
        "Land",
        "Building",
        "Plant"
      ],
      "correct": 0,
      "explanation": "Inventory is a current asset"
    },
    {
      "question": "Provision for depreciation is?",
      "options": [
        "A capital item",
        "Charged to profit and loss account",
        "A liability",
        "An asset"
      ],
      "correct": 1,
      "explanation": "Depreciation is an expense in P&L"
    },
    {
      "question": "Which of these is recorded in the cash book?",
      "options": [
        "Credit sales only",
        "Credit purchases only",
        "Cash sales",
        "Non-cash expenses only"
      ],
      "correct": 2,
      "explanation": "Cash sales go through cash book"
    },
    {
      "question": "The residual value of an asset is?",
      "options": [
        "Estimated value at the end of useful life",
        "Depreciation to date",
        "Current market value only",
        "Original cost"
      ],
      "correct": 0,
      "explanation": "Residual value is the scrap value"
    },
    {
      "question": "Which of these is a final account?",
      "options": [
        "Receipt",
        "Statement of financial position",
        "Invoice",
        "Cheque"
      ],
      "correct": 1,
      "explanation": "Statement of financial position is the balance sheet"
    },
    {
      "question": "A post-dated cheque is?",
      "options": [
        "A cheque with a future date",
        "A cheque already paid",
        "A dishonoured cheque",
        "A bank draft"
      ],
      "correct": 0,
      "explanation": "Post-dated has a future date"
    },
    {
      "question": "Which of these increases capital?",
      "options": [
        "Net loss",
        "Drawings",
        "Payment of expenses",
        "Revaluation of assets upward"
      ],
      "correct": 3,
      "explanation": "Upward revaluation increases capital"
    },
    {
      "question": "A journal entry has?",
      "options": [
        "Debit and credit aspects",
        "Only credit",
        "No aspects",
        "Only debit"
      ],
      "correct": 0,
      "explanation": "Journal entries have both debit and credit"
    },
    {
      "question": "Which of these is an intangible asset?",
      "options": [
        "Stock",
        "Cash",
        "Furniture",
        "Trademark"
      ],
      "correct": 3,
      "explanation": "Trademark is intangible"
    },
    {
      "question": "The historical cost concept means?",
      "options": [
        "Assets are recorded at cost",
        "Assets are not recorded",
        "Assets are recorded at residual value",
        "Assets are recorded at market value always"
      ],
      "correct": 0,
      "explanation": "Historical cost uses original cost"
    },
    {
      "question": "Which of these is used to close the books?",
      "options": [
        "Cash book only",
        "Closing journal entries",
        "Purchases day book",
        "Sales day book"
      ],
      "correct": 1,
      "explanation": "Closing entries close the temporary accounts"
    },
    {
      "question": "Discount received is?",
      "options": [
        "An expense",
        "A liability",
        "An asset",
        "An income"
      ],
      "correct": 3,
      "explanation": "Discount received is an income"
    },
    {
      "question": "Which of these is a personal account?",
      "options": [
        "Bank account",
        "Wages account",
        "Rent account",
        "Furniture account"
      ],
      "correct": 0,
      "explanation": "Bank account is personal"
    },
    {
      "question": "Accrued income is?",
      "options": [
        "An expense",
        "An asset",
        "A liability",
        "A capital item"
      ],
      "correct": 1,
      "explanation": "Accrued income is an asset"
    },
    {
      "question": "Which of these is a source document for payments?",
      "options": [
        "Cheque counterfoil",
        "Sales invoice",
        "Credit note",
        "Purchases invoice"
      ],
      "correct": 0,
      "explanation": "Cheque counterfoil records payments"
    },
    {
      "question": "Rate of stock turnover is?",
      "options": [
        "Sales divided by purchases",
        "Gross profit divided by sales",
        "Cost of goods sold divided by average stock",
        "Net profit divided by capital"
      ],
      "correct": 2,
      "explanation": "Stock turnover = COGS / Average stock"
    },
    {
      "question": "Which of these is a period cost?",
      "options": [
        "Direct materials",
        "Direct expenses",
        "Administrative expenses",
        "Direct labour"
      ],
      "correct": 2,
      "explanation": "Administrative expenses are period costs"
    },
    {
      "question": "The money measurement concept means?",
      "options": [
        "Only transactions measurable in money are recorded",
        "No transactions are recorded",
        "Only non-money items are recorded",
        "All events are recorded"
      ],
      "correct": 0,
      "explanation": "Only money-measurable items are recorded"
    },
    {
      "question": "Which of these is a non-current asset?",
      "options": [
        "Stock",
        "Office equipment",
        "Debtors",
        "Cash at bank"
      ],
      "correct": 1,
      "explanation": "Office equipment is non-current"
    },
    {
      "question": "A suspense account is used when?",
      "options": [
        "Final accounts are prepared",
        "All accounts balance",
        "No errors exist",
        "Trial balance does not agree"
      ],
      "correct": 3,
      "explanation": "Suspense holds the difference temporarily"
    },
    {
      "question": "Which of these is a current asset?",
      "options": [
        "Short-term investments",
        "Plant and machinery",
        "Land",
        "Building"
      ],
      "correct": 0,
      "explanation": "Short-term investments are current"
    },
    {
      "question": "Depreciation methods include?",
      "options": [
        "Straight line and reducing balance",
        "Only no depreciation",
        "Only revaluation upward",
        "Only increasing balance"
      ],
      "correct": 0,
      "explanation": "Straight line and reducing balance are common methods"
    },
    {
      "question": "Which of these is recorded in the petty cash book?",
      "options": [
        "Credit purchases",
        "Bank transfers only",
        "Small cash payments",
        "Large credit sales"
      ],
      "correct": 2,
      "explanation": "Petty cash is for small payments"
    },
    {
      "question": "The useful life of an asset is?",
      "options": [
        "Market value period",
        "Residual value period",
        "Original cost period",
        "Estimated period of use"
      ],
      "correct": 3,
      "explanation": "Useful life is the estimated period of use"
    },
    {
      "question": "Which of these is a final account?",
      "options": [
        "Cheque",
        "Receipt",
        "Invoice",
        "Cash flow statement"
      ],
      "correct": 3,
      "explanation": "Cash flow statement is a final account"
    },
    {
      "question": "A stale cheque is?",
      "options": [
        "A bank draft",
        "A cheque presented after six months",
        "A valid cheque",
        "A post-dated cheque"
      ],
      "correct": 1,
      "explanation": "Stale cheque is outdated"
    },
    {
      "question": "Which of these decreases capital?",
      "options": [
        "Net loss and drawings",
        "Net profit",
        "Revaluation gain",
        "Additional investment"
      ],
      "correct": 0,
      "explanation": "Loss and drawings reduce capital"
    }
  ],
  "gov": [
    {
      "question": "Government as an institution refers to?",
      "options": [
        "A private company",
        "A school",
        "The body that makes and enforces laws",
        "A market"
      ],
      "correct": 2,
      "explanation": "Government makes and enforces laws"
    },
    {
      "question": "Which of these is a function of government?",
      "options": [
        "Maintenance of law and order",
        "Dancing",
        "Playing football",
        "Selling goods only"
      ],
      "correct": 0,
      "explanation": "Government maintains law and order"
    },
    {
      "question": "Democracy is a system of government where?",
      "options": [
        "There is no government",
        "The army rules",
        "One person rules forever",
        "Power belongs to the people"
      ],
      "correct": 3,
      "explanation": "Democracy means rule by the people"
    },
    {
      "question": "Which of these is an organ of government?",
      "options": [
        "School",
        "Legislature",
        "Market",
        "Church"
      ],
      "correct": 1,
      "explanation": "Legislature is an organ of government"
    },
    {
      "question": "The organ that makes laws is?",
      "options": [
        "Judiciary",
        "Police",
        "Legislature",
        "Executive"
      ],
      "correct": 2,
      "explanation": "Legislature makes laws"
    },
    {
      "question": "The organ that implements laws is?",
      "options": [
        "Legislature",
        "Judiciary",
        "Press",
        "Executive"
      ],
      "correct": 3,
      "explanation": "Executive implements laws"
    },
    {
      "question": "The organ that interprets laws is?",
      "options": [
        "Legislature",
        "Police",
        "Executive",
        "Judiciary"
      ],
      "correct": 3,
      "explanation": "Judiciary interprets laws"
    },
    {
      "question": "Which of these is a type of constitution?",
      "options": [
        "Unwritten market",
        "Written constitution",
        "Private company",
        "Oral school"
      ],
      "correct": 1,
      "explanation": "Written constitution is a type"
    },
    {
      "question": "Federalism is a system where?",
      "options": [
        "Power is shared between central and regional governments",
        "There is no government",
        "One government controls all",
        "Only local government exists"
      ],
      "correct": 0,
      "explanation": "Federalism shares power"
    },
    {
      "question": "Which of these is a fundamental human right?",
      "options": [
        "Right to steal",
        "Right to break the law",
        "Right to life",
        "Right to kill"
      ],
      "correct": 2,
      "explanation": "Right to life is fundamental"
    },
    {
      "question": "The head of the executive in Nigeria is?",
      "options": [
        "The Chief Judge",
        "The Speaker",
        "The Senate President",
        "The President"
      ],
      "correct": 3,
      "explanation": "The President heads the executive"
    },
    {
      "question": "Which of these is a political party in Nigeria?",
      "options": [
        "APC",
        "UN",
        "FIFA",
        "WHO"
      ],
      "correct": 0,
      "explanation": "APC is a Nigerian political party"
    },
    {
      "question": "Suffrage means?",
      "options": [
        "The right to vote",
        "The right to rule forever",
        "The right to steal",
        "The right to fight"
      ],
      "correct": 0,
      "explanation": "Suffrage is the right to vote"
    },
    {
      "question": "Which of these is a feature of democracy?",
      "options": [
        "No elections",
        "Military rule",
        "One-man rule",
        "Periodic elections"
      ],
      "correct": 3,
      "explanation": "Democracy has periodic elections"
    },
    {
      "question": "The rule of law means?",
      "options": [
        "No one obeys the law",
        "Only the rich obey the law",
        "Everyone is equal before the law",
        "Only the poor obey the law"
      ],
      "correct": 2,
      "explanation": "Rule of law means equality before the law"
    },
    {
      "question": "Which of these is a local government function?",
      "options": [
        "Defence of the country",
        "Foreign policy",
        "Printing of currency",
        "Collection of rates"
      ],
      "correct": 3,
      "explanation": "Local governments collect rates"
    },
    {
      "question": "The Nigerian Constitution currently in use is?",
      "options": [
        "1960 Constitution",
        "1979 Constitution only",
        "1963 Constitution",
        "1999 Constitution"
      ],
      "correct": 3,
      "explanation": "Nigeria uses the 1999 Constitution"
    },
    {
      "question": "Which of these is a pressure group?",
      "options": [
        "APC",
        "UN",
        "PDP",
        "NLC"
      ],
      "correct": 3,
      "explanation": "NLC is a pressure group"
    },
    {
      "question": "Separation of powers means?",
      "options": [
        "Division of government powers among organs",
        "One organ does everything",
        "Only judiciary exists",
        "No government"
      ],
      "correct": 0,
      "explanation": "Powers are separated among organs"
    },
    {
      "question": "Which of these is a type of citizenship?",
      "options": [
        "Citizenship by theft",
        "Citizenship by chance",
        "Citizenship by force",
        "Citizenship by birth"
      ],
      "correct": 3,
      "explanation": "Citizenship can be by birth"
    },
    {
      "question": "The upper chamber of the National Assembly is?",
      "options": [
        "Senate",
        "House of Assembly",
        "Local Government Council",
        "House of Representatives"
      ],
      "correct": 0,
      "explanation": "Senate is the upper chamber"
    },
    {
      "question": "Which of these is a function of the judiciary?",
      "options": [
        "Collecting taxes",
        "Making laws",
        "Interpretation of laws",
        "Implementing laws"
      ],
      "correct": 2,
      "explanation": "Judiciary interprets laws"
    },
    {
      "question": "A unitary system of government has?",
      "options": [
        "Many independent governments",
        "One central government",
        "Only local governments",
        "No government"
      ],
      "correct": 1,
      "explanation": "Unitary system has one central government"
    },
    {
      "question": "Which of these is a civic responsibility?",
      "options": [
        "Avoiding elections",
        "Disobeying leaders",
        "Paying taxes",
        "Breaking the law"
      ],
      "correct": 2,
      "explanation": "Paying taxes is a civic duty"
    },
    {
      "question": "The first military coup in Nigeria was in?",
      "options": [
        "1966",
        "1999",
        "1979",
        "1960"
      ],
      "correct": 0,
      "explanation": "The first coup was in January 1966"
    },
    {
      "question": "Which of these is a feature of government?",
      "options": [
        "No laws",
        "Sovereignty",
        "No authority",
        "Private ownership only"
      ],
      "correct": 1,
      "explanation": "Government has sovereignty"
    },
    {
      "question": "The organ of government that settles disputes is?",
      "options": [
        "Executive",
        "Judiciary",
        "Legislature",
        "Police only"
      ],
      "correct": 1,
      "explanation": "Judiciary settles disputes"
    },
    {
      "question": "Which of these is a type of democracy?",
      "options": [
        "Military rule",
        "Monarchy absolute",
        "Dictatorship",
        "Representative democracy"
      ],
      "correct": 3,
      "explanation": "Representative democracy is a type"
    },
    {
      "question": "The body that makes laws in Nigeria is?",
      "options": [
        "Supreme Court",
        "Police",
        "Presidency only",
        "National Assembly"
      ],
      "correct": 3,
      "explanation": "National Assembly makes laws"
    },
    {
      "question": "Which of these is a fundamental right?",
      "options": [
        "Freedom to steal",
        "Freedom of expression",
        "Freedom to kill",
        "Freedom to break laws"
      ],
      "correct": 1,
      "explanation": "Freedom of expression is fundamental"
    },
    {
      "question": "Federal system of government is practised in?",
      "options": [
        "Ghana only",
        "France only",
        "Britain only",
        "Nigeria"
      ],
      "correct": 3,
      "explanation": "Nigeria practises federalism"
    },
    {
      "question": "Which of these is a function of the executive?",
      "options": [
        "Adjudicating cases",
        "Interpreting laws",
        "Making laws",
        "Implementation of laws"
      ],
      "correct": 3,
      "explanation": "Executive implements laws"
    },
    {
      "question": "The head of state in Nigeria is?",
      "options": [
        "The Speaker",
        "The President",
        "The Senate President",
        "The Chief Justice"
      ],
      "correct": 1,
      "explanation": "The President is the head of state"
    },
    {
      "question": "Which of these is a political party?",
      "options": [
        "NBA",
        "PDP",
        "NUT",
        "NLC"
      ],
      "correct": 1,
      "explanation": "PDP is a political party"
    },
    {
      "question": "Franchise means?",
      "options": [
        "Right to fight",
        "Right to steal",
        "Right to rule forever",
        "Right to vote"
      ],
      "correct": 3,
      "explanation": "Franchise is the right to vote"
    },
    {
      "question": "Which of these is a feature of the rule of law?",
      "options": [
        "Inequality",
        "No laws",
        "Equality before the law",
        "Selective justice"
      ],
      "correct": 2,
      "explanation": "Everyone is equal before the law"
    },
    {
      "question": "Local government is the?",
      "options": [
        "Only state government",
        "Closest government to the people",
        "Highest government",
        "Only federal government"
      ],
      "correct": 1,
      "explanation": "Local government is closest to the people"
    },
    {
      "question": "The 1999 Constitution is?",
      "options": [
        "Unwritten",
        "Written",
        "Not a constitution",
        "Flexible only"
      ],
      "correct": 1,
      "explanation": "Nigeria has a written constitution"
    },
    {
      "question": "Which of these is a pressure group in Nigeria?",
      "options": [
        "PDP",
        "APC",
        "UN",
        "Nigeria Labour Congress"
      ],
      "correct": 3,
      "explanation": "NLC is a pressure group"
    },
    {
      "question": "Separation of powers was popularised by?",
      "options": [
        "Montesquieu",
        "Karl Marx",
        "Plato only",
        "Adam Smith"
      ],
      "correct": 0,
      "explanation": "Montesquieu popularised separation of powers"
    },
    {
      "question": "Which of these is a way of acquiring citizenship?",
      "options": [
        "Naturalisation",
        "Stealing",
        "Force",
        "Chance"
      ],
      "correct": 0,
      "explanation": "Naturalisation is a legal way"
    },
    {
      "question": "The lower chamber of the National Assembly is?",
      "options": [
        "House of Representatives",
        "House of Assembly",
        "Local Council",
        "Senate"
      ],
      "correct": 0,
      "explanation": "House of Representatives is the lower chamber"
    },
    {
      "question": "Which of these is a function of the legislature?",
      "options": [
        "Arresting criminals",
        "Law making",
        "Implementing policies only",
        "Judging cases"
      ],
      "correct": 1,
      "explanation": "Legislature makes laws"
    },
    {
      "question": "A confederal system has?",
      "options": [
        "Strong central government",
        "Weak central government",
        "Only one level",
        "No government"
      ],
      "correct": 1,
      "explanation": "Confederation has weak centre"
    },
    {
      "question": "Which of these is a civic duty?",
      "options": [
        "Disrespecting leaders",
        "Breaking the law",
        "Obeying the law",
        "Avoiding tax"
      ],
      "correct": 2,
      "explanation": "Obeying the law is a civic duty"
    },
    {
      "question": "The first military Head of State in Nigeria was?",
      "options": [
        "Aguiyi Ironsi",
        "Murtala Mohammed",
        "Olusegun Obasanjo",
        "Yakubu Gowon"
      ],
      "correct": 0,
      "explanation": "Ironsi was the first military Head of State"
    },
    {
      "question": "Which of these is an organ of government?",
      "options": [
        "Hospital",
        "School",
        "Judiciary",
        "Market"
      ],
      "correct": 2,
      "explanation": "Judiciary is an organ of government"
    },
    {
      "question": "Democracy allows?",
      "options": [
        "Rule by one person only",
        "No elections",
        "Military rule",
        "Participation of the people"
      ],
      "correct": 3,
      "explanation": "Democracy allows popular participation"
    },
    {
      "question": "Which of these is a source of the Nigerian Constitution?",
      "options": [
        "Past constitutions",
        "Private diaries",
        "Foreign novels",
        "Story books"
      ],
      "correct": 0,
      "explanation": "Past constitutions influenced the current one"
    },
    {
      "question": "The principle of checks and balances prevents?",
      "options": [
        "Good governance",
        "Democracy",
        "Abuse of power",
        "Rule of law"
      ],
      "correct": 2,
      "explanation": "Checks and balances prevent abuse of power"
    },
    {
      "question": "Which of these is a characteristic of sovereignty?",
      "options": [
        "No power",
        "Limited power",
        "Supreme power",
        "Shared power only"
      ],
      "correct": 2,
      "explanation": "Sovereignty is supreme power"
    },
    {
      "question": "The organ that interprets the constitution is?",
      "options": [
        "Legislature",
        "Executive",
        "Police",
        "Judiciary"
      ],
      "correct": 3,
      "explanation": "Judiciary interprets the constitution"
    },
    {
      "question": "Which of these is a feature of democracy?",
      "options": [
        "Rule of law",
        "One-party system only",
        "No elections",
        "Rule by force"
      ],
      "correct": 0,
      "explanation": "Rule of law is a feature of democracy"
    },
    {
      "question": "The National Assembly of Nigeria consists of?",
      "options": [
        "Only House of Representatives",
        "Senate and House of Representatives",
        "Only Senate",
        "Only local councils"
      ],
      "correct": 1,
      "explanation": "National Assembly has two chambers"
    },
    {
      "question": "Which of these is a fundamental human right?",
      "options": [
        "Right to break the law",
        "Right to fair hearing",
        "Right to kill",
        "Right to steal"
      ],
      "correct": 1,
      "explanation": "Right to fair hearing is fundamental"
    },
    {
      "question": "In a federal system, power is?",
      "options": [
        "Absent",
        "Shared",
        "Only at local level",
        "Concentrated at the centre only"
      ],
      "correct": 1,
      "explanation": "Power is shared in a federation"
    },
    {
      "question": "Which of these is a function of the executive?",
      "options": [
        "Making laws only",
        "Formulation and implementation of policies",
        "Judging cases",
        "Interpreting the constitution only"
      ],
      "correct": 1,
      "explanation": "Executive formulates and implements policies"
    },
    {
      "question": "The Commander-in-Chief of the Armed Forces in Nigeria is?",
      "options": [
        "The President",
        "The Chief of Army Staff",
        "The Chief Justice",
        "The Senate President"
      ],
      "correct": 0,
      "explanation": "The President is Commander-in-Chief"
    },
    {
      "question": "Which of these is a multi-party system feature?",
      "options": [
        "No parties",
        "Only two parties always",
        "Existence of many parties",
        "Only one party"
      ],
      "correct": 2,
      "explanation": "Multi-party has many parties"
    },
    {
      "question": "Universal adult suffrage means?",
      "options": [
        "All adults have the right to vote",
        "Only the rich vote",
        "Only men vote",
        "Only women vote"
      ],
      "correct": 0,
      "explanation": "All adults can vote"
    },
    {
      "question": "Which of these is an aspect of the rule of law?",
      "options": [
        "Supremacy of the leader",
        "Supremacy of the law",
        "Selective application",
        "No laws"
      ],
      "correct": 1,
      "explanation": "Law is supreme"
    },
    {
      "question": "Local government councils are responsible for?",
      "options": [
        "Currency printing",
        "Primary education and local roads",
        "Defence",
        "Foreign affairs"
      ],
      "correct": 1,
      "explanation": "Local governments handle local services"
    },
    {
      "question": "The Nigerian Constitution can be?",
      "options": [
        "Replaced without process",
        "Ignored",
        "Amended",
        "Never changed"
      ],
      "correct": 2,
      "explanation": "The constitution can be amended"
    },
    {
      "question": "Which of these is a trade union?",
      "options": [
        "APC",
        "PDP",
        "Nigeria Union of Teachers",
        "UN"
      ],
      "correct": 2,
      "explanation": "NUT is a trade union"
    },
    {
      "question": "Checks and balances ensure?",
      "options": [
        "No organ becomes too powerful",
        "No government",
        "Only judiciary exists",
        "One organ controls all"
      ],
      "correct": 0,
      "explanation": "Checks prevent concentration of power"
    },
    {
      "question": "Citizenship by registration is possible for?",
      "options": [
        "Only children",
        "Anyone automatically",
        "Foreign women married to Nigerian men",
        "Only the rich"
      ],
      "correct": 2,
      "explanation": "Registration is possible in certain cases"
    },
    {
      "question": "The Senate President is the head of?",
      "options": [
        "The Judiciary",
        "The House of Representatives",
        "The Executive",
        "The Senate"
      ],
      "correct": 3,
      "explanation": "Senate President heads the Senate"
    },
    {
      "question": "Which of these is a function of the judiciary?",
      "options": [
        "Collecting taxes",
        "Protection of rights",
        "Making laws",
        "Implementing policies"
      ],
      "correct": 1,
      "explanation": "Judiciary protects rights"
    },
    {
      "question": "A unitary government has?",
      "options": [
        "No centre",
        "Weak centre",
        "Strong central government",
        "Only regional governments"
      ],
      "correct": 2,
      "explanation": "Unitary system has strong centre"
    },
    {
      "question": "Which of these is a civic responsibility?",
      "options": [
        "Breaking laws",
        "Voting in elections",
        "Avoiding elections",
        "Not paying taxes"
      ],
      "correct": 1,
      "explanation": "Voting is a civic responsibility"
    },
    {
      "question": "The military first intervened in Nigerian politics in?",
      "options": [
        "1960",
        "1999",
        "1979",
        "1966"
      ],
      "correct": 3,
      "explanation": "First intervention was in 1966"
    },
    {
      "question": "Which of these is an organ of government?",
      "options": [
        "Market",
        "School",
        "Hospital",
        "Executive"
      ],
      "correct": 3,
      "explanation": "Executive is an organ of government"
    },
    {
      "question": "In a democracy, sovereignty belongs to?",
      "options": [
        "The judges only",
        "The president only",
        "The people",
        "The army"
      ],
      "correct": 2,
      "explanation": "Sovereignty belongs to the people"
    },
    {
      "question": "Which of these is a source of constitutional law?",
      "options": [
        "Private letters",
        "Newspapers only",
        "Novels",
        "Judicial precedents"
      ],
      "correct": 3,
      "explanation": "Judicial precedents are a source"
    },
    {
      "question": "The principle of separation of powers promotes?",
      "options": [
        "Chaos",
        "Good governance",
        "Dictatorship",
        "Abuse of power"
      ],
      "correct": 1,
      "explanation": "Separation promotes good governance"
    },
    {
      "question": "Which of these is a characteristic of sovereignty?",
      "options": [
        "No power",
        "Shared power only",
        "Supreme power of the state",
        "Limited power"
      ],
      "correct": 2,
      "explanation": "Sovereignty is supreme power"
    },
    {
      "question": "The organ that interprets the constitution is?",
      "options": [
        "Legislature",
        "Executive",
        "Judiciary",
        "Police"
      ],
      "correct": 2,
      "explanation": "Judiciary interprets the constitution"
    },
    {
      "question": "Which of these is a form of government?",
      "options": [
        "School",
        "Hospital",
        "Monarchy",
        "Market"
      ],
      "correct": 2,
      "explanation": "Monarchy is a form of government"
    },
    {
      "question": "The body that approves the national budget is?",
      "options": [
        "National Assembly",
        "Supreme Court",
        "Police",
        "Civil service only"
      ],
      "correct": 0,
      "explanation": "National Assembly approves the budget"
    },
    {
      "question": "Which of these is a fundamental human right?",
      "options": [
        "Right to disobey laws",
        "Right to steal",
        "Right to fair hearing",
        "Right to kill"
      ],
      "correct": 2,
      "explanation": "Right to fair hearing is fundamental"
    },
    {
      "question": "In a federal system, power is shared between?",
      "options": [
        "Central and component units",
        "Only local governments",
        "Only the president",
        "Only the central government"
      ],
      "correct": 0,
      "explanation": "Power is shared in a federation"
    },
    {
      "question": "Which of these is a function of the civil service?",
      "options": [
        "Implementation of government policies",
        "Judging cases",
        "Arresting criminals only",
        "Making laws"
      ],
      "correct": 0,
      "explanation": "Civil service implements policies"
    },
    {
      "question": "The Commander-in-Chief of the Armed Forces in Nigeria is?",
      "options": [
        "The Chief of Army Staff",
        "The President",
        "The Chief Justice",
        "The Senate President"
      ],
      "correct": 1,
      "explanation": "The President is the Commander-in-Chief"
    },
    {
      "question": "Which of these is a multi-party system feature?",
      "options": [
        "No parties",
        "Two parties only always",
        "Existence of many parties",
        "Only one party"
      ],
      "correct": 2,
      "explanation": "Multi-party system has many parties"
    },
    {
      "question": "Universal adult suffrage means?",
      "options": [
        "Only women can vote",
        "All adults can vote",
        "Only men can vote",
        "Only the rich can vote"
      ],
      "correct": 1,
      "explanation": "All qualified adults can vote"
    },
    {
      "question": "Which of these is an attribute of the rule of law?",
      "options": [
        "Supremacy of individuals",
        "Selective application",
        "Supremacy of the law",
        "No laws"
      ],
      "correct": 2,
      "explanation": "Law is supreme"
    },
    {
      "question": "Local government reforms in Nigeria aimed at?",
      "options": [
        "Removing democracy",
        "Bringing government closer to the people",
        "Strengthening military rule",
        "Abolishing local government"
      ],
      "correct": 1,
      "explanation": "Reforms aimed at grassroots development"
    },
    {
      "question": "The Nigerian Constitution can be amended by?",
      "options": [
        "National Assembly and state assemblies",
        "The Police",
        "The President alone",
        "The Judiciary alone"
      ],
      "correct": 0,
      "explanation": "Amendment involves legislative bodies"
    },
    {
      "question": "Which of these is an example of a pressure group?",
      "options": [
        "UN",
        "PDP",
        "Academic Staff Union of Universities",
        "APC"
      ],
      "correct": 2,
      "explanation": "ASUU is a pressure group"
    },
    {
      "question": "Checks and balances ensure?",
      "options": [
        "No organ becomes too powerful",
        "One organ controls all",
        "Only judiciary functions",
        "No government exists"
      ],
      "correct": 0,
      "explanation": "Checks and balances limit power"
    },
    {
      "question": "Citizenship by registration is possible for?",
      "options": [
        "Anyone automatically",
        "Only by chance",
        "Only by force",
        "Foreign women married to Nigerian men"
      ],
      "correct": 3,
      "explanation": "Certain foreigners can register as citizens"
    },
    {
      "question": "The Senate is headed by?",
      "options": [
        "President of Nigeria",
        "Speaker",
        "Chief Justice",
        "Senate President"
      ],
      "correct": 3,
      "explanation": "Senate President heads the Senate"
    },
    {
      "question": "Which of these is a legislative function?",
      "options": [
        "Judging cases",
        "Printing money",
        "Arresting people",
        "Oversight of the executive"
      ],
      "correct": 3,
      "explanation": "Legislature oversights the executive"
    },
    {
      "question": "A unitary government is suitable for?",
      "options": [
        "Large diverse countries only",
        "Only federal states",
        "No country",
        "Small homogeneous countries"
      ],
      "correct": 3,
      "explanation": "Unitary system suits small homogeneous states"
    },
    {
      "question": "Which of these is a responsibility of a citizen?",
      "options": [
        "Disobedience to law",
        "Violation of rights",
        "Avoidance of tax",
        "Respect for the rights of others"
      ],
      "correct": 3,
      "explanation": "Citizens should respect others' rights"
    },
    {
      "question": "The Nigerian Civil War took place between?",
      "options": [
        "1960 and 1963",
        "1999 and 2003",
        "1979 and 1983",
        "1967 and 1970"
      ],
      "correct": 3,
      "explanation": "The Civil War was from 1967 to 1970"
    },
    {
      "question": "Which of these is an independent organ?",
      "options": [
        "Judiciary",
        "Political party",
        "Market",
        "Pressure group"
      ],
      "correct": 0,
      "explanation": "Judiciary is an independent organ of government"
    },
    {
      "question": "Representative democracy involves?",
      "options": [
        "No elections",
        "Election of representatives",
        "Military rule",
        "Direct rule by all citizens always"
      ],
      "correct": 1,
      "explanation": "People elect representatives"
    },
    {
      "question": "Which of these is a source of Nigerian law?",
      "options": [
        "Foreign novels",
        "Constitution",
        "Story books",
        "Private opinions only"
      ],
      "correct": 1,
      "explanation": "Constitution is a primary source of law"
    },
    {
      "question": "The principle of collective responsibility applies to?",
      "options": [
        "The legislature only",
        "The judiciary only",
        "The cabinet",
        "Local government only"
      ],
      "correct": 2,
      "explanation": "Cabinet members share collective responsibility"
    },
    {
      "question": "Which of these is a feature of a confederation?",
      "options": [
        "No component units",
        "Component units are more powerful than the centre",
        "Strong central government",
        "Only one level of government"
      ],
      "correct": 1,
      "explanation": "In a confederation the units are stronger"
    },
    {
      "question": "The judiciary ensures?",
      "options": [
        "Implementation of policies only",
        "Making of laws only",
        "Justice and interpretation of laws",
        "Collection of taxes only"
      ],
      "correct": 2,
      "explanation": "Judiciary dispenses justice"
    },
    {
      "question": "Which of these is a type of monarchy?",
      "options": [
        "Republican dictatorship",
        "Military rule",
        "Constitutional monarchy",
        "Absolute democracy"
      ],
      "correct": 2,
      "explanation": "Constitutional monarchy is a type"
    },
    {
      "question": "The National Assembly of Nigeria is?",
      "options": [
        "Not a legislature",
        "Unicameral",
        "Bicameral",
        "Tricameral"
      ],
      "correct": 2,
      "explanation": "It has two chambers"
    },
    {
      "question": "Which of these is a fundamental right in Nigeria?",
      "options": [
        "Right to break the law",
        "Right to kill",
        "Right to steal",
        "Right to private and family life"
      ],
      "correct": 3,
      "explanation": "Privacy is a fundamental right"
    },
    {
      "question": "In a parliamentary system, the head of government is usually?",
      "options": [
        "The President only",
        "The Senate President",
        "The Chief Justice",
        "The Prime Minister"
      ],
      "correct": 3,
      "explanation": "Prime Minister heads government in parliamentary system"
    },
    {
      "question": "Which of these is a function of the public service?",
      "options": [
        "Judging cases",
        "Making laws",
        "Contesting elections",
        "Continuity of government administration"
      ],
      "correct": 3,
      "explanation": "Public service ensures continuity"
    },
    {
      "question": "The President of Nigeria is elected for a term of?",
      "options": [
        "Three years",
        "Four years",
        "Five years",
        "Six years"
      ],
      "correct": 1,
      "explanation": "Presidential term is four years"
    },
    {
      "question": "Which of these is a feature of a multi-party system?",
      "options": [
        "Competition among parties",
        "No elections",
        "No opposition",
        "One-party dominance always"
      ],
      "correct": 0,
      "explanation": "Multi-party allows competition"
    },
    {
      "question": "Bye-election is held to?",
      "options": [
        "Elect all officers at once",
        "Select civil servants",
        "Appoint judges",
        "Fill a vacant elective position"
      ],
      "correct": 3,
      "explanation": "Bye-election fills vacancies"
    },
    {
      "question": "Which of these is an element of the rule of law?",
      "options": [
        "Equality before the law",
        "Selective justice",
        "No judicial review",
        "Inequality before the law"
      ],
      "correct": 0,
      "explanation": "Equality is central to rule of law"
    },
    {
      "question": "Local government in Nigeria operates under?",
      "options": [
        "No higher authority",
        "Only the judiciary",
        "The state government mainly",
        "Only the federal government"
      ],
      "correct": 2,
      "explanation": "Local governments are under states largely"
    },
    {
      "question": "The Nigerian Constitution is?",
      "options": [
        "Flexible only",
        "Unwritten",
        "Rigid",
        "Not amendable"
      ],
      "correct": 2,
      "explanation": "It requires special procedure to amend"
    },
    {
      "question": "Which of these is a pressure group method?",
      "options": [
        "Forming government",
        "Lobbying",
        "Contesting elections as a party",
        "Judging cases"
      ],
      "correct": 1,
      "explanation": "Lobbying is a pressure group method"
    },
    {
      "question": "Separation of powers promotes?",
      "options": [
        "No accountability",
        "Liberty and prevents tyranny",
        "Dictatorship",
        "Concentration of power"
      ],
      "correct": 1,
      "explanation": "Separation protects liberty"
    },
    {
      "question": "Citizenship by birth in Nigeria is based on?",
      "options": [
        "Only marriage",
        "Only registration",
        "Having Nigerian parents or being born in Nigeria under certain conditions",
        "Only naturalisation"
      ],
      "correct": 2,
      "explanation": "Birth is a main mode of citizenship"
    },
    {
      "question": "The House of Representatives is headed by?",
      "options": [
        "The Senate President",
        "The Chief Justice",
        "The President",
        "The Speaker"
      ],
      "correct": 3,
      "explanation": "Speaker heads the House"
    },
    {
      "question": "Which of these is a legislative power?",
      "options": [
        "Power to judge cases",
        "Power to arrest",
        "Power to make laws",
        "Power to print money only"
      ],
      "correct": 2,
      "explanation": "Legislature makes laws"
    },
    {
      "question": "A federal constitution is usually?",
      "options": [
        "Unwritten and flexible",
        "Only customary",
        "Not existent",
        "Written and rigid"
      ],
      "correct": 3,
      "explanation": "Federal constitutions are typically written and rigid"
    },
    {
      "question": "Which of these is a duty of a citizen?",
      "options": [
        "Payment of taxes",
        "Evasion of taxes",
        "Disobedience to law",
        "Destruction of public property"
      ],
      "correct": 0,
      "explanation": "Paying tax is a civic duty"
    },
    {
      "question": "The Nigerian Civil War ended in?",
      "options": [
        "1970",
        "1960",
        "1999",
        "1967"
      ],
      "correct": 0,
      "explanation": "The war ended in January 1970"
    },
    {
      "question": "Which of these is an independent body in Nigeria?",
      "options": [
        "A private company",
        "Independent National Electoral Commission",
        "A pressure group",
        "A political party"
      ],
      "correct": 1,
      "explanation": "INEC is an independent electoral body"
    },
    {
      "question": "Direct democracy involves?",
      "options": [
        "No participation",
        "Only elected representatives",
        "Military rule",
        "Citizens participating directly in decision making"
      ],
      "correct": 3,
      "explanation": "Direct democracy is direct participation"
    },
    {
      "question": "Which of these is a source of the constitution?",
      "options": [
        "Foreign novels",
        "Private diaries",
        "Judicial precedents",
        "Story books"
      ],
      "correct": 2,
      "explanation": "Judicial precedents can be a source"
    },
    {
      "question": "Collective responsibility means?",
      "options": [
        "Cabinet members share responsibility for decisions",
        "Only the leader is responsible",
        "Only the judiciary is responsible",
        "No one is responsible"
      ],
      "correct": 0,
      "explanation": "Cabinet stands or falls together"
    },
    {
      "question": "Which of these is a feature of a presidential system?",
      "options": [
        "Fusion of powers",
        "No fixed tenure",
        "Separation of the head of state and head of government is not there; they are combined",
        "Ceremonial president only"
      ],
      "correct": 2,
      "explanation": "In presidential system, one person is both head of state and government"
    },
    {
      "question": "The Supreme Court of Nigeria is headed by?",
      "options": [
        "The President",
        "The Senate President",
        "The Chief Justice of Nigeria",
        "The Speaker"
      ],
      "correct": 2,
      "explanation": "CJN heads the Supreme Court"
    },
    {
      "question": "Which of these is a type of rights?",
      "options": [
        "Right to kill",
        "Civil rights",
        "Right to steal",
        "Right to break laws"
      ],
      "correct": 1,
      "explanation": "Civil rights are legitimate rights"
    },
    {
      "question": "Decentralisation of power is a feature of?",
      "options": [
        "Absolute monarchy",
        "Federalism",
        "Dictatorship",
        "Unitary system only"
      ],
      "correct": 1,
      "explanation": "Federalism decentralises power"
    },
    {
      "question": "Which of these is a function of political parties?",
      "options": [
        "Judging cases",
        "Aggregating interests and presenting candidates",
        "Making judicial decisions",
        "Arresting criminals"
      ],
      "correct": 1,
      "explanation": "Parties aggregate interests and field candidates"
    },
    {
      "question": "An election that is free and fair is a feature of?",
      "options": [
        "Dictatorship",
        "Democracy",
        "Military rule",
        "Absolute monarchy"
      ],
      "correct": 1,
      "explanation": "Free and fair elections characterise democracy"
    },
    {
      "question": "Which of these is a limitation on the rule of law?",
      "options": [
        "Judicial independence",
        "State of emergency",
        "Equality before the law",
        "Supremacy of the law"
      ],
      "correct": 1,
      "explanation": "Emergency can limit normal rule of law"
    },
    {
      "question": "The 1976 Local Government Reform aimed at?",
      "options": [
        "Military control only",
        "Abolishing local government",
        "Removing grassroots participation",
        "Making local government effective and democratic"
      ],
      "correct": 3,
      "explanation": "The reform strengthened local government"
    },
    {
      "question": "Which of these is a way of amending the Nigerian Constitution?",
      "options": [
        "Special majority in the National Assembly and state houses",
        "Simple majority only",
        "Judicial pronouncement only",
        "Presidential decree only"
      ],
      "correct": 0,
      "explanation": "Special procedure is required"
    },
    {
      "question": "A pressure group differs from a political party because it?",
      "options": [
        "Forms government",
        "Judges cases",
        "Does not seek to form government",
        "Always contests elections"
      ],
      "correct": 2,
      "explanation": "Pressure groups do not aim to form government"
    },
    {
      "question": "Checks and balances operate through?",
      "options": [
        "One organ controlling all",
        "No interaction",
        "Only judiciary acting",
        "Each organ limiting the others"
      ],
      "correct": 3,
      "explanation": "Organs check one another"
    },
    {
      "question": "Citizenship can be lost through?",
      "options": [
        "Naturalisation only",
        "Registration only",
        "Renunciation",
        "Birth"
      ],
      "correct": 2,
      "explanation": "A citizen may renounce citizenship"
    },
    {
      "question": "The Senate has how many members from each state?",
      "options": [
        "Two",
        "Three",
        "Four",
        "One"
      ],
      "correct": 1,
      "explanation": "Each state has three senators"
    },
    {
      "question": "Which of these is an exclusive legislative list item?",
      "options": [
        "Local markets only",
        "Chieftaincy only",
        "Local roads only",
        "Defence"
      ],
      "correct": 3,
      "explanation": "Defence is exclusive to the federal government"
    },
    {
      "question": "A unitary system concentrates power at?",
      "options": [
        "Local governments only",
        "The regions only",
        "The centre",
        "No level"
      ],
      "correct": 2,
      "explanation": "Power is concentrated at the centre"
    },
    {
      "question": "Which of these is a civic obligation?",
      "options": [
        "Disobedience to law",
        "Avoidance of public service",
        "Desecration of national symbols",
        "Respect for national symbols"
      ],
      "correct": 3,
      "explanation": "Respect for symbols is an obligation"
    },
    {
      "question": "The Nigerian flag has colours?",
      "options": [
        "Black, green, gold",
        "Red, white, blue",
        "Blue, white, red",
        "Green, white, green"
      ],
      "correct": 3,
      "explanation": "Nigerian flag is green-white-green"
    },
    {
      "question": "Which of these is an electoral body in Nigeria?",
      "options": [
        "ICPC",
        "NPA",
        "EFCC",
        "INEC"
      ],
      "correct": 3,
      "explanation": "INEC conducts elections"
    },
    {
      "question": "Indirect election involves?",
      "options": [
        "Electing representatives who then elect others",
        "No election",
        "Appointment only",
        "Direct voting by all citizens for every office"
      ],
      "correct": 0,
      "explanation": "Indirect election uses intermediaries"
    },
    {
      "question": "Which of these is a source of Nigerian law?",
      "options": [
        "Foreign novels",
        "Statutes",
        "Story books",
        "Private opinions only"
      ],
      "correct": 1,
      "explanation": "Statutes are a source of law"
    },
    {
      "question": "Individual ministerial responsibility means?",
      "options": [
        "A minister is responsible for his ministry",
        "No minister is responsible",
        "Only the president is responsible",
        "All ministers share all blame equally always"
      ],
      "correct": 0,
      "explanation": "Each minister answers for his portfolio"
    },
    {
      "question": "Which of these is a feature of a republican system?",
      "options": [
        "No head of state",
        "Elective head of state",
        "Military head always",
        "Hereditary head of state"
      ],
      "correct": 1,
      "explanation": "Republic has elective head of state"
    },
    {
      "question": "The Court of Appeal is below the?",
      "options": [
        "High Court",
        "Customary Court",
        "Supreme Court",
        "Magistrate Court"
      ],
      "correct": 2,
      "explanation": "Court of Appeal is below the Supreme Court"
    },
    {
      "question": "Which of these is a political right?",
      "options": [
        "Right to break the law",
        "Right to steal",
        "Right to vote and be voted for",
        "Right to kill"
      ],
      "correct": 2,
      "explanation": "Voting is a political right"
    },
    {
      "question": "Power sharing is a feature of?",
      "options": [
        "Dictatorship",
        "Unitary system only",
        "Absolute monarchy",
        "Federalism"
      ],
      "correct": 3,
      "explanation": "Federalism involves power sharing"
    },
    {
      "question": "Which of these is a function of the opposition?",
      "options": [
        "Judging cases",
        "Constructive criticism of government",
        "Always supporting government",
        "Arresting people"
      ],
      "correct": 1,
      "explanation": "Opposition criticises constructively"
    },
    {
      "question": "A free and fair election requires?",
      "options": [
        "Violence",
        "Intimidation",
        "Transparency and impartiality",
        "Rigging"
      ],
      "correct": 2,
      "explanation": "Transparency is essential"
    },
    {
      "question": "Which of these can suspend some rights?",
      "options": [
        "Judicial independence",
        "Normal times always",
        "State of emergency",
        "Rule of law always"
      ],
      "correct": 2,
      "explanation": "Emergency can suspend some rights"
    },
    {
      "question": "The local government chairman is?",
      "options": [
        "Appointed by the president only",
        "Elected",
        "Appointed by the chief judge",
        "Selected by traditional rulers only"
      ],
      "correct": 1,
      "explanation": "Chairmen are elected"
    },
    {
      "question": "Which of these is required for constitutional amendment?",
      "options": [
        "Approval by a special majority",
        "Judicial order only",
        "Simple majority only",
        "Presidential order only"
      ],
      "correct": 0,
      "explanation": "Special majority is needed"
    },
    {
      "question": "A pressure group seeks to?",
      "options": [
        "Influence government policies",
        "Judge all cases",
        "Form government always",
        "Contest all elections"
      ],
      "correct": 0,
      "explanation": "Pressure groups influence policy"
    },
    {
      "question": "Judicial review allows the court to?",
      "options": [
        "Declare laws unconstitutional",
        "Implement policies",
        "Conduct elections",
        "Make laws"
      ],
      "correct": 0,
      "explanation": "Courts can strike down unconstitutional laws"
    },
    {
      "question": "Citizenship by naturalisation requires?",
      "options": [
        "Only marriage",
        "Only birth in the country",
        "Meeting legal conditions and application",
        "Automatic grant"
      ],
      "correct": 2,
      "explanation": "Naturalisation has conditions"
    },
    {
      "question": "The National Assembly is composed of?",
      "options": [
        "Only Senate",
        "Only House of Representatives",
        "Only state assemblies",
        "Senate and House of Representatives"
      ],
      "correct": 3,
      "explanation": "It is bicameral"
    },
    {
      "question": "Which of these is on the concurrent list?",
      "options": [
        "Currency only",
        "Education",
        "Defence only",
        "Foreign affairs only"
      ],
      "correct": 1,
      "explanation": "Education is concurrent"
    },
    {
      "question": "A confederal system is characterised by?",
      "options": [
        "Loose association of states",
        "No states",
        "Strong central government",
        "Only local governments"
      ],
      "correct": 0,
      "explanation": "Confederation is a loose association"
    },
    {
      "question": "Which of these is a national symbol?",
      "options": [
        "Political party symbol only",
        "Coat of arms",
        "Personal flag",
        "Private company logo"
      ],
      "correct": 1,
      "explanation": "Coat of arms is a national symbol"
    },
    {
      "question": "The body that conducts elections in Nigeria is?",
      "options": [
        "ICPC",
        "EFCC",
        "INEC",
        "NPA"
      ],
      "correct": 2,
      "explanation": "INEC conducts elections"
    },
    {
      "question": "A referendum is?",
      "options": [
        "An appointment",
        "A court judgment",
        "A direct vote by the electorate on an issue",
        "An indirect election"
      ],
      "correct": 2,
      "explanation": "Referendum is direct popular vote on an issue"
    },
    {
      "question": "Which of these is a source of law in Nigeria?",
      "options": [
        "Customary law",
        "Foreign novels",
        "Story books",
        "Private diaries"
      ],
      "correct": 0,
      "explanation": "Customary law is recognised"
    },
    {
      "question": "The cabinet is collectively responsible to?",
      "options": [
        "Only local government",
        "The legislature in a parliamentary system",
        "Only the judiciary",
        "Only the civil service"
      ],
      "correct": 1,
      "explanation": "Cabinet is responsible to the legislature"
    },
    {
      "question": "Which of these is a feature of a democratic government?",
      "options": [
        "No elections",
        "Hereditary rule",
        "Military takeover",
        "Periodic free elections"
      ],
      "correct": 3,
      "explanation": "Periodic elections define democracy"
    },
    {
      "question": "The highest court in Nigeria is?",
      "options": [
        "Court of Appeal",
        "Magistrate Court",
        "Supreme Court",
        "High Court"
      ],
      "correct": 2,
      "explanation": "Supreme Court is the highest"
    },
    {
      "question": "Which of these is a social right?",
      "options": [
        "Right to education",
        "Right to steal",
        "Right to break the law",
        "Right to kill"
      ],
      "correct": 0,
      "explanation": "Education is a social right"
    },
    {
      "question": "Division of powers is a feature of?",
      "options": [
        "Federalism",
        "Dictatorship",
        "Unitary system only",
        "Absolute monarchy"
      ],
      "correct": 0,
      "explanation": "Federalism divides powers"
    },
    {
      "question": "Which of these is a role of the media in democracy?",
      "options": [
        "Arresting criminals",
        "Judging cases",
        "Informing the public and acting as watchdog",
        "Making laws"
      ],
      "correct": 2,
      "explanation": "Media informs and watches government"
    },
    {
      "question": "An election petition is heard by?",
      "options": [
        "Election tribunal or court",
        "Pressure group",
        "Political party",
        "Local government only"
      ],
      "correct": 0,
      "explanation": "Tribunals handle election petitions"
    },
    {
      "question": "Which of these can lead to the suspension of the constitution?",
      "options": [
        "Judicial independence",
        "Military coup or state of emergency",
        "Free election",
        "Normal democratic process"
      ],
      "correct": 1,
      "explanation": "Coups or emergencies can suspend the constitution"
    },
    {
      "question": "The local government is created by?",
      "options": [
        "Law",
        "Private individuals",
        "Political parties only",
        "Pressure groups only"
      ],
      "correct": 0,
      "explanation": "Local governments are created by law"
    },
    {
      "question": "Which of these is a requirement for amending the constitution?",
      "options": [
        "Public opinion only",
        "Approval by two-thirds of the National Assembly and state houses",
        "Simple majority only",
        "Presidential order only"
      ],
      "correct": 1,
      "explanation": "Special majority is required"
    },
    {
      "question": "A pressure group uses?",
      "options": [
        "Only court judgments",
        "Only elections",
        "Only force",
        "Persuasion and lobbying"
      ],
      "correct": 3,
      "explanation": "Pressure groups mainly persuade and lobby"
    },
    {
      "question": "Judicial independence means?",
      "options": [
        "Judges conduct elections",
        "Judges implement policies",
        "Judges are free from external control in deciding cases",
        "Judges make laws"
      ],
      "correct": 2,
      "explanation": "Judges must be independent"
    },
    {
      "question": "Citizenship by descent is based on?",
      "options": [
        "Only place of birth",
        "Only naturalisation",
        "Only registration",
        "Parentage"
      ],
      "correct": 3,
      "explanation": "Descent is based on parentage"
    },
    {
      "question": "The Senate President is elected by?",
      "options": [
        "Senators",
        "The Chief Justice",
        "The general public directly",
        "The President of Nigeria"
      ],
      "correct": 0,
      "explanation": "Senators elect their President"
    },
    {
      "question": "Which of these is on the exclusive legislative list?",
      "options": [
        "Local government creation only",
        "Chieftaincy matters only",
        "Local markets only",
        "Currency"
      ],
      "correct": 3,
      "explanation": "Currency is exclusive to the centre"
    },
    {
      "question": "A unitary constitution is usually?",
      "options": [
        "Rigid always",
        "Unwritten always",
        "Not existent",
        "Flexible"
      ],
      "correct": 3,
      "explanation": "Unitary constitutions are often flexible"
    },
    {
      "question": "Which of these is a national symbol of Nigeria?",
      "options": [
        "Private company song",
        "Personal song",
        "National anthem",
        "Political party anthem only"
      ],
      "correct": 2,
      "explanation": "National anthem is a national symbol"
    },
    {
      "question": "The body responsible for the registration of voters is?",
      "options": [
        "NPA",
        "EFCC",
        "ICPC",
        "INEC"
      ],
      "correct": 3,
      "explanation": "INEC registers voters"
    },
    {
      "question": "A general election is?",
      "options": [
        "A referendum only",
        "A bye-election only",
        "An appointment",
        "An election covering the whole country or a wide area"
      ],
      "correct": 3,
      "explanation": "General election is nationwide or wide"
    },
    {
      "question": "Which of these is a source of Nigerian law?",
      "options": [
        "Case law",
        "Story books",
        "Private diaries",
        "Foreign novels"
      ],
      "correct": 0,
      "explanation": "Case law (precedents) is a source"
    },
    {
      "question": "The principle of individual responsibility holds a minister?",
      "options": [
        "Accountable for all ministries",
        "Accountable only to the judiciary",
        "Accountable for his ministry",
        "Not accountable"
      ],
      "correct": 2,
      "explanation": "Minister is accountable for his portfolio"
    },
    {
      "question": "Which of these is a feature of democracy?",
      "options": [
        "No elections",
        "Military rule",
        "Rule by one person",
        "Majority rule with minority rights"
      ],
      "correct": 3,
      "explanation": "Democracy balances majority and minority"
    },
    {
      "question": "The Federal High Court is below the?",
      "options": [
        "Magistrate Court",
        "Supreme Court only",
        "Court of Appeal",
        "Customary Court"
      ],
      "correct": 2,
      "explanation": "Federal High Court appeals go to the Court of Appeal"
    },
    {
      "question": "Which of these is an economic right?",
      "options": [
        "Right to kill",
        "Right to steal",
        "Right to break the law",
        "Right to work"
      ],
      "correct": 3,
      "explanation": "Right to work is an economic right"
    },
    {
      "question": "Power is shared in?",
      "options": [
        "A dictatorship",
        "A federation",
        "A unitary state only",
        "An absolute monarchy"
      ],
      "correct": 1,
      "explanation": "Federation shares power"
    },
    {
      "question": "Which of these is a role of civil society?",
      "options": [
        "Arresting criminals",
        "Making laws",
        "Promoting accountability and participation",
        "Judging cases"
      ],
      "correct": 2,
      "explanation": "Civil society promotes accountability"
    },
    {
      "question": "An election observer monitors?",
      "options": [
        "The conduct of elections",
        "Private businesses only",
        "Government policies only",
        "Court cases only"
      ],
      "correct": 0,
      "explanation": "Observers monitor elections"
    },
    {
      "question": "Which of these can lead to constitutional crisis?",
      "options": [
        "Smooth cooperation",
        "Free elections",
        "Judicial independence",
        "Conflict between organs of government"
      ],
      "correct": 3,
      "explanation": "Conflict among organs can cause crisis"
    },
    {
      "question": "The local government council is composed of?",
      "options": [
        "Elected councillors",
        "Only traditional rulers",
        "Only civil servants",
        "Only appointed officials"
      ],
      "correct": 0,
      "explanation": "Councillors are elected"
    },
    {
      "question": "Which of these is a condition for constitutional amendment?",
      "options": [
        "Support of a special majority of legislators",
        "Support of one person only",
        "Support of foreign countries only",
        "Support of the military only"
      ],
      "correct": 0,
      "explanation": "Special majority is required"
    },
    {
      "question": "A pressure group may use?",
      "options": [
        "Public demonstrations",
        "Only force",
        "Only secret meetings",
        "Only court cases"
      ],
      "correct": 0,
      "explanation": "Demonstrations are a method"
    },
    {
      "question": "The independence of the judiciary is protected by?",
      "options": [
        "Political control",
        "Security of tenure and immunity in decision making",
        "Executive interference",
        "Legislative control of every case"
      ],
      "correct": 1,
      "explanation": "Tenure security protects independence"
    },
    {
      "question": "Citizenship by registration is available to?",
      "options": [
        "Certain categories of foreigners",
        "Only by force",
        "Only by birth",
        "All foreigners automatically"
      ],
      "correct": 0,
      "explanation": "Certain foreigners may register"
    },
    {
      "question": "The Senate represents?",
      "options": [
        "Only the capital",
        "Only local governments",
        "The population proportionally only",
        "The states equally"
      ],
      "correct": 3,
      "explanation": "Senate gives equal representation to states"
    },
    {
      "question": "Which of these is on the exclusive list?",
      "options": [
        "Aviation",
        "Local markets",
        "Local roads",
        "Chieftaincy"
      ],
      "correct": 0,
      "explanation": "Aviation is exclusive"
    },
    {
      "question": "A flexible constitution is?",
      "options": [
        "Unwritten always",
        "Not a constitution",
        "Difficult to amend",
        "Easily amended"
      ],
      "correct": 3,
      "explanation": "Flexible constitutions are easy to amend"
    },
    {
      "question": "Which of these is a national symbol?",
      "options": [
        "Personal pledge",
        "Private company pledge",
        "National pledge",
        "Political party pledge only"
      ],
      "correct": 2,
      "explanation": "National pledge is a national symbol"
    },
    {
      "question": "The body that announces election results is?",
      "options": [
        "NPA",
        "INEC",
        "ICPC",
        "EFCC"
      ],
      "correct": 1,
      "explanation": "INEC announces results"
    },
    {
      "question": "A run-off election is held when?",
      "options": [
        "There is only one candidate",
        "There is no election",
        "All candidates win",
        "No candidate meets the required majority"
      ],
      "correct": 3,
      "explanation": "Run-off is held when no clear winner emerges"
    },
    {
      "question": "Which of these is a source of law?",
      "options": [
        "Legislation",
        "Story books",
        "Private diaries",
        "Foreign novels"
      ],
      "correct": 0,
      "explanation": "Legislation is a primary source of law"
    },
    {
      "question": "The cabinet in a presidential system is responsible to?",
      "options": [
        "The public service only",
        "The judiciary only",
        "The President",
        "The legislature only"
      ],
      "correct": 2,
      "explanation": "Cabinet is responsible to the President"
    },
    {
      "question": "Which of these is a pillar of democracy?",
      "options": [
        "Rule of law",
        "No elections",
        "Military rule",
        "Rule of man"
      ],
      "correct": 0,
      "explanation": "Rule of law is a pillar of democracy"
    }
  ],
  "lit": [
    {
      "question": "A novel is a?",
      "options": [
        "Speech only",
        "Short poem",
        "Long prose narrative",
        "Play only"
      ],
      "correct": 2,
      "explanation": "A novel is a long work of prose fiction"
    },
    {
      "question": "The central character in a story is the?",
      "options": [
        "Narrator only",
        "Author only",
        "Protagonist",
        "Antagonist"
      ],
      "correct": 2,
      "explanation": "The protagonist is the main character"
    },
    {
      "question": "A poem of fourteen lines is a?",
      "options": [
        "Lyric",
        "Epic",
        "Sonnet",
        "Ballad"
      ],
      "correct": 2,
      "explanation": "A sonnet has fourteen lines"
    },
    {
      "question": "The opposite character to the hero is the?",
      "options": [
        "Chorus",
        "Narrator",
        "Antagonist",
        "Protagonist"
      ],
      "correct": 2,
      "explanation": "The antagonist opposes the hero"
    },
    {
      "question": "A story that teaches a moral lesson is a?",
      "options": [
        "Fable",
        "Novel",
        "Epic",
        "Tragedy"
      ],
      "correct": 0,
      "explanation": "Fables teach moral lessons"
    },
    {
      "question": "The time and place of a story is the?",
      "options": [
        "Setting",
        "Plot",
        "Theme",
        "Style"
      ],
      "correct": 0,
      "explanation": "Setting is the time and place"
    },
    {
      "question": "A comparison using 'like' or 'as' is a?",
      "options": [
        "Hyperbole",
        "Metaphor",
        "Personification",
        "Simile"
      ],
      "correct": 3,
      "explanation": "Simile uses like or as"
    },
    {
      "question": "A direct comparison without 'like' or 'as' is a?",
      "options": [
        "Alliteration",
        "Irony",
        "Metaphor",
        "Simile"
      ],
      "correct": 2,
      "explanation": "Metaphor is a direct comparison"
    },
    {
      "question": "Giving human qualities to non-human things is?",
      "options": [
        "Metaphor",
        "Personification",
        "Simile",
        "Hyperbole"
      ],
      "correct": 1,
      "explanation": "Personification gives human traits to non-humans"
    },
    {
      "question": "An exaggeration for effect is?",
      "options": [
        "Irony",
        "Satire",
        "Hyperbole",
        "Paradox"
      ],
      "correct": 2,
      "explanation": "Hyperbole is deliberate exaggeration"
    },
    {
      "question": "The main idea in a literary work is the?",
      "options": [
        "Style",
        "Setting",
        "Plot",
        "Theme"
      ],
      "correct": 3,
      "explanation": "Theme is the central idea"
    },
    {
      "question": "The sequence of events in a story is the?",
      "options": [
        "Style",
        "Theme",
        "Setting",
        "Plot"
      ],
      "correct": 3,
      "explanation": "Plot is the sequence of events"
    },
    {
      "question": "A play with a sad ending is a?",
      "options": [
        "Tragedy",
        "Comedy",
        "Melodrama",
        "Farce"
      ],
      "correct": 0,
      "explanation": "Tragedy ends unhappily"
    },
    {
      "question": "A play with a happy ending is a?",
      "options": [
        "Elegy",
        "Comedy",
        "Epic",
        "Tragedy"
      ],
      "correct": 1,
      "explanation": "Comedy ends happily"
    },
    {
      "question": "A long narrative poem about heroic deeds is an?",
      "options": [
        "Lyric",
        "Epic",
        "Sonnet",
        "Ode"
      ],
      "correct": 1,
      "explanation": "Epic is a long heroic poem"
    },
    {
      "question": "The repetition of initial consonant sounds is?",
      "options": [
        "Rhythm",
        "Alliteration",
        "Rhyme",
        "Assonance"
      ],
      "correct": 1,
      "explanation": "Alliteration repeats consonant sounds"
    },
    {
      "question": "A poem expressing personal feelings is a?",
      "options": [
        "Ballad",
        "Sonnet only",
        "Epic",
        "Lyric"
      ],
      "correct": 3,
      "explanation": "Lyric expresses personal emotion"
    },
    {
      "question": "The person who tells the story is the?",
      "options": [
        "Protagonist only",
        "Narrator",
        "Antagonist only",
        "Author only"
      ],
      "correct": 1,
      "explanation": "The narrator tells the story"
    },
    {
      "question": "A sudden change in a character's fortune is?",
      "options": [
        "Climax only",
        "Exposition",
        "Peripeteia",
        "Resolution"
      ],
      "correct": 2,
      "explanation": "Peripeteia is a reversal of fortune"
    },
    {
      "question": "The highest point of tension in a story is the?",
      "options": [
        "Resolution",
        "Exposition",
        "Falling action",
        "Climax"
      ],
      "correct": 3,
      "explanation": "Climax is the peak of tension"
    },
    {
      "question": "A speech by a character alone on stage is a?",
      "options": [
        "Soliloquy",
        "Aside only",
        "Dialogue",
        "Chorus"
      ],
      "correct": 0,
      "explanation": "Soliloquy is a solo speech"
    },
    {
      "question": "A remark heard only by the audience is an?",
      "options": [
        "Soliloquy",
        "Aside",
        "Monologue",
        "Dialogue"
      ],
      "correct": 1,
      "explanation": "Aside is meant for the audience"
    },
    {
      "question": "The use of words that imitate sounds is?",
      "options": [
        "Alliteration",
        "Onomatopoeia",
        "Assonance",
        "Rhyme"
      ],
      "correct": 1,
      "explanation": "Onomatopoeia imitates sounds"
    },
    {
      "question": "A poem of mourning is an?",
      "options": [
        "Elegy",
        "Ode",
        "Epic",
        "Sonnet"
      ],
      "correct": 0,
      "explanation": "Elegy mourns the dead"
    },
    {
      "question": "The attitude of the writer towards the subject is the?",
      "options": [
        "Theme",
        "Setting",
        "Tone",
        "Plot"
      ],
      "correct": 2,
      "explanation": "Tone is the writer's attitude"
    },
    {
      "question": "A story within a story is an example of?",
      "options": [
        "Simple plot",
        "Frame narrative",
        "No structure",
        "Linear narrative only"
      ],
      "correct": 1,
      "explanation": "Frame narrative contains another story"
    },
    {
      "question": "The emotional release at the end of a tragedy is?",
      "options": [
        "Resolution only",
        "Climax",
        "Exposition",
        "Catharsis"
      ],
      "correct": 3,
      "explanation": "Catharsis is the purging of emotions"
    },
    {
      "question": "A character that does not change is?",
      "options": [
        "Static character",
        "Dynamic character",
        "Flat character only",
        "Round character only"
      ],
      "correct": 0,
      "explanation": "Static characters remain the same"
    },
    {
      "question": "A character that changes is?",
      "options": [
        "Stock character only",
        "Flat character only",
        "Static character",
        "Dynamic character"
      ],
      "correct": 3,
      "explanation": "Dynamic characters develop"
    },
    {
      "question": "The struggle between opposing forces is?",
      "options": [
        "Conflict",
        "Style",
        "Setting",
        "Theme"
      ],
      "correct": 0,
      "explanation": "Conflict is the struggle"
    },
    {
      "question": "Man against nature is a type of?",
      "options": [
        "Conflict",
        "Theme only",
        "Style only",
        "Setting only"
      ],
      "correct": 0,
      "explanation": "It is a type of conflict"
    },
    {
      "question": "A poem that tells a story is a?",
      "options": [
        "Lyric poem only",
        "Ode only",
        "Narrative poem",
        "Sonnet only"
      ],
      "correct": 2,
      "explanation": "Narrative poems tell stories"
    },
    {
      "question": "The repetition of vowel sounds is?",
      "options": [
        "Alliteration",
        "Rhyme",
        "Assonance",
        "Consonance"
      ],
      "correct": 2,
      "explanation": "Assonance repeats vowel sounds"
    },
    {
      "question": "A reference to a well-known person or event is?",
      "options": [
        "Metaphor",
        "Illusion",
        "Simile",
        "Allusion"
      ],
      "correct": 3,
      "explanation": "Allusion refers to something known"
    },
    {
      "question": "The opposite of what is expected is?",
      "options": [
        "Paradox",
        "Irony",
        "Satire",
        "Hyperbole"
      ],
      "correct": 1,
      "explanation": "Irony is the opposite of expectation"
    },
    {
      "question": "A work that ridicules human folly is?",
      "options": [
        "Epic",
        "Satire",
        "Elegy",
        "Tragedy"
      ],
      "correct": 1,
      "explanation": "Satire ridicules to criticise"
    },
    {
      "question": "A seeming contradiction is a?",
      "options": [
        "Paradox",
        "Irony",
        "Simile",
        "Metaphor"
      ],
      "correct": 0,
      "explanation": "Paradox appears contradictory"
    },
    {
      "question": "The ending of a story is the?",
      "options": [
        "Climax",
        "Exposition",
        "Resolution",
        "Rising action"
      ],
      "correct": 2,
      "explanation": "Resolution concludes the story"
    },
    {
      "question": "The introduction of a story is the?",
      "options": [
        "Climax",
        "Resolution",
        "Exposition",
        "Falling action"
      ],
      "correct": 2,
      "explanation": "Exposition introduces the story"
    },
    {
      "question": "A speech addressed to someone not present is?",
      "options": [
        "Aside",
        "Apostrophe",
        "Dialogue",
        "Soliloquy"
      ],
      "correct": 1,
      "explanation": "Apostrophe addresses the absent"
    },
    {
      "question": "The pattern of stressed and unstressed syllables is?",
      "options": [
        "Rhythm",
        "Assonance",
        "Alliteration",
        "Rhyme"
      ],
      "correct": 0,
      "explanation": "Rhythm is the pattern of stresses"
    },
    {
      "question": "Words that sound alike at the end of lines form?",
      "options": [
        "Rhyme",
        "Alliteration",
        "Rhythm",
        "Meter only"
      ],
      "correct": 0,
      "explanation": "Rhyme is similar ending sounds"
    },
    {
      "question": "A long serious poem on a dignified theme is an?",
      "options": [
        "Ode",
        "Elegy",
        "Sonnet",
        "Ballad"
      ],
      "correct": 0,
      "explanation": "Ode is a formal lyric poem"
    },
    {
      "question": "A traditional story that explains natural phenomena is a?",
      "options": [
        "Fable",
        "Parable",
        "Legend",
        "Myth"
      ],
      "correct": 3,
      "explanation": "Myths explain origins and nature"
    },
    {
      "question": "A story based on historical figures but exaggerated is a?",
      "options": [
        "Myth",
        "Legend",
        "Fable",
        "Parable"
      ],
      "correct": 1,
      "explanation": "Legends are semi-historical"
    },
    {
      "question": "A short story with a moral, often with animals, is a?",
      "options": [
        "Parable",
        "Myth",
        "Legend",
        "Fable"
      ],
      "correct": 3,
      "explanation": "Fables often use animals"
    },
    {
      "question": "A simple story used to illustrate a moral or spiritual lesson is a?",
      "options": [
        "Fable",
        "Myth",
        "Legend",
        "Parable"
      ],
      "correct": 3,
      "explanation": "Parables teach moral lessons"
    },
    {
      "question": "The author's choice of words is?",
      "options": [
        "Tone",
        "Syntax",
        "Diction",
        "Theme"
      ],
      "correct": 2,
      "explanation": "Diction is word choice"
    },
    {
      "question": "The arrangement of words in a sentence is?",
      "options": [
        "Tone",
        "Diction",
        "Syntax",
        "Style only"
      ],
      "correct": 2,
      "explanation": "Syntax is sentence structure"
    },
    {
      "question": "A work meant to be performed on stage is a?",
      "options": [
        "Novel",
        "Poem only",
        "Drama",
        "Essay"
      ],
      "correct": 2,
      "explanation": "Drama is written for performance"
    },
    {
      "question": "A character with complex personality is?",
      "options": [
        "Round character",
        "Flat character",
        "Static character only",
        "Stock character"
      ],
      "correct": 0,
      "explanation": "Round characters are complex"
    },
    {
      "question": "A simple, one-dimensional character is?",
      "options": [
        "Flat character",
        "Dynamic character",
        "Round character",
        "Protagonist only"
      ],
      "correct": 0,
      "explanation": "Flat characters are simple"
    },
    {
      "question": "The turning point of a story is the?",
      "options": [
        "Resolution",
        "Exposition",
        "Falling action",
        "Climax"
      ],
      "correct": 3,
      "explanation": "Climax is the turning point"
    },
    {
      "question": "A poem written to praise someone or something is an?",
      "options": [
        "Elegy",
        "Ode",
        "Ballad",
        "Sonnet"
      ],
      "correct": 1,
      "explanation": "Ode is a poem of praise"
    },
    {
      "question": "The use of mild words in place of harsh ones is?",
      "options": [
        "Euphemism",
        "Irony",
        "Hyperbole",
        "Metaphor"
      ],
      "correct": 0,
      "explanation": "Euphemism softens expression"
    },
    {
      "question": "A conversation between characters is?",
      "options": [
        "Dialogue",
        "Monologue",
        "Soliloquy",
        "Aside"
      ],
      "correct": 0,
      "explanation": "Dialogue is conversation"
    },
    {
      "question": "A long speech by one character is a?",
      "options": [
        "Aside",
        "Dialogue",
        "Chorus",
        "Monologue"
      ],
      "correct": 3,
      "explanation": "Monologue is a long solo speech"
    },
    {
      "question": "The events after the climax are the?",
      "options": [
        "Rising action",
        "Falling action",
        "Exposition",
        "Climax only"
      ],
      "correct": 1,
      "explanation": "Falling action follows the climax"
    },
    {
      "question": "A traditional song that tells a story is a?",
      "options": [
        "Ballad",
        "Elegy",
        "Ode",
        "Sonnet"
      ],
      "correct": 0,
      "explanation": "Ballads tell stories in song form"
    },
    {
      "question": "The atmosphere of a literary work is the?",
      "options": [
        "Tone only",
        "Plot only",
        "Mood",
        "Theme only"
      ],
      "correct": 2,
      "explanation": "Mood is the atmosphere"
    },
    {
      "question": "A writer's distinctive way of writing is his?",
      "options": [
        "Style",
        "Theme",
        "Setting",
        "Plot"
      ],
      "correct": 0,
      "explanation": "Style is the distinctive manner"
    },
    {
      "question": "The hero's fatal flaw in tragedy is?",
      "options": [
        "Peripeteia only",
        "Catharsis",
        "Hubris only",
        "Hamartia"
      ],
      "correct": 3,
      "explanation": "Hamartia is the tragic flaw"
    },
    {
      "question": "Excessive pride in a tragic hero is?",
      "options": [
        "Hamartia only",
        "Anagnorisis",
        "Catharsis",
        "Hubris"
      ],
      "correct": 3,
      "explanation": "Hubris is excessive pride"
    },
    {
      "question": "The moment of recognition in a tragedy is?",
      "options": [
        "Catharsis",
        "Peripeteia",
        "Hamartia",
        "Anagnorisis"
      ],
      "correct": 3,
      "explanation": "Anagnorisis is recognition"
    },
    {
      "question": "A work that criticises society through humour is?",
      "options": [
        "Elegy",
        "Epic",
        "Tragedy",
        "Satire"
      ],
      "correct": 3,
      "explanation": "Satire uses humour to criticise"
    },
    {
      "question": "The main character of a tragedy is the?",
      "options": [
        "Comic hero",
        "Narrator only",
        "Villain only",
        "Tragic hero"
      ],
      "correct": 3,
      "explanation": "Tragic hero is central in tragedy"
    },
    {
      "question": "A sudden revelation that changes understanding is?",
      "options": [
        "Epiphany",
        "Resolution",
        "Climax only",
        "Exposition"
      ],
      "correct": 0,
      "explanation": "Epiphany is a sudden insight"
    },
    {
      "question": "The arrangement of events is the?",
      "options": [
        "Diction only",
        "Style only",
        "Theme only",
        "Plot structure"
      ],
      "correct": 3,
      "explanation": "Plot structure is the arrangement"
    },
    {
      "question": "A story that could happen in real life is?",
      "options": [
        "Fantasy",
        "Myth only",
        "Science fiction only",
        "Realistic fiction"
      ],
      "correct": 3,
      "explanation": "Realistic fiction mirrors real life"
    },
    {
      "question": "A story with magical or supernatural elements is?",
      "options": [
        "Biography",
        "Historical fiction only",
        "Fantasy",
        "Realistic fiction"
      ],
      "correct": 2,
      "explanation": "Fantasy has supernatural elements"
    },
    {
      "question": "A novel based on historical events is?",
      "options": [
        "Fantasy",
        "Historical fiction",
        "Science fiction",
        "Mystery only"
      ],
      "correct": 1,
      "explanation": "Historical fiction uses real history"
    },
    {
      "question": "The person against whom the hero struggles is the?",
      "options": [
        "Antagonist",
        "Narrator",
        "Protagonist",
        "Author"
      ],
      "correct": 0,
      "explanation": "Antagonist opposes the hero"
    },
    {
      "question": "A short moral story is a?",
      "options": [
        "Epic",
        "Parable or fable",
        "Novel",
        "Drama only"
      ],
      "correct": 1,
      "explanation": "Parables and fables are short moral stories"
    },
    {
      "question": "The voice that tells the story is the?",
      "options": [
        "Author only",
        "Point of view / Narrator",
        "Protagonist only",
        "Antagonist only"
      ],
      "correct": 1,
      "explanation": "Narrator provides the point of view"
    },
    {
      "question": "A poem of serious reflection is a?",
      "options": [
        "Jingle",
        "Limerick",
        "Nursery rhyme",
        "Meditation or reflective lyric"
      ],
      "correct": 3,
      "explanation": "Reflective lyrics are serious"
    },
    {
      "question": "A character that represents a type is a?",
      "options": [
        "Round character",
        "Protagonist only",
        "Stock character",
        "Dynamic character"
      ],
      "correct": 2,
      "explanation": "Stock characters are stereotypes"
    },
    {
      "question": "The beginning of a story is the?",
      "options": [
        "Exposition",
        "Resolution",
        "Falling action",
        "Climax"
      ],
      "correct": 0,
      "explanation": "Exposition begins the story"
    },
    {
      "question": "A poem of mourning for the dead is an?",
      "options": [
        "Ode",
        "Ballad",
        "Elegy",
        "Sonnet"
      ],
      "correct": 2,
      "explanation": "Elegy mourns the dead"
    },
    {
      "question": "The use of words that appeal to the senses is?",
      "options": [
        "Irony",
        "Satire",
        "Imagery",
        "Paradox"
      ],
      "correct": 2,
      "explanation": "Imagery appeals to the senses"
    },
    {
      "question": "A comparison that continues throughout a work is an?",
      "options": [
        "Simple simile",
        "Alliteration",
        "Onomatopoeia",
        "Extended metaphor"
      ],
      "correct": 3,
      "explanation": "Extended metaphor runs through the work"
    },
    {
      "question": "The final outcome of a story is the?",
      "options": [
        "Rising action",
        "Exposition",
        "Climax",
        "Denouement / Resolution"
      ],
      "correct": 3,
      "explanation": "Denouement is the final outcome"
    },
    {
      "question": "A work intended to teach a moral is?",
      "options": [
        "Entertaining only",
        "Ambiguous only",
        "Confusing only",
        "Didactic"
      ],
      "correct": 3,
      "explanation": "Didactic works aim to teach"
    },
    {
      "question": "The main idea of a poem is the?",
      "options": [
        "Theme",
        "Rhyme",
        "Rhythm",
        "Meter only"
      ],
      "correct": 0,
      "explanation": "Theme is the main idea"
    },
    {
      "question": "A regular pattern of rhyme is a?",
      "options": [
        "Prose",
        "Blank verse only",
        "Free verse",
        "Rhyme scheme"
      ],
      "correct": 3,
      "explanation": "Rhyme scheme is the pattern"
    },
    {
      "question": "Poetry without regular rhyme or meter is?",
      "options": [
        "Sonnet",
        "Free verse",
        "Ballad",
        "Ode"
      ],
      "correct": 1,
      "explanation": "Free verse has no regular pattern"
    },
    {
      "question": "Unrhymed iambic pentameter is?",
      "options": [
        "Rhymed verse",
        "Free verse",
        "Prose",
        "Blank verse"
      ],
      "correct": 3,
      "explanation": "Blank verse is unrhymed iambic pentameter"
    },
    {
      "question": "A play that ends happily is a?",
      "options": [
        "Comedy",
        "Farce only",
        "Tragedy",
        "Tragicomedy only"
      ],
      "correct": 0,
      "explanation": "Comedy ends happily"
    },
    {
      "question": "A light dramatic work with exaggerated characters is a?",
      "options": [
        "Epic",
        "Elegy",
        "Tragedy",
        "Farce"
      ],
      "correct": 3,
      "explanation": "Farce is light and exaggerated"
    },
    {
      "question": "The audience's knowledge of something characters do not know is?",
      "options": [
        "Situational irony",
        "Verbal irony",
        "Dramatic irony",
        "Cosmic irony"
      ],
      "correct": 2,
      "explanation": "Dramatic irony involves audience knowledge"
    },
    {
      "question": "Saying the opposite of what is meant is?",
      "options": [
        "Verbal irony",
        "Situational irony",
        "Cosmic irony",
        "Dramatic irony"
      ],
      "correct": 0,
      "explanation": "Verbal irony is saying the opposite"
    },
    {
      "question": "A situation that is the opposite of what is expected is?",
      "options": [
        "Verbal irony",
        "Situational irony",
        "Dramatic irony",
        "Socratic irony"
      ],
      "correct": 1,
      "explanation": "Situational irony is unexpected outcome"
    },
    {
      "question": "The hero's journey is a common?",
      "options": [
        "Style only",
        "Theme only",
        "Setting only",
        "Archetype / Plot pattern"
      ],
      "correct": 3,
      "explanation": "The hero's journey is an archetypal plot"
    },
    {
      "question": "A symbol is?",
      "options": [
        "Only a setting",
        "Only a character",
        "Only a plot event",
        "Something that stands for something else"
      ],
      "correct": 3,
      "explanation": "A symbol represents something else"
    },
    {
      "question": "The feeling a work creates in the reader is the?",
      "options": [
        "Theme only",
        "Plot only",
        "Mood / Atmosphere",
        "Tone only"
      ],
      "correct": 2,
      "explanation": "Mood is the feeling created"
    },
    {
      "question": "The writer's attitude is the?",
      "options": [
        "Theme only",
        "Plot only",
        "Mood only",
        "Tone"
      ],
      "correct": 3,
      "explanation": "Tone is the writer's attitude"
    },
    {
      "question": "A short, witty statement is an?",
      "options": [
        "Epigram",
        "Epic",
        "Elegy",
        "Ode"
      ],
      "correct": 0,
      "explanation": "Epigram is a short witty statement"
    },
    {
      "question": "A long narrative poem is an?",
      "options": [
        "Lyric",
        "Sonnet",
        "Epic",
        "Haiku"
      ],
      "correct": 2,
      "explanation": "Epic is a long narrative poem"
    },
    {
      "question": "A Japanese poem of three lines is a?",
      "options": [
        "Ode",
        "Sonnet",
        "Ballad",
        "Haiku"
      ],
      "correct": 3,
      "explanation": "Haiku has three lines"
    },
    {
      "question": "The study of poetry's sound patterns is?",
      "options": [
        "Drama study only",
        "Novel study only",
        "Prosody",
        "Prose analysis"
      ],
      "correct": 2,
      "explanation": "Prosody studies poetic sound"
    },
    {
      "question": "A work that combines tragic and comic elements is a?",
      "options": [
        "Farce only",
        "Pure tragedy",
        "Tragicomedy",
        "Pure comedy"
      ],
      "correct": 2,
      "explanation": "Tragicomedy mixes both"
    },
    {
      "question": "A story that explains the origin of something is a?",
      "options": [
        "Parable",
        "Myth",
        "Fable",
        "Legend"
      ],
      "correct": 1,
      "explanation": "Myths often explain origins"
    },
    {
      "question": "A semi-true story about a historical figure is a?",
      "options": [
        "Legend",
        "Parable",
        "Fable",
        "Myth"
      ],
      "correct": 0,
      "explanation": "Legends are based on history but exaggerated"
    },
    {
      "question": "The main character in a story is the?",
      "options": [
        "Author only",
        "Antagonist",
        "Narrator only",
        "Protagonist"
      ],
      "correct": 3,
      "explanation": "Protagonist is the central character"
    },
    {
      "question": "The character who opposes the hero is the?",
      "options": [
        "Foil only",
        "Sidekick",
        "Antagonist",
        "Protagonist"
      ],
      "correct": 2,
      "explanation": "Antagonist opposes the protagonist"
    },
    {
      "question": "A character that highlights another by contrast is a?",
      "options": [
        "Protagonist",
        "Antagonist only",
        "Narrator",
        "Foil"
      ],
      "correct": 3,
      "explanation": "A foil contrasts with another character"
    },
    {
      "question": "The time and place of a story form the?",
      "options": [
        "Theme",
        "Style",
        "Plot",
        "Setting"
      ],
      "correct": 3,
      "explanation": "Setting is time and place"
    },
    {
      "question": "The central message of a work is the?",
      "options": [
        "Style",
        "Theme",
        "Plot",
        "Setting"
      ],
      "correct": 1,
      "explanation": "Theme is the central message"
    },
    {
      "question": "The sequence of events is the?",
      "options": [
        "Setting",
        "Plot",
        "Theme",
        "Style"
      ],
      "correct": 1,
      "explanation": "Plot is the sequence of events"
    },
    {
      "question": "A comparison using like or as is a?",
      "options": [
        "Personification",
        "Simile",
        "Metaphor",
        "Hyperbole"
      ],
      "correct": 1,
      "explanation": "Simile uses like or as"
    },
    {
      "question": "A direct comparison is a?",
      "options": [
        "Alliteration",
        "Assonance",
        "Simile",
        "Metaphor"
      ],
      "correct": 3,
      "explanation": "Metaphor is a direct comparison"
    },
    {
      "question": "Giving human traits to non-humans is?",
      "options": [
        "Hyperbole",
        "Simile",
        "Personification",
        "Metaphor"
      ],
      "correct": 2,
      "explanation": "Personification humanises non-humans"
    },
    {
      "question": "Deliberate exaggeration is?",
      "options": [
        "Hyperbole",
        "Paradox",
        "Irony",
        "Satire"
      ],
      "correct": 0,
      "explanation": "Hyperbole is exaggeration"
    },
    {
      "question": "The opposite of expectation is?",
      "options": [
        "Metaphor",
        "Irony",
        "Simile",
        "Alliteration"
      ],
      "correct": 1,
      "explanation": "Irony is the opposite of expectation"
    },
    {
      "question": "A work that ridicules to reform is?",
      "options": [
        "Satire",
        "Epic",
        "Elegy",
        "Tragedy"
      ],
      "correct": 0,
      "explanation": "Satire ridicules to bring change"
    },
    {
      "question": "A seeming contradiction is a?",
      "options": [
        "Simile",
        "Paradox",
        "Metaphor",
        "Irony"
      ],
      "correct": 1,
      "explanation": "Paradox appears contradictory"
    },
    {
      "question": "The peak of tension is the?",
      "options": [
        "Resolution",
        "Climax",
        "Falling action",
        "Exposition"
      ],
      "correct": 1,
      "explanation": "Climax is the peak"
    },
    {
      "question": "The introduction of characters and setting is?",
      "options": [
        "Climax",
        "Falling action",
        "Resolution",
        "Exposition"
      ],
      "correct": 3,
      "explanation": "Exposition introduces the story"
    },
    {
      "question": "The conclusion of a story is the?",
      "options": [
        "Climax",
        "Exposition",
        "Resolution",
        "Rising action"
      ],
      "correct": 2,
      "explanation": "Resolution concludes the story"
    },
    {
      "question": "A speech by one character alone is a?",
      "options": [
        "Soliloquy",
        "Aside",
        "Chorus",
        "Dialogue"
      ],
      "correct": 0,
      "explanation": "Soliloquy is a solo speech"
    },
    {
      "question": "A remark to the audience only is an?",
      "options": [
        "Soliloquy",
        "Monologue",
        "Aside",
        "Dialogue"
      ],
      "correct": 2,
      "explanation": "Aside is for the audience"
    },
    {
      "question": "Words that imitate sounds are?",
      "options": [
        "Onomatopoeia",
        "Assonance",
        "Alliteration",
        "Rhyme"
      ],
      "correct": 0,
      "explanation": "Onomatopoeia imitates sounds"
    },
    {
      "question": "Repetition of consonant sounds at the beginning is?",
      "options": [
        "Rhythm",
        "Assonance",
        "Alliteration",
        "Rhyme"
      ],
      "correct": 2,
      "explanation": "Alliteration repeats initial consonants"
    },
    {
      "question": "Repetition of vowel sounds is?",
      "options": [
        "Assonance",
        "Consonance",
        "Alliteration",
        "Rhyme"
      ],
      "correct": 0,
      "explanation": "Assonance repeats vowels"
    },
    {
      "question": "A fourteen-line poem is a?",
      "options": [
        "Sonnet",
        "Ballad",
        "Lyric",
        "Epic"
      ],
      "correct": 0,
      "explanation": "A sonnet has fourteen lines"
    },
    {
      "question": "A long heroic poem is an?",
      "options": [
        "Sonnet",
        "Epic",
        "Ode",
        "Lyric"
      ],
      "correct": 1,
      "explanation": "Epic is a long heroic poem"
    },
    {
      "question": "A story that teaches a moral using animals is a?",
      "options": [
        "Parable",
        "Legend",
        "Myth",
        "Fable"
      ],
      "correct": 3,
      "explanation": "Fables often use animals to teach morals"
    },
    {
      "question": "A simple story with a moral or spiritual lesson is a?",
      "options": [
        "Myth",
        "Legend",
        "Fable",
        "Parable"
      ],
      "correct": 3,
      "explanation": "Parables teach moral or spiritual lessons"
    },
    {
      "question": "The author's choice of words is called?",
      "options": [
        "Theme",
        "Syntax",
        "Diction",
        "Tone"
      ],
      "correct": 2,
      "explanation": "Diction is word choice"
    },
    {
      "question": "The arrangement of words is?",
      "options": [
        "Syntax",
        "Tone",
        "Diction",
        "Style"
      ],
      "correct": 0,
      "explanation": "Syntax is sentence structure"
    },
    {
      "question": "A work written to be performed is?",
      "options": [
        "Novel",
        "Poem only",
        "Essay",
        "Drama"
      ],
      "correct": 3,
      "explanation": "Drama is for performance"
    },
    {
      "question": "The main character is the?",
      "options": [
        "Foil",
        "Protagonist",
        "Antagonist",
        "Narrator only"
      ],
      "correct": 1,
      "explanation": "Protagonist is the main character"
    },
    {
      "question": "The opposing character is the?",
      "options": [
        "Antagonist",
        "Protagonist",
        "Sidekick",
        "Foil only"
      ],
      "correct": 0,
      "explanation": "Antagonist opposes the main character"
    },
    {
      "question": "A complex character is?",
      "options": [
        "Static only",
        "Stock",
        "Round",
        "Flat"
      ],
      "correct": 2,
      "explanation": "Round characters are complex"
    },
    {
      "question": "A simple character is?",
      "options": [
        "Dynamic",
        "Round",
        "Protagonist only",
        "Flat"
      ],
      "correct": 3,
      "explanation": "Flat characters are simple"
    },
    {
      "question": "A character that does not change is?",
      "options": [
        "Flat only",
        "Static",
        "Round only",
        "Dynamic"
      ],
      "correct": 1,
      "explanation": "Static characters do not change"
    },
    {
      "question": "A character that changes is?",
      "options": [
        "Dynamic",
        "Static",
        "Stock only",
        "Flat only"
      ],
      "correct": 0,
      "explanation": "Dynamic characters develop"
    },
    {
      "question": "The struggle in a story is the?",
      "options": [
        "Theme",
        "Conflict",
        "Setting",
        "Style"
      ],
      "correct": 1,
      "explanation": "Conflict is the struggle"
    },
    {
      "question": "Man vs nature is a type of?",
      "options": [
        "Style only",
        "Setting only",
        "Conflict",
        "Theme only"
      ],
      "correct": 2,
      "explanation": "It is a type of conflict"
    },
    {
      "question": "The highest point of the story is the?",
      "options": [
        "Climax",
        "Falling action",
        "Resolution",
        "Exposition"
      ],
      "correct": 0,
      "explanation": "Climax is the highest point"
    },
    {
      "question": "The end of the story is the?",
      "options": [
        "Resolution",
        "Climax",
        "Exposition",
        "Rising action"
      ],
      "correct": 0,
      "explanation": "Resolution is the end"
    },
    {
      "question": "A comparison with like or as is a?",
      "options": [
        "Metaphor",
        "Simile",
        "Personification",
        "Hyperbole"
      ],
      "correct": 1,
      "explanation": "Simile uses like or as"
    },
    {
      "question": "A direct comparison is a?",
      "options": [
        "Assonance",
        "Alliteration",
        "Metaphor",
        "Simile"
      ],
      "correct": 2,
      "explanation": "Metaphor is direct"
    },
    {
      "question": "Human qualities given to objects is?",
      "options": [
        "Hyperbole",
        "Metaphor",
        "Personification",
        "Simile"
      ],
      "correct": 2,
      "explanation": "Personification humanises objects"
    },
    {
      "question": "Exaggeration for effect is?",
      "options": [
        "Hyperbole",
        "Paradox",
        "Satire",
        "Irony"
      ],
      "correct": 0,
      "explanation": "Hyperbole is exaggeration"
    },
    {
      "question": "The opposite of what is expected is?",
      "options": [
        "Simile",
        "Irony",
        "Alliteration",
        "Metaphor"
      ],
      "correct": 1,
      "explanation": "Irony is unexpected"
    },
    {
      "question": "A work that mocks to improve is?",
      "options": [
        "Elegy",
        "Satire",
        "Tragedy",
        "Epic"
      ],
      "correct": 1,
      "explanation": "Satire mocks to improve"
    },
    {
      "question": "A contradiction that reveals truth is a?",
      "options": [
        "Irony",
        "Metaphor",
        "Simile",
        "Paradox"
      ],
      "correct": 3,
      "explanation": "Paradox reveals deeper truth"
    },
    {
      "question": "The writer's attitude is the?",
      "options": [
        "Plot",
        "Mood",
        "Tone",
        "Theme"
      ],
      "correct": 2,
      "explanation": "Tone is the writer's attitude"
    },
    {
      "question": "The feeling created in the reader is the?",
      "options": [
        "Theme",
        "Plot",
        "Tone",
        "Mood"
      ],
      "correct": 3,
      "explanation": "Mood is the feeling in the reader"
    },
    {
      "question": "A fourteen-line poem is a?",
      "options": [
        "Ballad",
        "Haiku",
        "Epic",
        "Sonnet"
      ],
      "correct": 3,
      "explanation": "Sonnet has fourteen lines"
    },
    {
      "question": "A poem that expresses personal emotion is a?",
      "options": [
        "Epic",
        "Sonnet only",
        "Ballad",
        "Lyric"
      ],
      "correct": 3,
      "explanation": "Lyric expresses personal feeling"
    },
    {
      "question": "A long narrative poem about heroes is an?",
      "options": [
        "Ode",
        "Lyric",
        "Sonnet",
        "Epic"
      ],
      "correct": 3,
      "explanation": "Epic is a long heroic poem"
    },
    {
      "question": "A poem of fourteen lines is a?",
      "options": [
        "Haiku",
        "Limerick",
        "Epic",
        "Sonnet"
      ],
      "correct": 3,
      "explanation": "Sonnet has fourteen lines"
    },
    {
      "question": "A Japanese three-line poem is a?",
      "options": [
        "Sonnet",
        "Ode",
        "Haiku",
        "Ballad"
      ],
      "correct": 2,
      "explanation": "Haiku has three lines"
    },
    {
      "question": "A poem of praise is an?",
      "options": [
        "Sonnet",
        "Elegy",
        "Ode",
        "Ballad"
      ],
      "correct": 2,
      "explanation": "Ode is a poem of praise"
    },
    {
      "question": "A poem of mourning is an?",
      "options": [
        "Sonnet",
        "Ballad",
        "Elegy",
        "Ode"
      ],
      "correct": 2,
      "explanation": "Elegy mourns the dead"
    },
    {
      "question": "A story poem often sung is a?",
      "options": [
        "Haiku",
        "Sonnet",
        "Ode",
        "Ballad"
      ],
      "correct": 3,
      "explanation": "Ballads tell stories in song"
    },
    {
      "question": "Repetition of initial consonants is?",
      "options": [
        "Alliteration",
        "Rhythm",
        "Rhyme",
        "Assonance"
      ],
      "correct": 0,
      "explanation": "Alliteration repeats consonants"
    },
    {
      "question": "Repetition of vowel sounds is?",
      "options": [
        "Rhyme",
        "Alliteration",
        "Assonance",
        "Consonance"
      ],
      "correct": 2,
      "explanation": "Assonance repeats vowels"
    },
    {
      "question": "Words that sound alike at line ends form?",
      "options": [
        "Rhyme",
        "Rhythm",
        "Meter",
        "Alliteration"
      ],
      "correct": 0,
      "explanation": "Rhyme is similar ending sounds"
    },
    {
      "question": "The pattern of stresses is?",
      "options": [
        "Alliteration",
        "Assonance",
        "Rhyme",
        "Rhythm"
      ],
      "correct": 3,
      "explanation": "Rhythm is the stress pattern"
    },
    {
      "question": "Poetry without regular rhyme or meter is?",
      "options": [
        "Rhymed verse",
        "Prose",
        "Free verse",
        "Blank verse"
      ],
      "correct": 2,
      "explanation": "Free verse has no regular pattern"
    },
    {
      "question": "Unrhymed iambic pentameter is?",
      "options": [
        "Free verse",
        "Rhymed verse",
        "Blank verse",
        "Prose"
      ],
      "correct": 2,
      "explanation": "Blank verse is unrhymed iambic pentameter"
    },
    {
      "question": "A play with a sad ending is a?",
      "options": [
        "Tragedy",
        "Melodrama",
        "Farce",
        "Comedy"
      ],
      "correct": 0,
      "explanation": "Tragedy ends unhappily"
    },
    {
      "question": "A play with a happy ending is a?",
      "options": [
        "Comedy",
        "Tragedy",
        "Epic",
        "Elegy"
      ],
      "correct": 0,
      "explanation": "Comedy ends happily"
    },
    {
      "question": "A light exaggerated play is a?",
      "options": [
        "Farce",
        "Tragedy",
        "Epic",
        "Elegy"
      ],
      "correct": 0,
      "explanation": "Farce is light and exaggerated"
    },
    {
      "question": "A speech alone on stage is a?",
      "options": [
        "Aside",
        "Soliloquy",
        "Dialogue",
        "Chorus"
      ],
      "correct": 1,
      "explanation": "Soliloquy is a solo speech"
    },
    {
      "question": "A remark only for the audience is an?",
      "options": [
        "Soliloquy",
        "Dialogue",
        "Aside",
        "Monologue"
      ],
      "correct": 2,
      "explanation": "Aside is for the audience"
    },
    {
      "question": "Conversation between characters is?",
      "options": [
        "Aside",
        "Dialogue",
        "Soliloquy",
        "Monologue"
      ],
      "correct": 1,
      "explanation": "Dialogue is conversation"
    },
    {
      "question": "A long speech by one character is a?",
      "options": [
        "Monologue",
        "Dialogue",
        "Chorus",
        "Aside"
      ],
      "correct": 0,
      "explanation": "Monologue is a long speech"
    },
    {
      "question": "The emotional release in tragedy is?",
      "options": [
        "Exposition",
        "Climax",
        "Catharsis",
        "Resolution"
      ],
      "correct": 2,
      "explanation": "Catharsis is emotional purging"
    },
    {
      "question": "The tragic hero's flaw is?",
      "options": [
        "Peripeteia only",
        "Hamartia",
        "Hubris only",
        "Catharsis"
      ],
      "correct": 1,
      "explanation": "Hamartia is the tragic flaw"
    },
    {
      "question": "Excessive pride is?",
      "options": [
        "Hubris",
        "Anagnorisis",
        "Catharsis",
        "Hamartia only"
      ],
      "correct": 0,
      "explanation": "Hubris is excessive pride"
    },
    {
      "question": "The moment of recognition is?",
      "options": [
        "Peripeteia",
        "Hamartia",
        "Catharsis",
        "Anagnorisis"
      ],
      "correct": 3,
      "explanation": "Anagnorisis is recognition"
    },
    {
      "question": "A sudden reversal of fortune is?",
      "options": [
        "Catharsis",
        "Peripeteia",
        "Anagnorisis",
        "Hamartia"
      ],
      "correct": 1,
      "explanation": "Peripeteia is reversal of fortune"
    },
    {
      "question": "A story within a story is a?",
      "options": [
        "Frame narrative",
        "Linear only",
        "No structure",
        "Simple plot"
      ],
      "correct": 0,
      "explanation": "Frame narrative contains another story"
    },
    {
      "question": "The purging of emotions is?",
      "options": [
        "Catharsis",
        "Exposition",
        "Climax",
        "Resolution"
      ],
      "correct": 0,
      "explanation": "Catharsis is emotional release"
    },
    {
      "question": "A character that stays the same is?",
      "options": [
        "Round only",
        "Dynamic",
        "Flat only",
        "Static"
      ],
      "correct": 3,
      "explanation": "Static characters do not change"
    },
    {
      "question": "A character that develops is?",
      "options": [
        "Dynamic",
        "Flat only",
        "Static",
        "Stock only"
      ],
      "correct": 0,
      "explanation": "Dynamic characters change"
    },
    {
      "question": "The struggle between forces is?",
      "options": [
        "Theme",
        "Style",
        "Setting",
        "Conflict"
      ],
      "correct": 3,
      "explanation": "Conflict is the struggle"
    },
    {
      "question": "A poem that tells a story is?",
      "options": [
        "Lyric only",
        "Narrative poem",
        "Sonnet only",
        "Ode only"
      ],
      "correct": 1,
      "explanation": "Narrative poems tell stories"
    },
    {
      "question": "Repetition of vowel sounds is?",
      "options": [
        "Consonance",
        "Rhyme",
        "Alliteration",
        "Assonance"
      ],
      "correct": 3,
      "explanation": "Assonance repeats vowels"
    },
    {
      "question": "A reference to something well-known is?",
      "options": [
        "Simile",
        "Illusion",
        "Metaphor",
        "Allusion"
      ],
      "correct": 3,
      "explanation": "Allusion refers to the known"
    },
    {
      "question": "The opposite of expectation is?",
      "options": [
        "Satire",
        "Irony",
        "Hyperbole",
        "Paradox"
      ],
      "correct": 1,
      "explanation": "Irony is unexpected"
    },
    {
      "question": "A work that ridicules folly is?",
      "options": [
        "Elegy",
        "Tragedy",
        "Epic",
        "Satire"
      ],
      "correct": 3,
      "explanation": "Satire ridicules folly"
    },
    {
      "question": "A seeming contradiction is?",
      "options": [
        "Metaphor",
        "Irony",
        "Paradox",
        "Simile"
      ],
      "correct": 2,
      "explanation": "Paradox seems contradictory"
    },
    {
      "question": "The end of a story is?",
      "options": [
        "Climax",
        "Resolution",
        "Rising action",
        "Exposition"
      ],
      "correct": 1,
      "explanation": "Resolution ends the story"
    },
    {
      "question": "The beginning of a story is?",
      "options": [
        "Resolution",
        "Falling action",
        "Exposition",
        "Climax"
      ],
      "correct": 2,
      "explanation": "Exposition begins the story"
    },
    {
      "question": "A speech to someone absent is?",
      "options": [
        "Apostrophe",
        "Dialogue",
        "Aside",
        "Soliloquy"
      ],
      "correct": 0,
      "explanation": "Apostrophe addresses the absent"
    },
    {
      "question": "The pattern of stresses is?",
      "options": [
        "Alliteration",
        "Rhythm",
        "Rhyme",
        "Meter only"
      ],
      "correct": 1,
      "explanation": "Rhythm is stress pattern"
    },
    {
      "question": "Similar ending sounds form?",
      "options": [
        "Rhythm",
        "Alliteration",
        "Meter",
        "Rhyme"
      ],
      "correct": 3,
      "explanation": "Rhyme is similar endings"
    },
    {
      "question": "A formal poem of praise is an?",
      "options": [
        "Ode",
        "Ballad",
        "Sonnet",
        "Elegy"
      ],
      "correct": 0,
      "explanation": "Ode is formal praise"
    },
    {
      "question": "A traditional explanatory story is a?",
      "options": [
        "Fable",
        "Myth",
        "Parable",
        "Legend"
      ],
      "correct": 1,
      "explanation": "Myths explain origins"
    },
    {
      "question": "A semi-historical story is a?",
      "options": [
        "Myth",
        "Fable",
        "Legend",
        "Parable"
      ],
      "correct": 2,
      "explanation": "Legends are semi-historical"
    },
    {
      "question": "A short moral animal story is a?",
      "options": [
        "Myth",
        "Parable",
        "Fable",
        "Legend"
      ],
      "correct": 2,
      "explanation": "Fables often use animals"
    },
    {
      "question": "A simple moral story is a?",
      "options": [
        "Myth",
        "Parable",
        "Legend",
        "Fable"
      ],
      "correct": 1,
      "explanation": "Parables teach morals"
    },
    {
      "question": "Word choice is?",
      "options": [
        "Tone",
        "Diction",
        "Theme",
        "Syntax"
      ],
      "correct": 1,
      "explanation": "Diction is word choice"
    },
    {
      "question": "Sentence structure is?",
      "options": [
        "Tone",
        "Style",
        "Syntax",
        "Diction"
      ],
      "correct": 2,
      "explanation": "Syntax is sentence structure"
    },
    {
      "question": "A work for the stage is?",
      "options": [
        "Poem only",
        "Novel",
        "Essay",
        "Drama"
      ],
      "correct": 3,
      "explanation": "Drama is for the stage"
    },
    {
      "question": "The writer's attitude is?",
      "options": [
        "Tone",
        "Plot",
        "Theme",
        "Mood"
      ],
      "correct": 0,
      "explanation": "Tone is the writer's attitude"
    }
  ],
  "crs": [
    {
      "question": "The first book of the Bible is?",
      "options": [
        "Genesis",
        "Matthew",
        "Psalms",
        "Exodus"
      ],
      "correct": 0,
      "explanation": "Genesis is the first book"
    },
    {
      "question": "Who led the Israelites out of Egypt?",
      "options": [
        "David",
        "Solomon",
        "Moses",
        "Abraham"
      ],
      "correct": 2,
      "explanation": "Moses led the Exodus"
    },
    {
      "question": "Jesus was born in?",
      "options": [
        "Jerusalem",
        "Bethlehem",
        "Nazareth",
        "Galilee"
      ],
      "correct": 1,
      "explanation": "Jesus was born in Bethlehem"
    },
    {
      "question": "The mother of Jesus was?",
      "options": [
        "Martha",
        "Elizabeth",
        "Sarah",
        "Mary"
      ],
      "correct": 3,
      "explanation": "Mary was the mother of Jesus"
    },
    {
      "question": "Jesus was baptised by?",
      "options": [
        "Peter",
        "Paul",
        "James",
        "John the Baptist"
      ],
      "correct": 3,
      "explanation": "John the Baptist baptised Jesus"
    },
    {
      "question": "The first disciples of Jesus were?",
      "options": [
        "Matthew and Thomas",
        "Peter and Andrew",
        "James and John only",
        "Philip and Bartholomew"
      ],
      "correct": 1,
      "explanation": "Peter and Andrew were among the first"
    },
    {
      "question": "Jesus fed five thousand with?",
      "options": [
        "Seven loaves",
        "Twelve baskets only",
        "One loaf",
        "Five loaves and two fish"
      ],
      "correct": 3,
      "explanation": "Five loaves and two fish fed the multitude"
    },
    {
      "question": "The shortest verse in the Bible is?",
      "options": [
        "Pray always",
        "God is love",
        "Jesus wept",
        "Fear not"
      ],
      "correct": 2,
      "explanation": "John 11:35 – Jesus wept"
    },
    {
      "question": "Who betrayed Jesus?",
      "options": [
        "Thomas",
        "Peter",
        "Judas Iscariot",
        "John"
      ],
      "correct": 2,
      "explanation": "Judas betrayed Jesus"
    },
    {
      "question": "Jesus was crucified at?",
      "options": [
        "Golgotha",
        "Nazareth",
        "Bethlehem",
        "Galilee"
      ],
      "correct": 0,
      "explanation": "Golgotha was the place of crucifixion"
    },
    {
      "question": "Jesus rose from the dead on the?",
      "options": [
        "Third day",
        "Seventh day",
        "Tenth day",
        "First day"
      ],
      "correct": 0,
      "explanation": "Resurrection was on the third day"
    },
    {
      "question": "The first Christian martyr was?",
      "options": [
        "Peter",
        "Stephen",
        "Paul",
        "James"
      ],
      "correct": 1,
      "explanation": "Stephen was the first martyr"
    },
    {
      "question": "Who wrote most of the New Testament letters?",
      "options": [
        "James",
        "John",
        "Peter",
        "Paul"
      ],
      "correct": 3,
      "explanation": "Paul wrote many epistles"
    },
    {
      "question": "The fruit of the Spirit includes?",
      "options": [
        "Fear, doubt, worry",
        "Pride, envy, greed",
        "Hatred, anger, strife",
        "Love, joy, peace"
      ],
      "correct": 3,
      "explanation": "Galatians 5 lists love, joy, peace"
    },
    {
      "question": "The greatest commandment according to Jesus is?",
      "options": [
        "Love God and love your neighbour",
        "Offer sacrifices",
        "Pay tithes only",
        "Keep the Sabbath only"
      ],
      "correct": 0,
      "explanation": "Love of God and neighbour is the greatest"
    },
    {
      "question": "Who was swallowed by a great fish?",
      "options": [
        "David",
        "Moses",
        "Jonah",
        "Noah"
      ],
      "correct": 2,
      "explanation": "Jonah was swallowed by a fish"
    },
    {
      "question": "The Ten Commandments were given to?",
      "options": [
        "Solomon",
        "Moses",
        "David",
        "Abraham"
      ],
      "correct": 1,
      "explanation": "Moses received the Ten Commandments"
    },
    {
      "question": "Jesus taught in?",
      "options": [
        "Only songs",
        "Only proverbs",
        "Only laws",
        "Parables"
      ],
      "correct": 3,
      "explanation": "Jesus often used parables"
    },
    {
      "question": "The Holy Spirit came upon the disciples on?",
      "options": [
        "Easter only",
        "Christmas",
        "Pentecost",
        "Passover"
      ],
      "correct": 2,
      "explanation": "Pentecost marks the coming of the Spirit"
    },
    {
      "question": "Who denied Jesus three times?",
      "options": [
        "Peter",
        "Andrew",
        "James",
        "John"
      ],
      "correct": 0,
      "explanation": "Peter denied Jesus three times"
    },
    {
      "question": "The last book of the Bible is?",
      "options": [
        "Genesis",
        "Revelation",
        "Psalms",
        "Matthew"
      ],
      "correct": 1,
      "explanation": "Revelation is the last book"
    },
    {
      "question": "Jesus said 'I am the way, the truth and the...'",
      "options": [
        "Bread",
        "Door",
        "Light",
        "Life"
      ],
      "correct": 3,
      "explanation": "John 14:6 – the life"
    },
    {
      "question": "Who was the father of Isaac?",
      "options": [
        "Abraham",
        "Joseph",
        "Moses",
        "Jacob"
      ],
      "correct": 0,
      "explanation": "Abraham was the father of Isaac"
    },
    {
      "question": "The Golden Rule is?",
      "options": [
        "Love yourself first",
        "Do unto others as you would have them do unto you",
        "Ignore others",
        "Hate your enemies"
      ],
      "correct": 1,
      "explanation": "The Golden Rule is about treating others well"
    },
    {
      "question": "Jesus washed the feet of his disciples to teach?",
      "options": [
        "Wealth",
        "Pride",
        "Power",
        "Humility and service"
      ],
      "correct": 3,
      "explanation": "It was a lesson in humility"
    },
    {
      "question": "The first man created by God was?",
      "options": [
        "Noah",
        "Abraham",
        "Adam",
        "Moses"
      ],
      "correct": 2,
      "explanation": "Adam was the first man"
    },
    {
      "question": "The first woman was?",
      "options": [
        "Mary",
        "Sarah",
        "Eve",
        "Ruth"
      ],
      "correct": 2,
      "explanation": "Eve was the first woman"
    },
    {
      "question": "Noah built an?",
      "options": [
        "Altar only",
        "Temple",
        "Ark",
        "Tower"
      ],
      "correct": 2,
      "explanation": "Noah built the ark"
    },
    {
      "question": "Abraham's son of promise was?",
      "options": [
        "Isaac",
        "Ishmael",
        "Esau",
        "Jacob"
      ],
      "correct": 0,
      "explanation": "Isaac was the son of promise"
    },
    {
      "question": "Jacob's name was changed to?",
      "options": [
        "Isaac",
        "Abraham",
        "Joseph",
        "Israel"
      ],
      "correct": 3,
      "explanation": "Jacob became Israel"
    },
    {
      "question": "Joseph was sold into slavery in?",
      "options": [
        "Babylon",
        "Egypt",
        "Assyria",
        "Canaan only"
      ],
      "correct": 1,
      "explanation": "Joseph was taken to Egypt"
    },
    {
      "question": "Moses received the law at?",
      "options": [
        "Mount Olives",
        "Mount Sinai",
        "Mount Zion",
        "Mount Carmel"
      ],
      "correct": 1,
      "explanation": "The law was given at Sinai"
    },
    {
      "question": "David killed?",
      "options": [
        "Goliath",
        "Jonathan",
        "Saul",
        "Absalom only"
      ],
      "correct": 0,
      "explanation": "David killed Goliath"
    },
    {
      "question": "Solomon was known for his?",
      "options": [
        "Wisdom",
        "Speed",
        "Strength only",
        "Wealth only"
      ],
      "correct": 0,
      "explanation": "Solomon was famous for wisdom"
    },
    {
      "question": "The prophet who was taken to heaven in a chariot of fire was?",
      "options": [
        "Elijah",
        "Jeremiah",
        "Isaiah",
        "Elisha"
      ],
      "correct": 0,
      "explanation": "Elijah was taken up in a chariot"
    },
    {
      "question": "Daniel was thrown into the?",
      "options": [
        "Lions' den",
        "River",
        "Fiery furnace",
        "Prison only"
      ],
      "correct": 0,
      "explanation": "Daniel was in the lions' den"
    },
    {
      "question": "The three Hebrew boys were thrown into?",
      "options": [
        "Lions' den",
        "Prison",
        "Sea",
        "Fiery furnace"
      ],
      "correct": 3,
      "explanation": "They were in the fiery furnace"
    },
    {
      "question": "Jesus was tempted by?",
      "options": [
        "Peter",
        "Satan",
        "Pilate",
        "Judas"
      ],
      "correct": 1,
      "explanation": "Satan tempted Jesus"
    },
    {
      "question": "The first miracle of Jesus was?",
      "options": [
        "Raising Lazarus",
        "Turning water into wine",
        "Walking on water",
        "Feeding five thousand"
      ],
      "correct": 1,
      "explanation": "The first miracle was at Cana"
    },
    {
      "question": "Jesus raised from the dead?",
      "options": [
        "Peter",
        "Lazarus",
        "John",
        "James"
      ],
      "correct": 1,
      "explanation": "Jesus raised Lazarus"
    },
    {
      "question": "The disciple who doubted was?",
      "options": [
        "Andrew",
        "Peter",
        "Thomas",
        "John"
      ],
      "correct": 2,
      "explanation": "Thomas was the doubter"
    },
    {
      "question": "Saul's name was changed to?",
      "options": [
        "Paul",
        "James",
        "Peter",
        "John"
      ],
      "correct": 0,
      "explanation": "Saul became Paul"
    },
    {
      "question": "The love chapter in the Bible is?",
      "options": [
        "Matthew 5",
        "John 3",
        "Psalm 23",
        "1 Corinthians 13"
      ],
      "correct": 3,
      "explanation": "1 Corinthians 13 is about love"
    },
    {
      "question": "Jesus said 'Let the little children come to me' to teach?",
      "options": [
        "Only adult faith",
        "Humility and acceptance",
        "Rejection of children",
        "Strict rules"
      ],
      "correct": 1,
      "explanation": "He welcomed children"
    },
    {
      "question": "The Good Samaritan parable teaches?",
      "options": [
        "Love for neighbour",
        "Hatred for enemies",
        "Only self-love",
        "Ignoring others"
      ],
      "correct": 0,
      "explanation": "It teaches care for others"
    },
    {
      "question": "The prodigal son parable teaches?",
      "options": [
        "Forgiveness and repentance",
        "Pride",
        "Rejection",
        "Punishment only"
      ],
      "correct": 0,
      "explanation": "It shows God's forgiveness"
    },
    {
      "question": "Jesus washed the disciples' feet at the?",
      "options": [
        "Transfiguration",
        "Ascension",
        "Sermon on the Mount",
        "Last Supper"
      ],
      "correct": 3,
      "explanation": "It was during the Last Supper"
    },
    {
      "question": "The Great Commission is to?",
      "options": [
        "Avoid preaching",
        "Make disciples of all nations",
        "Stay in one place",
        "Only pray"
      ],
      "correct": 1,
      "explanation": "Jesus commanded worldwide discipleship"
    },
    {
      "question": "The fruit of the Spirit is found in?",
      "options": [
        "Matthew 5",
        "John 3",
        "Romans 8",
        "Galatians 5"
      ],
      "correct": 3,
      "explanation": "Galatians 5 lists the fruit"
    },
    {
      "question": "Faith without works is?",
      "options": [
        "Strong",
        "Dead",
        "Perfect",
        "Alive"
      ],
      "correct": 1,
      "explanation": "James teaches faith without works is dead"
    },
    {
      "question": "The creation story is found in?",
      "options": [
        "Matthew",
        "Genesis",
        "Exodus",
        "Revelation"
      ],
      "correct": 1,
      "explanation": "Creation is in Genesis"
    },
    {
      "question": "Cain killed?",
      "options": [
        "Noah",
        "Abel",
        "Abraham",
        "Seth"
      ],
      "correct": 1,
      "explanation": "Cain killed Abel"
    },
    {
      "question": "The rainbow was a sign of God's?",
      "options": [
        "Covenant with Noah",
        "Anger",
        "Silence",
        "Judgment only"
      ],
      "correct": 0,
      "explanation": "The rainbow was the sign of the covenant"
    },
    {
      "question": "Abraham was called out of?",
      "options": [
        "Babylon only",
        "Ur of the Chaldees",
        "Assyria",
        "Egypt"
      ],
      "correct": 1,
      "explanation": "Abraham came from Ur"
    },
    {
      "question": "Isaac's sons were?",
      "options": [
        "Joseph and Benjamin",
        "Esau and Jacob",
        "Moses and Aaron",
        "Cain and Abel"
      ],
      "correct": 1,
      "explanation": "Esau and Jacob were Isaac's sons"
    },
    {
      "question": "Joseph interpreted dreams in?",
      "options": [
        "Canaan",
        "Assyria",
        "Babylon",
        "Egypt"
      ],
      "correct": 3,
      "explanation": "Joseph interpreted dreams in Egypt"
    },
    {
      "question": "The Israelites crossed the?",
      "options": [
        "Euphrates",
        "Jordan only",
        "Nile only",
        "Red Sea"
      ],
      "correct": 3,
      "explanation": "They crossed the Red Sea"
    },
    {
      "question": "The Ten Commandments are also called?",
      "options": [
        "Decalogue",
        "Gospel",
        "Epistle",
        "Pentateuch"
      ],
      "correct": 0,
      "explanation": "Decalogue means ten words"
    },
    {
      "question": "David was a?",
      "options": [
        "Only a farmer",
        "Shepherd, musician and king",
        "Only a prophet",
        "Only a priest"
      ],
      "correct": 1,
      "explanation": "David had many roles"
    },
    {
      "question": "Solomon built the?",
      "options": [
        "Pyramid",
        "Ark only",
        "Tower of Babel",
        "Temple in Jerusalem"
      ],
      "correct": 3,
      "explanation": "Solomon built the Temple"
    },
    {
      "question": "Isaiah prophesied about the?",
      "options": [
        "Only judgment",
        "Coming Messiah",
        "Only restoration",
        "Only exile"
      ],
      "correct": 1,
      "explanation": "Isaiah spoke of the Messiah"
    },
    {
      "question": "Jeremiah was known as the?",
      "options": [
        "Minor prophet only",
        "Weeping prophet",
        "Major prophet only",
        "King"
      ],
      "correct": 1,
      "explanation": "Jeremiah is called the weeping prophet"
    },
    {
      "question": "Jesus was tempted in the?",
      "options": [
        "Temple only",
        "City only",
        "Wilderness",
        "Synagogue only"
      ],
      "correct": 2,
      "explanation": "Jesus was tempted in the wilderness"
    },
    {
      "question": "The Beatitudes are found in?",
      "options": [
        "Mark 1",
        "Matthew 5",
        "Luke 15",
        "John 3"
      ],
      "correct": 1,
      "explanation": "Beatitudes are in Matthew 5"
    },
    {
      "question": "Jesus calmed the?",
      "options": [
        "Disciples only",
        "Crowd only",
        "Pharisees only",
        "Storm"
      ],
      "correct": 3,
      "explanation": "Jesus calmed the storm"
    },
    {
      "question": "The Lord's Prayer is found in?",
      "options": [
        "Mark 1",
        "Matthew 6",
        "Luke 15",
        "John 3"
      ],
      "correct": 1,
      "explanation": "The Lord's Prayer is in Matthew 6"
    },
    {
      "question": "Jesus rode into Jerusalem on a?",
      "options": [
        "Horse",
        "Camel",
        "Chariot",
        "Donkey"
      ],
      "correct": 3,
      "explanation": "Jesus rode a donkey"
    },
    {
      "question": "Peter cut off the ear of?",
      "options": [
        "Malchus",
        "Pilate",
        "Caiaphas",
        "Judas"
      ],
      "correct": 0,
      "explanation": "Peter cut off Malchus' ear"
    },
    {
      "question": "Jesus was crucified between?",
      "options": [
        "Two priests",
        "Two soldiers",
        "Two disciples",
        "Two thieves"
      ],
      "correct": 3,
      "explanation": "Two thieves were crucified with Him"
    },
    {
      "question": "On the cross Jesus said?",
      "options": [
        "My God why only",
        "Father forgive only",
        "I am thirsty only",
        "It is finished"
      ],
      "correct": 3,
      "explanation": "One of His sayings was 'It is finished'"
    },
    {
      "question": "Jesus appeared first after resurrection to?",
      "options": [
        "John only",
        "Mary Magdalene",
        "Thomas only",
        "Peter only"
      ],
      "correct": 1,
      "explanation": "Mary Magdalene saw Him first"
    },
    {
      "question": "The Ascension of Jesus took place at?",
      "options": [
        "Mount Zion only",
        "Mount Carmel",
        "Mount Sinai",
        "Mount of Olives"
      ],
      "correct": 3,
      "explanation": "Jesus ascended from the Mount of Olives"
    },
    {
      "question": "The early church began in?",
      "options": [
        "Jerusalem",
        "Corinth",
        "Rome",
        "Athens"
      ],
      "correct": 0,
      "explanation": "The church began in Jerusalem"
    },
    {
      "question": "Paul's first missionary journey was with?",
      "options": [
        "Barnabas",
        "James",
        "Peter",
        "John"
      ],
      "correct": 0,
      "explanation": "Paul went with Barnabas"
    },
    {
      "question": "The greatest of these is?",
      "options": [
        "Love",
        "Gifts only",
        "Hope only",
        "Faith only"
      ],
      "correct": 0,
      "explanation": "1 Corinthians 13 says the greatest is love"
    },
    {
      "question": "The serpent tempted?",
      "options": [
        "Abraham",
        "Adam only",
        "Eve",
        "Noah"
      ],
      "correct": 2,
      "explanation": "The serpent tempted Eve"
    },
    {
      "question": "After the flood, Noah offered a?",
      "options": [
        "Sacrifice",
        "Dance",
        "Prayer only",
        "Song only"
      ],
      "correct": 0,
      "explanation": "Noah offered a sacrifice"
    },
    {
      "question": "God's covenant with Abraham included?",
      "options": [
        "Only power",
        "Only long life",
        "Land and descendants",
        "Only wealth"
      ],
      "correct": 2,
      "explanation": "Land and many descendants were promised"
    },
    {
      "question": "Jacob wrestled with?",
      "options": [
        "Laban",
        "An angel / God",
        "Esau",
        "Joseph"
      ],
      "correct": 1,
      "explanation": "Jacob wrestled with a divine being"
    },
    {
      "question": "Joseph became a ruler in?",
      "options": [
        "Assyria",
        "Egypt",
        "Babylon",
        "Canaan"
      ],
      "correct": 1,
      "explanation": "Joseph rose to power in Egypt"
    },
    {
      "question": "Moses' brother was?",
      "options": [
        "Joshua",
        "Aaron",
        "Miriam only",
        "Caleb"
      ],
      "correct": 1,
      "explanation": "Aaron was Moses' brother"
    },
    {
      "question": "The Israelites wandered in the wilderness for?",
      "options": [
        "Forty years",
        "Twenty years",
        "Ten years",
        "Seven years"
      ],
      "correct": 0,
      "explanation": "They wandered for forty years"
    },
    {
      "question": "Joshua led the Israelites into?",
      "options": [
        "Egypt",
        "Babylon",
        "Assyria",
        "Canaan"
      ],
      "correct": 3,
      "explanation": "Joshua led them into the Promised Land"
    },
    {
      "question": "Samuel anointed?",
      "options": [
        "Saul and David",
        "Only Abraham",
        "Only Solomon",
        "Only Moses"
      ],
      "correct": 0,
      "explanation": "Samuel anointed both Saul and David"
    },
    {
      "question": "David brought the Ark to?",
      "options": [
        "Bethlehem",
        "Jerusalem",
        "Nazareth",
        "Hebron only"
      ],
      "correct": 1,
      "explanation": "David brought the Ark to Jerusalem"
    },
    {
      "question": "Solomon asked God for?",
      "options": [
        "Wealth only",
        "Victory only",
        "Wisdom",
        "Long life only"
      ],
      "correct": 2,
      "explanation": "Solomon asked for wisdom"
    },
    {
      "question": "The kingdom divided after?",
      "options": [
        "Saul's death",
        "Solomon's death",
        "Moses' death",
        "David's death"
      ],
      "correct": 1,
      "explanation": "The kingdom split after Solomon"
    },
    {
      "question": "Elijah challenged the prophets of?",
      "options": [
        "Asherah only",
        "Yahweh only",
        "Baal",
        "Molech only"
      ],
      "correct": 2,
      "explanation": "Elijah challenged Baal's prophets"
    },
    {
      "question": "Elisha received a double portion of?",
      "options": [
        "Elijah's spirit",
        "Land",
        "Wealth",
        "Power only"
      ],
      "correct": 0,
      "explanation": "Elisha asked for a double portion"
    },
    {
      "question": "Isaiah's vision of God was in the?",
      "options": [
        "Palace only",
        "Field",
        "Temple",
        "Wilderness"
      ],
      "correct": 2,
      "explanation": "Isaiah saw the vision in the temple"
    },
    {
      "question": "Jeremiah prophesied the fall of?",
      "options": [
        "Jerusalem",
        "Assyria only",
        "Babylon only",
        "Egypt"
      ],
      "correct": 0,
      "explanation": "Jeremiah warned of Jerusalem's fall"
    },
    {
      "question": "Daniel was taken to?",
      "options": [
        "Persia only",
        "Babylon",
        "Assyria",
        "Egypt"
      ],
      "correct": 1,
      "explanation": "Daniel was taken to Babylon"
    },
    {
      "question": "Jesus was baptised in the?",
      "options": [
        "Sea of Galilee only",
        "Nile",
        "River Jordan",
        "Red Sea"
      ],
      "correct": 2,
      "explanation": "Jesus was baptised in the Jordan"
    },
    {
      "question": "Jesus' first disciples were fishermen from?",
      "options": [
        "Judea only",
        "Jerusalem only",
        "Galilee",
        "Samaria only"
      ],
      "correct": 2,
      "explanation": "They were from Galilee"
    },
    {
      "question": "The Sermon on the Mount is in?",
      "options": [
        "John only",
        "Matthew",
        "Luke only",
        "Mark only"
      ],
      "correct": 1,
      "explanation": "The Sermon is mainly in Matthew"
    },
    {
      "question": "Jesus raised Jairus'?",
      "options": [
        "Friend only",
        "Son",
        "Servant only",
        "Daughter"
      ],
      "correct": 3,
      "explanation": "Jesus raised Jairus' daughter"
    },
    {
      "question": "The Last Supper was a?",
      "options": [
        "Funeral meal",
        "Wedding feast",
        "Passover meal",
        "Ordinary lunch"
      ],
      "correct": 2,
      "explanation": "It was a Passover meal"
    },
    {
      "question": "Jesus prayed in?",
      "options": [
        "Capernaum only",
        "Bethlehem",
        "Gethsemane",
        "Nazareth"
      ],
      "correct": 2,
      "explanation": "Jesus prayed in Gethsemane"
    },
    {
      "question": "Pilate found no fault in?",
      "options": [
        "Jesus",
        "John",
        "Peter",
        "Barabbas"
      ],
      "correct": 0,
      "explanation": "Pilate found no fault in Jesus"
    },
    {
      "question": "The resurrection is celebrated on?",
      "options": [
        "Christmas",
        "Easter",
        "Ascension only",
        "Pentecost only"
      ],
      "correct": 1,
      "explanation": "Easter celebrates the resurrection"
    },
    {
      "question": "God created the world in?",
      "options": [
        "Six days",
        "Five days",
        "Seven days",
        "Ten days"
      ],
      "correct": 0,
      "explanation": "Creation took six days"
    },
    {
      "question": "God rested on the?",
      "options": [
        "Sixth day",
        "Seventh day",
        "Third day",
        "First day"
      ],
      "correct": 1,
      "explanation": "God rested on the seventh day"
    },
    {
      "question": "Adam and Eve lived in?",
      "options": [
        "Garden of Eden",
        "Egypt",
        "Canaan",
        "Babylon"
      ],
      "correct": 0,
      "explanation": "They lived in Eden"
    },
    {
      "question": "The first murder was committed by?",
      "options": [
        "Cain",
        "Abel",
        "Noah",
        "Seth"
      ],
      "correct": 0,
      "explanation": "Cain killed Abel"
    },
    {
      "question": "Noah's ark saved?",
      "options": [
        "Only animals",
        "The whole world",
        "Noah's family and animals",
        "Only Noah"
      ],
      "correct": 2,
      "explanation": "Noah's family and animals were saved"
    },
    {
      "question": "Abraham's original name was?",
      "options": [
        "Jacob",
        "Isaac",
        "Abram",
        "Israel"
      ],
      "correct": 2,
      "explanation": "Abram became Abraham"
    },
    {
      "question": "Isaac's wife was?",
      "options": [
        "Rachel",
        "Sarah",
        "Leah",
        "Rebekah"
      ],
      "correct": 3,
      "explanation": "Rebekah was Isaac's wife"
    },
    {
      "question": "Jacob had how many sons?",
      "options": [
        "Ten",
        "Twelve",
        "Thirteen",
        "Eleven"
      ],
      "correct": 1,
      "explanation": "Jacob had twelve sons"
    },
    {
      "question": "Joseph's special gift was?",
      "options": [
        "Interpreting dreams",
        "Fighting",
        "Farming only",
        "Trading only"
      ],
      "correct": 0,
      "explanation": "Joseph interpreted dreams"
    },
    {
      "question": "Moses was hidden in a?",
      "options": [
        "Basket among the reeds",
        "Temple",
        "Cave",
        "House"
      ],
      "correct": 0,
      "explanation": "Moses was placed in a basket"
    },
    {
      "question": "God spoke to Moses from a?",
      "options": [
        "Mountain only",
        "Cloud only",
        "Burning bush",
        "River"
      ],
      "correct": 2,
      "explanation": "God spoke from the burning bush"
    },
    {
      "question": "The last plague in Egypt was the?",
      "options": [
        "Death of the firstborn",
        "Locusts",
        "Darkness only",
        "Frogs"
      ],
      "correct": 0,
      "explanation": "The final plague was the death of the firstborn"
    },
    {
      "question": "The Israelites celebrated the first?",
      "options": [
        "Passover",
        "Trumpets only",
        "Tabernacles only",
        "Pentecost"
      ],
      "correct": 0,
      "explanation": "The first Passover was in Egypt"
    },
    {
      "question": "Moses received the law on?",
      "options": [
        "Mount Carmel",
        "Mount Sinai",
        "Mount Zion",
        "Mount Olives"
      ],
      "correct": 1,
      "explanation": "The law was given at Sinai"
    },
    {
      "question": "Joshua succeeded?",
      "options": [
        "Miriam",
        "Moses",
        "Aaron",
        "Caleb"
      ],
      "correct": 1,
      "explanation": "Joshua succeeded Moses"
    },
    {
      "question": "David was anointed by?",
      "options": [
        "Elijah",
        "Gad only",
        "Nathan only",
        "Samuel"
      ],
      "correct": 3,
      "explanation": "Samuel anointed David"
    },
    {
      "question": "David's greatest sin involved?",
      "options": [
        "Bathsheba",
        "Saul only",
        "Jonathan only",
        "Goliath"
      ],
      "correct": 0,
      "explanation": "David sinned with Bathsheba"
    },
    {
      "question": "Solomon built the temple in?",
      "options": [
        "Bethlehem",
        "Jerusalem",
        "Nazareth",
        "Hebron"
      ],
      "correct": 1,
      "explanation": "The temple was in Jerusalem"
    },
    {
      "question": "The kingdom split into?",
      "options": [
        "Israel and Judah",
        "East and West",
        "Only one kingdom",
        "North and South America"
      ],
      "correct": 0,
      "explanation": "It split into Israel and Judah"
    },
    {
      "question": "Elijah was taken up in a?",
      "options": [
        "Cloud",
        "Whirlwind only",
        "Angel's arms only",
        "Chariot of fire"
      ],
      "correct": 3,
      "explanation": "Elijah went up in a chariot of fire"
    },
    {
      "question": "Daniel was thrown into the?",
      "options": [
        "Prison only",
        "Furnace",
        "Lions' den",
        "Sea"
      ],
      "correct": 2,
      "explanation": "Daniel was in the lions' den"
    },
    {
      "question": "Jesus was born in the time of?",
      "options": [
        "Herod the Great",
        "Pharaoh",
        "Caesar only",
        "Pilate only"
      ],
      "correct": 0,
      "explanation": "Jesus was born in Herod's time"
    },
    {
      "question": "The wise men followed a?",
      "options": [
        "Angel only",
        "Star",
        "Cloud",
        "Prophet only"
      ],
      "correct": 1,
      "explanation": "The wise men followed a star"
    },
    {
      "question": "Jesus grew up in?",
      "options": [
        "Jerusalem",
        "Capernaum only",
        "Bethlehem",
        "Nazareth"
      ],
      "correct": 3,
      "explanation": "Jesus grew up in Nazareth"
    },
    {
      "question": "Jesus began his ministry at about age?",
      "options": [
        "Forty",
        "Thirty",
        "Twenty",
        "Twelve"
      ],
      "correct": 1,
      "explanation": "Jesus was about thirty"
    },
    {
      "question": "The first book of the New Testament is?",
      "options": [
        "Psalms",
        "Matthew",
        "Genesis",
        "Revelation"
      ],
      "correct": 1,
      "explanation": "Matthew is the first Gospel"
    },
    {
      "question": "Jesus was born in?",
      "options": [
        "Bethlehem",
        "Galilee",
        "Jerusalem",
        "Nazareth"
      ],
      "correct": 0,
      "explanation": "Jesus was born in Bethlehem"
    },
    {
      "question": "Jesus' mother was?",
      "options": [
        "Mary Magdalene",
        "Elizabeth",
        "Mary",
        "Martha"
      ],
      "correct": 2,
      "explanation": "Mary was His mother"
    },
    {
      "question": "Jesus was baptised by?",
      "options": [
        "Paul",
        "Peter",
        "John the Baptist",
        "James"
      ],
      "correct": 2,
      "explanation": "John baptised Jesus"
    },
    {
      "question": "Jesus' first miracle was at?",
      "options": [
        "Nazareth",
        "Jerusalem",
        "Capernaum",
        "Cana"
      ],
      "correct": 3,
      "explanation": "The first miracle was at Cana"
    },
    {
      "question": "Jesus fed five thousand with?",
      "options": [
        "One loaf",
        "Twelve baskets",
        "Five loaves and two fish",
        "Seven loaves"
      ],
      "correct": 2,
      "explanation": "Five loaves and two fish"
    },
    {
      "question": "Jesus walked on?",
      "options": [
        "Fire",
        "Water",
        "Air only",
        "Land only"
      ],
      "correct": 1,
      "explanation": "Jesus walked on water"
    },
    {
      "question": "Jesus raised?",
      "options": [
        "John",
        "Peter",
        "Lazarus",
        "James"
      ],
      "correct": 2,
      "explanation": "Jesus raised Lazarus"
    },
    {
      "question": "Jesus taught in?",
      "options": [
        "Only proverbs",
        "Only songs",
        "Only laws",
        "Parables"
      ],
      "correct": 3,
      "explanation": "Jesus used parables"
    },
    {
      "question": "The Golden Rule is?",
      "options": [
        "Do to others as you want them to do to you",
        "Love yourself only",
        "Ignore others",
        "Hate enemies"
      ],
      "correct": 0,
      "explanation": "Treat others as you want to be treated"
    },
    {
      "question": "Jesus washed the disciples'?",
      "options": [
        "Clothes",
        "Heads only",
        "Feet",
        "Hands only"
      ],
      "correct": 2,
      "explanation": "Jesus washed their feet"
    },
    {
      "question": "Judas betrayed Jesus for?",
      "options": [
        "Thirty pieces of silver",
        "Gold",
        "Power",
        "Land"
      ],
      "correct": 0,
      "explanation": "Judas received thirty pieces of silver"
    },
    {
      "question": "Jesus was crucified at?",
      "options": [
        "Golgotha",
        "Bethlehem",
        "Galilee",
        "Nazareth"
      ],
      "correct": 0,
      "explanation": "Golgotha was the place"
    },
    {
      "question": "Jesus rose on the?",
      "options": [
        "First day",
        "Third day",
        "Tenth day",
        "Seventh day"
      ],
      "correct": 1,
      "explanation": "Resurrection was on the third day"
    },
    {
      "question": "The Holy Spirit came at?",
      "options": [
        "Passover",
        "Christmas",
        "Easter only",
        "Pentecost"
      ],
      "correct": 3,
      "explanation": "The Spirit came at Pentecost"
    },
    {
      "question": "The first Christian martyr was?",
      "options": [
        "Paul",
        "Peter",
        "Stephen",
        "James"
      ],
      "correct": 2,
      "explanation": "Stephen was the first martyr"
    },
    {
      "question": "Saul became?",
      "options": [
        "James",
        "Peter",
        "Paul",
        "John"
      ],
      "correct": 2,
      "explanation": "Saul became Paul"
    },
    {
      "question": "Paul wrote many?",
      "options": [
        "Proverbs",
        "Epistles",
        "Gospels only",
        "Psalms"
      ],
      "correct": 1,
      "explanation": "Paul wrote many letters"
    },
    {
      "question": "The fruit of the Spirit includes?",
      "options": [
        "Fear, doubt",
        "Hatred, anger",
        "Love, joy, peace",
        "Pride, envy"
      ],
      "correct": 2,
      "explanation": "Love, joy and peace are fruits"
    },
    {
      "question": "Faith without works is?",
      "options": [
        "Alive",
        "Strong",
        "Perfect",
        "Dead"
      ],
      "correct": 3,
      "explanation": "Faith without works is dead"
    },
    {
      "question": "The greatest commandment is to?",
      "options": [
        "Pay tithes only",
        "Offer sacrifices only",
        "Love God and neighbour",
        "Keep the Sabbath only"
      ],
      "correct": 2,
      "explanation": "Love God and neighbour"
    },
    {
      "question": "Jesus is the?",
      "options": [
        "Only a healer",
        "Only a teacher",
        "Only a prophet",
        "Way, truth and life"
      ],
      "correct": 3,
      "explanation": "Jesus is the way, truth and life"
    },
    {
      "question": "The Lord's Prayer begins with?",
      "options": [
        "Glory be",
        "I believe",
        "Our Father",
        "Hail Mary"
      ],
      "correct": 2,
      "explanation": "It begins with Our Father"
    },
    {
      "question": "Jesus said 'Let the children come to me' to show?",
      "options": [
        "Welcome and humility",
        "Rejection",
        "Strict rules only",
        "Adults only"
      ],
      "correct": 0,
      "explanation": "He welcomed children"
    },
    {
      "question": "The Great Commission is to?",
      "options": [
        "Avoid preaching",
        "Make disciples of all nations",
        "Only pray",
        "Stay local only"
      ],
      "correct": 1,
      "explanation": "Go and make disciples"
    },
    {
      "question": "God created man in His?",
      "options": [
        "Image",
        "Absence",
        "Silence",
        "Anger"
      ],
      "correct": 0,
      "explanation": "Man was created in God's image"
    },
    {
      "question": "Eve was created from?",
      "options": [
        "Water",
        "Adam's rib",
        "Dust only",
        "Clay only"
      ],
      "correct": 1,
      "explanation": "Eve was made from Adam's rib"
    },
    {
      "question": "The tree they were forbidden to eat from was the?",
      "options": [
        "Tree of life only",
        "Any tree",
        "No tree",
        "Tree of knowledge of good and evil"
      ],
      "correct": 3,
      "explanation": "It was the tree of knowledge"
    },
    {
      "question": "After the fall, Adam and Eve were?",
      "options": [
        "Left in Eden",
        "Given more trees",
        "Made angels",
        "Sent out of Eden"
      ],
      "correct": 3,
      "explanation": "They were expelled from Eden"
    },
    {
      "question": "Cain's offering was?",
      "options": [
        "Ignored",
        "Rejected",
        "Accepted",
        "Praised"
      ],
      "correct": 1,
      "explanation": "Cain's offering was rejected"
    },
    {
      "question": "Abel offered?",
      "options": [
        "Crops only",
        "Gold",
        "A lamb",
        "Nothing"
      ],
      "correct": 2,
      "explanation": "Abel offered a lamb"
    },
    {
      "question": "Noah was told to build an?",
      "options": [
        "Tower",
        "Temple",
        "Ark",
        "Altar only"
      ],
      "correct": 2,
      "explanation": "Noah built an ark"
    },
    {
      "question": "The sign of the covenant with Noah was the?",
      "options": [
        "Rainbow",
        "Fire",
        "Star",
        "Cloud"
      ],
      "correct": 0,
      "explanation": "The rainbow was the sign"
    },
    {
      "question": "Abraham was called to leave?",
      "options": [
        "Egypt",
        "Ur",
        "Canaan only",
        "Babylon only"
      ],
      "correct": 1,
      "explanation": "Abraham left Ur"
    },
    {
      "question": "Isaac was almost sacrificed on?",
      "options": [
        "Mount Zion",
        "Mount Sinai",
        "Mount Moriah",
        "Mount Carmel"
      ],
      "correct": 2,
      "explanation": "It was on Mount Moriah"
    },
    {
      "question": "Jacob's dream was of a?",
      "options": [
        "Tree",
        "River",
        "Ladder to heaven",
        "Mountain only"
      ],
      "correct": 2,
      "explanation": "Jacob dreamed of a ladder"
    },
    {
      "question": "Joseph was sold by his?",
      "options": [
        "Mother",
        "Father",
        "Brothers",
        "Friends"
      ],
      "correct": 2,
      "explanation": "His brothers sold him"
    },
    {
      "question": "Moses was found by?",
      "options": [
        "Pharaoh",
        "Aaron",
        "Pharaoh's daughter",
        "His mother only"
      ],
      "correct": 2,
      "explanation": "Pharaoh's daughter found him"
    },
    {
      "question": "God revealed His name to Moses as?",
      "options": [
        "Only El Shaddai",
        "Only Elohim",
        "Only Adonai",
        "I AM"
      ],
      "correct": 3,
      "explanation": "God said I AM"
    },
    {
      "question": "The Passover lamb's blood protected from?",
      "options": [
        "The angel of death",
        "War",
        "Disease only",
        "Famine"
      ],
      "correct": 0,
      "explanation": "It protected from the death angel"
    },
    {
      "question": "The Red Sea parted for?",
      "options": [
        "Moses only",
        "The Egyptians only",
        "Aaron only",
        "The Israelites"
      ],
      "correct": 3,
      "explanation": "It parted for the Israelites"
    },
    {
      "question": "Manna was?",
      "options": [
        "Meat only",
        "Food from heaven",
        "Fruit only",
        "Water"
      ],
      "correct": 1,
      "explanation": "Manna was heavenly food"
    },
    {
      "question": "The Ten Commandments were written on?",
      "options": [
        "Paper",
        "Scrolls only",
        "Stone tablets",
        "Wood"
      ],
      "correct": 2,
      "explanation": "They were on stone tablets"
    },
    {
      "question": "Joshua led the people across the?",
      "options": [
        "Nile",
        "Euphrates",
        "Jordan",
        "Red Sea only"
      ],
      "correct": 2,
      "explanation": "Joshua crossed the Jordan"
    },
    {
      "question": "David defeated Goliath with a?",
      "options": [
        "Spear only",
        "Bow only",
        "Sword only",
        "Sling and stone"
      ],
      "correct": 3,
      "explanation": "David used a sling"
    },
    {
      "question": "Solomon asked for?",
      "options": [
        "Long life only",
        "Victory only",
        "Wisdom",
        "Wealth only"
      ],
      "correct": 2,
      "explanation": "Solomon asked for wisdom"
    },
    {
      "question": "The temple was built in?",
      "options": [
        "Nazareth",
        "Jerusalem",
        "Hebron",
        "Bethlehem"
      ],
      "correct": 1,
      "explanation": "The temple was in Jerusalem"
    },
    {
      "question": "Jesus is called the?",
      "options": [
        "Eagle only",
        "Lion only",
        "Dove only",
        "Lamb of God"
      ],
      "correct": 3,
      "explanation": "Jesus is the Lamb of God"
    },
    {
      "question": "Jesus said He is the?",
      "options": [
        "Only a healer",
        "Good Shepherd",
        "Only a prophet",
        "Only a teacher"
      ],
      "correct": 1,
      "explanation": "Jesus is the Good Shepherd"
    },
    {
      "question": "The greatest is?",
      "options": [
        "Hope only",
        "Gifts only",
        "Love",
        "Faith only"
      ],
      "correct": 2,
      "explanation": "The greatest is love"
    },
    {
      "question": "The first man was?",
      "options": [
        "Noah",
        "Abraham",
        "Adam",
        "Moses"
      ],
      "correct": 2,
      "explanation": "Adam was the first man"
    },
    {
      "question": "The first woman was?",
      "options": [
        "Eve",
        "Ruth",
        "Sarah",
        "Mary"
      ],
      "correct": 0,
      "explanation": "Eve was the first woman"
    },
    {
      "question": "Noah built an?",
      "options": [
        "Tower",
        "Temple",
        "Altar only",
        "Ark"
      ],
      "correct": 3,
      "explanation": "Noah built an ark"
    },
    {
      "question": "Abraham's son of promise was?",
      "options": [
        "Esau",
        "Isaac",
        "Ishmael",
        "Jacob"
      ],
      "correct": 1,
      "explanation": "Isaac was the son of promise"
    },
    {
      "question": "Jacob became?",
      "options": [
        "Israel",
        "Joseph",
        "Isaac",
        "Abraham"
      ],
      "correct": 0,
      "explanation": "Jacob was named Israel"
    },
    {
      "question": "Joseph was sold into?",
      "options": [
        "Egypt",
        "Babylon",
        "Assyria",
        "Canaan only"
      ],
      "correct": 0,
      "explanation": "Joseph was sold into Egypt"
    },
    {
      "question": "Moses received the law at?",
      "options": [
        "Zion",
        "Carmel",
        "Olives",
        "Sinai"
      ],
      "correct": 3,
      "explanation": "The law was given at Sinai"
    },
    {
      "question": "David killed?",
      "options": [
        "Jonathan",
        "Absalom only",
        "Goliath",
        "Saul"
      ],
      "correct": 2,
      "explanation": "David killed Goliath"
    },
    {
      "question": "Solomon was known for?",
      "options": [
        "Wisdom",
        "Wealth only",
        "Speed",
        "Strength only"
      ],
      "correct": 0,
      "explanation": "Solomon was known for wisdom"
    },
    {
      "question": "Elijah went up in a?",
      "options": [
        "Whirlwind only",
        "Chariot of fire",
        "Angel's arms",
        "Cloud"
      ],
      "correct": 1,
      "explanation": "Elijah went in a chariot of fire"
    },
    {
      "question": "Daniel was in the?",
      "options": [
        "Lions' den",
        "Prison only",
        "Sea",
        "Furnace"
      ],
      "correct": 0,
      "explanation": "Daniel was in the lions' den"
    },
    {
      "question": "The three Hebrews were in the?",
      "options": [
        "Fiery furnace",
        "Sea",
        "Prison",
        "Lions' den"
      ],
      "correct": 0,
      "explanation": "They were in the furnace"
    },
    {
      "question": "Jesus was tempted by?",
      "options": [
        "Peter",
        "Judas",
        "Satan",
        "Pilate"
      ],
      "correct": 2,
      "explanation": "Satan tempted Jesus"
    },
    {
      "question": "Jesus' first miracle was?",
      "options": [
        "Water to wine",
        "Raising Lazarus",
        "Walking on water",
        "Feeding five thousand"
      ],
      "correct": 0,
      "explanation": "First miracle was water to wine"
    },
    {
      "question": "Jesus raised?",
      "options": [
        "Peter",
        "James",
        "Lazarus",
        "John"
      ],
      "correct": 2,
      "explanation": "Jesus raised Lazarus"
    },
    {
      "question": "The doubting disciple was?",
      "options": [
        "John",
        "Andrew",
        "Peter",
        "Thomas"
      ],
      "correct": 3,
      "explanation": "Thomas doubted"
    },
    {
      "question": "Saul became?",
      "options": [
        "James",
        "Peter",
        "Paul",
        "John"
      ],
      "correct": 2,
      "explanation": "Saul became Paul"
    },
    {
      "question": "The love chapter is?",
      "options": [
        "Psalm 23",
        "John 3",
        "1 Corinthians 13",
        "Matthew 5"
      ],
      "correct": 2,
      "explanation": "1 Corinthians 13 is about love"
    },
    {
      "question": "Jesus welcomed?",
      "options": [
        "Only the rich",
        "Children",
        "Only adults",
        "Only leaders"
      ],
      "correct": 1,
      "explanation": "Jesus welcomed children"
    },
    {
      "question": "The Good Samaritan teaches?",
      "options": [
        "Love for neighbour",
        "Ignoring others",
        "Hatred",
        "Self-love only"
      ],
      "correct": 0,
      "explanation": "It teaches love for neighbour"
    },
    {
      "question": "The prodigal son teaches?",
      "options": [
        "Punishment only",
        "Pride",
        "Rejection",
        "Forgiveness"
      ],
      "correct": 3,
      "explanation": "It teaches forgiveness"
    },
    {
      "question": "Jesus washed feet at the?",
      "options": [
        "Ascension",
        "Last Supper",
        "Transfiguration",
        "Sermon on the Mount"
      ],
      "correct": 1,
      "explanation": "It was at the Last Supper"
    },
    {
      "question": "The Great Commission is to?",
      "options": [
        "Avoid preaching",
        "Make disciples",
        "Stay local",
        "Only pray"
      ],
      "correct": 1,
      "explanation": "Make disciples of all nations"
    },
    {
      "question": "The fruit of the Spirit is in?",
      "options": [
        "John 3",
        "Romans 8",
        "Galatians 5",
        "Matthew 5"
      ],
      "correct": 2,
      "explanation": "It is in Galatians 5"
    },
    {
      "question": "Faith without works is?",
      "options": [
        "Perfect",
        "Strong",
        "Alive",
        "Dead"
      ],
      "correct": 3,
      "explanation": "Faith without works is dead"
    }
  ],
  "irs": [
    {
      "question": "The first pillar of Islam is?",
      "options": [
        "Zakat",
        "Shahada (declaration of faith)",
        "Hajj",
        "Salah"
      ],
      "correct": 1,
      "explanation": "Shahada is the first pillar"
    },
    {
      "question": "The holy book of Islam is the?",
      "options": [
        "Torah",
        "Psalms",
        "Bible",
        "Qur'an"
      ],
      "correct": 3,
      "explanation": "The Qur'an is the holy book of Islam"
    },
    {
      "question": "The Prophet of Islam is?",
      "options": [
        "Muhammad (SAW)",
        "Musa (AS)",
        "Ibrahim (AS)",
        "Isa (AS)"
      ],
      "correct": 0,
      "explanation": "Muhammad (SAW) is the final prophet"
    },
    {
      "question": "Muslims pray how many times a day?",
      "options": [
        "Five",
        "Three",
        "Seven",
        "Four"
      ],
      "correct": 0,
      "explanation": "There are five daily prayers"
    },
    {
      "question": "The direction of prayer is towards?",
      "options": [
        "Kaaba in Makkah",
        "Jerusalem",
        "Madinah only",
        "Any direction"
      ],
      "correct": 0,
      "explanation": "Muslims face the Kaaba"
    },
    {
      "question": "Zakat is?",
      "options": [
        "A type of fasting",
        "Compulsory charity",
        "Optional gift",
        "A type of prayer"
      ],
      "correct": 1,
      "explanation": "Zakat is obligatory almsgiving"
    },
    {
      "question": "Fasting in Ramadan is the?",
      "options": [
        "Fifth pillar",
        "Fourth pillar",
        "First pillar",
        "Second pillar"
      ],
      "correct": 1,
      "explanation": "Sawm (fasting) is the fourth pillar"
    },
    {
      "question": "Hajj is performed in?",
      "options": [
        "Makkah",
        "Cairo",
        "Jerusalem",
        "Madinah only"
      ],
      "correct": 0,
      "explanation": "Hajj is performed in Makkah"
    },
    {
      "question": "The night journey of the Prophet is called?",
      "options": [
        "Uhud",
        "Badr",
        "Isra and Mi'raj",
        "Hijrah"
      ],
      "correct": 2,
      "explanation": "Isra and Mi'raj is the night journey"
    },
    {
      "question": "The migration of the Prophet to Madinah is?",
      "options": [
        "Mi'raj",
        "Hijrah",
        "Badr",
        "Isra"
      ],
      "correct": 1,
      "explanation": "Hijrah is the migration"
    },
    {
      "question": "The first mosque was built in?",
      "options": [
        "Madinah",
        "Kufa",
        "Jerusalem",
        "Makkah"
      ],
      "correct": 0,
      "explanation": "The Prophet's mosque was in Madinah"
    },
    {
      "question": "The battle of Badr was fought in?",
      "options": [
        "2 AH",
        "1 AH",
        "5 AH",
        "3 AH"
      ],
      "correct": 0,
      "explanation": "Badr was in 2 AH"
    },
    {
      "question": "The Qur'an was revealed over?",
      "options": [
        "5 years",
        "40 years",
        "10 years",
        "23 years"
      ],
      "correct": 3,
      "explanation": "Revelation took about 23 years"
    },
    {
      "question": "The angel who brought revelation is?",
      "options": [
        "Israfil (AS)",
        "Jibril (AS)",
        "Mikail (AS)",
        "Izrail (AS)"
      ],
      "correct": 1,
      "explanation": "Jibril brought the revelation"
    },
    {
      "question": "The sayings and actions of the Prophet are?",
      "options": [
        "Qur'an only",
        "Fiqh only",
        "Hadith",
        "Tafsir only"
      ],
      "correct": 2,
      "explanation": "Hadith records the Prophet's sayings and actions"
    },
    {
      "question": "The month of fasting is?",
      "options": [
        "Ramadan",
        "Shawwal",
        "Muharram",
        "Dhul Hijjah"
      ],
      "correct": 0,
      "explanation": "Ramadan is the month of fasting"
    },
    {
      "question": "Eid al-Fitr marks the end of?",
      "options": [
        "Safar",
        "Hajj",
        "Muharram",
        "Ramadan"
      ],
      "correct": 3,
      "explanation": "Eid al-Fitr ends Ramadan"
    },
    {
      "question": "Eid al-Adha commemorates?",
      "options": [
        "The battle of Badr",
        "The sacrifice of Ibrahim (AS)",
        "The Hijrah",
        "The birth of the Prophet"
      ],
      "correct": 1,
      "explanation": "It commemorates Ibrahim's willingness to sacrifice"
    },
    {
      "question": "The Kaaba was built by?",
      "options": [
        "Ibrahim and Ismail (AS)",
        "Musa (AS)",
        "Yusuf (AS)",
        "Isa (AS)"
      ],
      "correct": 0,
      "explanation": "Ibrahim and Ismail built the Kaaba"
    },
    {
      "question": "The first Caliph was?",
      "options": [
        "Umar (RA)",
        "Abu Bakr (RA)",
        "Uthman (RA)",
        "Ali (RA)"
      ],
      "correct": 1,
      "explanation": "Abu Bakr was the first Caliph"
    },
    {
      "question": "The second Caliph was?",
      "options": [
        "Umar (RA)",
        "Abu Bakr (RA)",
        "Uthman (RA)",
        "Ali (RA)"
      ],
      "correct": 0,
      "explanation": "Umar succeeded Abu Bakr"
    },
    {
      "question": "Tawhid means?",
      "options": [
        "Prophethood",
        "Oneness of Allah",
        "Charity",
        "Prayer"
      ],
      "correct": 1,
      "explanation": "Tawhid is the oneness of Allah"
    },
    {
      "question": "Shirk means?",
      "options": [
        "Associating partners with Allah",
        "Belief in one God",
        "Fasting",
        "Prayer"
      ],
      "correct": 0,
      "explanation": "Shirk is polytheism"
    },
    {
      "question": "The night of power is?",
      "options": [
        "Lailatul Qadr",
        "Lailatul Badr",
        "Lailatul Miraj",
        "Lailatul Hijrah"
      ],
      "correct": 0,
      "explanation": "Lailatul Qadr is the night of power"
    },
    {
      "question": "Muslims greet with?",
      "options": [
        "Hi only",
        "Assalamu Alaikum",
        "Good morning only",
        "Hello only"
      ],
      "correct": 1,
      "explanation": "Assalamu Alaikum is the Islamic greeting"
    },
    {
      "question": "The second pillar of Islam is?",
      "options": [
        "Salah (prayer)",
        "Zakat",
        "Hajj",
        "Shahada"
      ],
      "correct": 0,
      "explanation": "Salah is the second pillar"
    },
    {
      "question": "The third pillar of Islam is?",
      "options": [
        "Hajj",
        "Zakat",
        "Sawm",
        "Salah"
      ],
      "correct": 1,
      "explanation": "Zakat is the third pillar"
    },
    {
      "question": "The fifth pillar of Islam is?",
      "options": [
        "Zakat",
        "Shahada",
        "Hajj",
        "Salah"
      ],
      "correct": 2,
      "explanation": "Hajj is the fifth pillar"
    },
    {
      "question": "Wudu is?",
      "options": [
        "A type of pilgrimage",
        "A type of charity",
        "Ablution before prayer",
        "A type of fasting"
      ],
      "correct": 2,
      "explanation": "Wudu is ritual washing"
    },
    {
      "question": "The call to prayer is?",
      "options": [
        "Iqamah only",
        "Adhan",
        "Tasbih only",
        "Takbir only"
      ],
      "correct": 1,
      "explanation": "Adhan is the call to prayer"
    },
    {
      "question": "The Prophet was born in?",
      "options": [
        "Jerusalem",
        "Makkah",
        "Madinah",
        "Taif"
      ],
      "correct": 1,
      "explanation": "The Prophet was born in Makkah"
    },
    {
      "question": "The Prophet migrated to?",
      "options": [
        "Madinah",
        "Taif",
        "Makkah",
        "Jerusalem"
      ],
      "correct": 0,
      "explanation": "He migrated to Madinah"
    },
    {
      "question": "The first revelation came in?",
      "options": [
        "Cave Hira",
        "Masjid Nabawi",
        "Kaaba",
        "Cave Thawr"
      ],
      "correct": 0,
      "explanation": "Revelation began in Cave Hira"
    },
    {
      "question": "The Prophet's uncle who protected him was?",
      "options": [
        "Abu Lahab",
        "Abu Talib",
        "Hamza only",
        "Abbas only"
      ],
      "correct": 1,
      "explanation": "Abu Talib protected the Prophet"
    },
    {
      "question": "The year of sadness is associated with?",
      "options": [
        "Death of Khadijah and Abu Talib",
        "Battle of Badr",
        "Hijrah",
        "Conquest of Makkah"
      ],
      "correct": 0,
      "explanation": "Both died in the same year"
    },
    {
      "question": "The Treaty of Hudaybiyyah was signed in?",
      "options": [
        "6 AH",
        "2 AH",
        "8 AH",
        "1 AH"
      ],
      "correct": 0,
      "explanation": "Hudaybiyyah was in 6 AH"
    },
    {
      "question": "The conquest of Makkah was in?",
      "options": [
        "6 AH",
        "8 AH",
        "2 AH",
        "10 AH"
      ],
      "correct": 1,
      "explanation": "Makkah was conquered in 8 AH"
    },
    {
      "question": "The Farewell Pilgrimage was in?",
      "options": [
        "10 AH",
        "8 AH",
        "11 AH",
        "9 AH"
      ],
      "correct": 0,
      "explanation": "The farewell Hajj was in 10 AH"
    },
    {
      "question": "The Prophet died in?",
      "options": [
        "12 AH",
        "10 AH",
        "11 AH",
        "9 AH"
      ],
      "correct": 2,
      "explanation": "The Prophet died in 11 AH"
    },
    {
      "question": "The third Caliph was?",
      "options": [
        "Uthman (RA)",
        "Abu Bakr (RA)",
        "Ali (RA)",
        "Umar (RA)"
      ],
      "correct": 0,
      "explanation": "Uthman was the third Caliph"
    },
    {
      "question": "The fourth Caliph was?",
      "options": [
        "Uthman (RA)",
        "Abu Bakr (RA)",
        "Umar (RA)",
        "Ali (RA)"
      ],
      "correct": 3,
      "explanation": "Ali was the fourth Caliph"
    },
    {
      "question": "The compilation of the Qur'an was completed during the time of?",
      "options": [
        "Umar only",
        "Uthman (RA)",
        "Abu Bakr only",
        "Ali only"
      ],
      "correct": 1,
      "explanation": "Uthman standardised the Qur'an"
    },
    {
      "question": "Jummah prayer is held on?",
      "options": [
        "Saturday",
        "Thursday",
        "Friday",
        "Monday"
      ],
      "correct": 2,
      "explanation": "Jummah is the Friday prayer"
    },
    {
      "question": "The night prayer in Ramadan is?",
      "options": [
        "Ishraq only",
        "Tahajjud only",
        "Tarawih",
        "Witr only"
      ],
      "correct": 2,
      "explanation": "Tarawih is prayed in Ramadan"
    },
    {
      "question": "Sadaqah is?",
      "options": [
        "Voluntary charity",
        "A type of prayer",
        "Compulsory charity only",
        "A type of fasting"
      ],
      "correct": 0,
      "explanation": "Sadaqah is voluntary"
    },
    {
      "question": "The dual testimony of faith is?",
      "options": [
        "There is no god but Allah and Muhammad is His messenger",
        "Only belief in angels",
        "Only belief in Allah",
        "Only belief in prophets"
      ],
      "correct": 0,
      "explanation": "Shahada has two parts"
    },
    {
      "question": "Iman means?",
      "options": [
        "Faith",
        "Charity",
        "Pilgrimage",
        "Prayer"
      ],
      "correct": 0,
      "explanation": "Iman is faith"
    },
    {
      "question": "The articles of faith include belief in?",
      "options": [
        "Only the Last Day",
        "Only prophets",
        "Only Allah",
        "Allah, angels, books, prophets, Last Day, and decree"
      ],
      "correct": 3,
      "explanation": "There are six articles of faith"
    },
    {
      "question": "Qadr means?",
      "options": [
        "Prayer",
        "Divine decree",
        "Fasting",
        "Charity"
      ],
      "correct": 1,
      "explanation": "Qadr is divine predestination"
    },
    {
      "question": "The Prophet's wife known as Mother of the Believers includes?",
      "options": [
        "Only Maryam",
        "Aishah (RA)",
        "Only Khadijah",
        "Only Fatimah"
      ],
      "correct": 1,
      "explanation": "Aishah is among the Mothers of the Believers"
    },
    {
      "question": "The fourth pillar of Islam is?",
      "options": [
        "Shahada",
        "Salah",
        "Sawm (fasting)",
        "Zakat"
      ],
      "correct": 2,
      "explanation": "Sawm is the fourth pillar"
    },
    {
      "question": "Salah is performed facing?",
      "options": [
        "Any direction",
        "South only",
        "Qiblah",
        "North only"
      ],
      "correct": 2,
      "explanation": "Muslims face the Qiblah"
    },
    {
      "question": "The number of compulsory rak'ahs in a day is?",
      "options": [
        "Ten",
        "Twenty",
        "Five",
        "Seventeen"
      ],
      "correct": 3,
      "explanation": "The five prayers total seventeen rak'ahs"
    },
    {
      "question": "Zakat is due on?",
      "options": [
        "Wealth that reaches the nisab",
        "Only animals",
        "All income regardless",
        "Only land"
      ],
      "correct": 0,
      "explanation": "Zakat is due when wealth reaches nisab"
    },
    {
      "question": "Fasting is obligatory on?",
      "options": [
        "Children only",
        "Adult Muslims who are able",
        "Travellers only",
        "The sick only"
      ],
      "correct": 1,
      "explanation": "Able adult Muslims must fast"
    },
    {
      "question": "Hajj is obligatory once in a?",
      "options": [
        "Year",
        "Month",
        "Lifetime for those who can afford it",
        "Week"
      ],
      "correct": 2,
      "explanation": "Hajj is once in a lifetime if able"
    },
    {
      "question": "The Prophet's first wife was?",
      "options": [
        "Khadijah (RA)",
        "Sawdah (RA)",
        "Aishah (RA)",
        "Hafsah (RA)"
      ],
      "correct": 0,
      "explanation": "Khadijah was the first wife"
    },
    {
      "question": "The Prophet's daughter who is most mentioned is?",
      "options": [
        "Umm Kulthum only",
        "Zainab only",
        "Ruqayyah only",
        "Fatimah (RA)"
      ],
      "correct": 3,
      "explanation": "Fatimah is the most prominent"
    },
    {
      "question": "The Prophet's closest companion was?",
      "options": [
        "Abu Bakr (RA)",
        "Umar (RA)",
        "Uthman (RA)",
        "Ali (RA)"
      ],
      "correct": 0,
      "explanation": "Abu Bakr was the closest"
    },
    {
      "question": "The battle of Uhud was in?",
      "options": [
        "3 AH",
        "8 AH",
        "2 AH",
        "5 AH"
      ],
      "correct": 0,
      "explanation": "Uhud was in 3 AH"
    },
    {
      "question": "The battle of the Trench was in?",
      "options": [
        "3 AH",
        "5 AH",
        "2 AH",
        "8 AH"
      ],
      "correct": 1,
      "explanation": "Khandaq (Trench) was in 5 AH"
    },
    {
      "question": "The Treaty of Hudaybiyyah led to?",
      "options": [
        "End of Islam",
        "Defeat of Muslims",
        "Immediate war",
        "Peace and later conquest of Makkah"
      ],
      "correct": 3,
      "explanation": "It paved the way for the conquest"
    },
    {
      "question": "The Farewell Sermon was delivered at?",
      "options": [
        "Mina only",
        "Makkah only",
        "Madinah only",
        "Arafat"
      ],
      "correct": 3,
      "explanation": "The sermon was at Arafat"
    },
    {
      "question": "The Prophet was buried in?",
      "options": [
        "Jerusalem",
        "Taif",
        "Makkah",
        "Madinah"
      ],
      "correct": 3,
      "explanation": "He was buried in Madinah"
    },
    {
      "question": "The compilation of Hadith was done by scholars like?",
      "options": [
        "Only Umar",
        "Bukhari and Muslim",
        "Only Abu Bakr",
        "Only Ali"
      ],
      "correct": 1,
      "explanation": "Bukhari and Muslim are major collectors"
    },
    {
      "question": "The five daily prayers are?",
      "options": [
        "Only Fajr and Isha",
        "Fajr, Dhuhr, Asr, Maghrib, Isha",
        "Only Dhuhr and Asr",
        "Only Maghrib"
      ],
      "correct": 1,
      "explanation": "These are the five prayers"
    },
    {
      "question": "Witr is prayed after?",
      "options": [
        "Isha",
        "Dhuhr",
        "Asr",
        "Fajr"
      ],
      "correct": 0,
      "explanation": "Witr is after Isha"
    },
    {
      "question": "The month of Hajj is?",
      "options": [
        "Dhul Hijjah",
        "Muharram",
        "Ramadan",
        "Shawwal"
      ],
      "correct": 0,
      "explanation": "Hajj is in Dhul Hijjah"
    },
    {
      "question": "Eid al-Adha is also called?",
      "options": [
        "Festival of Breaking Fast only",
        "Festival of Sacrifice",
        "New Year",
        "Ashura"
      ],
      "correct": 1,
      "explanation": "It is the Festival of Sacrifice"
    },
    {
      "question": "The black stone is in the?",
      "options": [
        "Al-Aqsa only",
        "Prophet's mosque",
        "Kaaba",
        "Dome of the Rock"
      ],
      "correct": 2,
      "explanation": "The Black Stone is in the Kaaba"
    },
    {
      "question": "Tawaf is?",
      "options": [
        "Circling the Kaaba",
        "Stoning the pillars",
        "Running between Safa and Marwah",
        "Standing at Arafat"
      ],
      "correct": 0,
      "explanation": "Tawaf is circling the Kaaba"
    },
    {
      "question": "Sa'i is?",
      "options": [
        "Circling the Kaaba",
        "Walking between Safa and Marwah",
        "Standing at Arafat",
        "Stoning"
      ],
      "correct": 1,
      "explanation": "Sa'i is between Safa and Marwah"
    },
    {
      "question": "The day of Arafat is the?",
      "options": [
        "Beginning of Hajj",
        "Climax of Hajj",
        "End of Ramadan",
        "Start of Muharram"
      ],
      "correct": 1,
      "explanation": "Arafat is the most important day of Hajj"
    },
    {
      "question": "Shirk is the opposite of?",
      "options": [
        "Tawhid",
        "Salah",
        "Hajj",
        "Zakat"
      ],
      "correct": 0,
      "explanation": "Shirk opposes Tawhid"
    },
    {
      "question": "The Prophet's sunnah includes?",
      "options": [
        "Only the Caliphs' actions",
        "Only the Qur'an",
        "His words, actions and approvals",
        "Only later scholars"
      ],
      "correct": 2,
      "explanation": "Sunnah is the Prophet's example"
    },
    {
      "question": "The first word revealed of the Qur'an was?",
      "options": [
        "Alhamdulillah",
        "Allahu Akbar",
        "Bismillah",
        "Iqra (Read)"
      ],
      "correct": 3,
      "explanation": "The first revelation was Iqra"
    },
    {
      "question": "The Qur'an has how many chapters?",
      "options": [
        "120",
        "99",
        "114",
        "100"
      ],
      "correct": 2,
      "explanation": "There are 114 surahs"
    },
    {
      "question": "The longest surah is?",
      "options": [
        "Al-Baqarah",
        "Al-Ikhlas",
        "An-Nas",
        "Al-Fatihah"
      ],
      "correct": 0,
      "explanation": "Al-Baqarah is the longest"
    },
    {
      "question": "The shortest surah is?",
      "options": [
        "Al-Fatihah",
        "Al-Kawthar",
        "Al-Baqarah",
        "Yasin"
      ],
      "correct": 1,
      "explanation": "Al-Kawthar is the shortest"
    },
    {
      "question": "Al-Fatihah is also called?",
      "options": [
        "The Closing",
        "The Opening",
        "The Middle",
        "The End"
      ],
      "correct": 1,
      "explanation": "Al-Fatihah means the Opening"
    },
    {
      "question": "The Prophet received the first revelation at age?",
      "options": [
        "25",
        "50",
        "30",
        "40"
      ],
      "correct": 3,
      "explanation": "He was 40 years old"
    },
    {
      "question": "The Prophet preached in Makkah for?",
      "options": [
        "23 years",
        "13 years",
        "3 years",
        "10 years"
      ],
      "correct": 1,
      "explanation": "He preached about 13 years in Makkah"
    },
    {
      "question": "The Prophet lived in Madinah for?",
      "options": [
        "13 years",
        "5 years",
        "10 years",
        "23 years"
      ],
      "correct": 2,
      "explanation": "He spent about 10 years in Madinah"
    },
    {
      "question": "The Constitution of Madinah established?",
      "options": [
        "Only Muslim rule with no others",
        "A multi-religious community under Islamic leadership",
        "Jewish rule only",
        "Christian rule"
      ],
      "correct": 1,
      "explanation": "It created a plural community"
    },
    {
      "question": "The Battle of Badr was a?",
      "options": [
        "Defeat for the Muslims",
        "Draw",
        "Victory for the Muslims",
        "No battle"
      ],
      "correct": 2,
      "explanation": "Badr was a Muslim victory"
    },
    {
      "question": "The Battle of Uhud was a?",
      "options": [
        "Setback for the Muslims",
        "Treaty",
        "No engagement",
        "Clear victory"
      ],
      "correct": 0,
      "explanation": "Uhud was a setback"
    },
    {
      "question": "The Conquest of Makkah was largely?",
      "options": [
        "A treaty only",
        "Peaceful",
        "Very bloody",
        "A defeat"
      ],
      "correct": 1,
      "explanation": "It was largely peaceful"
    },
    {
      "question": "The Prophet forgave the people of Makkah with?",
      "options": [
        "General amnesty",
        "Forced conversion only",
        "Exile only",
        "Severe punishment"
      ],
      "correct": 0,
      "explanation": "He granted general amnesty"
    },
    {
      "question": "The last sermon emphasised?",
      "options": [
        "Only trade",
        "Equality and rights of women and the weak",
        "Only war",
        "Only politics"
      ],
      "correct": 1,
      "explanation": "It stressed equality and justice"
    },
    {
      "question": "Abu Bakr's caliphate dealt with?",
      "options": [
        "Ridda (apostasy) wars",
        "Only compilation of Qur'an",
        "Only administration",
        "Only expansion"
      ],
      "correct": 0,
      "explanation": "He fought the Ridda wars"
    },
    {
      "question": "Umar's caliphate is known for?",
      "options": [
        "Only poetry",
        "Only religious matters",
        "Only trade",
        "Expansion and administration"
      ],
      "correct": 3,
      "explanation": "Umar expanded and organised the state"
    },
    {
      "question": "Uthman's caliphate is known for?",
      "options": [
        "Only military conquest",
        "Only building",
        "Only trade",
        "Compilation of the Qur'an"
      ],
      "correct": 3,
      "explanation": "Uthman standardised the Qur'an"
    },
    {
      "question": "Ali's caliphate faced?",
      "options": [
        "Only peace",
        "Only external wars",
        "Internal conflicts",
        "No challenges"
      ],
      "correct": 2,
      "explanation": "Ali faced civil strife"
    },
    {
      "question": "The five daily prayers are obligatory on?",
      "options": [
        "Only the rich",
        "Sane adult Muslims",
        "Children only",
        "Only scholars"
      ],
      "correct": 1,
      "explanation": "They are obligatory on sane adults"
    },
    {
      "question": "Ghusl is?",
      "options": [
        "Dry ablution",
        "Full ritual bath",
        "No washing",
        "Partial washing"
      ],
      "correct": 1,
      "explanation": "Ghusl is the full bath"
    },
    {
      "question": "Tayammum is?",
      "options": [
        "No purification",
        "Dry ablution with earth",
        "Full bath",
        "Partial washing only"
      ],
      "correct": 1,
      "explanation": "Tayammum uses clean earth"
    },
    {
      "question": "The niyyah is?",
      "options": [
        "Intention",
        "Action only",
        "Word only",
        "Place only"
      ],
      "correct": 0,
      "explanation": "Niyyah is the intention"
    },
    {
      "question": "Ruku is?",
      "options": [
        "Sitting",
        "Standing",
        "Bowing in prayer",
        "Prostration"
      ],
      "correct": 2,
      "explanation": "Ruku is the bowing posture"
    },
    {
      "question": "Sujud is?",
      "options": [
        "Prostration",
        "Standing",
        "Bowing",
        "Sitting"
      ],
      "correct": 0,
      "explanation": "Sujud is prostration"
    },
    {
      "question": "The Qur'an was revealed in?",
      "options": [
        "Latin",
        "Arabic",
        "French",
        "English"
      ],
      "correct": 1,
      "explanation": "The Qur'an was revealed in Arabic"
    },
    {
      "question": "The first pillar of Islam is the?",
      "options": [
        "Salah",
        "Shahada",
        "Zakat",
        "Hajj"
      ],
      "correct": 1,
      "explanation": "Shahada is the first pillar"
    },
    {
      "question": "Muslims declare that there is no god but?",
      "options": [
        "Allah",
        "Idols",
        "Any god",
        "Nature"
      ],
      "correct": 0,
      "explanation": "There is no god but Allah"
    },
    {
      "question": "Muhammad is the?",
      "options": [
        "God himself",
        "Angel",
        "Messenger of Allah",
        "Son of Allah"
      ],
      "correct": 2,
      "explanation": "Muhammad is the Messenger of Allah"
    },
    {
      "question": "Salah is performed?",
      "options": [
        "Five times a day",
        "Once a week",
        "Three times a day",
        "Once a day"
      ],
      "correct": 0,
      "explanation": "Salah is five times daily"
    },
    {
      "question": "The dawn prayer is?",
      "options": [
        "Maghrib",
        "Fajr",
        "Dhuhr",
        "Asr"
      ],
      "correct": 1,
      "explanation": "Fajr is the dawn prayer"
    },
    {
      "question": "The noon prayer is?",
      "options": [
        "Isha",
        "Fajr",
        "Dhuhr",
        "Asr"
      ],
      "correct": 2,
      "explanation": "Dhuhr is the noon prayer"
    },
    {
      "question": "The afternoon prayer is?",
      "options": [
        "Dhuhr",
        "Asr",
        "Maghrib",
        "Isha"
      ],
      "correct": 1,
      "explanation": "Asr is the afternoon prayer"
    },
    {
      "question": "The sunset prayer is?",
      "options": [
        "Isha",
        "Fajr",
        "Maghrib",
        "Asr"
      ],
      "correct": 2,
      "explanation": "Maghrib is the sunset prayer"
    },
    {
      "question": "The night prayer is?",
      "options": [
        "Asr",
        "Dhuhr",
        "Isha",
        "Maghrib"
      ],
      "correct": 2,
      "explanation": "Isha is the night prayer"
    },
    {
      "question": "Zakat purifies?",
      "options": [
        "Only the heart",
        "Only the body",
        "Wealth",
        "Only the mind"
      ],
      "correct": 2,
      "explanation": "Zakat purifies wealth"
    },
    {
      "question": "Fasting in Ramadan teaches?",
      "options": [
        "Only thirst",
        "Self-control and empathy",
        "Only hunger",
        "Only isolation"
      ],
      "correct": 1,
      "explanation": "Fasting builds self-control and empathy"
    },
    {
      "question": "Hajj is performed in?",
      "options": [
        "Safar",
        "Ramadan",
        "Muharram",
        "Dhul Hijjah"
      ],
      "correct": 3,
      "explanation": "Hajj is in Dhul Hijjah"
    },
    {
      "question": "The Prophet was born in the Year of the?",
      "options": [
        "Elephant",
        "Lion",
        "Camel",
        "Horse"
      ],
      "correct": 0,
      "explanation": "He was born in the Year of the Elephant"
    },
    {
      "question": "The Prophet's father was?",
      "options": [
        "Abdullah",
        "Abbas",
        "Abdul Muttalib",
        "Abu Talib"
      ],
      "correct": 0,
      "explanation": "Abdullah was his father"
    },
    {
      "question": "The Prophet's mother was?",
      "options": [
        "Aminah",
        "Aishah",
        "Khadijah",
        "Fatimah"
      ],
      "correct": 0,
      "explanation": "Aminah was his mother"
    },
    {
      "question": "The Prophet was raised by?",
      "options": [
        "Abbas only",
        "Abu Lahab",
        "Abu Talib",
        "Hamza only"
      ],
      "correct": 2,
      "explanation": "Abu Talib raised him"
    },
    {
      "question": "The first person to accept Islam was?",
      "options": [
        "Umar only",
        "Ali only",
        "Khadijah (RA)",
        "Abu Bakr only"
      ],
      "correct": 2,
      "explanation": "Khadijah was the first"
    },
    {
      "question": "The first man to accept Islam was?",
      "options": [
        "Umar",
        "Abu Bakr (RA)",
        "Uthman",
        "Ali only"
      ],
      "correct": 1,
      "explanation": "Abu Bakr was the first man"
    },
    {
      "question": "The young Ali accepted Islam at a?",
      "options": [
        "Never",
        "Middle age only",
        "Old age",
        "Young age"
      ],
      "correct": 3,
      "explanation": "Ali accepted Islam as a boy"
    },
    {
      "question": "The Hijrah marks the beginning of the?",
      "options": [
        "Islamic calendar",
        "Christian calendar",
        "Jewish calendar",
        "Roman calendar"
      ],
      "correct": 0,
      "explanation": "The Islamic calendar starts from the Hijrah"
    },
    {
      "question": "The Prophet's mosque is in?",
      "options": [
        "Madinah",
        "Jerusalem",
        "Taif",
        "Makkah"
      ],
      "correct": 0,
      "explanation": "The Prophet's mosque is in Madinah"
    },
    {
      "question": "The direction of prayer is called?",
      "options": [
        "Minbar only",
        "Minaret only",
        "Mihrab only",
        "Qiblah"
      ],
      "correct": 3,
      "explanation": "Qiblah is the direction of prayer"
    },
    {
      "question": "The call to prayer is given by the?",
      "options": [
        "Imam only",
        "Muezzin",
        "Khatib only",
        "Mufti only"
      ],
      "correct": 1,
      "explanation": "The muezzin gives the adhan"
    },
    {
      "question": "The leader of prayer is the?",
      "options": [
        "Qadi only",
        "Mufti only",
        "Muezzin only",
        "Imam"
      ],
      "correct": 3,
      "explanation": "The imam leads the prayer"
    },
    {
      "question": "The Friday sermon is the?",
      "options": [
        "Adhan",
        "Tasbih",
        "Khutbah",
        "Iqamah"
      ],
      "correct": 2,
      "explanation": "Khutbah is the Friday sermon"
    },
    {
      "question": "The second pillar of Islam is?",
      "options": [
        "Hajj",
        "Shahada",
        "Zakat",
        "Salah"
      ],
      "correct": 3,
      "explanation": "Salah is the second pillar"
    },
    {
      "question": "Muslims pray facing the?",
      "options": [
        "Any direction",
        "North",
        "Kaaba",
        "South"
      ],
      "correct": 2,
      "explanation": "They face the Kaaba"
    },
    {
      "question": "The third pillar is?",
      "options": [
        "Salah",
        "Zakat",
        "Hajj",
        "Sawm"
      ],
      "correct": 1,
      "explanation": "Zakat is the third pillar"
    },
    {
      "question": "Zakat is?",
      "options": [
        "Optional gift only",
        "Obligatory charity",
        "A fast",
        "A prayer"
      ],
      "correct": 1,
      "explanation": "Zakat is obligatory"
    },
    {
      "question": "The fourth pillar is?",
      "options": [
        "Sawm",
        "Salah",
        "Zakat",
        "Shahada"
      ],
      "correct": 0,
      "explanation": "Sawm is the fourth pillar"
    },
    {
      "question": "Fasting is in the month of?",
      "options": [
        "Ramadan",
        "Shawwal",
        "Muharram",
        "Dhul Hijjah"
      ],
      "correct": 0,
      "explanation": "Fasting is in Ramadan"
    },
    {
      "question": "The fifth pillar is?",
      "options": [
        "Shahada",
        "Hajj",
        "Zakat",
        "Salah"
      ],
      "correct": 1,
      "explanation": "Hajj is the fifth pillar"
    },
    {
      "question": "Hajj is performed in?",
      "options": [
        "Makkah",
        "Jerusalem",
        "Cairo",
        "Madinah only"
      ],
      "correct": 0,
      "explanation": "Hajj is in Makkah"
    },
    {
      "question": "The holy book is the?",
      "options": [
        "Psalms",
        "Torah",
        "Qur'an",
        "Bible"
      ],
      "correct": 2,
      "explanation": "The Qur'an is the holy book"
    },
    {
      "question": "The Prophet is?",
      "options": [
        "Isa (AS)",
        "Ibrahim (AS)",
        "Musa (AS)",
        "Muhammad (SAW)"
      ],
      "correct": 3,
      "explanation": "Muhammad is the final Prophet"
    },
    {
      "question": "The first revelation was?",
      "options": [
        "Alhamdulillah",
        "Iqra",
        "Bismillah",
        "Allahu Akbar"
      ],
      "correct": 1,
      "explanation": "Iqra was the first word"
    },
    {
      "question": "The angel of revelation was?",
      "options": [
        "Israfil",
        "Jibril",
        "Mikail",
        "Izrail"
      ],
      "correct": 1,
      "explanation": "Jibril brought the revelation"
    },
    {
      "question": "The migration to Madinah is?",
      "options": [
        "Mi'raj",
        "Isra",
        "Badr",
        "Hijrah"
      ],
      "correct": 3,
      "explanation": "Hijrah is the migration"
    },
    {
      "question": "The night journey is?",
      "options": [
        "Uhud",
        "Hijrah",
        "Badr",
        "Isra and Mi'raj"
      ],
      "correct": 3,
      "explanation": "Isra and Mi'raj is the night journey"
    },
    {
      "question": "The first Caliph was?",
      "options": [
        "Ali",
        "Uthman",
        "Umar",
        "Abu Bakr"
      ],
      "correct": 3,
      "explanation": "Abu Bakr was the first"
    },
    {
      "question": "The second Caliph was?",
      "options": [
        "Ali",
        "Uthman",
        "Umar",
        "Abu Bakr"
      ],
      "correct": 2,
      "explanation": "Umar was the second"
    },
    {
      "question": "The third Caliph was?",
      "options": [
        "Ali",
        "Umar",
        "Uthman",
        "Abu Bakr"
      ],
      "correct": 2,
      "explanation": "Uthman was the third"
    },
    {
      "question": "The fourth Caliph was?",
      "options": [
        "Umar",
        "Ali",
        "Abu Bakr",
        "Uthman"
      ],
      "correct": 1,
      "explanation": "Ali was the fourth"
    },
    {
      "question": "Tawhid means?",
      "options": [
        "Prayer",
        "Oneness of Allah",
        "Prophethood",
        "Charity"
      ],
      "correct": 1,
      "explanation": "Tawhid is the oneness of Allah"
    },
    {
      "question": "Shirk means?",
      "options": [
        "Associating partners with Allah",
        "Fasting",
        "Belief in one God",
        "Prayer"
      ],
      "correct": 0,
      "explanation": "Shirk is associating partners"
    },
    {
      "question": "The night of power is?",
      "options": [
        "Lailatul Miraj",
        "Lailatul Badr",
        "Lailatul Qadr",
        "Lailatul Hijrah"
      ],
      "correct": 2,
      "explanation": "Lailatul Qadr is the night of power"
    },
    {
      "question": "Muslims greet with?",
      "options": [
        "Good morning",
        "Hello",
        "Assalamu Alaikum",
        "Hi"
      ],
      "correct": 2,
      "explanation": "Assalamu Alaikum is the greeting"
    },
    {
      "question": "Eid al-Fitr ends?",
      "options": [
        "Ramadan",
        "Muharram",
        "Hajj",
        "Safar"
      ],
      "correct": 0,
      "explanation": "It ends Ramadan"
    },
    {
      "question": "Eid al-Adha commemorates?",
      "options": [
        "The Prophet's birth",
        "Badr",
        "Ibrahim's sacrifice",
        "Hijrah"
      ],
      "correct": 2,
      "explanation": "It commemorates Ibrahim's sacrifice"
    },
    {
      "question": "The Kaaba was built by?",
      "options": [
        "Ibrahim and Ismail",
        "Musa",
        "Yusuf",
        "Isa"
      ],
      "correct": 0,
      "explanation": "Ibrahim and Ismail built it"
    },
    {
      "question": "The first pillar is the?",
      "options": [
        "Shahada",
        "Hajj",
        "Zakat",
        "Salah"
      ],
      "correct": 0,
      "explanation": "Shahada is first"
    },
    {
      "question": "There is no god but?",
      "options": [
        "Any idol",
        "Nature",
        "Man",
        "Allah"
      ],
      "correct": 3,
      "explanation": "There is no god but Allah"
    },
    {
      "question": "Muhammad is His?",
      "options": [
        "Messenger",
        "Partner",
        "Son",
        "Equal"
      ],
      "correct": 0,
      "explanation": "Muhammad is the Messenger"
    },
    {
      "question": "Salah is the?",
      "options": [
        "Third pillar",
        "Second pillar",
        "First pillar",
        "Fifth pillar"
      ],
      "correct": 1,
      "explanation": "Salah is second"
    },
    {
      "question": "Muslims pray?",
      "options": [
        "Three times",
        "Once",
        "Seven times",
        "Five times daily"
      ],
      "correct": 3,
      "explanation": "Five times a day"
    },
    {
      "question": "Fajr is the?",
      "options": [
        "Night prayer",
        "Dawn prayer",
        "Afternoon prayer",
        "Noon prayer"
      ],
      "correct": 1,
      "explanation": "Fajr is dawn"
    },
    {
      "question": "Dhuhr is the?",
      "options": [
        "Night prayer",
        "Noon prayer",
        "Sunset prayer",
        "Dawn prayer"
      ],
      "correct": 1,
      "explanation": "Dhuhr is noon"
    },
    {
      "question": "Asr is the?",
      "options": [
        "Noon prayer",
        "Afternoon prayer",
        "Night prayer",
        "Dawn prayer"
      ],
      "correct": 1,
      "explanation": "Asr is afternoon"
    },
    {
      "question": "Maghrib is the?",
      "options": [
        "Sunset prayer",
        "Night prayer",
        "Dawn prayer",
        "Noon prayer"
      ],
      "correct": 0,
      "explanation": "Maghrib is sunset"
    },
    {
      "question": "Isha is the?",
      "options": [
        "Afternoon prayer",
        "Dawn prayer",
        "Noon prayer",
        "Night prayer"
      ],
      "correct": 3,
      "explanation": "Isha is night"
    },
    {
      "question": "Zakat is the?",
      "options": [
        "Third pillar",
        "First pillar",
        "Second pillar",
        "Fifth pillar"
      ],
      "correct": 0,
      "explanation": "Zakat is third"
    },
    {
      "question": "Zakat is paid on?",
      "options": [
        "Wealth above nisab",
        "Only land",
        "All income always",
        "Only animals"
      ],
      "correct": 0,
      "explanation": "It is on wealth that reaches nisab"
    },
    {
      "question": "Sawm is the?",
      "options": [
        "First pillar",
        "Fourth pillar",
        "Third pillar",
        "Second pillar"
      ],
      "correct": 1,
      "explanation": "Sawm is fourth"
    },
    {
      "question": "Fasting is in?",
      "options": [
        "Shawwal",
        "Ramadan",
        "Muharram",
        "Safar"
      ],
      "correct": 1,
      "explanation": "Fasting is in Ramadan"
    },
    {
      "question": "Hajj is the?",
      "options": [
        "Second pillar",
        "First pillar",
        "Fifth pillar",
        "Third pillar"
      ],
      "correct": 2,
      "explanation": "Hajj is fifth"
    },
    {
      "question": "Hajj is in?",
      "options": [
        "Ramadan",
        "Shawwal",
        "Dhul Hijjah",
        "Muharram"
      ],
      "correct": 2,
      "explanation": "Hajj is in Dhul Hijjah"
    },
    {
      "question": "The Prophet was born in?",
      "options": [
        "Makkah",
        "Taif",
        "Madinah",
        "Jerusalem"
      ],
      "correct": 0,
      "explanation": "He was born in Makkah"
    },
    {
      "question": "The Prophet migrated to?",
      "options": [
        "Madinah",
        "Makkah",
        "Jerusalem",
        "Taif"
      ],
      "correct": 0,
      "explanation": "He migrated to Madinah"
    },
    {
      "question": "The first revelation was in?",
      "options": [
        "Cave Thawr",
        "Cave Hira",
        "The mosque",
        "The Kaaba"
      ],
      "correct": 1,
      "explanation": "It was in Cave Hira"
    },
    {
      "question": "The angel was?",
      "options": [
        "Israfil",
        "Izrail",
        "Jibril",
        "Mikail"
      ],
      "correct": 2,
      "explanation": "Jibril brought the revelation"
    },
    {
      "question": "The first Caliph was?",
      "options": [
        "Ali",
        "Uthman",
        "Abu Bakr",
        "Umar"
      ],
      "correct": 2,
      "explanation": "Abu Bakr was first"
    },
    {
      "question": "The second Caliph was?",
      "options": [
        "Uthman",
        "Umar",
        "Ali",
        "Abu Bakr"
      ],
      "correct": 1,
      "explanation": "Umar was second"
    },
    {
      "question": "Tawhid is?",
      "options": [
        "Oneness of Allah",
        "Charity",
        "Prayer",
        "Prophethood"
      ],
      "correct": 0,
      "explanation": "Tawhid is oneness"
    },
    {
      "question": "Shirk is?",
      "options": [
        "Associating partners with Allah",
        "Belief in one God",
        "Prayer",
        "Fasting"
      ],
      "correct": 0,
      "explanation": "Shirk is polytheism"
    },
    {
      "question": "The night of power is?",
      "options": [
        "Lailatul Hijrah",
        "Lailatul Qadr",
        "Lailatul Miraj",
        "Lailatul Badr"
      ],
      "correct": 1,
      "explanation": "Lailatul Qadr is the night of power"
    },
    {
      "question": "The first pillar is?",
      "options": [
        "Salah",
        "Zakat",
        "Hajj",
        "Shahada"
      ],
      "correct": 3,
      "explanation": "Shahada is first"
    },
    {
      "question": "No god but?",
      "options": [
        "Nature",
        "Idols",
        "Man",
        "Allah"
      ],
      "correct": 3,
      "explanation": "No god but Allah"
    },
    {
      "question": "Muhammad is the?",
      "options": [
        "Partner",
        "Messenger",
        "Equal",
        "Son"
      ],
      "correct": 1,
      "explanation": "He is the Messenger"
    },
    {
      "question": "Salah is?",
      "options": [
        "First pillar",
        "Second pillar",
        "Fifth pillar",
        "Third pillar"
      ],
      "correct": 1,
      "explanation": "Salah is second"
    },
    {
      "question": "Prayers daily are?",
      "options": [
        "Three",
        "One",
        "Five",
        "Seven"
      ],
      "correct": 2,
      "explanation": "Five daily prayers"
    },
    {
      "question": "Fajr is?",
      "options": [
        "Afternoon",
        "Noon",
        "Dawn",
        "Night"
      ],
      "correct": 2,
      "explanation": "Fajr is dawn"
    },
    {
      "question": "Dhuhr is?",
      "options": [
        "Dawn",
        "Sunset",
        "Noon",
        "Night"
      ],
      "correct": 2,
      "explanation": "Dhuhr is noon"
    },
    {
      "question": "Asr is?",
      "options": [
        "Afternoon",
        "Dawn",
        "Night",
        "Noon"
      ],
      "correct": 0,
      "explanation": "Asr is afternoon"
    },
    {
      "question": "Maghrib is?",
      "options": [
        "Night",
        "Dawn",
        "Noon",
        "Sunset"
      ],
      "correct": 3,
      "explanation": "Maghrib is sunset"
    },
    {
      "question": "Isha is?",
      "options": [
        "Noon",
        "Dawn",
        "Afternoon",
        "Night"
      ],
      "correct": 3,
      "explanation": "Isha is night"
    },
    {
      "question": "Zakat is?",
      "options": [
        "First pillar",
        "Second pillar",
        "Third pillar",
        "Fifth pillar"
      ],
      "correct": 2,
      "explanation": "Zakat is third"
    },
    {
      "question": "Zakat purifies?",
      "options": [
        "Wealth",
        "Body only",
        "Heart only",
        "Mind only"
      ],
      "correct": 0,
      "explanation": "Zakat purifies wealth"
    },
    {
      "question": "Sawm is?",
      "options": [
        "Fourth pillar",
        "Second pillar",
        "Third pillar",
        "First pillar"
      ],
      "correct": 0,
      "explanation": "Sawm is fourth"
    },
    {
      "question": "Fasting is in?",
      "options": [
        "Safar",
        "Ramadan",
        "Muharram",
        "Shawwal"
      ],
      "correct": 1,
      "explanation": "Fasting is in Ramadan"
    },
    {
      "question": "Hajj is?",
      "options": [
        "First pillar",
        "Third pillar",
        "Second pillar",
        "Fifth pillar"
      ],
      "correct": 3,
      "explanation": "Hajj is fifth"
    },
    {
      "question": "Hajj is in?",
      "options": [
        "Muharram",
        "Shawwal",
        "Dhul Hijjah",
        "Ramadan"
      ],
      "correct": 2,
      "explanation": "Hajj is in Dhul Hijjah"
    },
    {
      "question": "Prophet born in?",
      "options": [
        "Madinah",
        "Makkah",
        "Jerusalem",
        "Taif"
      ],
      "correct": 1,
      "explanation": "He was born in Makkah"
    },
    {
      "question": "Prophet migrated to?",
      "options": [
        "Madinah",
        "Taif",
        "Jerusalem",
        "Makkah"
      ],
      "correct": 0,
      "explanation": "He migrated to Madinah"
    },
    {
      "question": "First revelation in?",
      "options": [
        "Cave Hira",
        "Mosque",
        "Cave Thawr",
        "Kaaba"
      ],
      "correct": 0,
      "explanation": "It was in Cave Hira"
    },
    {
      "question": "Angel of revelation?",
      "options": [
        "Israfil",
        "Mikail",
        "Izrail",
        "Jibril"
      ],
      "correct": 3,
      "explanation": "Jibril brought it"
    },
    {
      "question": "First Caliph?",
      "options": [
        "Uthman",
        "Ali",
        "Umar",
        "Abu Bakr"
      ],
      "correct": 3,
      "explanation": "Abu Bakr was first"
    },
    {
      "question": "Second Caliph?",
      "options": [
        "Umar",
        "Abu Bakr",
        "Ali",
        "Uthman"
      ],
      "correct": 0,
      "explanation": "Umar was second"
    },
    {
      "question": "Tawhid is?",
      "options": [
        "Prophethood",
        "Prayer",
        "Charity",
        "Oneness of Allah"
      ],
      "correct": 3,
      "explanation": "Tawhid is oneness"
    },
    {
      "question": "Shirk is?",
      "options": [
        "Fasting",
        "Belief in one God",
        "Prayer",
        "Associating partners"
      ],
      "correct": 3,
      "explanation": "Shirk is associating partners"
    },
    {
      "question": "Night of power?",
      "options": [
        "Lailatul Hijrah",
        "Lailatul Badr",
        "Lailatul Miraj",
        "Lailatul Qadr"
      ],
      "correct": 3,
      "explanation": "Lailatul Qadr is the night of power"
    }
  ],
  "his": [
    {
      "question": "Nigeria gained independence in?",
      "options": [
        "1963",
        "1960",
        "1970",
        "1956"
      ],
      "correct": 1,
      "explanation": "Nigeria became independent on 1 October 1960"
    },
    {
      "question": "The first Prime Minister of Nigeria was?",
      "options": [
        "Obafemi Awolowo",
        "Nnamdi Azikiwe",
        "Ahmadu Bello",
        "Abubakar Tafawa Balewa"
      ],
      "correct": 3,
      "explanation": "Balewa was the first Prime Minister"
    },
    {
      "question": "The first President of Nigeria was?",
      "options": [
        "Yakubu Gowon",
        "Abubakar Tafawa Balewa",
        "Nnamdi Azikiwe",
        "Olusegun Obasanjo"
      ],
      "correct": 2,
      "explanation": "Azikiwe was the first President"
    },
    {
      "question": "The amalgamation of Nigeria took place in?",
      "options": [
        "1900",
        "1914",
        "1960",
        "1963"
      ],
      "correct": 1,
      "explanation": "Lord Lugard amalgamated Nigeria in 1914"
    },
    {
      "question": "The British first came to Nigeria through?",
      "options": [
        "Exploration only",
        "Trade",
        "War only",
        "Religion only"
      ],
      "correct": 1,
      "explanation": "Trade (especially palm oil and slaves) brought the British"
    },
    {
      "question": "The Sokoto Caliphate was founded by?",
      "options": [
        "Usman dan Fodio",
        "Abdullahi ibn Fodio",
        "Ahmadu Bello",
        "Muhammad Bello only"
      ],
      "correct": 0,
      "explanation": "Usman dan Fodio led the jihad"
    },
    {
      "question": "The Oyo Empire was located in present-day?",
      "options": [
        "Middle Belt only",
        "South-West Nigeria",
        "Northern Nigeria",
        "Eastern Nigeria"
      ],
      "correct": 1,
      "explanation": "Oyo was in the Yoruba area"
    },
    {
      "question": "The Benin Kingdom was famous for?",
      "options": [
        "Gold mining only",
        "Fishing only",
        "Bronze works",
        "Cattle rearing only"
      ],
      "correct": 2,
      "explanation": "Benin was renowned for bronzes"
    },
    {
      "question": "The Atlantic slave trade involved?",
      "options": [
        "Only European local trade",
        "Only internal trade",
        "Only Asian trade",
        "Transportation of Africans to the Americas"
      ],
      "correct": 3,
      "explanation": "Slaves were taken across the Atlantic"
    },
    {
      "question": "Nigeria became a republic in?",
      "options": [
        "1979",
        "1960",
        "1963",
        "1966"
      ],
      "correct": 2,
      "explanation": "Nigeria became a republic in 1963"
    },
    {
      "question": "The first military coup in Nigeria was in?",
      "options": [
        "1975",
        "1960",
        "1963",
        "1966"
      ],
      "correct": 3,
      "explanation": "January 1966 coup"
    },
    {
      "question": "The Nigerian Civil War lasted from?",
      "options": [
        "1960 to 1963",
        "1966 to 1967",
        "1970 to 1975",
        "1967 to 1970"
      ],
      "correct": 3,
      "explanation": "The war was 1967–1970"
    },
    {
      "question": "Biafra was led by?",
      "options": [
        "Olusegun Obasanjo",
        "Murtala Mohammed",
        "Chukwuemeka Odumegwu Ojukwu",
        "Yakubu Gowon"
      ],
      "correct": 2,
      "explanation": "Ojukwu led Biafra"
    },
    {
      "question": "The capital of Nigeria was moved to Abuja in?",
      "options": [
        "1960",
        "1991",
        "1999",
        "1976"
      ],
      "correct": 1,
      "explanation": "Abuja became capital in 1991"
    },
    {
      "question": "Indirect rule was introduced by?",
      "options": [
        "Lord Harcourt",
        "Sir Hugh Clifford",
        "Sir Arthur Richards",
        "Lord Lugard"
      ],
      "correct": 3,
      "explanation": "Lugard introduced indirect rule"
    },
    {
      "question": "The Aba Women's Riot took place in?",
      "options": [
        "1966",
        "1914",
        "1960",
        "1929"
      ],
      "correct": 3,
      "explanation": "The riot was in 1929"
    },
    {
      "question": "Nigeria's first political party was?",
      "options": [
        "NCNC",
        "AG",
        "Nigerian National Democratic Party (NNDP)",
        "NPC"
      ],
      "correct": 2,
      "explanation": "NNDP was founded by Herbert Macaulay"
    },
    {
      "question": "The Richards Constitution was introduced in?",
      "options": [
        "1954",
        "1951",
        "1946",
        "1922"
      ],
      "correct": 2,
      "explanation": "Richards Constitution was in 1946"
    },
    {
      "question": "The Macpherson Constitution was in?",
      "options": [
        "1951",
        "1954",
        "1946",
        "1960"
      ],
      "correct": 0,
      "explanation": "Macpherson Constitution was 1951"
    },
    {
      "question": "Nigeria joined the United Nations in?",
      "options": [
        "1963",
        "1970",
        "1956",
        "1960"
      ],
      "correct": 3,
      "explanation": "Nigeria joined the UN in 1960"
    },
    {
      "question": "The Berlin Conference of 1884/85 was about?",
      "options": [
        "Partition of Africa",
        "Independence of Africa",
        "End of slave trade only",
        "Formation of UN"
      ],
      "correct": 0,
      "explanation": "It formalised the scramble for Africa"
    },
    {
      "question": "The Scramble for Africa was?",
      "options": [
        "European colonisation of Africa",
        "African colonisation of Europe",
        "Internal African wars only",
        "Trade agreements only"
      ],
      "correct": 0,
      "explanation": "Europeans competed for African territories"
    },
    {
      "question": "Colonial rule in Nigeria ended in?",
      "options": [
        "1963",
        "1956",
        "1970",
        "1960"
      ],
      "correct": 3,
      "explanation": "Independence in 1960 ended colonial rule"
    },
    {
      "question": "The National Council of Nigeria and the Cameroons (NCNC) was led by?",
      "options": [
        "Obafemi Awolowo",
        "Ahmadu Bello",
        "Nnamdi Azikiwe",
        "Abubakar Tafawa Balewa"
      ],
      "correct": 2,
      "explanation": "Azikiwe led the NCNC"
    },
    {
      "question": "The Action Group was led by?",
      "options": [
        "Obafemi Awolowo",
        "Ahmadu Bello",
        "Nnamdi Azikiwe",
        "Herbert Macaulay"
      ],
      "correct": 0,
      "explanation": "Awolowo led the Action Group"
    },
    {
      "question": "The Berlin Conference was held in?",
      "options": [
        "1960",
        "1884-1885",
        "1945",
        "1914"
      ],
      "correct": 1,
      "explanation": "The conference was in 1884-1885"
    },
    {
      "question": "Lord Lugard was the first?",
      "options": [
        "Premier",
        "Governor-General of Nigeria",
        "President",
        "Prime Minister"
      ],
      "correct": 1,
      "explanation": "Lugard was the first Governor-General"
    },
    {
      "question": "The Clifford Constitution introduced?",
      "options": [
        "Military rule",
        "Republic",
        "Elective principle",
        "Independence"
      ],
      "correct": 2,
      "explanation": "Clifford Constitution of 1922 introduced elective principle"
    },
    {
      "question": "The Lyttleton Constitution was in?",
      "options": [
        "1954",
        "1951",
        "1946",
        "1960"
      ],
      "correct": 0,
      "explanation": "Lyttleton Constitution was 1954"
    },
    {
      "question": "Nigeria became a federation under?",
      "options": [
        "Lyttleton Constitution",
        "Clifford Constitution",
        "Macpherson Constitution",
        "Richards Constitution"
      ],
      "correct": 0,
      "explanation": "1954 Constitution made Nigeria a federation"
    },
    {
      "question": "The Northern People's Congress (NPC) was led by?",
      "options": [
        "Nnamdi Azikiwe",
        "Herbert Macaulay",
        "Obafemi Awolowo",
        "Ahmadu Bello"
      ],
      "correct": 3,
      "explanation": "Ahmadu Bello led the NPC"
    },
    {
      "question": "The National Council of Nigerian Citizens was formerly?",
      "options": [
        "NCNC",
        "AG",
        "NNDP",
        "NPC"
      ],
      "correct": 0,
      "explanation": "NCNC later became National Council of Nigerian Citizens"
    },
    {
      "question": "The first military Head of State was?",
      "options": [
        "Aguiyi Ironsi",
        "Olusegun Obasanjo",
        "Murtala Mohammed",
        "Yakubu Gowon"
      ],
      "correct": 0,
      "explanation": "Ironsi was the first military Head of State"
    },
    {
      "question": "Yakubu Gowon became Head of State in?",
      "options": [
        "1975",
        "1966",
        "1970",
        "1967"
      ],
      "correct": 1,
      "explanation": "Gowon took over in July 1966"
    },
    {
      "question": "The three Rs after the Civil War stood for?",
      "options": [
        "Reform, Revolution and Rights",
        "Republic, Region and Rule",
        "Revenge, Resistance and Rebellion",
        "Reconstruction, Rehabilitation and Reconciliation"
      ],
      "correct": 3,
      "explanation": "Gowon's policy was the three Rs"
    },
    {
      "question": "Murtala Mohammed became Head of State in?",
      "options": [
        "1979",
        "1966",
        "1970",
        "1975"
      ],
      "correct": 3,
      "explanation": "Murtala took over in 1975"
    },
    {
      "question": "Olusegun Obasanjo handed over to?",
      "options": [
        "Ibrahim Babangida",
        "Shehu Shagari",
        "Sani Abacha",
        "Muhammadu Buhari"
      ],
      "correct": 1,
      "explanation": "Obasanjo handed over to Shagari in 1979"
    },
    {
      "question": "The Second Republic began in?",
      "options": [
        "1979",
        "1999",
        "1963",
        "1960"
      ],
      "correct": 0,
      "explanation": "Second Republic started in 1979"
    },
    {
      "question": "Muhammadu Buhari became Head of State in?",
      "options": [
        "1985",
        "1979",
        "1993",
        "1983"
      ],
      "correct": 3,
      "explanation": "Buhari's coup was in 1983"
    },
    {
      "question": "Ibrahim Babangida introduced?",
      "options": [
        "Amalgamation",
        "Independence",
        "Civil War",
        "Structural Adjustment Programme"
      ],
      "correct": 3,
      "explanation": "SAP was introduced under Babangida"
    },
    {
      "question": "The June 12 1993 election was annulled by?",
      "options": [
        "Ernest Shonekan",
        "Sani Abacha",
        "Ibrahim Babangida",
        "Abdulsalami Abubakar"
      ],
      "correct": 2,
      "explanation": "Babangida annulled the election"
    },
    {
      "question": "Sani Abacha ruled from?",
      "options": [
        "1979 to 1983",
        "1998 to 1999",
        "1993 to 1998",
        "1985 to 1993"
      ],
      "correct": 2,
      "explanation": "Abacha ruled 1993-1998"
    },
    {
      "question": "Nigeria returned to democracy in?",
      "options": [
        "1993",
        "1983",
        "1979",
        "1999"
      ],
      "correct": 3,
      "explanation": "Fourth Republic began in 1999"
    },
    {
      "question": "Olusegun Obasanjo became civilian President in?",
      "options": [
        "1976",
        "1999",
        "2007",
        "1979"
      ],
      "correct": 1,
      "explanation": "Obasanjo was elected in 1999"
    },
    {
      "question": "The Economic Community of West African States (ECOWAS) was formed in?",
      "options": [
        "1975",
        "1963",
        "1960",
        "1999"
      ],
      "correct": 0,
      "explanation": "ECOWAS was formed in 1975"
    },
    {
      "question": "Nigeria fought to keep which country united during the Civil War?",
      "options": [
        "Itself",
        "Ghana",
        "Cameroon",
        "Benin"
      ],
      "correct": 0,
      "explanation": "The war was to keep Nigeria one"
    },
    {
      "question": "The capital of the Sokoto Caliphate was?",
      "options": [
        "Sokoto",
        "Kano",
        "Katsina",
        "Zaria"
      ],
      "correct": 0,
      "explanation": "Sokoto was the capital"
    },
    {
      "question": "The Trans-Atlantic slave trade was abolished by Britain in?",
      "options": [
        "1860",
        "1833",
        "1900",
        "1807"
      ],
      "correct": 3,
      "explanation": "Britain abolished the trade in 1807"
    },
    {
      "question": "The Royal Niger Company was led by?",
      "options": [
        "George Goldie",
        "Sir Hugh Clifford",
        "Lord Harcourt",
        "Lord Lugard"
      ],
      "correct": 0,
      "explanation": "Goldie headed the Royal Niger Company"
    },
    {
      "question": "Nigeria's independence was granted by?",
      "options": [
        "Portugal",
        "Germany",
        "Britain",
        "France"
      ],
      "correct": 2,
      "explanation": "Britain granted independence"
    },
    {
      "question": "The scramble for Africa was formalised at?",
      "options": [
        "Yalta",
        "Berlin Conference",
        "Versailles",
        "Potsdam"
      ],
      "correct": 1,
      "explanation": "Berlin Conference formalised the scramble"
    },
    {
      "question": "Nigeria was a British?",
      "options": [
        "German colony",
        "Colony and protectorate",
        "Portuguese colony",
        "French colony"
      ],
      "correct": 1,
      "explanation": "Nigeria was under British rule"
    },
    {
      "question": "The warrant chiefs system was used in?",
      "options": [
        "Eastern Nigeria",
        "Western Nigeria only",
        "All of Nigeria equally",
        "Northern Nigeria only"
      ],
      "correct": 0,
      "explanation": "Warrant chiefs were used in the East"
    },
    {
      "question": "The Aba Women's Riot protested against?",
      "options": [
        "Taxation and warrant chiefs",
        "Military rule",
        "Independence",
        "Civil war"
      ],
      "correct": 0,
      "explanation": "Women protested tax and local administration"
    },
    {
      "question": "Herbert Macaulay is regarded as?",
      "options": [
        "First President",
        "Father of Nigerian nationalism",
        "First Prime Minister",
        "First military ruler"
      ],
      "correct": 1,
      "explanation": "Macaulay is the father of Nigerian nationalism"
    },
    {
      "question": "The NCNC was founded in?",
      "options": [
        "1923",
        "1951",
        "1960",
        "1944"
      ],
      "correct": 3,
      "explanation": "NCNC was founded in 1944"
    },
    {
      "question": "The Action Group was founded in?",
      "options": [
        "1923",
        "1944",
        "1960",
        "1951"
      ],
      "correct": 3,
      "explanation": "Action Group was founded in 1951"
    },
    {
      "question": "The NPC dominated?",
      "options": [
        "Western Nigeria",
        "Northern Nigeria",
        "Eastern Nigeria",
        "Southern Nigeria only"
      ],
      "correct": 1,
      "explanation": "NPC was the main northern party"
    },
    {
      "question": "The 1959 general election led to?",
      "options": [
        "Military rule",
        "Civil war",
        "Republic immediately",
        "Independence government"
      ],
      "correct": 3,
      "explanation": "It produced the independence government"
    },
    {
      "question": "Nigeria's independence constitution was?",
      "options": [
        "1960 Constitution",
        "1999 Constitution",
        "1963 Constitution",
        "1979 Constitution"
      ],
      "correct": 0,
      "explanation": "The 1960 Constitution was for independence"
    },
    {
      "question": "The 1963 Constitution made Nigeria a?",
      "options": [
        "Republic",
        "Military state",
        "Monarchy",
        "One-party state"
      ],
      "correct": 0,
      "explanation": "1963 made Nigeria a republic"
    },
    {
      "question": "The January 1966 coup was led by?",
      "options": [
        "Murtala Mohammed",
        "Chukwuma Nzeogwu and others",
        "Olusegun Obasanjo",
        "Yakubu Gowon"
      ],
      "correct": 1,
      "explanation": "Nzeogwu was a key figure in the coup"
    },
    {
      "question": "The July 1966 counter-coup brought?",
      "options": [
        "Yakubu Gowon to power",
        "Ojukwu to power",
        "Awolowo to power",
        "Ironsi to power"
      ],
      "correct": 0,
      "explanation": "Gowon emerged after the July coup"
    },
    {
      "question": "The Civil War was also called?",
      "options": [
        "Cold War",
        "Boer War",
        "World War",
        "Biafran War"
      ],
      "correct": 3,
      "explanation": "It is also known as the Biafran War"
    },
    {
      "question": "Gowon's regime ended in?",
      "options": [
        "1970",
        "1975",
        "1976",
        "1979"
      ],
      "correct": 1,
      "explanation": "Gowon was overthrown in 1975"
    },
    {
      "question": "Murtala Mohammed was assassinated in?",
      "options": [
        "1979",
        "1983",
        "1975",
        "1976"
      ],
      "correct": 3,
      "explanation": "Murtala was killed in 1976"
    },
    {
      "question": "Obasanjo's first regime handed over in?",
      "options": [
        "1979",
        "1999",
        "1976",
        "1983"
      ],
      "correct": 0,
      "explanation": "He handed over in 1979"
    },
    {
      "question": "Shehu Shagari was the first?",
      "options": [
        "Military Head of State",
        "Executive President of Nigeria",
        "Senate President only",
        "Prime Minister"
      ],
      "correct": 1,
      "explanation": "Shagari was the first executive President"
    },
    {
      "question": "The Second Republic ended in?",
      "options": [
        "1985",
        "1983",
        "1993",
        "1979"
      ],
      "correct": 1,
      "explanation": "Buhari's coup ended it in 1983"
    },
    {
      "question": "Babangida's regime introduced?",
      "options": [
        "Amalgamation",
        "Civil war",
        "SAP and two-party system",
        "Independence"
      ],
      "correct": 2,
      "explanation": "SAP and SDP/NRC were under Babangida"
    },
    {
      "question": "The Interim National Government was headed by?",
      "options": [
        "Olusegun Obasanjo",
        "Ernest Shonekan",
        "Abdulsalami Abubakar",
        "Sani Abacha"
      ],
      "correct": 1,
      "explanation": "Shonekan headed the ING"
    },
    {
      "question": "Abacha's regime ended with his?",
      "options": [
        "Resignation",
        "Election defeat",
        "Coup against him",
        "Death in 1998"
      ],
      "correct": 3,
      "explanation": "Abacha died in 1998"
    },
    {
      "question": "Abdulsalami Abubakar handed over in?",
      "options": [
        "2003",
        "1999",
        "2007",
        "1998"
      ],
      "correct": 1,
      "explanation": "He handed over in May 1999"
    },
    {
      "question": "The Fourth Republic began with?",
      "options": [
        "Umaru Yar'Adua",
        "Goodluck Jonathan",
        "Muhammadu Buhari",
        "Olusegun Obasanjo"
      ],
      "correct": 3,
      "explanation": "Obasanjo started the Fourth Republic"
    },
    {
      "question": "ECOWAS was established to promote?",
      "options": [
        "Isolation",
        "Military rule",
        "Colonialism",
        "Economic integration in West Africa"
      ],
      "correct": 3,
      "explanation": "ECOWAS promotes regional integration"
    },
    {
      "question": "The Royal Niger Company was granted a charter in?",
      "options": [
        "1960",
        "1900",
        "1914",
        "1886"
      ],
      "correct": 3,
      "explanation": "The charter was granted in 1886"
    },
    {
      "question": "The British took over from the Royal Niger Company in?",
      "options": [
        "1900",
        "1886",
        "1914",
        "1960"
      ],
      "correct": 0,
      "explanation": "The British government took over in 1900"
    },
    {
      "question": "Northern and Southern Nigeria were amalgamated in?",
      "options": [
        "1900",
        "1960",
        "1914",
        "1963"
      ],
      "correct": 2,
      "explanation": "Amalgamation was in 1914"
    },
    {
      "question": "The Clifford Constitution allowed?",
      "options": [
        "Military rule",
        "One-party system",
        "Limited elective representation",
        "Full independence"
      ],
      "correct": 2,
      "explanation": "It introduced limited elections"
    },
    {
      "question": "The Richards Constitution introduced?",
      "options": [
        "Military rule",
        "Regionalism",
        "Independence",
        "Republic"
      ],
      "correct": 1,
      "explanation": "Richards Constitution brought regionalism"
    },
    {
      "question": "The Macpherson Constitution allowed?",
      "options": [
        "More Nigerian participation",
        "Full independence",
        "No change",
        "Military rule"
      ],
      "correct": 0,
      "explanation": "It increased Nigerian involvement"
    },
    {
      "question": "The Lyttleton Constitution created?",
      "options": [
        "Unitary structure",
        "No structure",
        "Federal structure",
        "Confederal structure"
      ],
      "correct": 2,
      "explanation": "It established a federal system"
    },
    {
      "question": "Nigeria's independence was on?",
      "options": [
        "1 October 1956",
        "1 October 1963",
        "1 October 1960",
        "1 January 1960"
      ],
      "correct": 2,
      "explanation": "Independence Day is 1 October 1960"
    },
    {
      "question": "The first Nigerian Governor-General was?",
      "options": [
        "Abubakar Tafawa Balewa",
        "Ahmadu Bello",
        "Obafemi Awolowo",
        "Nnamdi Azikiwe"
      ],
      "correct": 3,
      "explanation": "Azikiwe became Governor-General"
    },
    {
      "question": "Nigeria became a republic on?",
      "options": [
        "1 January 1963",
        "1 October 1960",
        "1 October 1963",
        "1 October 1966"
      ],
      "correct": 2,
      "explanation": "Republic Day is 1 October 1963"
    },
    {
      "question": "The 1966 coup was the first?",
      "options": [
        "Civil war",
        "Military intervention",
        "Constitutional amendment",
        "Democratic election"
      ],
      "correct": 1,
      "explanation": "It was the first coup"
    },
    {
      "question": "Ironsi's regime introduced?",
      "options": [
        "Regionalism",
        "Unification decree",
        "Confederalism",
        "Federalism"
      ],
      "correct": 1,
      "explanation": "Ironsi tried to unify the country"
    },
    {
      "question": "The Civil War started on?",
      "options": [
        "15 January 1966",
        "6 July 1967",
        "29 July 1966",
        "1 October 1960"
      ],
      "correct": 1,
      "explanation": "The war began on 6 July 1967"
    },
    {
      "question": "Biafra surrendered in?",
      "options": [
        "July 1967",
        "January 1970",
        "January 1966",
        "October 1970"
      ],
      "correct": 1,
      "explanation": "Biafra surrendered in January 1970"
    },
    {
      "question": "Gowon's regime created?",
      "options": [
        "Four regions",
        "Nineteen states",
        "Three regions",
        "Twelve states"
      ],
      "correct": 3,
      "explanation": "Gowon created twelve states"
    },
    {
      "question": "Murtala Mohammed created?",
      "options": [
        "Thirty-six states",
        "Nineteen states",
        "Twelve states",
        "Three regions"
      ],
      "correct": 1,
      "explanation": "Murtala created nineteen states"
    },
    {
      "question": "The 1979 Constitution introduced?",
      "options": [
        "Parliamentary system",
        "Confederal system",
        "Presidential system",
        "Military system"
      ],
      "correct": 2,
      "explanation": "1979 brought the presidential system"
    },
    {
      "question": "Shagari's government was overthrown in?",
      "options": [
        "1993",
        "1983",
        "1985",
        "1979"
      ],
      "correct": 1,
      "explanation": "Buhari's coup was in December 1983"
    },
    {
      "question": "Babangida's regime lasted from?",
      "options": [
        "1998 to 1999",
        "1983 to 1985",
        "1985 to 1993",
        "1993 to 1998"
      ],
      "correct": 2,
      "explanation": "Babangida ruled 1985-1993"
    },
    {
      "question": "The June 12 election was won by?",
      "options": [
        "Bashir Tofa",
        "Sani Abacha",
        "Moshood Abiola",
        "Ernest Shonekan"
      ],
      "correct": 2,
      "explanation": "Abiola won the June 12 election"
    },
    {
      "question": "Abacha's regime was known for?",
      "options": [
        "No opposition",
        "Full democracy",
        "Handing over power early",
        "Authoritarianism"
      ],
      "correct": 3,
      "explanation": "Abacha's rule was authoritarian"
    },
    {
      "question": "The transition to the Fourth Republic was supervised by?",
      "options": [
        "Sani Abacha",
        "Abdulsalami Abubakar",
        "Ibrahim Babangida",
        "Ernest Shonekan"
      ],
      "correct": 1,
      "explanation": "Abdulsalami supervised the transition"
    },
    {
      "question": "Obasanjo's civilian tenure was from?",
      "options": [
        "2007 to 2010",
        "1976 to 1979",
        "2015 to 2023",
        "1999 to 2007"
      ],
      "correct": 3,
      "explanation": "He ruled as civilian 1999-2007"
    },
    {
      "question": "Nigeria is a founding member of?",
      "options": [
        "Only ASEAN",
        "Only EU",
        "ECOWAS and OAU/AU",
        "Only NATO"
      ],
      "correct": 2,
      "explanation": "Nigeria helped found ECOWAS and OAU"
    },
    {
      "question": "The main aim of the nationalists was?",
      "options": [
        "Independence and self-government",
        "Colonial rule forever",
        "Foreign domination",
        "Military rule"
      ],
      "correct": 0,
      "explanation": "Nationalists sought independence"
    },
    {
      "question": "The Berlin Conference regulated?",
      "options": [
        "African independence",
        "Cold War",
        "European colonisation of Africa",
        "World War"
      ],
      "correct": 2,
      "explanation": "It regulated the scramble for Africa"
    },
    {
      "question": "Nigeria was colonised by?",
      "options": [
        "France",
        "Portugal",
        "Germany",
        "Britain"
      ],
      "correct": 3,
      "explanation": "Britain colonised Nigeria"
    },
    {
      "question": "The Royal Niger Company operated in?",
      "options": [
        "South Africa",
        "The Congo",
        "The Niger area",
        "East Africa"
      ],
      "correct": 2,
      "explanation": "It operated around the Niger"
    },
    {
      "question": "Lord Lugard amalgamated Nigeria in?",
      "options": [
        "1963",
        "1960",
        "1914",
        "1900"
      ],
      "correct": 2,
      "explanation": "Amalgamation was in 1914"
    },
    {
      "question": "Indirect rule was most successful in?",
      "options": [
        "Northern Nigeria",
        "Eastern Nigeria",
        "Western Nigeria only",
        "All equally"
      ],
      "correct": 0,
      "explanation": "It worked best in the North"
    },
    {
      "question": "The Aba Women's Riot occurred in?",
      "options": [
        "1966",
        "1914",
        "1929",
        "1960"
      ],
      "correct": 2,
      "explanation": "The riot was in 1929"
    },
    {
      "question": "Herbert Macaulay founded?",
      "options": [
        "NPC",
        "NNDP",
        "NCNC",
        "AG"
      ],
      "correct": 1,
      "explanation": "Macaulay founded the NNDP"
    },
    {
      "question": "Nnamdi Azikiwe was associated with?",
      "options": [
        "AG",
        "NCNC",
        "NNDP only",
        "NPC"
      ],
      "correct": 1,
      "explanation": "Azikiwe led the NCNC"
    },
    {
      "question": "Obafemi Awolowo led?",
      "options": [
        "NCNC",
        "NNDP",
        "NPC",
        "Action Group"
      ],
      "correct": 3,
      "explanation": "Awolowo led the Action Group"
    },
    {
      "question": "Ahmadu Bello was the?",
      "options": [
        "Prime Minister only",
        "Premier of Eastern Nigeria",
        "Premier of Western Nigeria",
        "Premier of Northern Nigeria"
      ],
      "correct": 3,
      "explanation": "He was Premier of the North"
    },
    {
      "question": "Nigeria gained independence under?",
      "options": [
        "Balewa as Prime Minister",
        "Azikiwe as Prime Minister",
        "Bello as Prime Minister",
        "Awolowo as Prime Minister"
      ],
      "correct": 0,
      "explanation": "Balewa was Prime Minister at independence"
    },
    {
      "question": "Nigeria became a republic in?",
      "options": [
        "1966",
        "1979",
        "1963",
        "1960"
      ],
      "correct": 2,
      "explanation": "It became a republic in 1963"
    },
    {
      "question": "The first military coup was in?",
      "options": [
        "January 1966",
        "1975",
        "July 1966",
        "1967"
      ],
      "correct": 0,
      "explanation": "The first coup was in January 1966"
    },
    {
      "question": "The Civil War lasted?",
      "options": [
        "One year",
        "Thirty months",
        "Ten years",
        "Five years"
      ],
      "correct": 1,
      "explanation": "The war lasted about thirty months"
    },
    {
      "question": "Gowon created?",
      "options": [
        "Thirty-six states",
        "Twelve states",
        "Three regions",
        "Nineteen states"
      ],
      "correct": 1,
      "explanation": "Gowon created twelve states"
    },
    {
      "question": "Murtala/Obasanjo regime created?",
      "options": [
        "Three regions",
        "Thirty-six states",
        "Nineteen states",
        "Twelve states"
      ],
      "correct": 2,
      "explanation": "Nineteen states were created"
    },
    {
      "question": "The 1979 Constitution introduced?",
      "options": [
        "Presidential system",
        "Parliamentary system",
        "Confederal system",
        "Military system"
      ],
      "correct": 0,
      "explanation": "It introduced the presidential system"
    },
    {
      "question": "The Second Republic was led by?",
      "options": [
        "Muhammadu Buhari",
        "Olusegun Obasanjo",
        "Ibrahim Babangida",
        "Shehu Shagari"
      ],
      "correct": 3,
      "explanation": "Shagari led the Second Republic"
    },
    {
      "question": "Buhari's first regime began in?",
      "options": [
        "1993",
        "1983",
        "1979",
        "1985"
      ],
      "correct": 1,
      "explanation": "Buhari took over in 1983"
    },
    {
      "question": "Babangida introduced?",
      "options": [
        "Civil war",
        "Amalgamation",
        "SAP",
        "Independence"
      ],
      "correct": 2,
      "explanation": "Structural Adjustment Programme was under Babangida"
    },
    {
      "question": "The June 12 election was in?",
      "options": [
        "2003",
        "1983",
        "1999",
        "1993"
      ],
      "correct": 3,
      "explanation": "June 12 was in 1993"
    },
    {
      "question": "Abacha ruled from?",
      "options": [
        "1998 to 1999",
        "1985 to 1993",
        "1979 to 1983",
        "1993 to 1998"
      ],
      "correct": 3,
      "explanation": "Abacha ruled 1993-1998"
    },
    {
      "question": "Democracy returned in?",
      "options": [
        "1999",
        "1993",
        "1983",
        "1979"
      ],
      "correct": 0,
      "explanation": "The Fourth Republic began in 1999"
    },
    {
      "question": "Obasanjo's civilian government lasted?",
      "options": [
        "Two years",
        "Four years",
        "Eight years",
        "Twelve years"
      ],
      "correct": 2,
      "explanation": "He served two terms (1999-2007)"
    },
    {
      "question": "Nigeria is a member of?",
      "options": [
        "Only EU",
        "UN, AU, ECOWAS, Commonwealth",
        "Only ASEAN",
        "Only NATO"
      ],
      "correct": 1,
      "explanation": "Nigeria belongs to those organisations"
    },
    {
      "question": "The scramble for Africa was decided at?",
      "options": [
        "Berlin Conference",
        "Potsdam",
        "Versailles",
        "Yalta"
      ],
      "correct": 0,
      "explanation": "Berlin Conference decided the scramble"
    },
    {
      "question": "Nigeria was under?",
      "options": [
        "British colonial rule",
        "French rule",
        "German rule",
        "Portuguese rule"
      ],
      "correct": 0,
      "explanation": "Britain ruled Nigeria"
    },
    {
      "question": "The amalgamation was done by?",
      "options": [
        "Lord Harcourt",
        "Lord Lugard",
        "Sir Hugh Clifford",
        "Sir Arthur Richards"
      ],
      "correct": 1,
      "explanation": "Lugard amalgamated Nigeria"
    },
    {
      "question": "Indirect rule used?",
      "options": [
        "Only missionaries",
        "Traditional rulers",
        "Only British officials",
        "Only soldiers"
      ],
      "correct": 1,
      "explanation": "It used traditional rulers"
    },
    {
      "question": "The Aba Women's Riot was against?",
      "options": [
        "Tax and warrant chiefs",
        "Civil war",
        "Military rule",
        "Independence"
      ],
      "correct": 0,
      "explanation": "Women protested tax and chiefs"
    },
    {
      "question": "Herbert Macaulay is the?",
      "options": [
        "First military ruler",
        "First Prime Minister",
        "Father of Nigerian nationalism",
        "First President"
      ],
      "correct": 2,
      "explanation": "He is the father of nationalism"
    },
    {
      "question": "NCNC was led by?",
      "options": [
        "Abubakar Tafawa Balewa",
        "Nnamdi Azikiwe",
        "Obafemi Awolowo",
        "Ahmadu Bello"
      ],
      "correct": 1,
      "explanation": "Azikiwe led NCNC"
    },
    {
      "question": "Action Group was led by?",
      "options": [
        "Nnamdi Azikiwe",
        "Ahmadu Bello",
        "Obafemi Awolowo",
        "Herbert Macaulay"
      ],
      "correct": 2,
      "explanation": "Awolowo led AG"
    },
    {
      "question": "NPC was led by?",
      "options": [
        "Nnamdi Azikiwe",
        "Herbert Macaulay",
        "Obafemi Awolowo",
        "Ahmadu Bello"
      ],
      "correct": 3,
      "explanation": "Bello led NPC"
    },
    {
      "question": "Independence was in?",
      "options": [
        "1963",
        "1960",
        "1956",
        "1970"
      ],
      "correct": 1,
      "explanation": "Independence was in 1960"
    },
    {
      "question": "The first Prime Minister was?",
      "options": [
        "Nnamdi Azikiwe",
        "Obafemi Awolowo",
        "Ahmadu Bello",
        "Abubakar Tafawa Balewa"
      ],
      "correct": 3,
      "explanation": "Balewa was the first PM"
    },
    {
      "question": "The first President was?",
      "options": [
        "Nnamdi Azikiwe",
        "Olusegun Obasanjo",
        "Yakubu Gowon",
        "Abubakar Tafawa Balewa"
      ],
      "correct": 0,
      "explanation": "Azikiwe was the first President"
    },
    {
      "question": "Nigeria became a republic in?",
      "options": [
        "1960",
        "1979",
        "1963",
        "1966"
      ],
      "correct": 2,
      "explanation": "It became a republic in 1963"
    },
    {
      "question": "The first coup was in?",
      "options": [
        "1963",
        "1975",
        "1960",
        "1966"
      ],
      "correct": 3,
      "explanation": "The first coup was in 1966"
    },
    {
      "question": "The Civil War was from?",
      "options": [
        "1967 to 1970",
        "1960 to 1963",
        "1970 to 1975",
        "1966 to 1967"
      ],
      "correct": 0,
      "explanation": "The war was 1967-1970"
    },
    {
      "question": "Biafra was led by?",
      "options": [
        "Odumegwu Ojukwu",
        "Murtala Mohammed",
        "Yakubu Gowon",
        "Olusegun Obasanjo"
      ],
      "correct": 0,
      "explanation": "Ojukwu led Biafra"
    },
    {
      "question": "Gowon created?",
      "options": [
        "Nineteen states",
        "Three regions",
        "Thirty-six states",
        "Twelve states"
      ],
      "correct": 3,
      "explanation": "Gowon created twelve states"
    },
    {
      "question": "Murtala created?",
      "options": [
        "Twelve states",
        "Three regions",
        "Thirty-six states",
        "Nineteen states"
      ],
      "correct": 3,
      "explanation": "Murtala created nineteen states"
    },
    {
      "question": "The 1979 Constitution introduced?",
      "options": [
        "Military system",
        "Parliamentary system",
        "Confederal system",
        "Presidential system"
      ],
      "correct": 3,
      "explanation": "It introduced presidential system"
    },
    {
      "question": "Shagari was the first?",
      "options": [
        "Military Head",
        "Prime Minister",
        "Senate President only",
        "Executive President"
      ],
      "correct": 3,
      "explanation": "Shagari was the first executive President"
    },
    {
      "question": "Buhari's first coup was in?",
      "options": [
        "1979",
        "1993",
        "1983",
        "1985"
      ],
      "correct": 2,
      "explanation": "Buhari struck in 1983"
    },
    {
      "question": "Babangida ruled from?",
      "options": [
        "1998 to 1999",
        "1985 to 1993",
        "1983 to 1985",
        "1993 to 1998"
      ],
      "correct": 1,
      "explanation": "Babangida ruled 1985-1993"
    },
    {
      "question": "June 12 election was in?",
      "options": [
        "1983",
        "1999",
        "1993",
        "2003"
      ],
      "correct": 2,
      "explanation": "June 12 was in 1993"
    },
    {
      "question": "Abacha ruled till?",
      "options": [
        "1998",
        "1999",
        "2003",
        "1993"
      ],
      "correct": 0,
      "explanation": "Abacha died in 1998"
    },
    {
      "question": "Democracy returned in?",
      "options": [
        "1993",
        "1979",
        "1999",
        "1983"
      ],
      "correct": 2,
      "explanation": "Democracy returned in 1999"
    },
    {
      "question": "The Berlin Conference was in?",
      "options": [
        "1945",
        "1960",
        "1914",
        "1884-1885"
      ],
      "correct": 3,
      "explanation": "It was held in 1884-1885"
    },
    {
      "question": "Nigeria was colonised by?",
      "options": [
        "Portugal",
        "Britain",
        "France",
        "Germany"
      ],
      "correct": 1,
      "explanation": "Britain colonised Nigeria"
    },
    {
      "question": "Amalgamation was in?",
      "options": [
        "1914",
        "1960",
        "1963",
        "1900"
      ],
      "correct": 0,
      "explanation": "Amalgamation was in 1914"
    },
    {
      "question": "Indirect rule was introduced by?",
      "options": [
        "Sir Hugh Clifford",
        "Lord Harcourt",
        "Sir Arthur Richards",
        "Lord Lugard"
      ],
      "correct": 3,
      "explanation": "Lugard introduced it"
    },
    {
      "question": "The Aba Women's Riot was in?",
      "options": [
        "1914",
        "1929",
        "1960",
        "1966"
      ],
      "correct": 1,
      "explanation": "It was in 1929"
    },
    {
      "question": "Herbert Macaulay founded?",
      "options": [
        "AG",
        "NCNC",
        "NPC",
        "NNDP"
      ],
      "correct": 3,
      "explanation": "He founded NNDP"
    },
    {
      "question": "Azikiwe led?",
      "options": [
        "AG",
        "NPC",
        "NCNC",
        "NNDP only"
      ],
      "correct": 2,
      "explanation": "Azikiwe led NCNC"
    },
    {
      "question": "Awolowo led?",
      "options": [
        "NPC",
        "Action Group",
        "NNDP",
        "NCNC"
      ],
      "correct": 1,
      "explanation": "Awolowo led AG"
    },
    {
      "question": "Bello led?",
      "options": [
        "NNDP",
        "AG",
        "NPC",
        "NCNC"
      ],
      "correct": 2,
      "explanation": "Bello led NPC"
    },
    {
      "question": "Independence was in?",
      "options": [
        "1956",
        "1970",
        "1960",
        "1963"
      ],
      "correct": 2,
      "explanation": "Independence was in 1960"
    },
    {
      "question": "The first PM was?",
      "options": [
        "Azikiwe",
        "Balewa",
        "Bello",
        "Awolowo"
      ],
      "correct": 1,
      "explanation": "Balewa was the first PM"
    },
    {
      "question": "The first President was?",
      "options": [
        "Obasanjo",
        "Balewa",
        "Azikiwe",
        "Gowon"
      ],
      "correct": 2,
      "explanation": "Azikiwe was the first President"
    },
    {
      "question": "Republic came in?",
      "options": [
        "1979",
        "1960",
        "1963",
        "1966"
      ],
      "correct": 2,
      "explanation": "Republic came in 1963"
    },
    {
      "question": "First coup was in?",
      "options": [
        "1960",
        "1966",
        "1963",
        "1975"
      ],
      "correct": 1,
      "explanation": "First coup was in 1966"
    },
    {
      "question": "Civil War was?",
      "options": [
        "1967-1970",
        "1970-1975",
        "1960-1963",
        "1966-1967"
      ],
      "correct": 0,
      "explanation": "Civil War was 1967-1970"
    },
    {
      "question": "Biafra leader was?",
      "options": [
        "Obasanjo",
        "Murtala",
        "Ojukwu",
        "Gowon"
      ],
      "correct": 2,
      "explanation": "Ojukwu led Biafra"
    },
    {
      "question": "Gowon created?",
      "options": [
        "3 regions",
        "19 states",
        "36 states",
        "12 states"
      ],
      "correct": 3,
      "explanation": "Gowon created 12 states"
    },
    {
      "question": "Murtala created?",
      "options": [
        "19 states",
        "12 states",
        "3 regions",
        "36 states"
      ],
      "correct": 0,
      "explanation": "Murtala created 19 states"
    },
    {
      "question": "1979 Constitution brought?",
      "options": [
        "Military system",
        "Presidential system",
        "Parliamentary system",
        "Confederal system"
      ],
      "correct": 1,
      "explanation": "It brought presidential system"
    },
    {
      "question": "Shagari was first?",
      "options": [
        "Prime Minister",
        "Military Head",
        "Senate President",
        "Executive President"
      ],
      "correct": 3,
      "explanation": "Shagari was first executive President"
    },
    {
      "question": "Buhari coup was in?",
      "options": [
        "1983",
        "1985",
        "1993",
        "1979"
      ],
      "correct": 0,
      "explanation": "Buhari coup was in 1983"
    },
    {
      "question": "Babangida ruled?",
      "options": [
        "1983-1985",
        "1998-1999",
        "1985-1993",
        "1993-1998"
      ],
      "correct": 2,
      "explanation": "Babangida ruled 1985-1993"
    },
    {
      "question": "June 12 was in?",
      "options": [
        "2003",
        "1993",
        "1999",
        "1983"
      ],
      "correct": 1,
      "explanation": "June 12 was in 1993"
    },
    {
      "question": "Abacha ruled till?",
      "options": [
        "1999",
        "2003",
        "1993",
        "1998"
      ],
      "correct": 3,
      "explanation": "Abacha ruled till 1998"
    },
    {
      "question": "Democracy returned in?",
      "options": [
        "1993",
        "1983",
        "1979",
        "1999"
      ],
      "correct": 3,
      "explanation": "Democracy returned in 1999"
    },
    {
      "question": "Berlin Conference was?",
      "options": [
        "1884-1885",
        "1945",
        "1960",
        "1914"
      ],
      "correct": 0,
      "explanation": "It was 1884-1885"
    },
    {
      "question": "Nigeria colonised by?",
      "options": [
        "Britain",
        "France",
        "Germany",
        "Portugal"
      ],
      "correct": 0,
      "explanation": "Britain colonised Nigeria"
    },
    {
      "question": "Amalgamation year?",
      "options": [
        "1900",
        "1914",
        "1960",
        "1963"
      ],
      "correct": 1,
      "explanation": "Amalgamation was 1914"
    },
    {
      "question": "Indirect rule by?",
      "options": [
        "Richards",
        "Clifford",
        "Harcourt",
        "Lugard"
      ],
      "correct": 3,
      "explanation": "Lugard introduced it"
    },
    {
      "question": "Aba Riot year?",
      "options": [
        "1966",
        "1929",
        "1914",
        "1960"
      ],
      "correct": 1,
      "explanation": "Aba Riot was 1929"
    },
    {
      "question": "Macaulay founded?",
      "options": [
        "NPC",
        "AG",
        "NCNC",
        "NNDP"
      ],
      "correct": 3,
      "explanation": "Macaulay founded NNDP"
    },
    {
      "question": "Azikiwe led?",
      "options": [
        "NCNC",
        "NNDP",
        "NPC",
        "AG"
      ],
      "correct": 0,
      "explanation": "Azikiwe led NCNC"
    },
    {
      "question": "Awolowo led?",
      "options": [
        "NCNC",
        "NNDP",
        "AG",
        "NPC"
      ],
      "correct": 2,
      "explanation": "Awolowo led AG"
    },
    {
      "question": "Bello led?",
      "options": [
        "NNDP",
        "NCNC",
        "NPC",
        "AG"
      ],
      "correct": 2,
      "explanation": "Bello led NPC"
    },
    {
      "question": "Independence year?",
      "options": [
        "1970",
        "1960",
        "1956",
        "1963"
      ],
      "correct": 1,
      "explanation": "Independence was 1960"
    },
    {
      "question": "First PM?",
      "options": [
        "Bello",
        "Balewa",
        "Azikiwe",
        "Awolowo"
      ],
      "correct": 1,
      "explanation": "Balewa was first PM"
    },
    {
      "question": "First President?",
      "options": [
        "Balewa",
        "Gowon",
        "Azikiwe",
        "Obasanjo"
      ],
      "correct": 2,
      "explanation": "Azikiwe was first President"
    },
    {
      "question": "Republic year?",
      "options": [
        "1963",
        "1979",
        "1966",
        "1960"
      ],
      "correct": 0,
      "explanation": "Republic was 1963"
    },
    {
      "question": "First coup year?",
      "options": [
        "1966",
        "1975",
        "1960",
        "1963"
      ],
      "correct": 0,
      "explanation": "First coup was 1966"
    },
    {
      "question": "Civil War years?",
      "options": [
        "1966-1967",
        "1967-1970",
        "1970-1975",
        "1960-1963"
      ],
      "correct": 1,
      "explanation": "Civil War was 1967-1970"
    },
    {
      "question": "Biafra leader?",
      "options": [
        "Ojukwu",
        "Gowon",
        "Murtala",
        "Obasanjo"
      ],
      "correct": 0,
      "explanation": "Ojukwu led Biafra"
    },
    {
      "question": "Gowon states?",
      "options": [
        "12",
        "36",
        "3",
        "19"
      ],
      "correct": 0,
      "explanation": "Gowon created 12 states"
    },
    {
      "question": "Murtala states?",
      "options": [
        "19",
        "12",
        "36",
        "3"
      ],
      "correct": 0,
      "explanation": "Murtala created 19 states"
    },
    {
      "question": "1979 system?",
      "options": [
        "Parliamentary",
        "Confederal",
        "Presidential",
        "Military"
      ],
      "correct": 2,
      "explanation": "1979 brought presidential system"
    },
    {
      "question": "Shagari was?",
      "options": [
        "Senate President",
        "Military Head",
        "Prime Minister",
        "First Executive President"
      ],
      "correct": 3,
      "explanation": "Shagari was first Executive President"
    },
    {
      "question": "Buhari first coup?",
      "options": [
        "1979",
        "1983",
        "1985",
        "1993"
      ],
      "correct": 1,
      "explanation": "Buhari coup was 1983"
    },
    {
      "question": "Babangida years?",
      "options": [
        "1985-1993",
        "1993-1998",
        "1983-1985",
        "1998-1999"
      ],
      "correct": 0,
      "explanation": "Babangida ruled 1985-1993"
    },
    {
      "question": "June 12 year?",
      "options": [
        "1999",
        "1983",
        "1993",
        "2003"
      ],
      "correct": 2,
      "explanation": "June 12 was 1993"
    },
    {
      "question": "Abacha ended?",
      "options": [
        "1993",
        "1999",
        "1998",
        "2003"
      ],
      "correct": 2,
      "explanation": "Abacha ended 1998"
    },
    {
      "question": "Democracy back?",
      "options": [
        "1983",
        "1999",
        "1979",
        "1993"
      ],
      "correct": 1,
      "explanation": "Democracy returned 1999"
    }
  ]
};

// Field mapping for signup
const fieldSubjects = {
  science: allSubjects.filter(s => s.field === 'science' || s.field === 'all'),
  commercial: allSubjects.filter(s => s.field === 'commercial' || s.field === 'all'),
  arts: allSubjects.filter(s => s.field === 'arts' || s.field === 'all'),
  all: allSubjects
};

function getSubjectsForField(field) {
  return fieldSubjects[field] || allSubjects;
}

function shuffleArray(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}


// Compatibility for Oct 11 app (do not remove)
const jambSubjects = (typeof allSubjects !== 'undefined' ? allSubjects : []).map(s => ({ id: s.id, name: s.name, icon: s.icon }));
const level100Courses = [
  { id: 'eng', name: 'Use of English (GST)', icon: '📘' },
  { id: 'mth', name: 'Mathematics 101', icon: '🔢' },
  { id: 'phy', name: 'Physics 101', icon: '⚛️' },
  { id: 'chm', name: 'Chemistry 101', icon: '🧪' },
  { id: 'bio', name: 'Biology 101', icon: '🧬' },
  { id: 'gov', name: 'Government 101', icon: '🏛️' },
  { id: 'eco', name: 'Economics 101', icon: '📈' },
];
