const SUPABASE_URL = 'https://stwkrnpeocihmjhhrekb.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_K5eWSkUEH31fE5DlyMHrRA_8r089IC3';
const PAYSTACK_PUBLIC_KEY = 'pk_live_49822843a0842f4555b089e4045fadd9b0de8291';

(function() {
  function init() {
    if (typeof supabase !== 'undefined' && supabase.createClient) {
      window.supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
    } else {
      setTimeout(init, 40);
    }
  }
  init();
})();
